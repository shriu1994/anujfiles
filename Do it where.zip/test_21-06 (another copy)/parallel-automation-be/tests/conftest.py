"""A module to handle the additional parameters with pytest command.
"""
import datetime
import functools
import json
import os
import time
from logger.html_logger import create_log_from_json
# from logger.html_logger import delete_logs
import pytest
from siemplify_utils import siemplify
# Source utils
from source.config import NO_CLEANUP
from source.utils import delete_created_items_for_test
from source.utils import restore_required_items_for_test
import urllib3


global_tags = []
global_options = []
all_tests = {}
no_log = False
no_reset = False

LOG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "log.json"
)
TESTS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests.json"
)
LOGS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
)


def pytest_addoption(parser):
  """Pytest function to store the tag names.
  """
  parser.addoption("--tags", action="store")
  parser.addoption("--options", action="store")


@pytest.fixture(scope="session", autouse=True)
def save_tags(pytestconfig) -> list[str]:
  """Returns all tag names after --tags command.

  Args:
    pytestconfig: pytest inner variable
  Returns:
    A list of tags
  """
  received_tags = pytestconfig.getoption("tags")
  tags_list = received_tags.split(",")
  if received_tags:
    global global_tags
    global_tags = [tag.lower() for tag in tags_list]
    return global_tags


@pytest.fixture(scope="session", autouse=True)
def save_options(pytestconfig) -> list[str]:
  """Returns all options after --options command.

  Args:
    pytestconfig: pytest inner variable
  Returns:
    A list of options
  """
  received_options = pytestconfig.getoption("options")
  if received_options:
    options_list = received_options.split(",")
    global global_options
    global_options = [option for option in options_list]
    return global_options


def pytest_collection_modifyitems(items, config):
  """Changes the way pytest collects tests.

  Args:
    items: test names that were collected
    config: pytest config object
  """
  selected = []
  deselected = []
  received_tags = config.getoption("tags")
  received_options = config.getoption("options")
  global global_options
  global_options = received_options
  global global_tags
  global_tags = received_tags
  # Do not delete the log if NOLOG is in the options
  if not global_options or "NOLOGDELETE" not in global_options:
    #delete_logs()
    start_time = datetime.datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
    dummy_data = json.dumps({
        "first": False,
        "active": True,
        "start": start_time,
        "end": "",
        "tags": global_tags,
        "stats": {"total": 0, "success": 0, "failure": 0, "skipped": 0},
    })
    with open(LOG_PATH, "w") as f:
      f.write(dummy_data)
  if not received_tags:
    all_tags = []
  else:
    all_tags = received_tags.split(",")
  for item in items:
    text_item = (str(item).lower())
    list_item = text_item.split()[1]
    new_item = list_item.replace(">", "")
    if new_item in all_tests.keys():
      if not any(item in all_tags for item in all_tests[new_item]):
        deselected.append(item)
      else:
        selected.append(item)
  config.hook.pytest_deselected(items=deselected)
  items[:] = selected


def prepare_environment_for_test(name: str) -> bool:
  """Creates an isolated environment for the test.

  Args:
    name: name of the test
  Returns:
    True
  """
  password = "Password1!"
  permission = siemplify.users.create_custom_permission_group(
      name=name,
      playbooks_permission=True,
      playbooks_editing_playbooks=True,
      playbooks_managing_folders=True,
      marketplace_permisson=True,
      marketplace_allow_marketplace_actions=True,
      jobs_permission=True,
      jobs_editing_jobs=True,
      settings_permission=True,
      settings_editing_settings=True,
      settings_editing_self_branding=True,
      settings_editing_environments=True,
      settings_editing_agents=True,
      views_permission=True,
      connectors_permission=True,
      connectors_editing_connectors=True,
      webhooks_permission=True,
      webhooks_editing_webhooks=True,
      dashboards_permission=True,
      dashboards_editing_dashboards=True,
      search_permission=True,
      search_view_case_search=True,
      search_actions=True,
      cases_permission=True,
      cases_case_management_actions=True,
      cases_case_playbooks_tab=True,
      cases_attach_playbooks=True,
      cases_respond_to_actions=True,
      cases_rerun_playbooks=True,
      cases_case_wall=True,
      cases_adding_comments=True,
      cases_pinning_chat_messages=True,
      cases_case_simulation=True,
      cases_ingest_alerts=True,
      cases_manual_actions=True,
      cases_creating_manual_cases=True,
      cases_responding_to_case_actions=True,
      cases_case_chat=True,
      cases_adding_entity_properties=True,
      entity_explorer_permission=True,
      entity_explorer_adding_entity_comments=True,
      entity_explorer_editing_entity_properties=True,
      homepage_permission=True,
      homepage_my_tasks=True,
      homepage_create_tasks=True,
      homepage_announcements=True,
      homepage_create_announcements=True,
      homepage_requests=True,
      homepage_pending_actions=True,
      homepage_workspace=True,
      investigation_permission=True,
      investigation_manual_actions=True,
      investigation_editing_enities=True,
      reports_permission=True,
      reports_editing_reports=True,
      reports_advanced_reports=True,
      reports_editing_advanced_reports=True,
      ontology_permission=True,
      ontology_event_configuration=True,
      ide_permission=True,
      command_center_permission=True,
      all_environments_permission=False,
      sla_permission=True,
      sla_pause_sla=True,
      remote_agents_permission=True,
      generate_user_auth_permission=True,
  )
  permission_group_id = permission.id
  siemplify.environments.create_custom_environment(
      name=name,
      description=name,
      contact_name=name,
      contact_email=f"{name}@test.com",
  )
  siemplify.users.create_custom_user(
      first_name=name,
      email=f"{name}@siemplify.co",
      environments=[name],
      permission_group=name,
  )
  siemplify.authentication.authenticate_first_time_for_test(
      username=f"{name}@siemplify.co",
      password=password,
      test_name=name,
      permission_group_id=permission_group_id,
  )
  return True


def prepare_for_tests() -> bool:
  """Prepares settings for tests once before all the tests.

  Returns:
    True
  """
  print("PREPARING FOR TESTS")
  urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
  siemplify.authentication.authenticate()
  time.sleep(2)
  siemplify.cases.close_all_cases()
  siemplify.settings.change_email_verification_sequence_only(enabled=False)
  siemplify.settings.edit_alert_grouping_sequence_only(max_alerts="20")
  # Cleanup before the tests
  siemplify.jobs.delete_all_custom_jobs()
  siemplify.users.delete_all_extra_users()
  siemplify.users.delete_all_extra_roles()
  siemplify.environments.delete_all_custom_environments()
  siemplify.users.delete_all_custom_permission_groups()
  siemplify.networks.delete_all_networks()
  siemplify.domains.delete_all_domains()
  siemplify.custom_lists.remove_all_custom_lists()
  siemplify.sla.delete_all_sla_definitions()
  siemplify.playbooks.delete_all_custom_folders()
  siemplify.integrations.delete_all_custom_integrations()
  siemplify.integrations.delete_all_optional_instances_in_environment(
      environment="Default Environment"
  )
  siemplify.external_auth_settings.delete_all_external_auth_settings()
  siemplify.webhooks.delete_all_webhooks()
  time.sleep(1)
  return True


def finish_after_tests() -> bool:
  """Resets the settings for tests once after all the tests.

  Returns:
    True
  """
  time.sleep(1)
  if global_options and "NO_CLEANUP" in global_options or NO_CLEANUP:
    print("\nSKIPPING FINAL CLEANUP")
  else:
    print("\nPERFORMING FINAL CLEANUP")
    siemplify.authentication.authenticate()
    siemplify.settings.change_email_verification_sequence_only(enabled=False)
    siemplify.settings.edit_alert_grouping_sequence_only(max_alerts="20")
    siemplify.networks.delete_all_networks()
    siemplify.webhooks.delete_all_webhooks()
    siemplify.domains.delete_all_domains()

  # End the JSON log
  end_time = datetime.datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
  with open(LOG_PATH, "r") as f:
    data = json.load(f)
    data["end"] = end_time
    data["tags"] = global_tags
    json_data = json.dumps(data)
  with open(LOG_PATH, "w") as f:
    f.write(json_data)
  create_log_from_json()
  return True


def pytest_sessionfinish(session):
  finish_after_tests()
  if not hasattr(session.config, "workerinput"):
    pass


def pytest_sessionstart(session):
  prepare_for_tests()
  if not hasattr(session.config, "workerinput"):
    pass


@pytest.fixture(scope="function", autouse=True)
def cleanup_after_test(request):
  """Deletes all test-specific data after the tests is finished.

  Args:
    request: the pytest request object

  Yields:
    yield is used by pytest to check when test is finished
  """
  yield
  testname = request.node.name
  siemplify.authentication.relog_for_test(test_name=testname)
  path = os.path.join(LOGS_PATH, f"{testname}.json")
  with open(path, "r") as f:
    data = json.load(f)
  username = data.get("username")
  environment = data.get("environment")
  permission_id = data.get("permission_group_id")

  if global_options and "NO_CLEANUP" in global_options or NO_CLEANUP:
    print(f"\nSKIPPING CLEANUP AFTER TEST {testname}")
  else:
    delete_created_items_for_test(test_name=testname)
    restore_required_items_for_test(test_name=testname)
    siemplify.users.delete_user(username=username)
    siemplify.environments.delete_environment(name=environment)
    siemplify.users.delete_permission_group(group_id=permission_id)
    siemplify.webhooks.delete_all_webhooks()


@pytest.fixture(scope="function", autouse=True)
def set_test_status(request):
  """Determines if test failed or not and logs it after it finished running.
  """
  test_name = request.node.name
  tests_failed_before_module = request.session.testsfailed
  yield
  tests_failed_during_module = (
      request.session.testsfailed - tests_failed_before_module
  )
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  end_time = datetime.datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
  # If it didn't check if it failed in pytest
  with open(path, "r") as f:
    data = json.load(f)
  if tests_failed_during_module == 0 and data["test_status"] is not False:
    data["test_status"] = True
    data["test_end"] = end_time
    json_test_log_data = json.dumps(data)
    with open(path, "w") as f:
      f.write(json_test_log_data)
  # And if it did mark test as failed
  else:
    data["test_status"] = False
    data["test_end"] = end_time
    json_test_log_data = json.dumps(data)
    with open(path, "w") as f:
      f.write(json_test_log_data)


def tags(tags_list: list[str]):
  """Wrapper to process tags.

  Runs a function if no tags or one of the needed tags was specified

  Args:
    tags_list: a list of tags, at least one of which is required
  Returns:
    A wrapped function
  """

  def tags_wrapper(func):
    lower_tags = [tag.lower() for tag in tags_list]
    if not set(lower_tags).intersection(set(global_tags)):
      text_test = (str(func).lower())
      list_item = text_test.split()[1]
      if "." in list_item:
        temp_item = list_item.split(".")[1]
        list_item = temp_item
      all_tests[list_item] = tags_list
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
      test_name = func.__name__
      prepare_environment_for_test(name=test_name)
      value = func(*args, **kwargs)
      path = os.path.join(LOGS_PATH, f"{test_name}.json")
      with open(path, "r") as file:
        data = json.load(file)
      if data["test_status"] is False:
        pytest.fail(
            "Failed due to soft asserts (see test-report.html for info)"
        )
      return value
    return wrapper

  return tags_wrapper
