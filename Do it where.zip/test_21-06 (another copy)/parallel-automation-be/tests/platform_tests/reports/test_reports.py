"""Module for testing Siemplify reports module.
"""
from siemplify_utils import siemplify
from source.utils import soft_assert
from tests.conftest import tags


@tags(["REPORTS", "SEQUENCE"])
def test_ootb_reports():
  """Performs a "Test all OOTB reports" test.

  Steps:
  1) Create all OOTB reports
  2) Verify that they exist and are not empty
  3) Delete all reports
  """
  # Generate all reports
  siemplify.reports.create_soc_status_report()
  siemplify.reports.create_stages_report()
  siemplify.reports.create_c_level_report()
  siemplify.reports.create_open_cases_report()
  siemplify.reports.create_analysts_benchmark_report()
  siemplify.reports.create_closed_cases_report()
  siemplify.reports.create_overall_status_report()
  # Verify them
  soc_status = siemplify.reports.check_if_report_exists(
      file_name="soc_status_report"
  )
  soft_assert(
      is_true=soc_status,
      success_message="Soc Status report found",
      failure_message="Soc Status report doesn't exist or is empty",
  )
  stages_status = siemplify.reports.check_if_report_exists(
      file_name="stages_report"
  )
  soft_assert(
      is_true=stages_status,
      success_message="Stages report found",
      failure_message="Stages report doesn't exist or is empty",
  )
  c_level_status = siemplify.reports.check_if_report_exists(
      file_name="c_level_report"
  )
  soft_assert(
      is_true=c_level_status,
      success_message="C level report found",
      failure_message="C level report doesn't exist or is empty",
  )
  open_cases_status = siemplify.reports.check_if_report_exists(
      file_name="open_cases_report"
  )
  soft_assert(
      is_true=open_cases_status,
      success_message="Open Cases report found",
      failure_message="Open Cases report doesn't exist or is empty",
  )
  analysts_status = siemplify.reports.check_if_report_exists(
      file_name="analysts_benchmark_report"
  )
  soft_assert(
      is_true=analysts_status,
      success_message="Analysts Benchmark report found",
      failure_message="Analysts Benchmark report doesn't exist or is empty",
  )
  closed_cases_status = siemplify.reports.check_if_report_exists(
      file_name="closed_cases_report"
  )
  soft_assert(
      is_true=closed_cases_status,
      success_message="Closed Cases report found",
      failure_message="Closed Cases report doesn't exist or is empty",
  )
  overall_status = siemplify.reports.check_if_report_exists(
      file_name="overall_status_report"
  )
  soft_assert(
      is_true=overall_status,
      success_message="Overall Status report found",
      failure_message="Overall Status report doesn't exist or is empty",
  )
