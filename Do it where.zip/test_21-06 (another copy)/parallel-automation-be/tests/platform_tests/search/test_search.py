"""Module for testing Siemplify search module.
"""
from siemplify_utils import siemplify
from source import enums
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags


@tags(["SEARCH", "PARALLEL"])
def test_search_case_filters():
  """Performs a "Search cases" test.

  Steps:
  1) Simulate cases
  2) search cases by using all 13 filters
  3) Verify that case search works by the selected filters

  """
  siemplify.cases.simulate_cases_for_test()
  siemplify.cases.close_cases_for_test()
  siemplify.cases.simulate_cases_for_test()
  last_case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.add_tag(tag="AutomationBE", case_id=last_case_id)
  siemplify.cases.change_priority(case_id=last_case_id)
  siemplify.cases.raise_incident(case_id=last_case_id)
  search_closed = siemplify.search.search_cases_for_test(is_closed=True)
  search_open = siemplify.search.search_cases_for_test(is_closed=False)
  search_by_env = siemplify.search.search_cases_for_test(
      environments=["test_search_case_filters"]
  )
  search_by_tag = siemplify.search.search_cases_for_test(tags=["AutomationBE"])
  search_by_user = siemplify.search.search_cases_for_test(
      assigned_users=["@Tier1"]
  )
  search_by_allow_catergory = siemplify.search.search_cases_for_test(
      category_outcomes=["Allowed"]
  )
  search_by_block_catergory = siemplify.search.search_cases_for_test(
      category_outcomes=["Blocked"]
  )
  search_by_port = siemplify.search.search_cases_for_test(ports=["770"])
  search_by_product = siemplify.search.search_cases_for_test(
      products=["DLP_Product"]
  )
  search_by_source = siemplify.search.search_cases_for_test(
      case_source=["System"]
  )
  search_by_stage_triage = siemplify.search.search_cases_for_test(
      stage=["Triage"]
  )
  search_by_stage_incident = siemplify.search.search_cases_for_test(
      stage=["Incident"]
  )
  search_by_alert = siemplify.search.search_cases_for_test(
      rule_generator=["Data Exfiltration"]
  )
  search_by_priority_high = siemplify.search.search_cases_for_test(
      priorities=["High"]
  )
  search_by_priority_critical = siemplify.search.search_cases_for_test(
      priorities=["Critical"]
  )
  search_by_importance_true = siemplify.search.search_cases_for_test(
      importance=["True"]
  )
  search_by_importance_false = siemplify.search.search_cases_for_test(
      importance=["False"]
  )
  search_incident_true = siemplify.search.search_cases_for_test(
      is_incident=["True"]
  )
  search_incident_false = siemplify.search.search_cases_for_test(
      is_incident=["False"]
  )
  closed_cases = siemplify.utils.find_key_in_json(
      json_data=search_closed,
      key="results",
  )
  open_cases = siemplify.utils.find_key_in_json(
      json_data=search_open,
      key="totalCount",
  )
  env_cases = siemplify.utils.find_key_in_json(
      json_data=search_by_env,
      key="results"
  )
  tag_case = siemplify.utils.find_key_in_json(
      json_data=search_by_tag,
      key="results"
  )
  user_cases = siemplify.utils.find_key_in_json(
      json_data=search_by_user,
      key="results"
  )
  allow_category = siemplify.utils.find_key_in_json(
      json_data=search_by_allow_catergory,
      key="results",
  )
  blocked_category = siemplify.utils.find_key_in_json(
      json_data=search_by_block_catergory,
      key="results",
  )
  ports = siemplify.utils.find_key_in_json(
      json_data=search_by_port,
      key="results"
  )
  products = siemplify.utils.find_key_in_json(
      json_data=search_by_product,
      key="results"
  )
  case_source = siemplify.utils.find_key_in_json(
      json_data=search_by_source,
      key="results"
  )
  stage_triage = siemplify.utils.find_key_in_json(
      json_data=search_by_stage_triage,
      key="results"
  )
  stage_incident = siemplify.utils.find_key_in_json(
      json_data=search_by_stage_incident,
      key="results"
  )
  alert_type = siemplify.utils.find_key_in_json(
      json_data=search_by_alert,
      key="results"
  )
  priortiy_high = siemplify.utils.find_key_in_json(
      json_data=search_by_priority_high,
      key="results"
  )
  priortiy_critical = siemplify.utils.find_key_in_json(
      json_data=search_by_priority_critical,
      key="results"
  )
  true_impotance = siemplify.utils.find_key_in_json(
      json_data=search_by_importance_true,
      key="results"
  )
  false_impotance = siemplify.utils.find_key_in_json(
      json_data=search_by_importance_false,
      key="results"
  )
  true_incident = siemplify.utils.find_key_in_json(
      json_data=search_incident_true,
      key="results"
  )
  false_incident = siemplify.utils.find_key_in_json(
      json_data=search_incident_false,
      key="results"
  )

  soft_assert(
      compare=open_cases,
      to=7,
      success_message=f"Found: {open_cases} open cases succesfully in search",
      failure_message="Didnt find any open cases",
      extra_info=open_cases,
  )
  soft_assert(
      compare=closed_cases[0]["isCaseClosed"],
      to=True,
      success_message="Found closed cases in Search",
      failure_message="Didnt find any closed cases in Search",
      extra_info=closed_cases,
  )
  soft_assert(
      compare=env_cases[0]["environment"],
      to="test_search_case_filters",
      success_message="Found cases in Test Environment",
      failure_message="Didnt find any cases in Test Environment",
      extra_info=env_cases,
  )
  soft_assert(
      compare=tag_case[0]["tags"][0],
      to="AutomationBE",
      success_message=f"Found tags: {tag_case[0]['tags'][0]} ",
      failure_message="Didnt find any tags ",
      extra_info=tag_case,
  )
  soft_assert(
      compare=user_cases[0]["userAssigned"],
      to="@Tier1",
      success_message=f"Found Assigned users: {user_cases[0]['userAssigned']}",
      failure_message="Didnt find any Assigned users",
      extra_info=user_cases,
  )
  soft_assert(
      compare=allow_category[0]["outcomes"][0],
      to="allowed",
      success_message="Found allowed outcomes",
      failure_message="Didnt find any allowed outcomes",
      extra_info=allow_category,
  )
  soft_assert(
      compare=blocked_category[0]["outcomes"][0],
      to="blocked",
      success_message="Found blocked outcomes",
      failure_message="Didnt find any blocked outcomes",
      extra_info=blocked_category,
  )
  soft_assert(
      compare=ports[0]["ports"][0],
      to="770",
      success_message=f"Found port: {ports[0]['ports'][0]}",
      failure_message="Didnt find any port",
      extra_info=ports,
  )
  soft_assert(
      is_true= "DLP_Product" in products[0]["products"],
      success_message=f"Found product: {products[0]['products'][0]}",
      failure_message="Didnt find any product",
      extra_info=products,
  )
  soft_assert(
      is_true=len(case_source) > 0,
      success_message="Found case source",
      failure_message="Didnt find any case source",
      extra_info=case_source,
  )
  soft_assert(
      compare=stage_triage[0]["stage"],
      to="Triage",
      success_message=f"Found cases with stage: {stage_triage[0]['stage']}",
      failure_message="Didnt find any cases with triage stage",
      extra_info=stage_triage,
  )
  soft_assert(
      compare=stage_incident[0]["stage"],
      to="Incident",
      success_message=f"Found cases with stage: {stage_incident[0]['stage']}",
      failure_message="Didnt find any cases with Incident stage",
      extra_info=stage_incident,
  )
  soft_assert(
      compare=alert_type[0]["title"],
      to="Data Exfiltration",
      success_message=f"Found cases with alert type: {alert_type[0]['title']}",
      failure_message="Didnt find any cases with alert type Data Exfiltration",
      extra_info=alert_type,
  )
  soft_assert(
      compare=priortiy_high[0]["priority"],
      to=80,
      success_message=(
          "Found cases with high priority, "
          f"priority number: {priortiy_high[0]['priority']}"
      ),
      failure_message="Didnt find any cases with high priority",
      extra_info=priortiy_high,
  )
  soft_assert(
      compare=priortiy_critical[0]["priority"],
      to=100,
      success_message=(
          "Found cases with critical priority, "
          f"priority number: {priortiy_critical[0]['priority']}"
      ),
      failure_message="Didnt find any cases with critical priority",
      extra_info=priortiy_critical,
  )
  soft_assert(
      compare=true_impotance[0]["isImportant"],
      to=True,
      success_message="Found cases with is important equals to true",
      failure_message="Didnt find any cases with true importance",
      extra_info=true_impotance,
  )
  soft_assert(
      compare=false_impotance[0]["isImportant"],
      to=False,
      success_message="Found cases with false importance",
      failure_message="Didnt find any cases with false importance",
      extra_info=false_impotance,
  )
  soft_assert(
      compare=true_incident[0]["isIncident"],
      to=True,
      success_message="Found cases with true incident",
      failure_message="Didnt find any cases with true incident",
      extra_info=true_incident,
  )
  strong_assert(
      compare=false_incident[0]["isIncident"],
      to=False,
      success_message="Found cases with false incident",
      failure_message="Didnt find any cases with false incident",
      extra_info=false_incident,
  )


@tags(["SEARCH", "PARALLEL"])
def test_search_cases_for_test():
  """Performs a "Search cases" test.

  Steps:
  1) Simulate a case
  2) Search for open cases
  3) Verify that case is in the search
  4) Close case
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  search = siemplify.search.search_cases_for_test(is_closed=False)
  case_id = siemplify.cases.get_last_case_id_for_test()
  results = siemplify.utils.find_key_in_json(
      json_data=search,
      key="results",
  )
  check_id = siemplify.utils.find_key_in_json(
      json_data=results,
      key="id",
  )
  strong_assert(
      compare=check_id,
      to=case_id,
      success_message=f"Case #{case_id} found in assigned cases",
      failure_message=f"Case #{case_id} not found in assigned cases",
      extra_info=check_id,
  )


@tags(["SEARCH", "PARALLEL"])
def test_search_phishing():
  """Performs a "Search for phishing case" test.

  Steps:
  1) Simulate all OOTB cases
  2) Fetches a cases queue
  3) Verify that case queue length is equal to the number of OOTB cases
  4) Searches for a case with "Phishing" in its name
  5) Verifies that search only has 1 result
  6) Closes all cases
  """
  required_count = 7
  siemplify.cases.simulate_cases_for_test()
  case_queue = siemplify.cases.get_cases_for_test()
  length = case_queue.total_count
  soft_assert(
      compare=case_queue.total_count,
      to=required_count,
      success_message=f"Cases queue is {length} items long",
      failure_message=(
          f"Cases queue is wrong length. Expected: 10. Received: {length}"
      ),
  )
  search = siemplify.search.search_cases_for_test(
      is_closed=False,
      title="Phishing"
  )
  sr = siemplify.utils.find_key_in_json(
      json_data=search,
      key="results",
  )
  strong_assert(
      compare=len(sr),
      to=1,
      success_message=f"Cases search is {len(sr)} items long",
      failure_message=f"Cases search is wrong length: {len(sr)}",
  )

@tags(["SEARCH", "PARALLEL"])
def test_search_entities():
  """Performs a "Search entitites" test.

  Steps:
  1) Simulate a case
  2) Search for entities
  3) Verify that entities is in the search
  4) Close case
  """
  # Simulate a case
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  # Search all entities
  search = siemplify.search.search_entities_for_test()
  results = siemplify.utils.find_key_in_json(
      json_data=search,
      key="results",
  )
  total_count = siemplify.utils.find_key_in_json(
      json_data=search,
      key="totalCount",
  )
  strong_assert(
      is_true=results,
      success_message="There is search result",
      failure_message="There is no search result",
      extra_info=f"The total count for seearch result : {total_count}",
  )
  # Search all entities with specific input
  search = siemplify.search.search_entities_for_test(term="XWZ")
  results = siemplify.utils.find_key_in_json(
      json_data=search,
      key="results",
  )
  total_count = siemplify.utils.find_key_in_json(
      json_data=search,
      key="totalCount",
  )
  strong_assert(
      is_true=results,
      success_message="There is search result with input",
      failure_message="There is no search result with added input",
      extra_info=f"The total count for seearch result : {total_count}",
  )
