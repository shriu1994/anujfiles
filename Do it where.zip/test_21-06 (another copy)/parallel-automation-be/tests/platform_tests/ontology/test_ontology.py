"""Module for testing Siemplify integrations.
"""
from siemplify_utils import siemplify
from source import enums
from source.utils import strong_assert
from tests.conftest import tags


@tags(["ONTOLOGY", "BUG-286698376"])
def test_install_integration_with_ootb_where_no_record_exist():
  """Install integration with OOTB ontology where no other records exist.

  This test installs a wellknown integration from the market place
    and asserts against expected entry should be returned back by the
    ontology get status REST api.

  Steps:
  1) Install the 'Arcsight' integration from marketplace
  2) Call REST api to fetch ontology status
  3) Assert that the ontology status contains exactly one expected record
  """
  # Install integration under test from marketplace
  integration_name = "Arcsight"
  siemplify.integrations.install_integration(
      name=integration_name,
      version=0
  )
  # Query ontology status
  result = siemplify.ontology.get_ontology_status_records().json()
  actual_ontologies = list(filter(
      lambda x:
      x["source"] == integration_name and
      x["product"] is None and
      x["eventName"] is None and
      x["changeSource"] == 0,
      result["objectsList"]))
  actual_count = 0 if actual_ontologies is None else len(actual_ontologies)
  strong_assert(
      is_true=actual_count == 1,
      failure_message=(
          "Expected exactly one ontology entry by installing "
          f"'{integration_name}' interation but got {actual_count}"
      ),
  )


@tags(["ONTOLOGY", "SEQUENCE"])
def test_simulate_case_with_ontology_mappings():
  """Simulate a case which adds ontology mappings.

  This test simulates a case which adds ontology mappings
    and asserts against expected entry should be returned back by the
    ontology get status REST api.

  Steps:
  1) Simulate a case to have ontology mappings
  3) Call REST api to fetch ontology status
  4) Assert that the ontology status contains two records
  """
  # Simulate a case with ontology mappings
  case_name = "Data Exfiltration"
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  # Query ontology status
  result = siemplify.ontology.get_ontology_status_records().json()
  actual_ontologies = list(filter(lambda x:
                                  x["source"] == "Arcsight" and
                                  x["product"] == "DLP_Product" and
                                  x["eventName"] == "Data Exfiltration" and
                                  x["exampleEventFields"] is not None and 
                                  len(x["exampleEventFields"]) > 0 and
                                  x["changeSource"] == 1,
                                  result["objectsList"]))
  actual_count = 0 if actual_ontologies is None else len(actual_ontologies)
  strong_assert(
      is_true=actual_count != 0,
      failure_message=(
          "Expected exactly one ontology entry by simulating "
          f"'{case_name}' case but got zero"
      ),
  )
  strong_assert(
      is_true=actual_count == 1,
      failure_message=(
          f"Expected exactly one ontology entry by simulating "
          f"'{case_name}' case but got many"
      ),
  )

@tags(["ONTOLOGY", "SEQUENCE"])
def test_create_delete_visual_family():
  """Simulate a case which create and delete Visual Family.

  Steps:
  1) Create Visual Family
  2) Fetch Visual Family details
  3) Delete Visaul Family
  4) Check Visual Family Deleted
  """
  # Create Visual Family
  family_name="testing_purpose_04"
  result = siemplify.ontology.create_visual_family(
    family_name=family_name
  )
  strong_assert(
      is_true=result,
      failure_message=(
          f"created visual family"
          f"couldnot create"
      ),
  )
  # Fetches list of visual family and check if present
  response=siemplify.ontology.fetch_visual_families()
  all_vfamilies = response.json()
  check = siemplify.utils.find_key_value_in_json(
    json_data=all_vfamilies,
    key="family",
    value=family_name,
  )
  strong_assert(
    is_true=response,
    success_message="Visual Families succesfully fetched",
    failure_message="Failed to fetch Visual Families",
    extra_info=check
  )
  # Deltes the visual family using ID
  is_deleted=siemplify.ontology.delete_visual_families(
    family_id=check["id"]
  )
  strong_assert(
    is_true=is_deleted,
    success_message="Visual family deleted",
    failure_message="Failed to delete visual family"
  )
  # Fetches the list of Visual Families and check if deleted.
  response=siemplify.ontology.fetch_visual_families()
  all_vfamilies = response.json()
  check = siemplify.utils.find_key_value_in_json(
    json_data=all_vfamilies,
    key="family",
    value=family_name,
  )
  strong_assert(
    is_false=check,
    success_message="Visual Families succesfully fetched",
    failure_message="Failed to fetch Visual Families",
    extra_info=check
  )

@tags(["ONTOLOGY", "SEQUENCE"])
def test_edit_delete_system_visual_family():
  """Simulate a case which create and delete Visual Family.

  Steps:
  1) Fetch any system Visual Family details
  2) Edit Visaul Family
  3) Delete Visual Family
  """
  # Fetches list of visual family and check if present
  response=siemplify.ontology.fetch_visual_families()
  vfamilies = response.json()
  for vfamily in vfamilies:
    is_custom = siemplify.utils.find_key_in_json(
      json_data=vfamily,
      key="isCustom"
    )
    if not is_custom:
      custom_vf = vfamily
      break
  # Update Visual Family
  family_name=siemplify.utils.find_key_in_json(
    json_data=custom_vf,
    key="family"
  )
  family_id=siemplify.utils.find_key_in_json(
    json_data=custom_vf,
    key="id"
  )
  result = siemplify.ontology.update_visual_family(
    family_name=family_name,
    id=family_id,
    description="edited"
  )
  cant_str = "can't"
  strong_assert(
      compare=result.text,
      to=f'"You {cant_str} change system family"',
      success_message="Failed to update system family",
      failure_message="Updated visual family",
      extra_info=result.text
  )
  # Deltes the visual family using ID
  is_deleted=siemplify.ontology.delete_visual_families(
    family_id=family_id
  )
  strong_assert(
    compare=is_deleted.status_code,
    to=500,
    success_message="Visual family cannot be deleted",
    failure_message="Visual family deleted"
  )

@tags(["ONTOLOGY", "SEQUENCE"])
def test_all_system_visual_family():
  """Simulate a case which checks all system Visual Families.

  Steps:
  1) Fetch any system Visual Family details
  2) Verfiy all system faamilies
  """
  # Fetches list of visual family and check if present
  response=siemplify.ontology.fetch_visual_families()
  vfamilies = response.json()
  default_families = [
    "AV",
    "DAM",
    "DLP",
    "DNS",
    "DoSOrDDoS",
    "EDR",
    "NAC",
    "FAM",
    "FW",
    "Fraud",
    "Default",
    "IPS",
    "InsiderThreat",
    "Login",
    "MailRelayOrTAP",
    "Proxy",
    "ActiveDirectory",
    "WebOrWAF",
    "RACF",
    "OS"
  ]
  system_families = []
  for vfamily in vfamilies:
    is_custom = siemplify.utils.find_key_in_json(
      json_data=vfamily,
      key="isCustom"
    )
    if not is_custom:
      family_name=siemplify.utils.find_key_in_json(
        json_data=vfamily,
        key="family"
      )
      system_families.append(family_name)
  # Checks all system visual family by name
  all_present = True
  for family in default_families:
    if family not in system_families:
      all_present = False
      break
  strong_assert(
    is_true=all_present,
    success_message="All system families present",
    failure_message="All system families are not present",
    extra_info=system_families
  )