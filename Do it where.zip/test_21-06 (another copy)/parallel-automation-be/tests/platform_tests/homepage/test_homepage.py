"""Module for testing Siemplify HomePage module."""
from siemplify_utils import siemplify
from source import enums
from source.utils import get_random_string
from source.utils import strong_assert
from tests.conftest import tags


@tags(["HOMEPAGE", "SEQUENCE"])
def test_create_and_delete_announcement():
  """Validate "Create and Delete Annoucement" test.

  Steps:
  1) Create a Annoucement with title and feed.
  2) Validate that Announcement is displayed.
  3) Delete the created Annoucement.
  4) Validate that Announcement is deleted successfully.
  """

  validate_title = get_random_string(5)
  resp = siemplify.homepage.create_announcement(title=validate_title)
  strong_assert(
      compare=resp.title,
      to=validate_title,
      success_message=f"Correct Annoucement title received: {validate_title}",
      failure_message=(
          f"Wrong title received. Expected: {validate_title}, ",
          f"received: {resp.title}",
      ),
  )
  announcement_count = siemplify.homepage.get_announcement_count()
  strong_assert(
      compare=announcement_count.text,
      to="1",
      success_message=(
          "Number of Announcements present on the feed:"
          f" {announcement_count.text}"
      ),
      failure_message=(
          "Incorrect number of Announcements received. Expected: 1,",
          f"received: {announcement_count.text}",
      ),
  )
  delete_resp = siemplify.homepage.delete_announcement(resp.id)
  strong_assert(
      compare=delete_resp.status_code,
      to=204,
      success_message="Deletion of the Announcement successful",
      failure_message="Unable to Delete the Announcement",
  )
  announcement_count = siemplify.homepage.get_announcement_count()
  strong_assert(
      compare=announcement_count.text,
      to="0",
      success_message=(
          "Number of Announcements present on the feed:"
          f" {announcement_count.text}"
      ),
      failure_message=(
          "Incorrect number of Announcements received. Expected: 0,",
          f"received: {announcement_count.text}",
      ),
  )


@tags(["HOMEPAGE", "SEQUENCE"])
def test_create_and_delete_contacts():
  """Validate "Create and Delete Contacts" test.

  Steps:
  1) Create a Contact with contact name, phone number, Email and description.
  2) Update the contact with new name
  3) Validate that contact is displayed.
  4) Delete the created Contact.
  5) Validate that Contact is deleted successfully.
  """

  validate_title = get_random_string(5)
  validate_email = get_random_string(5) + "@gmail.com"
  resp = siemplify.homepage.create_contact(
    contact_name=validate_title,
    email=validate_email
  )
  strong_assert(
      compare=resp.contact_name,
      to=validate_title,
      success_message=f"Correct Contact Name received: {validate_title}",
      failure_message=(
          f"Wrong Contact Name received. Expected: {validate_title}, ",
          f"received: {resp.contact_name}",
      ),
  )
  update_title = get_random_string(5)
  update_contact = siemplify.homepage.update_contact(
      contact_name=update_title,
      id=resp.id
  )
  strong_assert(
      compare=update_contact.contact_name,
      to=update_title,
      success_message=f"Updated Contact Name received: {update_title}",
      failure_message=(
          f"Unable to update the contact. Expected: {update_title}, ",
          f"received: {update_contact.contact_name}",
      ),
  )
  contact_count = siemplify.homepage.get_contact_details()
  strong_assert(
      compare=contact_count.total_record_count,
      to=1,
      success_message=(
          "Number of Contacts present on the feed:"
          f" {contact_count.total_record_count}"
      ),
      failure_message=(
          "Incorrect number of contacts received. Expected: 1,",
          f"received: {contact_count.total_record_count}",
      ),
  )
  delete_resp = siemplify.homepage.delete_contact(resp.id)
  strong_assert(
      compare=delete_resp.status_code,
      to=204,
      success_message="Deletion of the Contact successful",
      failure_message="Unable to Delete the Contact",
  )
  contact_count = siemplify.homepage.get_contact_details()
  strong_assert(
      compare=contact_count.total_record_count,
      to=0,
      success_message=(
          "Number of Contacts present on the feed:"
          f" {contact_count.total_record_count}"
      ),
      failure_message=(
          "Incorrect number of contacts received. Expected: 0,",
          f"received: {contact_count.total_record_count}",
      ),
  )


@tags(["HOMEPAGE", "SEQUENCE"])
def test_create_contacts_with_same_details():
  """Validate "Create contact with same details will not be created" test.

  Steps:
  1) Create a Contact with contact name, phone number, Email and description.
  2) Create another contact with same details.
  3) Delete the contact.
  4) Validate that Contact is deleted successfully.
  """

  validate_title = get_random_string(5)
  validate_email = get_random_string(5) + "@gmail.com"
  resp = siemplify.homepage.create_contact(
    contact_name=validate_title,
    email = validate_email
  )
  strong_assert(
      compare=resp.contact_name,
      to=validate_title,
      success_message=f"Correct Contact Name received: {validate_title}",
      failure_message=(
          f"Wrong Contact Name received. Expected: {validate_title}, ",
          f"received: {resp.contact_name}",
      ),
  )
  contact_details = siemplify.homepage.create_contact_failed(
      contact_name=validate_title,
      email=validate_email
  )
  strong_assert(
      compare=contact_details.status_code,
      to=400,
      success_message="Unable to create contact with same details",
      failure_message="Able to Create the Contact",
  )
  delete_resp = siemplify.homepage.delete_contact(resp.id)
  strong_assert(
      compare=delete_resp.status_code,
      to=204,
      success_message="Deletion of the Contact successful",
      failure_message="Unable to Delete the Contact",
  )
  contact_count = siemplify.homepage.get_contact_details()
  strong_assert(
      compare=contact_count.total_record_count,
      to=0,
      success_message=(
          "Number of Contacts present on the feed:"
          f" {contact_count.total_record_count}"
      ),
      failure_message=(
          "Incorrect number of contacts received. Expected: 0,",
          f"received: {contact_count.total_record_count}",
      ),
  )


@tags(["HOMEPAGE", "SEQUENCE"])
def test_contact_email_and_phone_format():
  """Validate "Contact with invalid phone number and Email will not be created" test.

  Steps:
  1) Create a Contact with invalid phone number and invalid Email
  2) Validate that contact will ot be created
  """

  validate_title = get_random_string(5)
  invalid_phone_number = get_random_string(5)
  validate_email = get_random_string(5) + "@gmail.com"
  resp = siemplify.homepage.create_contact_failed(
      contact_name=validate_title,
      phone_number=invalid_phone_number,
      email=validate_email
  )
  strong_assert(
      compare=resp.status_code,
      to=400,
      success_message="Unable to create contact with incorrect phone number",
      failure_message="Able to Create the Contact with incorrect phone number",
  )
  contact_count = siemplify.homepage.get_contact_details()
  strong_assert(
      compare=contact_count.total_record_count,
      to=0,
      success_message=(
          "Number of Contacts present on the feed:"
          f" {contact_count.total_record_count}"
      ),
      failure_message=(
          "Incorrect number of Contacts received. Expected: 0,",
          f"received: {contact_count.total_record_count}",
      ),
  )
  invalid_email = "Testgmail.com"
  resp = siemplify.homepage.create_contact_failed(
      contact_name=validate_title,
      email=invalid_email
  )
  strong_assert(
      compare=resp.status_code,
      to=400,
      success_message="Unable to create contact with invalid Email ",
      failure_message="Able to Create the Contact with invalied Email",
  )
  contact_count = siemplify.homepage.get_contact_details()
  strong_assert(
      compare=contact_count.total_record_count,
      to=0,
      success_message=(
          "Number of Contacts present on the feed:"
          f" {contact_count.total_record_count}"
      ),
      failure_message=(
          "Incorrect number of Contacts received. Expected: 0,",
          f"received: {contact_count.total_record_count}",
      ),
  )


@tags(["HOMEPAGE", "SEQUENCE"])
def test_update_contact_with_invalid_email():
  """Validate "Update Contact with Invalid Email" test.

  Steps:
  1) Create a Contact with contact name, phone number, Email and description.
  2) Update the contact with invalid Email
  3) Validate that contact will not be updated
  4) Delete the created Contact.
  5) Validate that Contact is deleted successfully.
  """

  validate_title = get_random_string(5)
  validate_email = get_random_string(5) + "@gmail.com"
  resp = siemplify.homepage.create_contact(
    contact_name=validate_title,
    email=validate_email
  )
  strong_assert(
      compare=resp.contact_name,
      to=validate_title,
      success_message=f"Correct Contact Name received: {validate_title}",
      failure_message=(
          f"Wrong Contact Name received. Expected: {validate_title}, ",
          f"received: {resp.contact_name}",
      ),
  )
  invalid_email = "Testgmail.com"
  update_contact = siemplify.homepage.update_contact_failed(
      contact_name=validate_title,
      email=invalid_email,
      id=resp.id
  )
  strong_assert(
      compare=update_contact.status_code,
      to=400,
      success_message="Unable to create contact with invalid Email ",
      failure_message="Able to Create the Contact with invalid Email",
  )
  delete_resp = siemplify.homepage.delete_contact(resp.id)
  strong_assert(
      compare=delete_resp.status_code,
      to=204,
      success_message="Deletion of the Contact successful",
      failure_message="Unable to Delete the Contact",
  )
  contact_count = siemplify.homepage.get_contact_details()
  strong_assert(
      compare=contact_count.total_record_count,
      to=0,
      success_message=(
          "Number of Contacts present on the feed:"
          f" {contact_count.total_record_count}"
      ),
      failure_message=(
          "Incorrect number of Contacts received. Expected: 0,",
          f"received: {contact_count.total_record_count}",
      ),
  )