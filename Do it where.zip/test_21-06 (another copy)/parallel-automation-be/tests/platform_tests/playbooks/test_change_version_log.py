"""Module for testing Siemplify playbooks version logs module."""

from siemplify_utils import siemplify
from source import enums
from source.utils import strong_assert
from tests.conftest import tags


@tags(["PLAYBOOKS", "PARALLEL"])
def test_create_multiple_playbook_log_version():
  """Performs a "Create a playbook log versions" test.

  Steps:
  1) Create a playbook
  2) Verify playbook created successfully
  3) Create 2 log versions for this playbook
  4) Get the log history of the playbook
  5) Verify the old playbook's log versions exist
  """
  comment_v1 = "Version1"
  comment_v2 = "Version2"
  playbook = siemplify.playbooks.create_playbook_for_test()

  saved_log_playbook = siemplify.playbooks.save_playbook_log_version(
      playbook_identifier=playbook.identifier, comment=comment_v1
  )
  strong_assert(
      is_true=saved_log_playbook.identifier != playbook.identifier,
      success_message="First version log playbook's identifier is different",
      failure_message=(
          "First version log playbook's identifier is the same as the old"
          " playbook"
      ),
  )
  saved_log_playbook_2 = siemplify.playbooks.save_playbook_log_version(
      playbook_identifier=saved_log_playbook.identifier, comment=comment_v2
  )
  strong_assert(
      is_true=saved_log_playbook_2.identifier != playbook.identifier,
      success_message="Second version log playbook's identifier is different",
      failure_message=(
          "Second version log playbook's identifier is the same as the old"
          " playbook"
      ),
  )

  playbook_log_version_response = siemplify.playbooks.get_playbook_log_versions(
      playbook_identifier=saved_log_playbook_2.identifier
  )
  first_log_version = siemplify.utils.find_key_value_in_json(
      json_data=playbook_log_version_response.json(),
      key="workFlowIdentifier",
      value=playbook.identifier,
  )
  strong_assert(
      compare=first_log_version["versionComment"],
      to=comment_v1,
      success_message="First playbook version received",
      failure_message="First playbook version did not received",
  )

  second_log_version = siemplify.utils.find_key_value_in_json(
      json_data=playbook_log_version_response.json(),
      key="workFlowIdentifier",
      value=saved_log_playbook.identifier,
  )
  strong_assert(
      compare=second_log_version["versionComment"],
      to=comment_v2,
      success_message="Second playbook version received",
      failure_message="Second playbook version did not received",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_create_version_to_playbook_then_update_block_step():
  """Performs a "Create a version of playbook with updated block step" test.

  Steps:
  1) Create a playbook with block
  2) Create a log version for this playbook
  3) Attach this playbook to an alert
  4) Update the block
  4) Get the log history of the playbook
  5) Verify the old playbook's log versions exist
  """
  block_trigger = siemplify.playbooks.create_block_trigger()
  comment_action = siemplify.payloads.playbook_actions.add_case_comment()
  nested_block = (
      siemplify.payloads.playbook_actions.create_nested_block_output_step()
  )
  create_block = siemplify.playbooks.create_playbook_for_test(
      trigger=block_trigger,
      playbook_type=1,
      actions=[comment_action, nested_block],
  )
  nested_block_step = (
      siemplify.payloads.playbook_actions.create_nested_block_step(
          nested_name=create_block.name,
          nested_workflow_id=create_block.identifier,
      )
  )
  playbook = siemplify.playbooks.create_playbook_for_test(
      actions=[nested_block_step],
      view_template=True,
  )
  saved_log_playbook = siemplify.playbooks.save_playbook_log_version(
      playbook_identifier=playbook.identifier
  )
  strong_assert(
      is_true=saved_log_playbook.identifier != playbook.identifier,
      success_message="version log playbook's identifier is different",
      failure_message=(
          "version log playbook's identifier is the same as the old playbook"
      ),
  )

  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  pb_name = playbook.name
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=pb_name,
  )

  block_new_name = siemplify.utils.generate_random_name()
  updated_block = siemplify.playbooks.update_playbook(
      playbook_identifier=create_block.identifier,
      playbook_name=block_new_name,
  )

  strong_assert(
      is_true=updated_block.identifier != create_block.identifier,
      success_message="Update block succeeded",
      failure_message="Failed to update the block",
  )
  updated_playbook = siemplify.utils.find_key_value_in_json(
      json_data=siemplify.playbooks.get_all_playbooks().json(),
      key="name",
      value=playbook.name,
  )
  playbook_log_version_response = siemplify.playbooks.get_playbook_log_versions(
      playbook_identifier=updated_playbook["identifier"]
  )
  playbook_log_version = siemplify.utils.find_key_value_in_json(
      json_data=playbook_log_version_response.json(),
      key="workFlowIdentifier",
      value=playbook.identifier,
  )

  strong_assert(
      is_true=playbook_log_version,
      success_message="Playbook's log version exist",
      failure_message="Playbook's log version does not exist",
  )
