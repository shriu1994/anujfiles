"""Module for testing Siemplify playbooks module.
"""
from decorators.decorators import integrations_required
from siemplify_utils import siemplify
from source import enums
from source.utils import get_random_string
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags


@tags(["PLAYBOOKS", "PARALLEL"])
def test_create_playbook_for_test():
  """Performs a "Create a playbook" test.

  Steps:
  1) Create a playbook
  2) Verify playbook is in playbook list
  3) Simulate a case
  4) Verify playbook is attached to the case
  """
  playbook = siemplify.playbooks.create_playbook_for_test()
  all_playbooks = siemplify.playbooks.get_all_playbooks()
  check = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks,
      key="id",
      value=playbook.id,
  )
  soft_assert(
      is_true=check,
      success_message=f"Playbook '{playbook.id}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  check_name = siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=playbook.name,
  )
  strong_assert(
      is_true=check_name,
      success_message=f"Playbook '{playbook.id}' attached to case",
      failure_message="Playbook failed to attach to a case",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_playbook_assigned_to_specific_environment():
  """Performs a test with a name listed below.

  "PB assigned to a specific environment runs only
  on cases from specific environment"

  Steps:
  1) Create an environment
  2) Simulate a case for new environment
  3) Simulate a case for default environment
  3) Verify playbook is ONLY attached to the cases from new environment
  4) Close the case
  5) Delete the playbook
  6) Delete new environment
  """
  new_env = siemplify.environments.create_environment_for_test()
  created_playbook = siemplify.playbooks.create_playbook_in_environments(
      environments=[new_env.name],
  )
  siemplify.cases.simulate_cases_in_environment(
      cases=[enums.DefaultCases.PHISHING_EMAIL],
      environment=new_env.name,
  )
  new_env_case_id = siemplify.cases.get_last_case_id_in_environments(
      environments=[new_env.name]
  )
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=new_env_case_id,
      playbook_name=created_playbook.name,
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  new_env_case_details = siemplify.cases.get_case_full_details(
      case_id=new_env_case_id
  )
  playbook_name = created_playbook.name
  attached_to_new_env_pb_name = siemplify.utils.find_key_value_in_json(
      json_data=new_env_case_details.wall_data,
      key="playbookName",
      value=created_playbook.name,
  )
  pb_name = siemplify.utils.find_key_in_json(
      json_data=new_env_case_details.wall_data,
      key="playbookName"
  )
  soft_assert(
      is_true=attached_to_new_env_pb_name,
      success_message=(
          f"Playbook match: '{pb_name}' = '{playbook_name}'"
      ),
      failure_message="Playbooks don't match",
      extra_info=attached_to_new_env_pb_name,
  )
  default_env_case_id = siemplify.cases.get_last_case_id_for_test()
  default_env_case_details = siemplify.cases.get_case_full_details(
      case_id=default_env_case_id
  )
  check_default_env = siemplify.utils.find_key_value_in_json(
      json_data=default_env_case_details.wall_data,
      key="playbookName",
      value=playbook_name,
  )
  strong_assert(
      is_false=check_default_env,
      success_message=(
          f"Case #{default_env_case_id} doesn't have playbook '{playbook_name}'"
      ),
      failure_message="Case has a playbook attached",
      extra_info=check_default_env,
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_deleted_playbook_not_attached_to_case():
  """Performs a test with a name listed below.

  "After playbook deletion, pb is no longer attached to new cases
  but remains in old before deletion"

  Steps:
  1) Create playbook
  2) Simulate a case
  3) Delete playbook
  4) Simulate case
  5) Playbook remains attached to old cases but is not attached
    to new one after deletion
  """
  created_playbook = siemplify.playbooks.create_playbook_for_test()
  playbook_name = created_playbook.name
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=created_playbook.name,
  )
  siemplify.playbooks.delete_playbook(playbook=created_playbook.identifier)
  cases_with_pb_details = siemplify.cases.get_last_case_full_details_for_test()
  cases_with_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_with_pb_details.wall_data,
      key="playbookName",
      value=created_playbook.name
  )
  pb_name = cases_with_playbook.get("playbookName")
  soft_assert(
      is_true=cases_with_playbook,
      success_message="Playbook matched",
      failure_message="Playbooks don't match",
      extra_info=f"'{pb_name}' = '{created_playbook.name}'",
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  cases_without_pb = siemplify.cases.get_last_case_full_details_for_test()
  cases_without_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_without_pb.wall_data,
      key="playbookName",
      value=created_playbook.name,
  )
  strong_assert(
      is_false=cases_without_playbook,
      success_message=(
          f"Case #{cases_without_pb.id} has playbook '{playbook_name}'"
      ),
      failure_message="Case doesn't have attached playbook",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_disabled_playbook_not_attached_to_case():
  """Performs a test with a name listed below.

  "After playbook disabling, pb is no longer attached to new cases
  but remains in old before deletion"

  Steps:
  1) Create playbook
  2) Simulate case
  3) Disable playbook
  3) Simulate case
  4) Playbook remains attached to old cases but is not attached
    to new one after deletion
  """
  created_playbook = siemplify.playbooks.create_playbook_for_test()
  playbook_name = created_playbook.name
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=created_playbook.name,
  )
  siemplify.playbooks.update_playbook(
      playbook_identifier=created_playbook.identifier,
      is_enabled=False,
  )
  cases_with_pb_details = siemplify.cases.get_last_case_full_details_for_test()
  cases_with_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_with_pb_details.wall_data,
      key="playbookName",
      value=created_playbook.name
  )
  name = cases_with_playbook.get("playbookName")
  soft_assert(
      is_true=cases_with_playbook,
      success_message=(
          f"Playbook match: '{name}' = '{created_playbook.name}'"
      ),
      failure_message="Playbooks don't match",
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  cases_without_pb = siemplify.cases.get_last_case_full_details_for_test()
  cases_without_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_without_pb.wall_data,
      key="playbookName",
      value=created_playbook.name,
  )
  strong_assert(
      is_false=cases_without_playbook,
      success_message=(
          f"Case #{cases_without_pb.id} doesn't have playbook '{playbook_name}'"
      ),
      failure_message="Case doesn't have attached playbook",
      extra_info=cases_without_playbook,
  )


@tags(["PLAYBOOKS", "SEQUENCE"])
def test_use_custom_action_in_playbook():
  """Performs a test with a name listed below.

  "Use custom actions in playbooks"

  Steps:
  1) Create custom action
  2) Verify the action is present in the IDE
  3) Create a playbook
  3) Add the created custom action to the playbook
  4) Verify the action appears in the playbook
  5) Delete the action from the playbook
  6) Verify the action is no longer in the playbook
  """
  item = siemplify.ide.add_custom_ide_item()
  action_data = siemplify.ide.get_ide_item_data_by_name(
      item_name=item.name,
      integration_name="Siemplify"
  )
  soft_assert(
      is_true=action_data.name,
      success_message="Custom action successfully found",
      failure_message="Custom action wasn't found"
  )
  action = siemplify.payloads.playbook_actions.custom_test_action()
  playbook = siemplify.playbooks.create_playbook_for_test(actions=[action])
  check_name = siemplify.utils.find_key_value_in_json(
      json_data=playbook.steps,
      key="name",
      value="Siemplify_Test"
  )
  soft_assert(
      is_true=check_name,
      success_message="Custom action successfully added to the playbook",
      failure_message="Custom action wasn't added to the playbook"
  )
  pb_with_deleted_action = siemplify.playbooks.delete_action_from_playbook(
      playbook_identifier=playbook.identifier,
      action_name="Siemplify_Test_1"
  )
  check_deletion = siemplify.utils.find_key_value_in_json(
      json_data=pb_with_deleted_action.steps,
      key="name",
      value="Test"
  )
  soft_assert(
      is_false=check_deletion,
      success_message="Custom action successfully deleted from the playbook",
      failure_message="Custom action wasn't deleted from the playbook"
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_duplicated_playbook():
  """Performs a "duplicated playbook" test.

  Steps:
  1) Create a playbook
  2) Verify playbook is in playbook list
  3) Create a duplicated playbook
  4) Verify duplicated playbook is in the list
  5) Verify playbook environment, priority and category
  6) Delete the playbook
  """
  playbook = siemplify.playbooks.create_playbook_for_test()
  duplicated_pb = siemplify.playbooks.duplicate_playbooks(
      playbook_identifiers=[playbook.identifier],
      environments=playbook.environments
  )
  pb_data = siemplify.playbooks.get_playbook_data(
      identifier=duplicated_pb.identifier
  )
  all_playbooks = siemplify.playbooks.get_all_playbooks()
  check = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks,
      key="id",
      value=playbook.id,
  )
  check_duplicated_pb = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks,
      key="id",
      value=duplicated_pb.id,
  )
  soft_assert(
      is_true=check,
      success_message=f"Playbook '{playbook.id}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  soft_assert(
      is_true=check_duplicated_pb,
      success_message=f"Playbook '{duplicated_pb.id}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  soft_assert(
      compare=duplicated_pb.name,
      to=pb_data.name,
      success_message=f"Playbook name is '{duplicated_pb.name}'",
      failure_message=f"""Playbook name: {duplicated_pb.name}
       is not 'Copy of New Playbook'""",
  )
  strong_assert(
      compare=playbook.environments,
      to=duplicated_pb.environments,
      success_message=f"""Playbook environment: {playbook.environments}
       is equal to duplicated PB environment: {duplicated_pb.environments}""",
      failure_message="Environment of duplicated playbook is different"
  )
  strong_assert(
      compare=playbook.priority,
      to=duplicated_pb.priority,
      success_message=f"""Playbook priority: {playbook.priority}
       is equal to duplicated PB priority: {duplicated_pb.priority}""",
      failure_message="priority of duplicated playbook is different"
  )
  strong_assert(
      compare=playbook.category_name,
      to=duplicated_pb.category_name,
      success_message=f"""Playbook category: {playbook.category_name}
       is equal to duplicated PB category: {duplicated_pb.category_name}""",
      failure_message="category folder of duplicated playbook is different"
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_duplicated_playbook_change_values():
  """Performs a "duplicated playbook value" test.

  Steps:
  1) Create a new environment
  2) Create a new folder in playbook
  1) Create a playbook
  2) Verify playbook is in playbook list
  3) Create a duplicated playbook
  4) Verify duplicated playbook is in the list
  5) Verify playbook environment, priority and category
  6) Delete the playbook
  """
  new_env = siemplify.environments.create_environment_for_test()
  playbook = siemplify.playbooks.create_playbook_for_test()
  new_folder = siemplify.playbooks.add_playbook_folder()
  duplicated_pb = siemplify.playbooks.duplicate_playbooks(
      playbook_identifiers=[playbook.identifier],
      environments=[new_env.name],
      category_id=new_folder.id,
      priority=1
  )
  pb_data = siemplify.playbooks.get_playbook_data(
      identifier=duplicated_pb.identifier
  )
  all_playbooks = siemplify.playbooks.get_all_playbooks()
  check = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks,
      key="id",
      value=playbook.id,
  )
  check_duplicated_pb = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks,
      key="id",
      value=duplicated_pb.id,
  )
  soft_assert(
      is_true=check,
      success_message=f"Playbook '{playbook.id}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  soft_assert(
      is_true=check_duplicated_pb,
      success_message=f"Playbook '{duplicated_pb.id}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  soft_assert(
      compare=duplicated_pb.name,
      to=pb_data.name,
      success_message=f"Playbook name is '{duplicated_pb.name}'",
      failure_message=f"""Playbook name: {duplicated_pb.name}
       is not 'Copy of New Playbook'""",
  )
  strong_assert(
      compare=duplicated_pb.environments,
      to=pb_data.environments,
      success_message=f"""Playbook environment: {duplicated_pb.environments}
       is equal to duplicated PB environment: {pb_data.environments}""",
      failure_message="Environment of duplicated playbook is different"
  )
  strong_assert(
      compare=duplicated_pb.priority,
      to=pb_data.priority,
      success_message=f"""Playbook priority: {playbook.priority}
       is equal to duplicated PB priority: {pb_data.priority}""",
      failure_message="priority of duplicated playbook is different"
  )
  strong_assert(
      compare=duplicated_pb.category_name,
      to=pb_data.category_name,
      success_message=f"""Playbook category: {playbook.category_name}
       is equal to duplicated PB category: {pb_data.category_name}""",
      failure_message="category folder of duplicated playbook is different"
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_disabled_playbooks():
  """Performs a test with a name listed below.

  "After playbook disabling, pb is no longer attached to new cases
  but remains in old before deletion"s

  Steps:
  1) Create playbook with prioriry 1
  2) Simulate case
  3) Disable playbook
  4) Create a playbook with priority 2
  5) Simulate case
  6) Playbook with priority 1 remains attached to old cases
  7) Playbook with priority 2 attached to the new simulated case

  """
  first_pb = siemplify.playbooks.create_playbook_for_test(priority=1)
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  cases_details = siemplify.cases.get_last_case_full_details_for_test()
  alert_group_identifier = (
      cases_details.alerts[0].additional_properties["alertGroupIdentifier"]
  )
  # check if pb succeded to run #status 2 = completed
  siemplify.playbooks.wait_for_playbook_status(
      case_id=cases_details.id,
      alert_id=alert_group_identifier,
      playbook_name=first_pb.name,
      status=2,
  )
  siemplify.playbooks.update_playbook(
      playbook_identifier=first_pb.identifier,
      is_enabled=False,
  )
  cases_with_pb_details = siemplify.cases.get_last_case_full_details_for_test()
  cases_with_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_with_pb_details.wall_data,
      key="playbookName",
      value=first_pb.name
  )
  pb_name1 = cases_with_playbook['playbookName']
  soft_assert(
      is_true=cases_with_playbook,
      success_message=(
          f"Playbook match: '{pb_name1}' = '{first_pb.name}'"
      ),
      failure_message="Playbooks don't match",
  )
  second_pb = siemplify.playbooks.create_playbook_for_test(priority=2)
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  cases_details = siemplify.cases.get_last_case_full_details_for_test()
  alert_group_identifier = (
      cases_details.alerts[0].additional_properties["alertGroupIdentifier"]
  )
  # check if pb succeded to run #status 2 = completed
  siemplify.playbooks.wait_for_playbook_status(
      case_id=cases_details.id,
      alert_id=alert_group_identifier,
      playbook_name=second_pb.name,
      status=2,
  )
  cases_details = siemplify.cases.get_last_case_full_details_for_test()
  cases_with_prioritized_pb = siemplify.utils.find_key_value_in_json(
      json_data=cases_details.wall_data,
      key="playbookName",
      value=second_pb.name
  )
  pb_name2 = cases_with_prioritized_pb['playbookName']
  soft_assert(
      is_true=cases_with_prioritized_pb,
      success_message=(
          f"Playbook match: '{pb_name2}' = '{second_pb.name}'"
      ),
      failure_message="Playbooks don't match",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_deleted_playbooks():
  """Performs a test with a name listed below.

  "After playbook deleted, pb is no longer attached to new cases
  but remains in old before deletion"s

  Steps:
  1) Create playbook with prioriry 1
  2) Simulate case
  3) Disable playbook
  4) Create a playbook with priority 2
  5) Simulate case
  6) Delete the playbook with priority 1
  7) Playbook with priority 1 remains attached to old cases
  8) Playbook with priority 2 attached to the new simulated case

  """
  first_pb = siemplify.playbooks.create_playbook_for_test(priority=1)
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  cases_details = siemplify.cases.get_last_case_full_details_for_test()
  alert_group_identifier = (
      cases_details.alerts[0].additional_properties["alertGroupIdentifier"]
  )
  # check if pb succeded to run #status 2 = completed
  siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_group_identifier,
      playbook_name=first_pb.name,
      status=2,
  )
  siemplify.playbooks.update_playbook(
      playbook_identifier=first_pb.identifier,
      is_enabled=False,
  )
  cases_with_pb_details = siemplify.cases.get_last_case_full_details_for_test()
  cases_with_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_with_pb_details.wall_data,
      key="playbookName",
      value=first_pb.name
  )
  pb_name = cases_with_playbook.get("playbookName")
  soft_assert(
      is_true=cases_with_playbook,
      success_message=(
          f"Playbook match: '{pb_name}' = '{first_pb.name}'"
      ),
      failure_message="Playbooks don't match",
  )
  siemplify.playbooks.delete_playbook(playbook=first_pb.identifier)
  second_pb = siemplify.playbooks.create_playbook_for_test(priority=2)
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  cases_details = siemplify.cases.get_last_case_full_details_for_test()
  alert_group_identifier = (
      cases_details.alerts[0].additional_properties["alertGroupIdentifier"]
  )
  # check if pb succeded to run #status 2 = completed
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=second_pb.name,
  )
  siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_group_identifier,
      playbook_name=second_pb.name,
      status=2,
  )
  cases_details = siemplify.cases.get_last_case_full_details_for_test()
  cases_with_prioritized_pb = siemplify.utils.find_key_value_in_json(
      json_data=cases_details.wall_data,
      key="playbookName",
      value=second_pb.name
  )
  pb_name2 = cases_with_prioritized_pb.get("playbookName")
  strong_assert(
      is_true=cases_with_prioritized_pb,
      success_message=(
          f"Playbook match: '{pb_name2}' = '{second_pb.name}'"
      ),
      failure_message="Playbooks don't match",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_exported_imported_pb():
  """Performs a exported and imported pb test.

  Steps:
  1) Create a new playbook
  2) Export the playbook
  3) Import the playbook back
  4) Edit the playbook
  5) Simulate a case
  6) Verify The imported playbook is saved under "imported" folder
  7) Verify The playbook is editable
  8) Verify The playbooks runs successfully on an alert
  9) Delete the playbook
  """

  imported_pb_name = get_random_string(5)
  playbook = siemplify.playbooks.create_playbook_for_test()
  siemplify.playbooks.update_playbook(
      playbook_identifier=playbook.identifier,
      is_enabled=False,
  )
  export_pb = siemplify.playbooks.export_playbook(
      playbook_identifiers=[playbook.identifier]
  )
  blob = export_pb.json()["blob"]
  file_name = export_pb.json()["fileName"]
  imported_pb = siemplify.playbooks.import_playbook(
      blob=blob,
      file_name=file_name,
  )
  pb_data = siemplify.playbooks.get_all_playbooks_for_test()
  imported_pb_data = siemplify.utils.find_key_value_in_json(
      json_data=pb_data.json(),
      key="categoryName",
      value="Imported Playbooks"
  )
  pb_id = imported_pb_data["identifier"]
  siemplify.playbooks.update_playbook(
      playbook_identifier=pb_id,
      is_enabled=True,
      playbook_name=imported_pb_name
  )
  pb_imported_data = siemplify.playbooks.get_all_playbooks_for_test()
  imported_pb = siemplify.utils.find_key_value_in_json(
      json_data=pb_imported_data.json(),
      key="name",
      value=imported_pb_name
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  strong_assert(
      compare=imported_pb_data["categoryName"],
      to="Imported Playbooks",
      success_message=f"""Playbook category has imported folder,
      name: {imported_pb_data['categoryName']}""",
      failure_message="category folder is not 'Imported Playbooks'"
  )
  strong_assert(
      compare=imported_pb["name"],
      to=imported_pb_name,
      success_message=f"""Playbook name after edit is:
       {imported_pb_data['name']}""",
      failure_message="playbook name is incorrect after edit"
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_group_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  # check if pb succeded to run #status 2 = completed
  pb_status = siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_group_identifier,
      playbook_name=imported_pb_name,
      status=2,
  )
  strong_assert(
      compare=pb_status,
      to=2,
      success_message=(
          f"Playbook finished running succesfully with status: {pb_status}"
      ),
      failure_message=(
          f"Playbook didnt finish succesfully, status: {pb_status}"
      ),
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_two_exported_imported_playbooks():
  """Performs an "Export and import playbooks" test.

  Steps:
  1) Create 2 new playbooks
  2) Export the playbooks
  3) Import the playbooks
  4) Verify The imported playbook is saved under "imported" folder
  5) Delete the playbook
  """

  playbook_1 = siemplify.playbooks.create_playbook_for_test()
  playbook_2 = siemplify.playbooks.create_playbook_for_test()
  export_pb_1 = siemplify.playbooks.export_playbook(
      playbook_identifiers=[playbook_1.identifier]
  )
  blob_1 = export_pb_1.json()["blob"]
  file_name_1 = export_pb_1.json()["fileName"]
  export_pb_2 = siemplify.playbooks.export_playbook(
      playbook_identifiers=[playbook_2.identifier]
  )
  blob_2 = export_pb_2.json()["blob"]
  file_name_2 = export_pb_2.json()["fileName"]
  siemplify.playbooks.import_playbook(
      blob=blob_1,
      file_name=file_name_1,
  )
  siemplify.playbooks.import_playbook(
      blob=blob_2,
      file_name=file_name_2,
  )
  pb_data = siemplify.playbooks.get_all_playbooks_for_test()
  imported_pb_data = siemplify.utils.find_key_value_in_json(
      json_data=pb_data.json(),
      key="categoryName",
      value="Imported Playbooks"
  )
  strong_assert(
      compare=imported_pb_data[0]["categoryName"],
      to="Imported Playbooks",
      success_message=f"""Playbook category has imported folder,
      name: {imported_pb_data[0]['categoryName']}""",
      failure_message="category folder is not 'Imported Playbooks'"
  )
  strong_assert(
      compare=len(imported_pb_data),
      to=2,
      success_message="Found 2 imported playbooks",
      failure_message="Didnt found any Imported Playbooks"
  )


@tags(["PLAYBOOKS", "SEQUENCE"])
@integrations_required(integrations=["CSV"])
def test_unsupported_steps_with_deleted_instance():
  """Performs a unsupported stesp with deletion of integration instance test.

  Steps:
  1) Install and configure commerical integraiton
  2) Create a pb with commerical action
  3) Disable the aciton in IDE
  4) Open the playbook in playbook page
  5) Attach the playbook to a case
  6) Validate the commerical action is faulted
  7) Validate the commerical step is failed on runnig alert
  """
  integration_id = siemplify.integrations.get_integration_id("CSV")
  create_instance = siemplify.integrations.create_integration_instance(
      integration_id=integration_id
  )
  csv_ping = siemplify.payloads.playbook_actions.add_csv_ping_action()
  playbook = siemplify.playbooks.create_playbook_for_test(actions=[csv_ping])
  action_data = siemplify.ide.get_ide_item_data_by_name(
      item_name="Ping",
      integration_name="CSV",
  )
  soft_assert(
      compare=action_data.name,
      to="Ping",
      success_message="CSV Ping action successfully found",
      failure_message="CSV ping action wasn't found"
  )
  siemplify.integrations.delete_integration_instance(
      integration_id=integration_id,
      instance_name=create_instance.json()["instanceName"],
      integration_name="CSV"
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_group_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  # check if pb succeded to run #status 3 = failed
  status = siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_group_identifier,
      playbook_name=playbook.name,
      status=3,
  )
  strong_assert(
      compare=status,
      to=3,
      success_message=(
          f"Playbook finished running with failed status: {status}"
      ),
      failure_message=(
          f"Playbook didnt finish with failed status, status: {status}"
      ),
  )
  pb_res = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_group_identifier,
  )
  def_id = pb_res.json()[0]["definitionIdentifier"]
  pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=case_id,
      alert_identifier=alert_group_identifier,
      definition_id=def_id)
  siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_group_identifier,
      playbook_name=playbook.name,
      status=3,
  )
  result_code = pb_res_summary.json()["faultedSteps"][0]["resultCode"]
  # check action status with result code, -7 = unsupported action
  strong_assert(
      compare=result_code,
      to=-7,
      success_message=(
          f"Playbook finished running with unsupported code: {result_code}"
      ),
      failure_message=(
          f"Playbook didn't finish with correct code: {result_code}"
      ),
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_custom_trigger():
  """Performs a creation of custom trigger in a pb test.

  Steps:
  1) Create playbook with custom trigger
  2) Simulate 2 cases
  3) Verify the playbook is attached to Phishing E-mail case
  4) Verify playbook is not attached to the Data Exfiltration case
  """

  custom_trigger = siemplify.playbooks.create_trigger(
      trigger_type="custom_trigger",
      match_type="contains",
      value="F.ATTACKER4@GMAIL.COM",
      field_name="[Entity.Identifier]",
  )
  playbook = siemplify.playbooks.create_playbook_for_test(
      trigger=custom_trigger
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=playbook.name,
  )
  cases_with_pb_details = siemplify.cases.get_last_case_full_details_for_test()
  cases_with_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_with_pb_details.wall_data,
      key="playbookName",
      value=playbook.name
  )
  pb_name = siemplify.utils.find_key_in_json(
      json_data=cases_with_pb_details.wall_data,
      key="playbookName"
  )
  soft_assert(
      is_true=cases_with_playbook,
      success_message=(
          f"Playbook match: '{pb_name}' = '{playbook.name}'"
      ),
      failure_message="Playbooks don't match",
  )
  cases = siemplify.cases.get_cases_for_test()
  for case_data in cases.case_cards:
    if case_data["title"] == enums.DefaultCases.DATA_EXFILTRATION:
      case_without_pb = case_data
  cases_without_playbook_details = siemplify.cases.get_case_full_details(
      case_id=case_without_pb["id"]
  )
  case_id = case_without_pb["id"]
  cases_without_playbook = siemplify.utils.find_key_value_in_json(
      json_data=cases_without_playbook_details.wall_data,
      key="playbookName",
      value=playbook.name,
  )
  strong_assert(
      is_false=cases_without_playbook,
      success_message=(
          f"Case #{case_id} has no attached playbook {playbook.name}"
      ),
      failure_message="Case has a attached playbook",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_playbook_with_all_env():
  """Performs a creation of custom trigger in a pb test.

  Steps:
  1) Create a new environment
  2) Create a playbook with trigger all
  3) Simulate cases for both environments
  4) Verify The playbook is attached to both of the cases
  """
  add_entity = siemplify.payloads.playbook_actions.add_entity_insight()
  env = siemplify.environments.create_environment_for_test()
  playbook = siemplify.playbooks.create_playbook_in_environments(
      environments=[env.name, "test_playbook_with_all_env"],
      actions=[add_entity]
  )
  siemplify.cases.simulate_cases_in_environment(
      cases=[enums.DefaultCases.DATA_EXFILTRATION],
      environment=env.name,
  )
  case_1 = siemplify.cases.get_last_case_id_in_environments(
      environments=[env.name]
  )
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_1,
      playbook_name=playbook.name,
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_2 = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_2,
      playbook_name=playbook.name,
  )
  cases = siemplify.cases.get_cases_in_environments(
      environments=[env.name, "test_playbook_with_all_env"],
  )
  for case_data in cases.case_cards:
    if case_data["title"] == enums.DefaultCases.DATA_EXFILTRATION:
      case_with_pb = case_data
      break
  first_case = siemplify.cases.get_case_full_details(
      case_id=case_with_pb["id"]
  )
  first_case_pb = siemplify.utils.find_key_value_in_json(
      json_data=first_case.wall_data,
      key="playbookName",
      value=playbook.name,
  )
  strong_assert(
      is_true=first_case_pb,
      success_message=(
          f"Case #{first_case.id} has attached playbook #{playbook.id}"
      ),
      failure_message="Case has no attached playbook",
  )
  for case_data in cases.case_cards:
    if case_data["title"] == enums.DefaultCases.PHISHING_EMAIL:
      case_with_pb = case_data
      break
  second_case = siemplify.cases.get_case_full_details(
      case_id=case_with_pb["id"]
  )
  second_case_pb = siemplify.utils.find_key_value_in_json(
      json_data=second_case.wall_data,
      key="playbookName",
      value=playbook.name,
  )
  strong_assert(
      is_true=second_case_pb,
      success_message=(
          f"Case #{second_case.id} has attached playbook {playbook.name}"
      ),
      failure_message="Case has no attached playbook",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_previous_action_condition():
  """Performs a "Execute previous condition action" test.

  Steps:
  1) Create a playbook
  2) Add previous condition action
  3) Configure Siemplify_Case Comment_1.SuccessStatus= true
  4) "Case Comment" action on the first branch
  5) Save playbook and simulate case
  6) Check 'Previous Actions Conditions' flow inside the case
  7) Verify Siemplify_Case Comment_Success Status in the action parameters
  8) Verify The playbook runs on the case, All actions status = success
  9) Verify result is correct:
   (1) IF:
   [Siemplify_Case Comment_1.SuccessStatus Equals true]
   (2) DEFAULT
   Result = 1
  """
  instances = siemplify.integrations.get_optional_integration_instances(
      environments=["*"],
      integration_name="Siemplify",
  ).json()
  comment_action = siemplify.payloads.playbook_actions.add_case_comment(
      integration_id=instances[0]["identifier"]
  )
  flow = siemplify.payloads.playbook_actions.add_previous_condition_flow()
  action = siemplify.payloads.playbook_actions.add_entity_insight(
      integration_id=instances[0]["identifier"]
  )
  playbook = siemplify.playbooks.create_playbook_for_test(
      use_previous_flow_action=True,
      actions=[comment_action, flow, action],
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  pb_status_res = siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_identifier,
      playbook_name=playbook.name,
      status=2,
  )
  pb_summary = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_identifier,
  )
  def_id = pb_summary.json()[0]["definitionIdentifier"]
  pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=case_id,
      alert_identifier=alert_identifier,
      definition_id=def_id,
  )
  pb_flow_action = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["usedIntegrations"],
      key="identifier",
      value="Flow",
  )
  case_comment_action = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["completedSteps"],
      key="actionName",
      value="Siemplify_Case Comment",
  )
  flow_res_status = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["completedSteps"],
      key="actionName",
      value="IfElse",
  )
  strong_assert(
      is_true=pb_flow_action,
      success_message=f"Playbook: {playbook.name} contains flow action",
      failure_message=f"Playbook: {playbook.name} doesn't have a flow action",
  )
  # status 2 - completed successfully
  action_status = case_comment_action.get("status")
  strong_assert(
      compare=action_status,
      to=2,
      success_message=f"Case comment completed  with status: {action_status}",
      failure_message=f"Case comment failed with status: {action_status}",
  )
  flow_status = flow_res_status.get("resultValue")
  strong_assert(
      compare=flow_status,
      to="1",
      success_message=f"Flow action completed with right status: {flow_status}",
      failure_message=f"Flow action completed with wrong status: {flow_status}",
  )
  # status 2 - completed successfully
  strong_assert(
      compare=pb_status_res,
      to=2,
      success_message=(
          f"Playbook: {playbook.name} completed with status: {pb_status_res}"
      ),
      failure_message=(
          f"Playbook: {playbook.name} failed with status {pb_status_res}"
      )
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_nested_playbook_with_view():
  """Performs a "Nested playbook with a view" test.

  Steps:
  1) Create a playbook with trigger all and a nested block
  2) Attach a view to the playbook, assigned to your role
  3) Simulate a case,
  4) Verify the playbook is attached to the case
  5) Verify the view is applied to the alert view
  6) Edit the block
  7) The block change is applied
  8) The view is applied to the alert view
  """
  block_trigger = siemplify.playbooks.create_block_trigger()
  comment_action = siemplify.payloads.playbook_actions.add_case_comment()
  nested_block_output_step = siemplify.payloads.playbook_actions.create_nested_block_output_step()
  create_block = siemplify.playbooks.create_playbook_for_test(
      trigger=block_trigger,
      playbook_type=1,
      actions=[comment_action, nested_block_output_step],
  )
  nested_block_step = siemplify.payloads.playbook_actions.create_nested_block_step(
      nested_name=create_block.name,
      nested_workflow_id=create_block.identifier,
  )
  playbook = siemplify.playbooks.create_playbook_for_test(
      actions=[nested_block_step],
      view_template=True,
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_id = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  pb_name = playbook.name
  # status 2 - completed successfully
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=pb_name,
  )
  status = siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_id,
      playbook_name=pb_name,
      status=2,
  )
  strong_assert(
      compare=status,
      to=2,
      success_message=f"Playbook: {pb_name} completed with status: {status}",
      failure_message=f"Playbook failed with status {status}",
  )
  case_details = siemplify.cases.get_last_case_full_details_for_test()
  wall_data = case_details.wall_data
  check_name = siemplify.utils.find_key_value_in_json(
      json_data=wall_data,
      key="playbookName",
      value=playbook.name
  )
  strong_assert(
      is_true=check_name,
      success_message=f"Playbook '{playbook.name}' attached to case",
      failure_message="Playbook failed to attach to a case",
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["identifier"]
  pb_view = siemplify.cases.get_alert_overview_data(
      case_id=case_id,
      alert_identifier=alert_identifier,
  )
  pb_new_name = siemplify.utils.generate_random_name()
  siemplify.playbooks.update_playbook(
      playbook_identifier=create_block.identifier,
      playbook_name=pb_new_name,
  )
  check_view = siemplify.utils.find_key_value_in_json(
      json_data=pb_view.json()["widgets"],
      key="title",
      value="Automation Test"
  )
  strong_assert(
      is_true=check_view,
      success_message=(
          "Playbook view 'Automation Test' attached to alert overview"
      ),
      failure_message="No playbook view found in Alert overview tab",
  )
  pb_summary = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_id,
  )
  def_id = pb_summary.json()[0]["definitionIdentifier"]
  pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=case_id,
      alert_identifier=alert_id,
      definition_id=def_id,
  )
  block_output_data = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["completedSteps"],
      key="resultValue",
      value="Automation Test"
  )
  strong_assert(
      is_true=block_output_data,
      success_message="Block output has correct value 'Automation Test'",
      failure_message="Nested Workflow Output wasn't correct"
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_multichoise_question_flow():
  """Performs a "Multichouce question playbook flow" test.

  Steps:
  1) Create playbook with MultiChoiceQuestion Flow with 2 options (yes/no)
  2) additional steps to each branch with different values
  3) Simulate a case
  4) The playbook on a case - Answer Yes
  5) Simulate a case
  6) Run the playbook on another case - Answer No
  7) The relevant branch is running according to the selected answer
  8) The step of the selected branch are executed accordingly
  """
  flow = siemplify.payloads.playbook_actions.add_multichoise_flow()
  comment_action = siemplify.payloads.playbook_actions.add_case_comment()
  playbook = siemplify.playbooks.create_playbook_for_test(
      use_condition=True,
      actions=[flow, comment_action],
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=playbook.name,
  )
  alert_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  execute_action = siemplify.cases.get_workflow_step_instance(
      case_id=case_id,
      alert_identifier=alert_identifier,
      step_identifier=playbook.steps[0]["originalStepIdentifier"],
      workflow_identifier=playbook.identifier,
  )
  execute_action = execute_action.json()
  properties = {
      "Question": "Automation Test",
      "Answers": "{\"1\":\"Yes\",\"2\":\"No\"}",
      "SelectedScopeName": None,
      "AssignedUsers": None,
      "MessageToAssignee": None,
      "PendingActionTimeout": None,
      "HasApprovalLink": None,
      "MultichoiceSelectedAnswer": "1"}
  new_json = execute_action
  new_json["properties"].update(properties)
  siemplify.cases.execute_pending_action(json_params=new_json)
  pb_status_after_execute = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_identifier,
  )
  def_id = pb_status_after_execute.json()[0]["definitionIdentifier"]
  pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=case_id,
      alert_identifier=alert_identifier,
      definition_id=def_id,
  )
  pb_status = pb_status_after_execute.json()[0]["status"]
  pb_status = siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_identifier,
      playbook_name=playbook.name,
      status=2,
  )
  strong_assert(
      compare=pb_status,
      to=2,
      success_message=f"Playbook: {playbook.name} completed successfully",
      failure_message=f"Playbook: {playbook.name} Failed to run",
  )
  multi_choise_answer_yes = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["completedSteps"],
      key="actionName",
      value="MultiChoiceQuestion",
  )
  strong_assert(
      compare=multi_choise_answer_yes["resultValue"],
      to="1",
      success_message=f"Playbook: {playbook.name} completed successfully",
      failure_message=f"Playbook: {playbook.name} Failed to run",
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=case_id,
      playbook_name=playbook.name,
  )
  pb_status = siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_identifier,
      playbook_name=playbook.name,
      status=2,
  )
  execute_action = siemplify.cases.get_workflow_step_instance(
      case_id=case_id,
      alert_identifier=alert_identifier,
      step_identifier=playbook.steps[0]["originalStepIdentifier"],
      workflow_identifier=playbook.identifier,
  )
  execute_action = execute_action.json()
  properties = {
      "Question": "Automation Test",
      "Answers": "{\"1\":\"Yes\",\"2\":\"No\"}",
      "SelectedScopeName": None,
      "AssignedUsers": None,
      "MessageToAssignee": None,
      "PendingActionTimeout": None,
      "HasApprovalLink": None,
      "MultichoiceSelectedAnswer": "2"}
  new_json = execute_action
  new_json["properties"].update(properties)
  siemplify.cases.execute_pending_action(json_params=new_json)
  pb_status_after_execute = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_identifier,
  )
  def_id = pb_status_after_execute.json()[0]["definitionIdentifier"]
  pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=case_id,
      alert_identifier=alert_identifier,
      definition_id=def_id,
  )
  pb_status = pb_status_after_execute.json()[0]["status"]
  strong_assert(
      compare=pb_status,
      to=2,
      success_message=f"Playbook: {playbook.name} completed successfully",
      failure_message=f"Playbook: {playbook.name} Failed to run",
  )
  multi_choise_answer_yes = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["completedSteps"],
      key="actionName",
      value="MultiChoiceQuestion",
  )
  result = multi_choise_answer_yes["resultValue"]
  strong_assert(
      compare=result,
      to="2",
      success_message=f"Playbook: {playbook.name} completed successfully",
      failure_message=f"Playbook: {playbook.name} Failed with status: {result}"
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_entity_selection_flow_action():
  """Performs a "Entity selection flow" test.

  Steps:
  Create a playbook:
  1. Triger all
  2. EntitySelection step configured as -  Entity.Type contains URL
  3. Entity insight action configured as - Entity Selection_1.SelectedEntities
  4. Entity insight action configured as - All IP adresses
  5. Save the playbbok
  6. Simulate  Phishing Email case
  7. Simulate  Data exfiltration case
  8. The playbook runs automatically on the cases
  In the Data exfiltration case:
  1. The entity selection step output = No matching entities found
  2. The entity insight step1 output = Scope is empty. Nothing happened.
  3. The entity insight step2 output = Added insight with message ...
  In the Phishig e-mail case:
  1. The entity selection step output = HTTP://MARKOSSOLOMON.COM/F1Q7QX.PHP
  2. The entity insight step1 output = Added insight with message ...
  3. The entity insight step2 output = Scope is empty. Nothing happened.
  """

  entity_selection = siemplify.payloads.playbook_actions.add_entity_selection()
  entity_select_value = "Entity Selection_1.SelectedEntities"
  entity_insight = siemplify.payloads.playbook_actions.add_entity_insight(
      selected_scope=entity_select_value
  )
  all_ip_value = "All IP addresses"
  ip_entity_insight = siemplify.payloads.playbook_actions.add_entity_insight(
      selected_scope=all_ip_value,
  )
  playbook = siemplify.playbooks.create_playbook_for_test(
      actions=[entity_selection, entity_insight, ip_entity_insight],
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  get_cases_data = siemplify.cases.get_cases_for_test().case_cards
  data_exfiltration_case = siemplify.utils.find_key_value_in_json(
      json_data=get_cases_data,
      key="title",
      value=enums.DefaultCases.DATA_EXFILTRATION,
  )
  phishing_case = siemplify.utils.find_key_value_in_json(
      json_data=get_cases_data,
      key="title",
      value="Phishing email detector",
  )
  alert_identifier = siemplify.cases.get_case_full_details(
      case_id=data_exfiltration_case["id"]
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  alert_identifier_phishing_case = siemplify.cases.get_case_full_details(
      case_id=phishing_case["id"]
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=data_exfiltration_case["id"],
      playbook_name=playbook.name,
  )
  siemplify.playbooks.wait_for_playbook_status(
      case_id=data_exfiltration_case["id"],
      alert_id=alert_identifier,
      playbook_name=playbook.name,
      status=2,
  )
  siemplify.playbooks.wait_for_playbook_in_case(
      case_id=phishing_case["id"],
      playbook_name=playbook.name,
  )
  siemplify.playbooks.wait_for_playbook_status(
      case_id=phishing_case["id"],
      alert_id=alert_identifier_phishing_case,
      playbook_name=playbook.name,
      status=2,
  )
  pb_status_after_execute = siemplify.playbooks.get_playbook_summary(
      case_id=data_exfiltration_case["id"],
      alert_id=alert_identifier,
  )
  pb_status_after_execute_phishing = siemplify.playbooks.get_playbook_summary(
      case_id=phishing_case["id"],
      alert_id=alert_identifier_phishing_case,
  )
  def_id = pb_status_after_execute.json()[0]["definitionIdentifier"]
  summary_exfiltration = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=data_exfiltration_case["id"],
      alert_identifier=alert_identifier,
      definition_id=def_id,
  )
  def_id_phishing = (
      pb_status_after_execute_phishing.json()[0]["definitionIdentifier"]
  )
  summary_phishing = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=phishing_case["id"],
      alert_identifier=alert_identifier_phishing_case,
      definition_id=def_id_phishing,
  )
  entity_selection_status = siemplify.utils.find_key_value_in_json(
      json_data=summary_exfiltration.json()["completedSteps"],
      key="actionName",
      value="EntitySelection",
  )
  entity_selection_status_phishing = siemplify.utils.find_key_value_in_json(
      json_data=summary_phishing.json()["completedSteps"],
      key="actionName",
      value="EntitySelection",
  )
  entity_res_insight = siemplify.utils.find_key_value_in_json(
      json_data=summary_exfiltration.json()["completedSteps"],
      key="message",
      value="Scope is empty. Nothing happened.",
  )
  entity_res_insight_phishing_res = siemplify.utils.find_key_value_in_json(
      json_data=
      summary_phishing.json()["completedSteps"][1]["resultEntities"],
      key="entityType",
      value="DestinationURL",
  )
  test_msg = (
      "Added insight with message [Test!] to "
      "[HTTP://MARKOSSOLOMON.COM/F1Q7QX.PHP]"
  )
  entity_res_insight_phishing_msg = siemplify.utils.find_key_value_in_json(
      json_data=summary_phishing.json()["completedSteps"],
      key="message",
      value=test_msg,
  )
  entity_res_entities = siemplify.utils.find_key_value_in_json(
      json_data=(
          summary_exfiltration.json()["completedSteps"][2]["resultEntities"]
      ),
      key="entityType",
      value="ADDRESS",
  )
  strong_assert(
      compare=pb_status_after_execute.json()[0]["status"],
      to=2,
      success_message="Playbook completed successfully",
      failure_message="Playbook Failed to run"
  )
  strong_assert(
      compare=pb_status_after_execute_phishing.json()[0]["status"],
      to=2,
      success_message="Playbook completed successfully",
      failure_message="Playbook Failed to run"
  )
  entity_res_insight_phishing = siemplify.utils.find_key_value_in_json(
      json_data=summary_phishing.json()["completedSteps"],
      key="message",
      value="Scope is empty. Nothing happened.",)
  check = entity_selection_status["resultValue"] == None
  strong_assert(
      is_true=check,
      success_message="The Entity Selection output is Null (None)",
      failure_message="Entity Selection is not Null",
      extra_info=entity_selection_status,
  )
  strong_assert(
      compare=entity_selection_status_phishing["message"],
      to="HTTP://MARKOSSOLOMON.COM/F1Q7QX.PHP",
      success_message="The Entity Selection output is a valid URL ",
      failure_message="The Entity Selection is incorrect",
      extra_info=entity_selection_status_phishing,
  )
  strong_assert(
      compare=entity_selection_status["message"],
      to="No matching entities found",
      success_message="The Entity Selection message is correct",
      failure_message="Entity Selection message is incorrect",
      extra_info=entity_selection_status,
  )
  strong_assert(
      compare=entity_res_insight["message"],
      to="Scope is empty. Nothing happened.",
      success_message="The Entity Insight message is correct",
      failure_message="The Entity Insight message is incorrect",
      extra_info=entity_res_insight,
  )
  strong_assert(
      compare=entity_res_insight_phishing_res["entityType"],
      to="DestinationURL",
      success_message="The Entity Result Type is DestinationURL",
      failure_message="Entity Result Type is incorrect",
      extra_info=entity_res_insight_phishing_res,
  )
  required = (
      "Added insight with message [Test!] to "
      "[HTTP://MARKOSSOLOMON.COM/F1Q7QX.PHP]"
  )
  strong_assert(
      compare=entity_res_insight_phishing_msg["message"],
      to=required,
      success_message="The Entity Insight output is correct",
      failure_message="The Entity Insight output is incorrect",
      extra_info=entity_res_insight_phishing_msg,
  )
  strong_assert(
      compare=entity_res_entities["identifier"],
      to="10.0.0.28",
      success_message="Entity Insight found results that matched to IP Address",
      failure_message="Entity Insight is incorrect",
      extra_info=entity_res_entities,
  )
  strong_assert(
      compare=entity_res_insight_phishing["message"],
      to="Scope is empty. Nothing happened.",
      success_message="The Entity Insight output is correct",
      failure_message="The Entity Insight output is incorrect",
      extra_info=entity_res_insight_phishing,
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_merged_flow_actions():
  """Performs a "Merged actions with a condition action" test.

  Steps:
  1. Create a playbook with merged actions
  2. Simulate a case
  3. The playbook runs on the case
  4. branch action "2" step does not run
  5. the rest of the steps status = success
  6. Playbook finished to run succesfully
  """
  playbook = siemplify.playbooks.create_merged_actions_playbook(
      environments=["test_merged_flow_actions"]
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION],
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_group_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_group_identifier,
      playbook_name=playbook.name,
      status=2,
  )
  pb_res = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_group_identifier,
  )
  status = pb_res.json()[0]["status"]
  strong_assert(
      compare=status,
      to=2,
      success_message=(
          f"Playbook finished running succesfully with status: {status}"
      ),
      failure_message=(
          f"Playbook didnt finish succesfully, status: {status}"
      ),
  )
  flow_action = siemplify.cases.get_workflow_step_instance(
      case_id=case_id,
      alert_identifier=alert_group_identifier,
      step_identifier=playbook.steps[0]["originalStepIdentifier"],
      workflow_identifier=playbook.identifier
  )
  flow = flow_action.json()
  strong_assert(
      compare=flow["resultValue"],
      to="1",
      success_message=(
          "Branch 1 was selected in flow action"
      ),
      failure_message=(
          f"Incorrect Branch was selected in Flow action: {flow['resultValue']}"
      ),
  )
  branch_1 = siemplify.cases.get_workflow_step_instance(
      case_id=case_id,
      alert_identifier=alert_group_identifier,
      step_identifier=playbook.steps[1]["originalStepIdentifier"],
      workflow_identifier=playbook.identifier
  )
  running_branch = branch_1.json()
  strong_assert(
      compare=running_branch["status"],
      to=2,
      success_message=(
          "Selected Action Branch 1 was succesfully completed"
      ),
      failure_message=(
          f"Action was failed with status: {running_branch['status']}"
      ),
  )
  branch_2 = siemplify.cases.get_workflow_step_instance(
      case_id=case_id,
      alert_identifier=alert_group_identifier,
      step_identifier=playbook.steps[2]["originalStepIdentifier"],
      workflow_identifier=playbook.identifier
  )
  not_running_branch = branch_2.json()
  strong_assert(
      compare=not_running_branch["status"],
      to=-1,
      success_message=(
          "Branch Action 2 Didnt run, because Branch 1 was Running"
      ),
      failure_message=(
          "Branch 2 Action failed with diffrenet status"
      ),
      extra_info=branch_2.json(),
  )
  merged_action = siemplify.cases.get_workflow_step_instance(
      case_id=case_id,
      alert_identifier=alert_group_identifier,
      step_identifier=playbook.steps[3]["originalStepIdentifier"],
      workflow_identifier=playbook.identifier
  )
  running_branch = merged_action.json()
  strong_assert(
      compare=running_branch["status"],
      to=2,
      success_message=(
          "Merged action 1 was succesfully completed"
      ),
      failure_message=(
          f"Merged action failed to run with status: {running_branch['status']}"
      ),
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_create_same_playbook_in_different_env():
  """Performs a test with the name listed below.

  "Create playbooks with the same name in different environments"

  Steps:
  1) Create a custom environment
  2) Create a playbook in the created environment
  3) Create a playbook in the default environment
  4) Verify playbooks have the same name
  5) Verify playbooks have different identifiers
  6) Verify both playbooks are found in the playbooks folder
  """
  new_env = siemplify.environments.create_environment_for_test()
  playbook_a = siemplify.playbooks.create_playbook_in_environments(
      environments=[new_env.name],
  )
  playbook_default = siemplify.playbooks.create_playbook_for_test()
  siemplify.playbooks.update_playbook(
      playbook_identifier=playbook_a.identifier,
      playbook_name="PlaybookTest"
  )
  siemplify.playbooks.update_playbook(
      playbook_identifier=playbook_default.identifier,
      playbook_name="PlaybookTest"
  )
  pb1 = siemplify.playbooks.get_playbook_data(
      identifier=playbook_a.identifier
  )
  pb2 = siemplify.playbooks.get_playbook_data(
      identifier=playbook_default.identifier
  )
  soft_assert(
      compare=pb1.name,
      to=pb2.name,
      success_message="Playbooks have the same name",
      failure_message="Playbooks have different names",
  )
  soft_assert(
      is_false=pb1.identifier == pb2.identifier,
      success_message="Playbooks have different identifiers",
      failure_message="Playbooks have the same identifier",
  )
  all_playbooks = siemplify.playbooks.get_all_playbooks()
  playbook_a_found = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks.json(),
      key="identifier",
      value=pb1.identifier,
  )
  playbook_default_found = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks.json(),
      key="identifier",
      value=pb2.identifier,
  )
  soft_assert(
      is_true=playbook_a_found,
      success_message="Playbook #1 found",
      failure_message="Playbook #1 not found",
      extra_info=playbook_a_found
  )
  strong_assert(
      is_true=playbook_default_found,
      success_message="Playbook #2 found",
      failure_message="Playbook #2 not found",
      extra_info=playbook_default_found,
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_condition_order_evaluation():
  """Test early condition evaluation exit on branch selection.

  Makes sure we dont evaluate all conditions when we can know the output.
  Takes the first branch that returns 'true'

  Steps:
  1) Create playbook
  2) Add action with json result
  3) Add condition with 2 branches that the second fails
  4) Add action to the 'correct' branch to test against
  5) Simulate case and wait for playbook to run
  6) Assert if the action after the condition was not executed
  """

  action = siemplify.playbooks.create_action(
      action_name="List Operations",
      integration_name="SiemplifyUtilities",
      number=1,
      script_value={
          "First List": "a,b,c,d",
          "Second List": "b,c,d,e",
          "Delimiter": ",",
          "Operator": "intersection",
      },
      description=""
  )

  # Flow with two condition branches, and the first branch
  # has two conditions separated with the OR operator
  # Second condition in first branch and second branch should
  # fail and we test that it still follows the first branch
  flow = siemplify.playbooks.create_condition_flow(
      integration_name="Flow",
      branch_conditions_json="""[{\"LogicalOperator\": 1, \"Conditions\": [{\"Operator\": 0, \"FieldName\": \"[SiemplifyUtilities_List Operations_1.JsonResult|\\\"results.count\\\"]\", \"Type\": 2, \"Value\": \"3\"}, {\"Operator\": 0, \"FieldName\": \"[SiemplifyUtilities_List Operations_1.JsonResult|\\\"Events._fields.Start1Time\\\"|max(\\\"some\\\")]\", \"Type\": 2, \"Value\": \"0\"}], \"Order\": 1, \"IsDefaultBranch\": false, \"Name\": \"Branch\"}, {\"LogicalOperator\": 0, \"Conditions\": [{\"Operator\": 0, \"FieldName\": \"[SiemplifyUtilities_List Operations_1.JsonResult|\\\"Events._fields.Start2Time\\\"|min(\\\"some\\\")]\", \"Type\": 2, \"Value\": \"0\"}], \"Order\": 2, \"IsDefaultBranch\": false, \"Name\": \"Branch\"}, {\"LogicalOperator\": 0, \"Conditions\": [], \"Order\": 3, \"IsDefaultBranch\": true, \"Name\": \"Branch\"}]""",
  )
  comment_action = siemplify.payloads.playbook_actions.add_case_comment()
  plabyook = siemplify.playbooks.create_playbook_for_test(
      use_previous_flow_action=True,
      actions=[action, flow, comment_action],
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  siemplify.playbooks.wait_for_playbook_status(
      case_id=case_id,
      alert_id=alert_identifier,
      playbook_name=plabyook.name,
      status=2,
  )
  pb_status = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_identifier,
  )
  def_id = pb_status.json()[0]["definitionIdentifier"]
  pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
      case_id=case_id,
      alert_identifier=alert_identifier,
      definition_id=def_id,
  )
  print(pb_res_summary.json())
  pb_flow_action = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["usedIntegrations"],
      key="identifier",
      value="Flow",
  )
  case_comment_action = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["completedSteps"],
      key="actionName",
      value="Siemplify_Case Comment",
  )
  flow_res_status = siemplify.utils.find_key_value_in_json(
      json_data=pb_res_summary.json()["completedSteps"],
      key="actionName",
      value="IfFlowCondition",
  )
  strong_assert(
      compare=pb_flow_action["identifier"],
      to="Flow",
      success_message=(f"""Playbook: {pb_status.json()[0]['name']}
         contains flow action"""),
      failure_message="Playbook dont have a flow action"
  )
  # status 2 - completed successfully
  strong_assert(
      compare=case_comment_action["status"],
      to=2,
      success_message=(
          f"""Case comment completed successfully
            with status: {case_comment_action['status']}"""
      ),
      failure_message=(
          f"Case comment failed with status: {case_comment_action['status']}"
      ),
  )
  strong_assert(
      compare=flow_res_status["resultValue"],
      to="1",
      success_message=f"""Flow action result completed
        with correct status result {flow_res_status['resultValue']}""",
      failure_message=f"""Flow action didnt complete with status 1,
         status was: {flow_res_status['resultValue']}"""
  )
  # status 2 - completed successfully
  status = pb_status.json()[0]["status"]
  strong_assert(
      compare=status,
      to=2,
      success_message=(
          f"""Playbook: {pb_status.json()[0]['name']}
             completed successfully with status: {status}"""
      ),
      failure_message=f"Playbook failed with status {status}"
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_create_playbook_in_specific_category_test():
  """Performs a test with a name listed below.

  "Playbook should be created under provided category"

  Steps:
  1) Create playbook
  2) Verify that playbook is created under provided category
  """
  category = "test_category"
  playbook = siemplify.playbooks.create_playbook_for_test(category_name=category)
  all_playbooks = siemplify.playbooks.get_all_playbooks()
  check = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks,
      key="categoryName",
      value=playbook.category_name,
  )
  soft_assert(
      is_true=check,
      success_message=f"Playbook '{playbook.category_name}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  strong_assert(
      compare=category,
      to=playbook.category_name,
      success_message=f"Playbook is in category '{playbook.category_name}'",
      failure_message=f"Playbook is not in category '{playbook.category_name}'",
  )


@tags(["PLAYBOOKS", "PARALLEL"])
def test_update_playbook_category_test():
  """Performs a test with a name listed below.

  "Playbook should be moved from Default to newly provided category"

  Steps:
  1) Create playbook with Default category
  2} Move playbook to a new category
  2) Verify that playbook should be moved from Default to newly provided category
  """
  category = "test_category1"
  playbook = siemplify.playbooks.create_playbook_for_test()
  all_playbooks = siemplify.playbooks.get_all_playbooks()
  check = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks,
      key="categoryName",
      value=playbook.category_name,
  )
  soft_assert(
      is_true=check,
      success_message=f"Playbook '{playbook.category_name}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  strong_assert(
      compare="Default",
      to=playbook.category_name,
      success_message=f"Playbook is in category '{playbook.category_name}'",
      failure_message=f"Playbook is not in category '{playbook.category_name}'",
  )
  updated_pb = siemplify.playbooks.update_playbook(
      playbook_identifier=playbook.identifier,
      is_enabled=True,
      category_name=category,
  )
  all_playbooks_new = siemplify.playbooks.get_all_playbooks()
  new_check = siemplify.utils.find_key_value_in_json(
      json_data=all_playbooks_new,
      key="categoryName",
      value=updated_pb.category_name,
  )
  soft_assert(
      is_true=new_check,
      success_message=f"Playbook '{updated_pb.category_name}' found in playbooks list",
      failure_message="Playbook not found in the list of playbooks",
  )
  strong_assert(
      compare=category,
      to=updated_pb.category_name,
      success_message=f"Playbook is in category '{updated_pb.category_name}'",
      failure_message=f"Playbook is not in category '{updated_pb.category_name}'",
  )
  
# @tags(["BUG-REPORT-265300811"])
# @integrations_required(integrations=["CSV"])
# @cleanup(modules=["playbooks", "cases", "environments"])
# def test_unsupported_steps_with_uninstalled_integration():
#   """Performs a unsupported steps with uninstalled integration test.

#   Steps:
#   1) Install and configure commerical integraiton
#   2) Create a pb with commerical action
#   3) Uninstall the integration
#   4) Open the playbook in playbook page
#   5) Attach the playbook to a case
#   6) Validate the commerical action is unsupported
#   7) Validate the commerical step is failed on runnig alert
#   """
#   csv_ping = siemplify.payloads.playbook_actions.add_csv_ping_action()
#   siemplify.playbooks.create_playbook_for_test(actions=[csv_ping])
#   action_data = siemplify.actions.get_action_full_data(
#       action_name="Ping",
#       integration_name="CSV")
#   soft_assert(
#       compare=action_data.name,
#       to="Ping",
#       success_message="CSV Ping action successfully found",
#       failure_message="CSV ping action wasn't found"
#   )
#   siemplify.integrations.delete_integration(name="CSV")
#   siemplify.cases.simulate_cases_for_test(cases=[enums.DefaultCases.DATA_EXFILTRATION])
#   case_id = siemplify.cases.get_last_case_id_for_test()
#   alert_group_identifier = siemplify.cases.get_case_full_details(
#       case_id=case_id
#   ).alerts[0].additional_properties["alertGroupIdentifier"]
#   # check if pb succeded to run #status 3 = failed
#   pb_res = siemplify.playbooks.get_playbook_summary(
#       case_id=case_id,
#       alert_id=alert_group_identifier
#   )
#   status = pb_res.json()[0]["status"]
#   strong_assert(
#       compare=status,
#       to=3,
#       success_message=(
#           f"Playbook finished running with failed status: {status}"
#       ),
#       failure_message=(
#           f"Playbook didnt finish with failed status, status: {status}"
#       ),
#   )
#   def_id = pb_res.json()[0]["definitionIdentifier"]
#   pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
#       case_id=case_id,
#       alert_identifier=alert_group_identifier,
#       definition_id=def_id)
#   result_code = pb_res_summary.json()["faultedSteps"][0]["resultCode"]
#   siemplify.playbooks.pb_result_waiter(res=result_code, status=-7)
#  # check action status with result code, -7 = unsaupported action
#   strong_assert(
#       compare=result_code,
#       to=-7,
#       success_message=(
#           f"Playbook finished with unsupported result code: {result_code}"
#       ),
#       failure_message=(
#           f"Playbook finished with correct result code: {result_code}"
#       ),
#   )


# @tags(["BUG-REPORT-265300811"])
# @integrations_required(integrations=["CSV"])
# @cleanup(modules=["playbooks", "cases", "environments",
#                   "installed integrations"])
# def test_unsupported_steps_with_disabled_action():
#   """Performs a unsupported steps with disabled action test.

#   Steps:
#   1) Install and configure commerical integraiton
#   2) Create a pb with commerical action
#   3) Disable the aciton in IDE
#   4) Open the playbook in playbook page
#   5) Attach the playbook to a case
#   6) Validate the commerical action is faulted
#   7) Validate the commerical step is failed on runnig alert
#   """
#   csv_ping = siemplify.payloads.playbook_actions.add_csv_ping_action()
#   playbook = siemplify.playbooks.create_playbook_for_test(actions=[csv_ping])
#   action_data = siemplify.actions.get_action_full_data(
#       action_name="Ping",
#       integration_name="CSV"
#   )
#   soft_assert(
#       compare=action_data.name,
#       to="Ping",
#       success_message="CSV Ping action successfully found",
#       failure_message="CSV ping action wasn't found"
#   )
#   siemplify.actions.disable_ide_item(integration_name="CSV", item_name="Ping")
#   siemplify.cases.simulate_cases_for_test(cases=[enums.DefaultCases.DATA_EXFILTRATION])
#   case_id = siemplify.cases.get_last_case_id_for_test()
#   alert_group_identifier = siemplify.cases.get_case_full_details(
#       case_id=case_id
#   ).alerts[0].additional_properties["alertGroupIdentifier"]
#   # check if pb succeded to run #status 3 = failed
#   status = siemplify.playbooks.wait_for_playbook_status(
#       case_id=case_id,
#       alert_id=alert_group_identifier,
#       playbook_name=playbook.name,
#       status=3,
#   )
#   strong_assert(
#       compare=status,
#       to=3,
#       success_message=(
#           f"Playbook finished running with failed status: {status}"
#       ),
#       failure_message=(
#           f"Playbook didnt finish with failed status, status: {status}"
#       ),
#   )
#   pb_res = siemplify.playbooks.get_playbook_summary(
#       case_id=case_id,
#       alert_id=alert_group_identifier
#   )
#   def_id = pb_res.json()[0]["definitionIdentifier"]
#   pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
#       case_id=case_id,
#       alert_identifier=alert_group_identifier,
#       definition_id=def_id)
#   result_code = pb_res_summary.json()["faultedSteps"][0]["resultCode"]
#   # check action status with result code, -7 = unsupported action
#   strong_assert(
#       compare=result_code,
#       to=-7,
#       success_message=(
#           f"Playbook finished with unsupported result code: {result_code}"
#       ),
#       failure_message=(
#           f"Playbook didnt finish with correct result code: {result_code}"
#       ),
#   )


# @tags(["UNSTABLE"])
# @cleanup(modules=["playbooks", "cases"])
# def test_create_playbook_for_test_with_alert_name_trigger():
#   """Performs a "Simulate cases in different environments" test.

#   Steps:
#   1) Create a custom trigger for playbook: "Contains 'data'"
#   2) Create a playbook with the custom trigger
#   3) Verify created playbook has the correct trigger
#   4) Simulate all OOTB cases
#   5) Verify the playbook is only attached to enums.DefaultCases.DATA_EXFILTRATION case
#   """
#   trigger = siemplify.playbooks.create_trigger(
#       trigger_type="alert_type",
#       match_type="contains",
#       value="data",
#   )
#   playbook = siemplify.playbooks.create_playbook_for_test(trigger=trigger)
#   created_pb_name = playbook.name
#   siemplify.cases.simulate_cases_for_test()
#   cases = siemplify.cases.get_cases()
#   # Verify that all cases were simulated
#   cases_number = len(cases.case_cards)
#   soft_assert(
#       compare=cases_number,
#       to=10,
#       success_message=f"Right number of cases simulated: {cases_number}",
#       failure_message=f"Wrong number of cases simulated: {cases_number}",
#   )
#   # Verify that only one case has changed workflow status (has playbook)
#   workflow_changed = siemplify.utils.find_key_value_in_json(
#       json_data=cases.case_cards,
#       key="workflowStatus",
#       value=2,
#   )
#   strong_assert(
#       is_true=isinstance(workflow_changed, dict),
#       success_message="Playbook attached to exactly one case",
#       failure_message="Playbook attached to more than one case",
#       extra_info=workflow_changed,
#   )
#   # Verify that that case is enums.DefaultCases.DATA_EXFILTRATION
#   title = workflow_changed.get("title")
#   soft_assert(
#       compare=title,
#       to=enums.DefaultCases.DATA_EXFILTRATION,
#       success_message="The only case with the playbook is Data Exfiltration",
#       failure_message=f"The only case with the playbook is {title}",
#   )
#   case_id = workflow_changed.get("id")
#   case_details = siemplify.cases.get_case_full_details(case_id=case_id)
#   playbook_found = siemplify.utils.find_key_value_in_json(
#       json_data=case_details.wall_data,
#       key="playbookName",
#       value=playbook.name,
#   )
#   # Verify the playbook attached to the case is the created playbook
#   found_pb_name = playbook_found.get("playbookName")
#   strong_assert(
#       compare=created_pb_name,
#       to=found_pb_name,
#       success_message="Playbook name matches in the case",
#       failure_message="Playbook name doesn't match in the case",
#       extra_info=f"Expected: {created_pb_name}. Received: {found_pb_name}.",
#   )


# @tags(["TEST"])
# @cleanup(modules=["playbooks", "cases", "environments", "custom integrations"])
# def test_condition_action_flow():
#   """Performs a "Previous condition action" test.

#   Steps:
#   1) Create a playbook
#   2) Add condition flow action
#   3) Add "Case Comment" action on the first branch
#   4) Save playbook and simulate case
#   5) Check 'Condition flow' inside the running playbook
#   6) Verify Siemplify_Case Comment_Success Status in the action parameters
#   7) Verify The playbook runs on the case, All actions status = success
#   8) Verify result is correct:
#    (1) IF:
#    [Siemplify_Case Comment_1.SuccessStatus Equals true]
#    (2) DEFAULT
#    Result = 1
#   """

#   flow = siemplify.payloads.playbook_actions.add_condition_flow()
#   comment_action = siemplify.payloads.playbook_actions.add_case_comment()
#   siemplify.playbooks.create_playbook_for_test(use_condition=True, actions=[
#       flow, comment_action])
#   siemplify.cases.simulate_cases_for_test(cases=[enums.DefaultCases.DATA_EXFILTRATION])
#   case_id = siemplify.cases.get_last_case_id_for_test()
#   alert_identifier = siemplify.cases.get_case_full_details(
#       case_id=case_id
#   ).alerts[0].additional_properties["alertGroupIdentifier"]
#   pb_status = siemplify.playbooks.get_playbook_summary(
#       case_id=case_id,
#       alert_id=alert_identifier
#   )
#   def_id = pb_status.json()[0]["definitionIdentifier"]
#   pb_res_summary = siemplify.playbooks.get_playbook_instance_summmary(
#       case_id=case_id,
#       alert_identifier=alert_identifier,
#       definition_id=def_id)
#   pb_flow_action = siemplify.utils.find_key_value_in_json(
#       json_data=pb_res_summary.json()["usedIntegrations"],
#       key="identifier",
#       value="Flow",
#   )
#   case_comment_action = siemplify.utils.find_key_value_in_json(
#       json_data=pb_res_summary.json()["completedSteps"],
#       key="actionName",
#       value="Siemplify_Case Comment",
#   )
#   flow_res_status = siemplify.utils.find_key_value_in_json(
#       json_data=pb_res_summary.json()["completedSteps"],
#       key="actionName",
#       value="IfFlowCondition",
#   )
#   strong_assert(
#       compare=pb_flow_action["identifier"],
#       to="Flow",
#       success_message=(f"""Playbook: {pb_status.json()[0]['name']}
#        contains flow action"""),
#       failure_message="Playbook dont have a flow action"
#   )
#   # status 2 - completed successfully
#   strong_assert(
#       compare=case_comment_action["status"],
#       to=2,
#       success_message=(
#           f"""Case comment completed successfully
#           with status: {case_comment_action['status']}"""
#       ),
#       failure_message=(
#           f"Case comment failed with status: {case_comment_action['status']}"
#       ),
#   )
#   strong_assert(
#       compare=flow_res_status["resultValue"],
#       to="1",
#       success_message=f"""Flow action result completed
#       with corret status result {flow_res_status['resultValue']}""",
#       failure_message=f"""Flow action didnt complete with status 1,
#        status was: {flow_res_status['resultValue']}"""
#   )
#   # status 2 - completed successfully
#   status = pb_status.json()[0]["status"]
#   strong_assert(
#       compare=status,
#       to=2,
#       success_message=(
#           f"""Playbook: {pb_status.json()[0]['name']}
#            completed successfully with status: {status}"""
#       ),
#       failure_message=f"Playbook failed with status {status}"
#   )


# @tags(["TEST"])
# @cleanup(modules=["playbooks", "cases"])
# def test_playbook_with_a_nested_block():
#   """Performs a "Nested block playbook" test.

#   Steps:
#   1) Create a playbook with trigger all and a nested block
#   2) Attach a view to the playbook, assigned to your role
#   3) Simulate a case,
#   4) Verify the playbook is attached to the case
#   5) Verify playbook succeded to run
#   """
#   custom_trigger = siemplify.playbooks.create_block_trigger()
#   comment_action = siemplify.payloads.playbook_actions.add_case_comment()
#   nested_block = siemplify.payloads.playbook_actions.add_nested_block_step()
#   create_block = siemplify.playbooks.create_playbook_for_test(
#       trigger=custom_trigger,
#       playbook_type=1,
#       actions=[comment_action, nested_block],
#   )
#   nested_action = siemplify.payloads.playbook_actions.nested_action_with_pb(
#       nested_name=create_block.name,
#       nested_workflow_id=create_block.identifier,
#   )
#   playbook = siemplify.playbooks.create_playbook_for_test(
#       actions=[nested_action],
#       view_template=True,
#   )
#   siemplify.cases.simulate_cases_for_test(cases=[enums.DefaultCases.DATA_EXFILTRATION])
#   case_id = siemplify.cases.get_last_case_id_for_test()
#   alert_identifier = siemplify.cases.get_case_full_details(
#       case_id=case_id
#   ).alerts[0].additional_properties["alertGroupIdentifier"]
#   pb_summary = siemplify.playbooks.get_playbook_summary(
#       case_id=case_id,
#       alert_id=alert_identifier,
#   )
#   pb_status = pb_summary.json()[0]["status"]
#   pb_name = pb_summary.json()[0]["name"]
#   siemplify.playbooks.pb_result_waiter(
#       res=pb_status, status=2)
#   # status 2 - completed successfully
#   strong_assert(
#       compare=pb_status,
#       to=2,
#       success_message=f"Playbook {pb_name} completed with status: {pb_status}",
#       failure_message=f"Playbook failed with status {pb_status}"
#   )
#   case_details = siemplify.cases.get_case_full_details()
#   wall_data = case_details.wall_data
#   check_name = siemplify.utils.find_key_value_in_json(
#       json_data=wall_data,
#       key="playbookName",
#       value=playbook.name
#   )
#   strong_assert(
#       is_true=check_name,
#       success_message=f"Playbook '{playbook.name}' attached to case",
#       failure_message="Playbook failed to attach to a case",
#   )
#   all_playbooks = siemplify.playbooks.get_all_playbooks()
#   check = siemplify.utils.find_key_value_in_json(
#       json_data=all_playbooks,
#       key="id",
#       value=create_block.id,
#   )
#   soft_assert(
#       is_true=check,
#       success_message=f"Playbook '{create_block.id}' found in playbooks list",
#       failure_message="Playbook not found in the list of playbooks",
#   )


# @tags(["TEST"])
# @cleanup(modules=["playbooks", "cases", "environments"])
# def test_rerun_playbook_with_a_pending_action():
#   """Performs a rerun playbook with pending action.

#   Steps:
#   1. Create a playbook with Trigger All
#   2. Add a manual action (add comment)
#   3. Add other action
#   4. Attach the playbook to a case
#   5. Skip the manual step
#   6. Re-run the playbook on the same case
#   7. Execute the manual action
#   8. Verify step was skipped
#   9. Verify playbook was completed after skipping
#   10. Verify playbook was completed after executed

#   """
#   assigned_role = "[\"@Administrator\"]"
#   manual_action = siemplify.payloads.playbook_actions.add_entity_insight(
#       is_automatic=False,
#       assigned_users=assigned_role,
#   )
#   action = siemplify.payloads.playbook_actions.add_entity_insight()
#   playbook = siemplify.playbooks.create_playbook_for_test(
#       actions=[manual_action, action],
#   )
#   siemplify.cases.simulate_cases_for_test(cases=[enums.DefaultCases.PHISHING_EMAIL])
#   case_id = siemplify.cases.get_last_case_id_for_test()
#   alert_identifier = siemplify.cases.get_case_full_details(
#       case_id=case_id
#   ).alerts[0].additional_properties["alertGroupIdentifier"]
#   skip_action = siemplify.cases.get_workflow_step_instance(
#       case_id=case_id,
#       alert_identifier=alert_identifier,
#       step_identifier=playbook.steps[0]["originalStepIdentifier"],
#       workflow_identifier=playbook.identifier
#   )
#   siemplify.cases.skip_pending_action(
#       json_params=skip_action.json()
#   )
#   playbook_summary = siemplify.playbooks.get_playbook_summary(
#       case_id=case_id,
#       alert_id=alert_identifier
#   )
#   playbook_status = playbook_summary.json()[0]["status"]
#   skip_instance = siemplify.cases.get_workflow_step_instance(
#       case_id=case_id,
#       alert_identifier=alert_identifier,
#       step_identifier=playbook.steps[0]["originalStepIdentifier"],
#       workflow_identifier=playbook.identifier
#   )
#   skip_status = skip_instance.json()["status"]
#   # status 2 - completed successfully
#   strong_assert(
#       compare=playbook_status,
#       to=2,
#       success_message=f"Playbook completed with status: {playbook_status}",
#       failure_message=f"Playbook failed with status {playbook_status}"
#   )
#   # status 10 - pending action skipped
#   strong_assert(
#       compare=skip_status,
#       to=10,
#       success_message=f"Step successfully skipped with status: {skip_status}",
#       failure_message="Action didn't get skipped"
#   )
#   siemplify.cases.rerun_playbook(
#       alert_identifier=alert_identifier,
#       case_id=case_id,
#       workflow_identifier=playbook.identifier
#   )
#   pb_status_after_rerun = siemplify.playbooks.get_playbook_summary(
#       case_id=case_id,
#       alert_id=alert_identifier,
#   )
#   run_count = pb_status_after_rerun.json()[0]["runCount"]
#   strong_assert(
#       compare=run_count,
#       to=2,
#       success_message=(
#           f"Playbook rerunning completed successfully, run count: {run_count}"
#       ),
#       failure_message=f"Failed to rerun the playbook, run count: {run_count}"
#   )
#   execute_action = siemplify.cases.get_workflow_step_instance(
#       case_id=case_id,
#       alert_identifier=alert_identifier,
#       step_identifier=playbook.steps[0]["originalStepIdentifier"],
#       workflow_identifier=playbook.identifier
#   )
#   execute_action = execute_action.json()
#   integration_instance = None
#   for instance in execute_action["parameters"]:
#     if instance["name"] == "IntegrationInstance":
#       integration_instance = instance["value"]
#       break
#   assert integration_instance is not None
#   properties = {
#       "SelectedScopeName": "All entities",
#       "IntegrationInstance": integration_instance,
#       "FallbackIntegrationInstance": None,
#       "AssignedUsers": "[\"@Administrator\"]",
#       "MessageToAssignee": None,
#       "PendingActionTimeout": None,
#       "HasApprovalLink": None,
#       "ScriptName": "Siemplify_Add Entity Insight",
#       "ScriptParametersEntityFields": "{\"Message\":\"Test!\"}"
#       }
#   new_json = execute_action
#   new_json["properties"].update(properties)
#   siemplify.cases.execute_pending_action(json_params=new_json)
#   pb_status_after_execute = siemplify.playbooks.get_playbook_summary(
#       case_id=case_id,
#       alert_id=alert_identifier,
#   )
#   pb_status = pb_status_after_execute.json()[0]["status"]
#   strong_assert(
#       compare=pb_status,
#       to=2,
#       success_message=(
#           f"Pending action executed successfully, status: {pb_status}"
#       ),
#       failure_message=f"Failed to execute pendin action, status: {pb_status}"
#   )