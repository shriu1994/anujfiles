"""Module for testing Jobs.
"""
import copy
import re

from siemplify_utils import siemplify
from source import enums
from source.utils import strong_assert
from tests.conftest import tags


@tags(["JOBS", "UNSTABLE"])
def test_job_instance_param_update():
  """Update job instance param mid run.

  This tests checks to make sure that updating
  job parameters are reflected in the scheduler
  iterations.
  steps:
  1. Create custom integration
  2. Create custom job
  3. Update custom job with script that writes
    to log input param
  4. Create job instance
  5. Wait for job instance to run
  6. Update param for job instance
  7. Wait for scheduler to run job
  8. Assert for result of job (should print new param)
  """
  job_param_name = "some generic param"
  default_param_value = "default value"
  new_param_value = "new value"
  re_pattern = "<<<(.*?)>>>"
  # Create custom integration
  integration = siemplify.integrations.create_custom_integration()
  int_name = integration.identifier
  # Check if integration is created and assert if not
  all_integrations = siemplify.integrations.get_installed_integrations().json()
  custom_integration = siemplify.utils.find_dict_by_key_in_dicts_list(
      dicts_list=all_integrations,
      key="identifier",
      value=int_name
  )
  strong_assert(
      is_true=custom_integration,
      success_message="Custom integration created",
      failure_message="Failed to create custom integration"
  )
  # Create custom job with a parameter.
  # Job should write param to log to be easily spotted
  script = "\n".join([
      "from SiemplifyJob import SiemplifyJob",
      "siemplify=SiemplifyJob()",
      "siemplify.LOGGER.info(f'''<<<{{siemplify."
      "parameters.get('{}')}}>>>''')".format(job_param_name),
      "siemplify.end_script()"
  ])
  custom_job = siemplify.ide.add_custom_ide_item(
      integration=int_name,
      script=script,
      item_type=enums.IdeItemType.JOB,
  )
  new_job_definition = siemplify.ide.get_ide_item_data_by_name(
      item_name=custom_job.name,
      integration_name=int_name,
  )
  new_param = copy.deepcopy(new_job_definition.parameters[0])
  new_param["id"] = 0
  new_param["name"] = job_param_name
  new_param["defaultValue"] = default_param_value
  new_job_definition.parameters.append(new_param)
  update_job = siemplify.ide.add_custom_ide_item(
      custom_payload=new_job_definition.response_json
  )
  update_job_id = update_job.id
  update_job_name = update_job.name
  # Create job instance with default value for the parameter and 1 min interval
  running_job_payload = siemplify.payloads.jobs.add_job(
      item_id=update_job_id,  # New job
      integration_name=int_name,
      job_name=f"{update_job_name}_instance",
      interval=20,
  )
  running_job_payload["parameters"].append(
      dict(
          id=0,
          isMandatory=True,
          name=job_param_name,
          type=2,
          value=default_param_value
      )
  )
  new_job_instance = siemplify.jobs.add_running_job(
      None, None, None,
      payload=running_job_payload
  ).response_json

  # Wait for job to run once
  siemplify.jobs.wait_for_new_history_log_item(
      job_id=new_job_instance["id"],
      retries=70,
      cadence=4,
  )
  # Change job instance parameter and save
  param_to_update = siemplify.utils.find_dict_by_key_in_dicts_list(
      dicts_list=new_job_instance["parameters"],
      key="name",
      value=job_param_name
  )
  param_to_update["value"] = new_param_value
  updated_job = siemplify.jobs.add_running_job(
      None, None, None,
      payload=new_job_instance
  ).response_json
  strong_assert(
      is_true=updated_job["id"] == new_job_instance["id"],
      success_message="Job instance param updated successfully",
      failure_message="Failed to update job instance param"
  )
  # Wait for job to run with executor
  # Get job history and value of the param in run job and in natural iteration
  history = siemplify.jobs.wait_for_new_history_log_item(
      job_id=updated_job["id"],
      retries=70,
      cadence=4,
  )
  # Assert if updated param is not refleted in history
  # Logs are in descending order
  first_job_run_param_value = re.search(
      re_pattern,
      history.log_items[-1].message
  ).group(1)
  last_job_run_param_value = re.search(
      re_pattern,
      history.log_items[0].message
  ).group(1)
  strong_assert(
      is_true=first_job_run_param_value == default_param_value,
      success_message="First iteration of the job "
                      "is correct",
      failure_message="First iteration of the job "
                      "did not produce predicted values",
      extra_info=history.log_items[0].message
  )
  strong_assert(
      is_true=last_job_run_param_value == new_param_value,
      success_message="Last iteration of the job "
                      "runs with the updated param",
      failure_message="Last iteration of the job "
                      "did not produce predicted values",
      extra_info=history.log_items[-1].message
  )
  siemplify.jobs.delete_all_custom_jobs()
