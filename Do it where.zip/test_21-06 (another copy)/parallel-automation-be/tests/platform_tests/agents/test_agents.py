"""Module for testing Siemplify agent module.
"""
import time
from siemplify_utils import siemplify
from source import enums
from source.utils import get_random_string
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags


@tags(["PUBLISHER", "UNTESTED"])
def test_agent_execute_manual_action_remotely():
  """Performs a test with a name listed below.

  "Execute remote action with commerical and custom integration"

  Steps:
  1) Get active agents data
  2) Download and configure VirusTotal Integration with remote agent
  3) Create Custom Integration
  4) Create Remote Instance
  5) Create Custom Action
  6) Simulate a case
  7) Execute manual custom action remotly on a case
  8) Execute manual commerical action remotly on a case
  9) Execute manual async action remotly on a case
  10) Clean environment
  """
  agents_list = siemplify.agents.get_agent_list()
  agent_data = None
  for agent in agents_list.json():
    if agent["status"] == 0:  # 0 active, 2 disabled, 1 deleted
      agent_data = agent
      break
  strong_assert(
      compare=agent_data.get("status", None),
      to=0,
      success_message="Found 1 active agent",
      failure_message="Didn't find any active agents",
      extra_info=agent_data,
  )
  agent_name = agent_data["name"]
  agent_identifier = agent_data["identifier"]
  siemplify.integrations.reinstall_integration(name="VirusTotalV3", version=10)
  new_instance = siemplify.integrations.create_integration_instance(
      integration_id="VirusTotalV3"
  )
  int_id = new_instance.json()["identifier"]
  vt_template = siemplify.payloads.virustotalv3.configure_with_agent(
      int_inst_id=int_id,
      agent_name=agent_name,
      agent_id=agent_identifier,
  )
  siemplify.integrations.configure_integration(
      integration_id=int_id,
      json_settings=vt_template,
  )
  run_test_with_agent = siemplify.integrations.run_integration_test(
      integration_instance_id=int_id,
  )
  res = run_test_with_agent.json()["isSuccess"]
  msg = run_test_with_agent.json()["message"]
  soft_assert(
      is_true=res,
      success_message=(
          "Successfully connected with agent to the VirusTotalV3 server"
      ),
      failure_message=f"Run Integration Test failed with message: {msg}",
  )
  # generate random string
  custom_integ = get_random_string(5)
  custom_action_name = get_random_string(5)
  # create custom integration with custom action
  custom_integration = siemplify.integrations.create_custom_integration(
      identifier=custom_integ,
  )
  custom_id_int = custom_integration.json()["identifier"]
  siemplify.ide.add_custom_ide_item(
      name=custom_action_name,
      integration=custom_id_int,
  )
  # create and configure remote instance
  custom_integration_id = siemplify.integrations.create_integration_instance(
      integration_id=custom_integ,
      environment="Default Environment",
  )
  int_custom_id = custom_integration_id.json()["identifier"]
  custom_template = siemplify.payloads.integrations.integration_with_agent(
      int_inst_id=int_custom_id,
      integration_name=custom_integ,
      agent_name=agent_name,
      agent_id=agent_identifier,
  )
  siemplify.integrations.configure_integration(
      json_settings=custom_template,
      integration_id=int_custom_id,
  )
  res = siemplify.integrations.check_if_integration_remote(
      integration_name=custom_integ
  )
  strong_assert(
      is_true=res,
      success_message=(
          f"Custom integration: {custom_integ}, configured with agent"
      ),
      failure_message=(
          f"Custom integration: {custom_integ}, not configured with agent"
      ),
  )
  agent = siemplify.agents.get_agent_list_by_env(
      environment="Default Environment"
  )
  agent_check = siemplify.utils.find_key_value_in_json(
      json_data=agent,
      key="name",
      value=agent_name,
  )
  strong_assert(
      is_true=agent_check,
      success_message=(
          f"Agent:{agent_name} is configured with default environment"
      ),
      failure_message="No agents found configured in default environment",
  )
  # simulate case and run manual action with custom, commerical and async action
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  action_ty = f"{custom_integ}_{custom_action_name}"
  manual_action = siemplify.cases.run_manual_action(
      case_id=case_id,
      action_name=action_ty,
      action_data={
          "ScriptName": action_ty,
          "ScriptParametersEntityFields": "{}",
          "IntegrationInstance": "",
      },
      integration_instance=int_custom_id
  )
  # status 2 = action completed to run, 0 - faulted
  status = manual_action.status
  # Run virustotalv3 ping
  commerical_action = siemplify.cases.run_manual_action(
      case_id=case_id,
      action_name="VirusTotalV3_Ping",
      action_data={
          "ScriptName": "VirusTotalV3_Ping",
          "ScriptParametersEntityFields": "{}",
          "IntegrationInstance": ""
      },
      integration_instance=int_id
  )
  commerical_status = commerical_action.status
  strong_assert(
      compare=status,
      to=2,
      success_message=(
          f"Custom action succesfully completed with status: {status}"
      ),
      failure_message=(
          f"Custom Action failed, ended with status: {status}"
      ),
  )
  strong_assert(
      compare=commerical_status,
      to=2,
      success_message=(
          f"Commerical action succesfully ran with status: {commerical_status}"
      ),
      failure_message=(
          f"Commercial Action failed, ended with status: {commerical_status}"
      ),
  )

  params = {
      "Engine Threshold": 1,
      "Engine Percentage Threshold": 1,
      "Engine Whitelist": "",
      "Resubmit URL": True,
      "Retrieve Comments": False,
      "Only Suspicious Entity Insight": False,
      "Create Insight": True,
      "Max Comments To Return": 10,
      "Resubmit After (Days)": 30,
      "Widget Theme": "Dark",
      "Fetch Widget": True,
  }
  # test async commerical
  siemplify.cases.simulate_cases_for_test(
      cases_list=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_2_id = siemplify.cases.get_last_case_id_for_test()
  vt_response = siemplify.cases.run_manual_action(
      case_id=case_2_id,
      action_name="VirusTotalV3_Enrich URL",
      target_entities=["HTTP://MARKOSSOLOMON.COM/F1Q7QX.PHP"],
      action_data=params,
  )
  time.sleep(5)
  vt_res = vt_response.status
  strong_assert(
      compare=vt_res,
      to=2,
      success_message=(
          f"Commerical action succesfully completed with status: {vt_res}"
      ),
      failure_message=(
          f"Commerical Action failed to run, ended with status: {vt_res}"
      ),
  )
  siemplify.integrations.delete_custom_integration(
      integration_name=custom_integ
  )


@tags(["PUBLISHER", "UNTESTED"])
def test_run_pb_with_actions_remotely():
  """Performs a test with a name listed below.

  "Execute run playbook with actions remotely"

  Steps:
  1) Get active agents data
  2) Download and configure VirusTotal Integration with remote agent
  3) Create Custom Integration
  4) Create Remote Instance
  5) Create Custom Action
  6) Create playbook with remote actions, custom and commerical
  7) Simulate case, pb will be attached to the alert
  8) Verify playbook was run and completed succefully
  9) Clean environment
  """
  agents_list = siemplify.agents.get_agent_list()
  agent_data = {}
  for agent in agents_list.json():
    if agent["status"] == 0:  # 0 active, 2 disabled, 1 deleted
      agent_data = agent
      break
  agent_name = agent_data["name"]
  agent_identifier = agent_data["identifier"]
  agent_info = siemplify.agents.get_agents_info_by_ids(
      agent_ids=[agent_identifier]
  )
  agent_communication = agent_info.json()[0]["communicationStatus"]
  # Verify agent is live
  # Statuses: live: 0, error: 1, disabled" 2, waitingforagent: 3, deleted: 4
  strong_assert(
      compare=agent_communication,
      to=0,
      success_message="agent is live",
      failure_message=(
          f"agent status is not 0(live), current status: {agent_communication}"
      ),
  )
  siemplify.integrations.reinstall_integration(name="VirusTotalV3", version=10)
  new_instance = siemplify.integrations.create_integration_instance(
      integration_id="VirusTotalV3",
  )
  int_id = new_instance.json()["identifier"]
  settings = siemplify.payloads.integrations.virustotal_integration_with_agent(
      int_inst_id=int_id,
      agent_name=agent_name,
      agent_id=agent_identifier
  )
  siemplify.integrations.configure_integration(
      json_settings=settings,
      integration_id=int_id
  )
  run_test_with_agent = siemplify.integrations.run_integration_test(
      integration_instance_id=int_id
  )
  res = run_test_with_agent.json()["isSuccess"]
  msg = run_test_with_agent.json()["message"]
  soft_assert(
      is_true=res,
      success_message="Successfully connected with agent to VirusTotal server",
      failure_message=f"Run Integration Test failed with message: {msg}",
  )
  # generate random string
  custom_integ = get_random_string(5)
  custom_action_name = get_random_string(5)
  # create custom integration with custom action
  custom_integration = siemplify.integrations.create_custom_integration(
      identifier=custom_integ
  )
  custom_id_int = custom_integration.json()["identifier"]
  siemplify.ide.add_custom_ide_item(
      name=custom_action_name,
      integration=custom_id_int
  )
  # create and configure remote instance
  custom_integration_id = siemplify.integrations.create_integration_instance(
      integration_id=custom_integ
  )
  int_custom_id = custom_integration_id.json()["identifier"]
  custom_template = siemplify.payloads.integrations.integration_with_agent(
      int_inst_id=int_custom_id,
      integration_name=custom_integ,
      agent_name=agent_name,
      agent_id=agent_identifier
  )
  siemplify.integrations.configure_integration(
      json_settings=custom_template,
      integration_id=int_custom_id
  )
  remote = siemplify.integrations.check_if_integration_remote(
      integration_name=custom_integ
  )
  strong_assert(
      is_true=remote,
      success_message=(
          f"custom integration: {custom_integ} configured with remote agent"
      ),
      failure_message=(
          f"custom integration: {custom_integ} not configured with remote agent"
      ),
  )
  agent = siemplify.agents.get_agent_list_by_env()
  agent_check = siemplify.utils.find_key_value_in_json(
      json_data=agent,
      key="name",
      value=agent_name,
  )
  strong_assert(
      is_true=agent_check,
      success_message=(
          f"agent:{agent_name} is configured with default environment"
      ),
      failure_message="no agents found configured in default environment",
  )
  action_1 = siemplify.playbooks.create_action(
      action_name=custom_action_name,
      description="Test description",
      integration_name=custom_integ,
      script_value={}
  )
  action_2 = siemplify.playbooks.create_action(
      action_name="Enrich URL",
      description=(
          "Enrich URL using information from VirusTotal. "
          "Supported entities: URL."
      ),
      integration_name="VirusTotalV3",
      script_value={
          "Engine Threshold": 1,
          "Engine Percentage Threshold": 1,
          "Engine Whitelist": "",
          "Resubmit URL": True,
          "Retrieve Comments": False,
          "Only Suspicious Entity Insight": False,
          "Create Insight": True,
          "Max Comments To Return": 10,
          "Resubmit After (Days)": 30,
          "Widget Theme": "Dark",
          "Fetch Widget": True,
      }
  )
  siemplify.playbooks.create_playbook_for_test(
      actions=[action_1, action_2]
  )
  # simulate case so pb will be attached
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  time.sleep(2)
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_group_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  # check if pb succeded to run #status 2 = completed
  time.sleep(10)
  pb_res = siemplify.playbooks.get_playbook_summary(
      case_id=case_id,
      alert_id=alert_group_identifier
  )
  status = pb_res.json()[0]["status"]
  strong_assert(
      compare=status,
      to=2,
      success_message=(
          f"Playbook finished running succesfully with status: {status}"
      ),
      failure_message=(
          f"Playbook didnt finish succesfully, status: {status}"
      ),
  )


@tags(["PUBLISHER", "UNTESTED"])
def test_dummy_connector_remotely():
  """Performs a test with a name listed below.

  "Configure and run remote connector with agent"

  Steps:
  1) Get active agents data
  2) Create Custom Integration with agent
  3) Create Remote Instance
  4) Create Custom remote Connector
  5) Enable it
  6) Run custom connector
  7) verify cases are ingested
  8) disable custom connector
  9) clean environment
  """
  agents_list = siemplify.agents.get_agent_list()
  agent_data = {}
  for agent in agents_list.json():
    if agent["status"] == 0:  # 0 active, 2 disabled, 1 deleted
      agent_data = agent
      break
  agent_name = agent_data["name"]
  agent_identifier = agent_data["identifier"]
  agent_info = siemplify.agents.get_agents_info_by_ids(
      agent_ids=[agent_identifier]
  )
  agent_communication = agent_info.json()[0]["communicationStatus"]
  # verify agent is live
  strong_assert(
      compare=agent_communication,
      to=0,
      success_message="Agent is live",
      failure_message=(
          f"Agent status is not 0, current status: {agent_communication}"
      ),
  )
  # generate random string
  custom_integ = get_random_string(5)
  custom_action_name = get_random_string(5)
  # create custom integration with custom action
  custom_integration = siemplify.integrations.create_custom_integration(
      identifier=custom_integ,
  )
  custom_id_int = custom_integration.json()["identifier"]
  siemplify.ide.add_custom_ide_item(
      name=custom_action_name,
      integration=custom_id_int
  )
  # create and configure remote instance
  custom_integration_id = siemplify.integrations.create_integration_instance(
      integration_id=custom_integ,
      environment="Default Environment"
  )
  int_custom_id = custom_integration_id.json()["identifier"]
  custom_template = siemplify.payloads.integrations.integration_with_agent(
      int_inst_id=int_custom_id,
      integration_name=custom_integ,
      agent_name=agent_name,
      agent_id=agent_identifier,
  )
  siemplify.integrations.configure_integration(
      json_settings=custom_template,
      integration_id=int_custom_id,
  )
  res = siemplify.integrations.check_if_integration_remote(
      integration_name=custom_integ
  )
  strong_assert(
      is_true=res,
      success_message=(
          f"Custom integration: {custom_integ} configured with remote agent"
      ),
      failure_message=(
          f"Custom integration: {custom_integ} not configured with remote agent"
      ),
  )
  agent = siemplify.agents.get_agent_list_by_env()
  agent_check = siemplify.utils.find_key_value_in_json(
      json_data=agent,
      key="name",
      value=agent_name,
  )
  strong_assert(
      is_true=agent_check,
      success_message=(
          f"agent:{agent_name} is configured with default environment"
      ),
      failure_message="no agents found configured in default environment",
  )
  connector = siemplify.connectors.create_connector_for_test(
      integration=custom_integ
  )
  connector_instance = siemplify.connectors.create_connector_instance_for_test(
      connector_name=connector.name,
      integration_name=custom_integ,
      is_remote=True,
      agent_id=agent_identifier,
      run_interval_in_sec=2
  )
  connector_id = connector_instance.identifier
  connector_enabled = connector_instance.is_enabled
  strong_assert(
      is_true=connector_enabled,
      success_message="Connector is enabled with status",
      failure_message="Connector is not enabled",
  )
  connector_remote = connector_instance.is_remote
  strong_assert(
      is_true=connector_remote,
      success_message="Connector instance created with Run Remotely option",
      failure_message="Failed to create remote instance",
  )
  agent_id = connector_instance.agent_identifier
  strong_assert(
      compare=agent_id,
      to=agent_identifier,
      success_message=(
          "Connector instance was created with active agent identifier, "
          f"agent id: {agent_identifier}"
      ),
      failure_message=(
          "Failed to create remote instance with current agent identifier, "
          f"agent id: {agent_id}"
      ),
  )
  time.sleep(90)
  # disable the connector
  dis_connector = siemplify.connectors.update_connector_instance(
      identifier=connector_id,
      is_enabled=False
  )
  strong_assert(
      is_false=dis_connector.is_enabled,
      success_message="Connector is disabled",
      failure_message="Failed to disable the connector",
  )
  # get all cases
  case_id = siemplify.cases.get_last_case_id_for_test()
  strong_assert(
      is_true=case_id > 0,
      success_message="Found a case",
      failure_message="No Cases",
  )


@tags(["PUBLISHER"])
def test_run_remote_action_and_connector_from_ide():
  """Performs a test with a name listed below.

  "Configure and run remote connector and action with agent from ide page"

  Steps:
  1) Get active agents data
  2) Create Custom Integration with agent
  3) Create Remote Instance
  4) Create Custom remote Connector
  5) create custom action
  6) Run custom connector and action
  7) verify test run results are succesfull
  8) clean environment
  """
  agents_list = siemplify.agents.get_agent_list()
  agent_data = {}
  for agent in agents_list.json():
    if agent["status"] == 0:  # 0 active, 2 disabled, 1 deleted
      agent_data = agent
      break
  agent_name = agent_data["name"]
  agent_identifier = agent_data["identifier"]
  agent_info = siemplify.agents.get_agents_info_by_ids(
      agent_ids=[agent_identifier]
  )
  agent_communication = agent_info.json()[0]["communicationStatus"]
  # verify agent is live
  strong_assert(
      compare=agent_communication,
      to=0,
      success_message="Agent is live",
      failure_message=(
          f"Agent status is not 0, current status: {agent_communication}"
      ),
  )
  # generate random string
  custom_integ = get_random_string(5)
  custom_action_name = get_random_string(5)
  custom_integration = siemplify.integrations.create_custom_integration(
      identifier=custom_integ,
  )
  custom_id_int = custom_integration.json()["identifier"]
  action_id = siemplify.ide.add_custom_ide_item(
      name=custom_action_name,
      integration=custom_id_int
  )
  # create and configure remote instance
  custom_integration_id = siemplify.integrations.create_integration_instance(
      integration_id=custom_integ,
      environment="Default Environment"
  )
  int_custom_id = custom_integration_id.json()["identifier"]
  custom_template = siemplify.payloads.integrations.integration_with_agent(
      int_inst_id=int_custom_id,
      integration_name=custom_integ,
      agent_name=agent_name,
      agent_id=agent_identifier,
  )
  siemplify.integrations.configure_integration(
      json_settings=custom_template,
      integration_id=int_custom_id,
  )
  res = siemplify.integrations.check_if_integration_remote(
      integration_name=custom_integ
  )
  strong_assert(
      is_true=res,
      success_message=(
          f"Custom integration: {custom_integ} configured with remote agent"
      ),
      failure_message=(
          f"Custom integration: {custom_integ} not configured with remote agent"
      ),
  )
  agent = siemplify.agents.get_agent_list_by_env()
  agent_check = siemplify.utils.find_key_value_in_json(
      json_data=agent,
      key="name",
      value=agent_name,
  )
  strong_assert(
      is_true=agent_check,
      success_message=(
          f"agent:{agent_name} is configured with default environment"
      ),
      failure_message="no agents found configured in default environment",
  )
  connector_id = siemplify.connectors.create_connector_for_test(
      integration=custom_integ
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_id = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["identifier"]
  siemplify.cases.ingest_alert_as_a_case_test(
      alert_id=alert_id,
      case_id=case_id,
      environment="Default Environment"
  )
  custom_action_data = siemplify.ide.get_ide_item_data_by_id(
      item_type=1,
      item_id=action_id.json(),
  )
  custom_connector_data = siemplify.ide.get_ide_item_data_by_id(
      item_type=0,
      item_id=connector_id.json()
  )
  scope = "All entities"
  action_case_id = case_id+1
  action_run = siemplify.ide.run_item_test_ide(
      integration_name=custom_integ,
      creator=custom_action_data.creator,
      action_case_id=action_case_id,
      integration_instance=int_custom_id,
      item_id=custom_action_data.id,
      item_name=custom_action_data.name,
      creator_name=custom_action_data.creator_full_name,
      script=custom_action_data.script,
      parameters=custom_action_data.parameters,
      test_scope=scope,
      item_type=1,
  )
  connector_run = siemplify.ide.run_item_test_ide(
      integration_name=custom_integ,
      creator=custom_action_data.creator,
      integration_instance=int_custom_id,
      item_id=custom_connector_data.id,
      item_name=custom_connector_data.name,
      creator_name=custom_action_data.creator_full_name,
      script=custom_connector_data.script,
      parameters=custom_connector_data.parameters,
      test_scope="",
      item_type=0,
  )
  result = action_run.result_name
  strong_assert(
      compare=result,
      to="Test!",
      success_message="Run test from IDE with agent completed successfully",
      failure_message=f"failed to run Action from IDE, retuned {result}",
  )
  conn_result = connector_run.output
  strong_assert(
      is_true="true" in conn_result,
      success_message="Run test from IDE with agent completed successfully",
      failure_message=(
          f"failed to run Connector from IDE, retuned {conn_result}"
      ),
  )


# @tags(["PUBLISHER"])
# @cleanup(modules=["cases"])
# def test_run_commerical_connector():
#   """Performs a test with a name listed below.

#   "Configure and run remote connector and action with agent from ide page"

#   Steps:
#   1) Get active agents data
#   2) verify agent is active
#   3) download commerical integration that has a connector
#   4) create instance with remote agent
#   5) create connector instnace with agent
#   6) run connector 
#   7) verify cases ingested
#   8) clean environment
#   """

#   agents_list = siemplify.publisher.get_agent_list()
#   agent_data = {}
#   for agent in agents_list.json():
#     if agent["status"] == 0:  # 0 active, 2 disabled, 1 deleted
#       agent_data = agent
#       break
#   agent_name = agent_data["name"]
#   agent_identifier = agent_data["identifier"]
#   agent_info = siemplify.publisher.get_agents_info_by_ids(
#       agent_ids=[agent_identifier]
#   )
#   agent_communication = agent_info.json()[0]["communicationStatus"]
#   # verify agent is live
#   strong_assert(
#       compare=agent_communication,
#       to=0,
#       success_message="Agent is live",
#       failure_message=(
#           f"Agent status is not 0, current status: {agent_communication}"
#       ),
#   )
#   agent_identifier = agent_data["identifier"]
#   siemplify.integrations.reinstall_integration(name="EmailV2")
#   new_instance = siemplify.integrations.create_integration_instance(
#       integration_id="EmailV2",
#   )
#   int_id = new_instance.json()["identifier"]
#   email_temp = siemplify.payloads.integrations.emailv2_integration_with_agent(
#       int_inst_id=int_id,
#       agent_name=agent_name,
#       agent_id=agent_identifier,
#   )
#   siemplify.integrations.configure_integration(
#       json_settings=email_temp,
#       integration_id=int_id,
#   )
#   run_test_with_agent = siemplify.integrations.run_integration_test(
#       integration_instance_id=int_id,
#   )
#   res = run_test_with_agent.json()["isSuccess"]
#   msg = run_test_with_agent.json()["message"]
#   soft_assert(
#       is_true=res,
#       success_message=(
#           "Test was Successfully"
#       ),
#       failure_message=f"Run Integration Test failed with message: {msg}",
#   )
#   connector = siemplify.connectors.create_emailv2_connector(
#       agent_id=agent_identifier,
#   )
#   connector_enabled = connector.json()["isEnabled"]
#   strong_assert(
#       is_true=connector_enabled,
#       success_message="Connector is enabled with status",
#       failure_message="Connector is not enabled",
#   )
#   connector_remote = connector.json()["isRemote"]
#   strong_assert(
#       is_true=connector_remote,
#       success_message="Connector instance created with Run Remotely option",
#       failure_message="Failed to create remote instance",
#   )
#   agent_id = connector.json()["agentIdentifier"]
#   strong_assert(
#       compare=agent_id,
#       to=agent_identifier,
#       success_message=(
#           "Connector instance was created with active agent identifier, "
#           f"agent id: {agent_identifier}"
#       ),
#       failure_message=(
#           "Failed to create remote instance with current agent identifier, "
#           f"agent id: {agent_id}"
#       ),
#   )
#     # disable the connector
#   dis_connector = siemplify.connectors.update_connector_instance(
#       identifier=connector.json()['identifier'],
#       is_enabled=False
#   )
#   strong_assert(
#       is_false=dis_connector.is_enabled,
#       success_message="Connector is disabled",
#       failure_message="Failed to disable the connector",
#   )
#   time.sleep(90)
#   # get all cases
#   case_id = siemplify.cases.get_last_case_id()
#   strong_assert(
#       is_true=case_id > 0,
#       success_message="Found a case",
#       failure_message="No Cases",
#   )


# @tags(["PUBLISHER"])
# def test_update_agent():
#   """Performs a "test updating agent" test.

#   Steps:
#   1) Get active agents data
#   2) Download and configure VirusTotal Integration with remote agent
#   3) Edit agent name
#   4) change log level
#   5) Disable agent
#   6) Enable agent
#   7) Delete agent
#   """
#   agents_list = siemplify.publisher.get_agent_list()
#   agent_data = {}
#   for agent in agents_list.json():
#     if agent["status"] == 0:  # 0 active, 2 disabled, 1 deleted
#       agent_data = agent
#       break
#   agent_identifier = agent_data["identifier"]
#   agent_info = siemplify.publisher.get_agents_info_by_ids(
#       agent_ids=[agent_identifier]
#   )
#   agent_communication = agent_info.json()[0]["communicationStatus"]
#   # verify agent is live
#   strong_assert(
#       compare=agent_communication,
#       to=0,
#       success_message="Agent is live",
#       failure_message=(
#           f"Agent status is not 0, current status: {agent_communication}"
#       ),
#   )
#   ag_identifier = agent_data["identifier"]
#   ag_cer = agent_data["certificate"]
#   ag_link = agent_data["accessLink"]
#   ag_name = agent_data["name"]
#   pub_name = agent_data["publisherName"]
#   ag_id = agent_data["id"]
#   pub_id = agent_data["publisherId"]
#   agent_info = siemplify.publisher.get_agents_info_by_ids(
#       agent_ids=[ag_identifier]
#   )
#   agent_communication = agent_info.json()[0]["communicationStatus"]
#   agent_ip = agent_info.json()[0]["agentIP"]
#   agent_ver = agent_info.json()[0]["agentVersion"]
#   agent_req_ver = agent_info.json()[0]["requiredSiemplifyVersion"]
#   ag_hostname = agent_info.json()[0]["agentHostname"]
#   upd_agent = siemplify.publisher.update_agent(
#       agent_id=ag_id,
#       name="new_agent_name",
#       agent_name=ag_name,
#       publisher_id=pub_id,
#       publisher_name=pub_name,
#       access_link=ag_link,
#       certificate=ag_cer,
#       agent_identifier=ag_identifier,
#       agent_version=agent_ver,
#       agent_ip=agent_ip,
#       hostname=ag_hostname,
#       required_version=agent_req_ver,
#       log_level=20,
#       is_deleted=False,
#       is_disabled=True,
#       agent_status=1,
#   )
#   # update name and check if name changed
#   strong_assert(
#       compare=upd_agent.json()["name"],
#       to="new_agent_name",
#       success_message="Agent name has been changed succesfully",
#       failure_message="Failed to change agent name",
#   )
#   # verify if log level changed
#   strong_assert(
#       compare=upd_agent.json()["loggingLevel"],  # 20 = info, 40 = error
#       to=20,
#       success_message="Agent name has been changed succesfully",
#       failure_message="Failed to change agent name",
#   )
#   # verify agent is disabled
#   agent_status = upd_agent.json()["status"]
#   strong_assert(
#       compare=agent_status,
#       to=1,
#       success_message="Agent is disabled",
#       failure_message=f"Failed to disable agent, status{agent_status}",
#   )
#   enb_agent = siemplify.publisher.update_agent(
#       agent_id=ag_id,
#       name="new_agent_name",
#       agent_name=ag_name,
#       publisher_id=pub_id,
#       publisher_name=pub_name,
#       access_link=ag_link,
#       certificate=ag_cer,
#       agent_identifier=ag_identifier,
#       agent_version=agent_ver,
#       agent_ip=agent_ip,
#       hostname=ag_hostname,
#       required_version=agent_req_ver,
#       log_level=20,
#       is_deleted=False,
#       is_disabled=False,
#       agent_status=0
#   )
#   # verify agent is enabled
#   agent_status = enb_agent.json()["status"]
#   strong_assert(
#       compare=agent_status,
#       to=0,
#       success_message="Agent is enabled",
#       failure_message=f"Failed to enable the agent, status{agent_status}",
#   )
#   # delete agent, status = 2 deleted
#   del_agent = siemplify.publisher.delete_agent(agent_id=ag_identifier)
#   strong_assert(
#       compare=del_agent.json()["status"],
#       to=2,
#       success_message="Agent is deleted",
#       failure_message=(
#           f"Failed to delete agent, status{del_agent.json()['status']}"
#       ),
#   )


# @tags(["PUBLISHER"])
# def test_update_publisher():
#   """Performs a test with a name listed below.

#   "Configure and run remote connector and action with agent from ide page"

#   Steps:
#   1) Get active publisher data
#   2) test publisher connectivity
#   3) update publisher name
#   4) update publisher communication time
#   5) delete publisher
#   8) clean environment
#   """

#   # get publisher data
#   pub_data = siemplify.publisher.get_publishers_data()
#   pub_id = pub_data.json()[0]["id"]
#   pub_name = pub_data.json()[0]["name"]
#   pub_server = pub_data.json()[0]["serverApiRoot"]
#   agent_communication = pub_data.json()[0]["agentCommunicationTimeInSeconds"]
#   pub_token = pub_data.json()[0]["apiToken"]
#   # test publisher connectivity
#   pub_connectivity = siemplify.publisher.test_publisher_connectivity(
#       publisher_id=pub_id
#   )
#   pub_status = pub_connectivity.json()["status"]
#   # status: 0 = live, 1 = error
#   strong_assert(
#       compare=pub_status,
#       to=0,
#       success_message="Publisher status is live",
#       failure_message=(
#           f"Publisher is in error mode, stauts:{pub_status}"
#       ),
#   )
#   pub_msg = siemplify.utils.find_key_in_json(
#       json_data=pub_connectivity,
#       key="message",
#   )
#   strong_assert(
#       is_true=pub_msg["message"].__contains__("Server Up"),
#       success_message="Publisher server is running",
#       failure_message=(
#           f"Publisher Server is offline, status:{pub_msg['message']}"
#       ),
#   )
#   strong_assert(
#       is_true=pub_msg["message"].__contains__("is valid"),
#       success_message="Publisher Api Token is Valid",
#       failure_message=(
#           f"Publisher Token is invalid, status:{pub_msg['message']}"
#       ),
#   )
#   rand_name = get_random_string(5)
#   upt_pub = siemplify.publisher.update_publisher(
#       agent_run_time=61,
#       api_token=pub_token,
#       publisher_id=pub_id,
#       name=pub_name+rand_name,
#       server_api=pub_server,
#   )
#   new_pub = siemplify.publisher.get_publishers_data()
#   strong_assert(
#       compare=upt_pub.json()["name"],
#       to=new_pub.json()[0]["name"],
#       success_message="Publisher name has been changed successfully",
#       failure_message=(
#           f"Publisher name is not correct: {new_pub.json()[0]['name']}"
#       ),
#   )
#   comm_time = upt_pub.json()["agentCommunicationTimeInSeconds"]
#   strong_assert(
#       compare=comm_time,
#       to=61,
#       success_message="Publisher agent run time has been changed successfully",
#       failure_message=(
#           f"Publisher run time is not corret: {comm_time}"
#       ),
#   )

# reported bug WEB-32147
#   del_pub = siemplify.publisher.delete_publisher(publisher_id=pub_id)
#   strong_assert(
#       compare=del_pub.json()['ErrorCode'],
#       to=2000,
#       success_message="Publisher agent run time has been changed successfully",
#       failure_message=(
#           f"Publisher run time is not corret: {upt_pub.json()['agentCommunicationTimeInSeconds']}"
#       ),
#   )
