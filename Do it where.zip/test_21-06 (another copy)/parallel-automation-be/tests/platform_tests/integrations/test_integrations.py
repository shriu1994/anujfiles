"""Module for testing Siemplify integrations.
"""
from siemplify_utils import siemplify
from siemplify_utils.ide import export_ide_integration
from siemplify_utils.ide import find_ide_item_by_integration_and_name
from siemplify_utils.ide import find_integration_details
from siemplify_utils.ide import import_ide_integration_package
from siemplify_utils.integrations import delete_custom_integration
from siemplify_utils.integrations import delete_integration
from source import enums
from source.enums import IdeItemType
from source.utils import strong_assert
from tests.conftest import tags


@tags(["SEQUENCE", "INTEGRATIONS"])
def test_export_import_commercial_integration_with_custom_manager():
  """Testing custom manager in official integration.

  This function tests the scenario where we add a custom manager to
  a commercial integration and export it. Export zip should contain
  the entire manager list, including official and custom.
  Steps:
  1) Install integration
  2) Create custom manager
  3) Delete commercial integration
  4) Update custom manager X times
  5) Install commercial integration
  6) Export Integration
  7) Commercial integration
  8) Delete custom integration
  9) Import integration
  10) Assert
  """
  integration_name = "Alexa"

  # Install commercial integration
  siemplify.integrations.install_integration(
      name=integration_name,
      version=0
  )
  integration = find_integration_details(
      integration_identifier=integration_name
  )
  strong_assert(
      # Integration exists and not custom
      is_true=isinstance(integration, dict) and
      not integration.get("isCustomIntegration"),
      success_message=f"Commercial integration {integration_name} installed",
      failure_message=(
          f"Commercial integration {integration_name} NOT installed"
      ),
  )
  # Add custom manager
  script = """print("Hello World")"""
  custom_manager = siemplify.ide.add_custom_ide_item(
      integration=integration_name,
      script=script,
      item_type=enums.IdeItemType.MANAGER,  # Manager
  )
  custom_manager_name = custom_manager.name
  custom_manager_id = custom_manager.id
  # Delete commercial integration
  delete_integration(
      name=integration_name
  )

  # Update custom manager for that integartions
  for _ in range(0, 5):
    script = script + "!"
    custom_manager_id = siemplify.ide.add_custom_ide_item(
        integration=integration_name,
        script=script,
        item_type=enums.IdeItemType.MANAGER,  # Manager
        action_id=custom_manager_id
    ).id

  strong_assert(
      is_true=find_ide_item_by_integration_and_name(
          integration_identifier=integration_name,
          item_name=custom_manager_name
      ),
      success_message="Custom manager installed properly",
      failure_message="Custom manager not installed properly",
  )

  # Install commercial integration
  siemplify.integrations.install_integration(
      name=integration_name,
      version=0
  )

  # Get original managers
  original_managers = []
  integration = find_integration_details(
      integration_identifier=integration_name
  )
  for item in integration.get("cards"):
    if item.get("type") == IdeItemType.MANAGER:
      original_managers.append(item.get("name"))

  # Export integration
  export_response = export_ide_integration(
      integration_name=integration_name
  )

  # Delete integration
  delete_integration(
      name=integration_name
  )
  integration = find_integration_details(
      integration_identifier=integration_name
  )
  strong_assert(
      # integration exists and custom
      is_true=isinstance(integration, dict) and
      integration.get("isCustomIntegration"),
      success_message="Commercial integration deleted successfully",
      failure_message="Failed deleting commercial integration",
  )

  # Delete custom integration
  delete_custom_integration(
      integration_name=integration_name
  )
  integration = find_integration_details(
      integration_identifier=integration_name
  )
  strong_assert(
      is_false=integration,
      success_message="Custom integration deleted successfully",
      failure_message="Failed deleting custom integration",
  )

  # Import package
  import_ide_integration_package(
      integration_identifier=integration_name,
      package_data=export_response.package_zip
  )

  # Verify integration installed, all items are custom,
  # custom manger and commercial manager exist and actions exist
  integration = find_integration_details(
      integration_identifier=integration_name
  )
  # Integration exists and custom
  strong_assert(
      is_true=isinstance(integration, dict)
      and integration.get("isCustomIntegration"),
      success_message="Imported integration successfully",
      failure_message="Failed to import integration"
  )
  new_managers = []
  for item in integration.get("cards"):
    if item.get("type") == IdeItemType.MANAGER:
      new_managers.append(item.get("name"))

  for original_manager in original_managers:
    strong_assert(
        is_true=original_manager in new_managers,
        failure_message="Missing one (or more) original managers after import",
        success_message="All original managers are imported successfully"
    )
  if "test_custom_manager_Alexa" in new_managers:
    new_managers.remove("test_custom_manager_Alexa")
  for new_manager in new_managers:
    strong_assert(
        is_true=new_manager in original_managers,
        failure_message="One or more installed managers "
                        "was not in the original integration "
                        "nor is the custom added",
        success_message="New manager that was not "
                        "present during export is imported",
        extra_info=new_manager,
    )
