"""Module for testing Siemplify views module.
"""
from siemplify_utils import siemplify
from source.utils import soft_assert
from tests.conftest import tags


@tags(["DASHBOARDS", "PARALLEL"])
def test_get_all_widgets():
  """Performs a "Get all widgets" test.

  Steps:
  1) Fetch dashboard widgets
  2) Verify the widget list is not empty
  """
  widgets_response = siemplify.dashboards.get_dashboard_widgets(dashboard_id=1)
  widgets_json = widgets_response.response_json
  soft_assert(
      is_true=widgets_json,
      success_message="List of widgets is not empty",
      failure_message="List of widgets is empty",
  )


@tags(["DASHBOARDS", "PARALLEL"])
def test_cases_widget():
  """Performs a "Test cases widget".

  Steps:
  1) Simulate all OOTB cases
  2) Create a pie chart widget of cases grouped by analyst
  3) Verify that widget has the needed number of cases
  4) Close all cases
  5) Delete all widgets
  """
  dashboard = siemplify.dashboards.create_dashboard_for_test()
  dash_id = dashboard.id
  widget = siemplify.dashboards.create_widget(
      dashboard=dash_id,
      case_status_filter=["open"],
  )
  siemplify.cases.simulate_cases_for_test()
  number_of_cases = siemplify.dashboards.wait_for_widget_cases_value(
      widget=widget,
      value=7,
  )
  soft_assert(
      compare=number_of_cases,
      to=7,
      success_message="Received correct number of cases",
      failure_message="Check failed: received wrong number of cases",
      extra_info=f"Expected: 7. Received: {number_of_cases}"
  )
