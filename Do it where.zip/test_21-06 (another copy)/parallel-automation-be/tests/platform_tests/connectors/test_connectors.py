"""Module for testing Siemplify connectors module.
"""
import time
from decorators.decorators import integrations_required
from payloads.connectors import generate_custom_connector_param
from payloads.connectors import generate_param_for_connector_instance
from resources.strings import strings
from siemplify_utils import siemplify
from source import enums
from source.utils import add_created_item_to_test
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags


@tags(["CONNECTORS", "BUG-286782342"])
def test_custom_connector():
  """Preforms a "New custom connector" test.

  Steps:
  1) Create custom connector
  2) Create connector instance and enable it
  3) verify ingested alert created a case
  """
  name = siemplify.connectors.create_connector_for_test().name
  ide_items = siemplify.ide.get_all_ide_items()
  siemplify_items = siemplify.utils.find_key_value_in_json(
      json_data=ide_items,
      key="identifier",
      value="Siemplify",
  )
  item_cards = siemplify.utils.find_key_in_json(
      json_data=siemplify_items,
      key="cards",
  )
  connector_found = any(
      item.get("name", name) for item in item_cards
  )
  soft_assert(
      is_true=connector_found,
      success_message="Connector found under Siemplify",
      failure_message="Connector not found under Siemplify",
  )
  custom_ide_items = siemplify.utils.find_key_value_in_json(
      json_data=item_cards,
      key="isCustom",
      value=True,
  )
  connector_exists = siemplify.utils.find_key_value_in_json(
      json_data=custom_ide_items,
      key="name",
      value=name,
  )
  connector = custom_ide_items if connector_exists else None
  soft_assert(
      is_true=connector,
      success_message="Connector is under Siemplify custom items",
      failure_message="Connector is not under Siemplify custom items",
  )
  siemplify.connectors.create_connector_instance_for_test(connector_name=name)
  case_check = siemplify.cases.wait_for_case_for_test(data="Example_Rule_1")
  soft_assert(
      is_true=case_check,
      success_message="Connector ingested alerts into the system",
      failure_message="Connector did not ingest alerts into the system",
      extra_info=case_check,
  )


@tags(["CONNECTORS", "ENVIRONMENTS", "PARALLEL"])
def test_multiple_environments_ingestion():
  """Preforms a "multiple environments connectors ingestion" test.

  Steps:
  1) Create custom connector
  2) Create 2 environments
  2) Create a connector instance on each environment and enable it
  3) verify ingestion to both environments
  """
  env1 = siemplify.environments.create_environment_for_test().name
  env2 = siemplify.environments.create_environment_for_test().name
  connector_name = siemplify.connectors.create_connector_for_test().name
  siemplify.connectors.create_custom_connector_instance(
      connector_name=connector_name,
      instance_display_name=f"{connector_name}_1",
      environment=env1,
  )
  siemplify.connectors.create_custom_connector_instance(
      connector_name=connector_name,
      instance_display_name=f"{connector_name}_2",
      environment=env2,
  )
  env1_found = siemplify.cases.wait_for_case_in_environments(
      environments=[env1],
      data="Example_Rule_1",
  )
  env2_found = siemplify.cases.wait_for_case_in_environments(
      environments=[env2],
      data="Example_Rule_1",
  )
  soft_assert(
      is_true=env1_found,
      success_message="Case was ingested to testEnv1 environment successfully",
      failure_message="No case was ingested to testEnv1 environment",
  )
  strong_assert(
      is_true=env2_found,
      success_message="Case was ingested to testEnv2 environment successfully",
      failure_message="No case was ingested to testEnv2 environment",
  )


@tags(["CONNECTORS", "PARALLEL"])
def test_disable_enable_connector():
  """Preforms a "disable enable connector" test.

  Steps:
  1) Create custom connector
  2) Create enabled connector instance
  2) Count cases
  3) Disable the connector
  4) Count cases again, and verify none were added
  5) Enable the connector
  6) Count cases again, and verify some were added
  """
  connector_name = siemplify.connectors.create_connector_for_test().name
  connector_inst = siemplify.connectors.create_connector_instance_for_test(
      connector_name=connector_name
  ).identifier
  siemplify.cases.wait_for_case_for_test(data="Example_Rule_1")
  siemplify.connectors.update_connector_instance(
      identifier=connector_inst,
      is_enabled=False,
  )
  time.sleep(5)
  cases_before_disabling = siemplify.cases.get_cases_for_test().total_count
  time.sleep(15)
  cases_after_disabling = siemplify.cases.get_cases_for_test().total_count
  check_count = cases_after_disabling <= cases_before_disabling
  soft_assert(
      is_true=check_count,
      success_message="New cases were not added after connector was disabled",
      failure_message="New cases added after connector was disabled",
  )
  siemplify.connectors.update_connector_instance(
      identifier=connector_inst,
      is_enabled=True,
  )
  after_enabling = siemplify.cases.wait_for_case_count_for_test(
      more_than=cases_after_disabling,
  )
  check_count = after_enabling > cases_after_disabling
  soft_assert(
      is_true=check_count,
      success_message="Cases were added after enabling the connector",
      failure_message="No cases were added after enabling the connector",
  )


@tags(["CONNECTORS", "SEQUENCE"])
@integrations_required(integrations=["CSV"])
def test_two_different_connectors():
  """Tests 2 different connectors, custom and commerical, running togther.

  Steps:
  1) Add custom job, which generates csv file for the commerical connector
  2) Create custom connector
  3) Create connector instance and enable it
  4) Download csv integration
  5) Add a connector and point it to the csv file path
  6) Verify ingested alerts created a case
  """

  # create custom integration with custom action
  custom_id_int = siemplify.integrations.create_custom_integration().identifier
  job = siemplify.ide.add_custom_ide_item(
      integration=custom_id_int,
      item_type=enums.IdeItemType.JOB,
      script=siemplify.resources.strings.CREATE_CSV_JOB,
  )
  ide_items = siemplify.ide.get_all_ide_items()
  custom_items = siemplify.utils.find_key_value_in_json(
      json_data=ide_items,
      key="identifier",
      value=custom_id_int,
  )
  item_cards = siemplify.utils.find_key_in_json(
      json_data=custom_items,
      key="cards",
  )
  item_id = job.id
  running_job = siemplify.jobs.add_running_job(
      item_id=item_id,
      integration_name=custom_id_int,
  )
  uniq_id = running_job.identifier
  item_id = running_job.id
  run_job = siemplify.jobs.run_job(
      item_id=item_id,
      integration_name=custom_id_int,
      job_name=running_job.name,
      uniq_id=uniq_id
  )
  strong_assert(
      is_true=run_job,
      success_message="Run completed succefully",
      failure_message="Failed to run a job",
  )
  siemplify.connectors.create_connector_instance_for_test(
      connector_name="CSV Connector",
      is_custom=False,
      integration_name="CSV",
      integration_version=27,
      device_product_field="device_product",
      event_name_field="name",
      parameters="use_csv_params",
    )
  rule_found = siemplify.cases.wait_for_case_for_test(data="CSV")
  soft_assert(
      is_true=rule_found,
      success_message="Commerical Connector ingested alerts into the system",
      failure_message="Commerical Connector didn't ingest alerts",
  )
  con_name = siemplify.connectors.create_connector_for_test().name
  ide_items = siemplify.ide.get_all_ide_items()
  siemplify_items = siemplify.utils.find_key_value_in_json(
      json_data=ide_items,
      key="identifier",
      value="Siemplify"
  )
  item_cards = siemplify.utils.find_key_in_json(
      json_data=siemplify_items,
      key="cards",
  )
  connector_found = any(
      item.get("name", con_name) for item in item_cards
  )
  soft_assert(
      is_true=connector_found,
      success_message="Connector found under Siemplify",
      failure_message="Connector not found under Siemplify",
  )
  custom_ide_items = siemplify.utils.find_key_value_in_json(
      json_data=item_cards,
      key="isCustom",
      value=True,
  )
  connector_exists = siemplify.utils.find_key_value_in_json(
      json_data=custom_ide_items,
      key="name",
      value=con_name,
  )
  connector = custom_ide_items if connector_exists else None
  soft_assert(
      is_true=connector,
      success_message="Connector is under Siemplify custom items",
      failure_message="Connector is not under Siemplify custom items",
  )
  siemplify.connectors.create_connector_instance_for_test(
      connector_name=con_name,
  )
  rule_found = siemplify.cases.wait_for_case_for_test(data="Example_Rule_1")
  soft_assert(
      is_true=rule_found,
      success_message="Custom Connector ingested alerts into the system",
      failure_message="Custom Connector did not ingest alerts into the system",
    )
  siemplify.jobs.delete_all_custom_jobs()


@tags(["CONNECTORS", "ENVIRONMENTS", "SEQUENCE"])
def test_envionment_alias_ingestion():
  """Test verifies entities are internal if ingested through enviroment alias.

  Steps:
  1) Define Environment with alias.
  2) Configure network with internal address.
  3) Create manual connector with specific parameters.
  4) Configure connector instance.
  5) Get event details for mapping.
  6) Set Ontology Maapping.
  7) Check new cases generated.
  """
  alias_name = "TestAlias"
  env_name = siemplify.environments.create_environment_for_test(
    env_aliases=[alias_name]
  ).name
  siemplify.networks.add_network_to_environments(
      name="Test_Network", address="10.0.0.0/8", environments=[env_name]
  )
  env_field_name = generate_custom_connector_param(
      param_name="Environment Field Name",
      description="Environment Field name",
      value=None,
  )
  env_alias_name = generate_custom_connector_param(
      is_mandtory=True,
      param_name="Environment Name or Alias",
      value=env_name,
  )
  env_regex = generate_custom_connector_param(
      param_name="Environment Regex Pattern",
      value="",
      description="Select environment through regex",
  )
  params = [
      env_field_name,
      env_alias_name,
      env_regex,
  ]
  siemplify.connectors.create_custom_connector(
      name="Test Alias Connector",
      integration="GoogleChronicle",
      description=(
          "Connector to test Environment field name parameter usage behavior"
          " with environment aliases."
      ),
      event_field_name=None,
      product_field_name=None,
      add_parameters=params,
      script=strings.TEST_ALIAS_CUSTOM_CONNECTOR_SCRIPT,
  )
  ins_env_field = generate_param_for_connector_instance(
      is_advanced=True,
      param_name="Environment Field Name",
      value="TestEnvAlias",
      description="Environment Field name",
  )
  ins_env_alias = generate_param_for_connector_instance(
      is_mandtory=True,
      param_name="Environment Name or Alias",
      value="TestAlias",
  )
  ins_env_regex = generate_param_for_connector_instance(
      is_advanced=True,
      param_name="Environment Regex Pattern",
      value="",
      description="Select environment through regex",
  )
  ins_param = [ins_env_field, ins_env_alias, ins_env_regex]
  siemplify.connectors.create_connector_instance_for_test(
      connector_name="Test Alias Connector",
      description=(
          "Connector to test Environment field name parameter usage behavior"
          " with environment aliases."
      ),
      integration_name="GoogleChronicle",
      parameters=ins_param,
      is_enabled=True,
  )
  siemplify.cases.wait_for_alert_count_in_environments(
      environments=env_name, count=1
  )
  case_id = siemplify.cases.get_last_case_id_in_environments(
      environments=[env_name]
  )
  events = siemplify.cases.get_alert_events(case=case_id)
  event = events[0]
  siemplify.ontology.set_field_mapping(
      source=event.source_system_name,
      product=event.product,
      field_name="SourceAddress",
      primary_field_match_term="SourceAddress",
  )
  cases = siemplify.cases.get_cases_in_environments(environments=[env_name])
  case_count = cases.total_count
  siemplify.cases.wait_for_case_count_in_environments(
      environments=env_name, count=case_count + 1
  )
  case_id = siemplify.cases.get_last_case_id_in_environments(
      environments=[env_name]
  )
  entities = siemplify.entities.get_case_entities(case_id=case_id)
  is_internal = siemplify.utils.find_key_in_json(
      json_data=entities, key="isInternal"
  )
  strong_assert(
      is_true=is_internal,
      success_message="Entities are internal",
      failure_message="Entities are not internal",
  )
