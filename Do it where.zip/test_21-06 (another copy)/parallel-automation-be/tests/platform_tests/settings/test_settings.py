"""Module for testing Advanced Settings Module.
"""

from siemplify_utils import siemplify
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags
from source import enums


@tags(["SETTINGS", "SEQUENCE"])
def test_update_localization_settings():
  """Performs a test with a name listed below.

  "Update the Time zone in Localization"

  Steps:
  1) Update the Time Zone
  2) Verify the response code.
  """
  req = siemplify.settings.add_update_localization(zone_id="America/Belize")
  strong_assert(
      compare=req.status_code,
      to=200,
      success_message="Time Zone update was successful",
      failure_message="Time Zone update was not successful"
  )


@tags(["SETTINGS", "SEQUENCE"])
def test_email_settings():
  """Performs a test with a name listed below.

  "Test and Save Email Settings"

  Steps:
  1) Test entered email settings .
  2) Save the new settings.
  """
  test = siemplify.settings.test_email_settings()
  check = siemplify.utils.find_key_value_in_json(
      json_data=test,
      key="isSuccessful",
      value=True,
  )
  strong_assert(
      is_true=check,
      success_message="Test Email settings was successful",
      failure_message="Test Email settings was not successful",
  )
  siemplify.settings.save_email_settings()
  status = siemplify.settings.get_email_settings()
  customSettings = siemplify.utils.find_key_in_json(
    json_data=status.json(),
    key="customSettings"
  )
  data = siemplify.utils.find_key_in_json(
      json_data=customSettings,
      key="senderDisplayName",
  )
  strong_assert(
      compare=data,
      to="siemplifytest",
      success_message="Update Email settings was successful",
      failure_message="Update Email settings was not successful"
  )