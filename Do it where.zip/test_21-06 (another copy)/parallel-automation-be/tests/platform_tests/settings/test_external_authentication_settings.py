"""Module for testing Siemplify external authentication settings module.
"""
import uuid
from pathlib import Path
from siemplify_utils import siemplify
from siemplify_utils import external_auth_settings as auth_settings
from siemplify_utils.external_auth_settings import Base64SettingWrapper
from siemplify_utils.external_auth_settings import ExternalProvider
from source import enums
from source.utils import strong_assert
from tests.conftest import tags

# metadata_base64 = open(
#     "./tests/platform_tests/settings/metadata_base64.txt", "r").read()
# certificate_base64 = open(
#     "./tests/platform_tests/settings/certificate_base64.txt", "r").read()

metadata_base64 = open(
    Path(__file__).with_name("metadata_base64.txt"), "r"
).read()
certificate_base64 = open(
    Path(__file__).with_name("certificate_base64.txt"), "r"
).read()


@tags(["SETTINGS", "SEQUENCE", "EXTERNALAUTH"])
def test_create_new_external_authentication_settings():
  """Performs a test with a name listed below.

  "Check external authentication settings created correctly"

  Steps:
  1) Create a new external authentication setting using auxiliary functions.
  2) Call get external authentication settings
  3) verify a new setting was created correctly.
  """

  expected_setting = ExternalProvider(
      provider_id="temoprary",
      provider_name="okta2",
      identity_provider_type=enums.IdentityProviderType.OKTA,
      remote_entity_id_url="http://www.okta.com/exk7hamvfwwzmrS4Z4x7",
      local_entity_id_url="https://localhost:8443/Saml2/",
      metadata=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.METADATA,
          name="metadata.xml",
          content_base64=metadata_base64),
      public_certificate=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.PUBLIC_CERTIFICATE,
          name="certificate.cert",
          content_base64=certificate_base64),
      default_environments=[],
      default_license_type=None,
      default_soc_role_id=None,
  )

  new_setting_response = auth_settings.create_external_authentication_settings(
      provider_name=expected_setting.provider_name,
      identity_provider_type=expected_setting.identity_provider_type,
      remote_entity_id_url=expected_setting.remote_entity_id_url,
      local_entity_id_url=expected_setting.local_entity_id_url,
      metadata=expected_setting.metadata,
      public_certificate=expected_setting.public_certificate
  )

  strong_assert(
      compare=len(new_setting_response.external_providers),
      to=1,
      success_message="Successfully created new external auth settings",
      failure_message="Failed to create new external auth settings",
  )

  new_setting = new_setting_response.external_providers[0]
  expected_setting.provider_id = new_setting.provider_id

  strong_assert(
      compare=new_setting.to_json(),
      to=expected_setting.to_json(),
      success_message="Created expected external auth setting are equal",
      failure_message="Created expected external auth setting are not equal",
  )


@tags(["SETTINGS", "SEQUENCE", "EXTERNALAUTH"])
def test_delete_external_authentication_settings():
  """Performs a test with a name listed below.

  "Delete external authentication settings"

  Steps:
  1) Create a new external authentication setting using auxiliary functions.
  2) Call get external authentication settings
  3) verify a new setting was created correctly.
  4) delete the settings and make sure it is deleted
  """

  expected_setting = ExternalProvider(
      provider_id="temoprary",
      provider_name="okta2",
      identity_provider_type=enums.IdentityProviderType.OKTA,
      remote_entity_id_url="http://www.okta.com/exk7hamvfwwzmrS4Z4x7",
      local_entity_id_url="https://localhost:8443/Saml2/",
      metadata=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.METADATA,
          name="metadata.xml",
          content_base64=metadata_base64),
      public_certificate=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.PUBLIC_CERTIFICATE,
          name="certificate.cert",
          content_base64=certificate_base64),
      default_environments=[],
      default_license_type=None,
      default_soc_role_id=None,
  )

  new_setting_response = auth_settings.create_external_authentication_settings(
      provider_name=expected_setting.provider_name,
      identity_provider_type=expected_setting.identity_provider_type,
      remote_entity_id_url=expected_setting.remote_entity_id_url,
      local_entity_id_url=expected_setting.local_entity_id_url,
      metadata=expected_setting.metadata,
      public_certificate=expected_setting.public_certificate
  )

  strong_assert(
      is_true=len(new_setting_response.external_providers) == 1,
      success_message="Successfully created new external auth settings",
      failure_message="Failed to create new external auth settings",
  )

  new_setting = new_setting_response.external_providers[0]
  expected_setting.provider_id = new_setting.provider_id

  strong_assert(
      compare=new_setting.to_json(),
      to=expected_setting.to_json(),
      success_message="Created expected external auth setting are equal",
      failure_message="Created expected external auth setting are not equal",
  )

  auth_settings.delete_external_authentication_settings(
      expected_setting.provider_id)

  all_settings = auth_settings.get_all_external_authentication_settings()

  strong_assert(
      compare=len(all_settings.external_providers),
      to=0,
      success_message="Successfully deleted external authentication setting",
      failure_message="Failed deleting external authentication setting",
  )


@tags(["SETTINGS", "SEQUENCE", "EXTERNALAUTH"])
def test_update_external_authentication_settings():
  """Performs a test with a name listed below.

  "Check external authentication settings updated correctly"

  Steps:
  1) Create a new external authentication setting using auxiliary functions.
  2) Call get external authentication settings
  3) Verify a new setting was created correctly.
  4) Update first name attribute.
  5) Verify change was successful.
  """

  expected_setting = ExternalProvider(
      provider_id="temoprary",
      provider_name="okta2",
      identity_provider_type=enums.IdentityProviderType.OKTA,
      remote_entity_id_url="http://www.okta.com/exk7hamvfwwzmrS4Z4x7",
      local_entity_id_url="https://localhost:8443/Saml2/",
      metadata=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.METADATA,
          name="metadata.xml",
          content_base64=metadata_base64),
      public_certificate=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.PUBLIC_CERTIFICATE,
          name="certificate.cert",
          content_base64=certificate_base64),
      default_environments=[],
      default_license_type=None,
      default_soc_role_id=None,
  )

  new_setting_response = auth_settings.create_external_authentication_settings(
      provider_name=expected_setting.provider_name,
      identity_provider_type=expected_setting.identity_provider_type,
      remote_entity_id_url=expected_setting.remote_entity_id_url,
      local_entity_id_url=expected_setting.local_entity_id_url,
      metadata=expected_setting.metadata,
      public_certificate=expected_setting.public_certificate
  )

  strong_assert(
      is_true=len(new_setting_response.external_providers) == 1,
      success_message="Successfully created new external auth settings",
      failure_message="Failed to create new external auth settings",
  )

  new_setting = new_setting_response.external_providers[0]
  expected_setting.provider_id = new_setting.provider_id

  strong_assert(
      compare=new_setting.to_json(),
      to=expected_setting.to_json(),
      success_message="Created & expected external auth setting are equal",
      failure_message="Created & expected external auth setting are not equal",
  )

  expected_setting.first_name_attribute = "firstName"

  updated_setting = auth_settings.update_external_authentication_settings(
      expected_setting)

  strong_assert(
      compare=updated_setting.external_providers[0].first_name_attribute,
      to="firstName",
      success_message="Successfully updated external authentication setting",
      failure_message="Failed updating external authentication setting",
  )


@tags(["SETTINGS", "SEQUENCE", "EXTERNALAUTH"])
def test_update_on_non_existing_external_authentication_settings():
  """Performs a test with a name listed below.

  "Check update failed on non-existing authentication settings"

  Steps:
  1) Call update on non-existing external authentication settings
  4) Verify change failed.
  """

  expected_external_authentication_setting = ExternalProvider(
      provider_id=str(uuid.uuid4()),
      provider_name="okta2",
      identity_provider_type=enums.IdentityProviderType.OKTA,
      remote_entity_id_url="http://www.OKTA.com/exk7hamvfwwzmrS4Z4x7",
      local_entity_id_url="https://localhost:8443/Saml2/",
      metadata=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.METADATA,
          name="metadata.xml",
          content_base64=metadata_base64),
      public_certificate=Base64SettingWrapper(
          saml_settings_file_type=enums.SamlSettingsFileType.PUBLIC_CERTIFICATE,
          name="certificate.cert",
          content_base64=certificate_base64),
      default_environments=[],
      default_license_type=None,
      default_soc_role_id=None,
  )
  siemplify.utils.next_request_should_fail()
  updated_setting = auth_settings.update_external_authentication_settings(
      expected_external_authentication_setting)
  strong_assert(
      compare=updated_setting.status_code,
      to=400,
      success_message="Successfully updated external authentication setting",
      failure_message="Failed updating external authentication setting",
  )
