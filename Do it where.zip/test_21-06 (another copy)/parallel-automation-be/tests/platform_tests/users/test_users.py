"""Module for testing Siemplify users module.
"""
import pytest
from siemplify_utils import siemplify
from source import enums
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags


@tags(["USERS", "PARALLEL"])
def test_new_user_new_role():
  """Preforms a "New user and role assigned cases" test.

  Steps:
  1) Create role
  2) Create user with newly created role
  3) Simulate case and assign to new role
  4) Login as new user and verify simulated case is in assigned cases
  """
  role_id = siemplify.users.create_role_for_test().id
  user = siemplify.users.create_user_for_test(role=role_id)
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.assign_case_to_user(
      case_id=case_id,
      user_id=user.username,
  )
  siemplify.authentication.log_in_for_test(
      email=user.email,
      password="Password1!",
  )
  new_user_cases = siemplify.cases.get_assigned_cases_for_test()
  objects_list = siemplify.utils.find_key_in_json(
      json_data=new_user_cases,
      key="objectsList",
  )
  check_id = siemplify.utils.find_key_in_json(
      json_data=objects_list,
      key="caseId",
  )
  strong_assert(
      compare=check_id,
      to=case_id,
      success_message=f"Case {case_id} showed in new user's assigned cases",
      failure_message=(
          f"Case {case_id} did not show in new user's assigned cases"
      ),
  )


@tags(["USERS", "PARALLEL"])
def test_two_users_and_two_roles():
  """Preforms a "New user and role assigned cases" test.

  Steps:
  1) Create first role
  2) Create first user with newly created first role
  3) Create second role
  4) Create second user with new second role
  5) Simulate case and assign to first role
  6) Simulate case and assign to second role
  7) Login as first user and verify user sees only assigned to its role case
    and doesn't see case assigned to second user
  8) Login as second user and verify user sees only assigned to its role case
    and doesn't see case assigned to first user
  """
  role_1 = siemplify.users.create_role_for_test()
  user_1 = siemplify.users.create_user_for_test(role=role_1.id)
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_role_1_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.assign_case_to_user(
      case_id=case_role_1_id,
      user_id=f"@{role_1.name}")
  role_2 = siemplify.users.create_role_for_test()
  user_2 = siemplify.users.create_user_for_test(role=role_2.id)
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_role_2_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.assign_case_to_user(
      case_id=case_role_2_id,
      user_id=f"@{role_2.name}",
  )
  # Login as first user and verify the case ID's
  siemplify.authentication.log_in_for_test(
      email=user_1.email,
      password="Password1!",
  )
  role1_assigned_cases = siemplify.cases.get_assigned_cases_for_test()
  role1_objects_list = siemplify.utils.find_key_in_json(
      json_data=role1_assigned_cases,
      key="objectsList",
  )
  check_case1_role1 = siemplify.utils.find_key_value_in_json(
      json_data=role1_objects_list,
      key="caseId",
      value=case_role_1_id,
  )
  check_case2_role1 = siemplify.utils.find_key_value_in_json(
      json_data=role1_objects_list,
      key="caseId",
      value=case_role_2_id,
  )
  soft_assert(
      is_true=check_case1_role1,
      success_message="Case #1 found in cases assigned to user #1",
      failure_message="Case #1 not found in cases assigned to user #1",
  )
  soft_assert(
      is_false=check_case2_role1,
      success_message="Case #2 not found in cases assigned to user #1",
      failure_message="Case #2 found in cases assigned to user #1",
  )
  # Login as second user and verify the case ID's
  siemplify.authentication.log_in_for_test(
      email=user_2.email,
      password="Password1!",
  )
  role2_assigned_cases = siemplify.cases.get_assigned_cases_for_test()
  role2_objects_list = siemplify.utils.find_key_in_json(
      json_data=role2_assigned_cases,
      key="objectsList",
  )
  check_case2_role2 = siemplify.utils.find_key_value_in_json(
      json_data=role2_objects_list,
      key="caseId",
      value=case_role_2_id,
  )
  check_case1_role2 = siemplify.utils.find_key_value_in_json(
      json_data=role2_objects_list,
      key="caseId",
      value=case_role_1_id,
  )
  soft_assert(
      is_true=check_case2_role2,
      success_message="Case #2 found in cases assigned to user #2",
      failure_message="Case #2 not found in cases assigned to user #2",
  )
  soft_assert(
      is_false=check_case1_role2,
      success_message="Case #1 not found in cases assigned to user #2",
      failure_message="Case #1 found in cases assigned to user #2",
  )


@tags(["USERS", "PARALLEL"])
def test_verify_reader_access():
  """Performs a "Create Reader User Verify Access" test.

  Steps:
  1) Create a playbook
  2) Create a new user with Reader permissions
  3) Verify the user was created
  4) Log in as new user and try editing a playbook
  5) Verify editing is not permitted
  """
  playbook = siemplify.playbooks.create_playbook_for_test()
  user_1 = siemplify.users.create_user_for_test(permission_group="Readers")
  users = siemplify.users.get_users()
  user_found = siemplify.utils.find_key_value_in_json(
      json_data=users.objects_list,
      key="firstName",
      value=user_1.first_name,
  )
  soft_assert(
      is_true=user_found,
      success_message="Test user found",
      failure_message="Test user not found",
  )
  siemplify.authentication.log_in_for_test(
      email=user_1.email,
      password="Password1!",
  )
  siemplify.utils.next_request_should_fail()
  update = siemplify.playbooks.update_playbook(
      playbook_identifier=playbook.identifier,
      playbook_description="Updated!",
  )
  strong_assert(
      compare=update.status_code,
      to=403,
      success_message="Couldn't edit the playbook without permission",
      failure_message="Edited a playbook without permission",
  )


@tags(["USERS", "PARALLEL"])
def test_create_delete_user():
  """Performs a "Delete User And Verify" test.

  Steps:
  1) Create a user
  2) Verify the user was created
  3) Log in as the new user and verify it succeeds
  4) Log in as default user
  5) Delete the created user
  6) Try to log in as deleted user and verify authentication fails
  """
  new_user = siemplify.users.create_user_for_test()
  users = siemplify.users.get_users()
  user_found = siemplify.utils.find_key_value_in_json(
      json_data=users.objects_list,
      key="firstName",
      value=new_user.first_name
  )
  soft_assert(
      is_true=user_found,
      success_message="Test user found",
      failure_message="Test user not found",
      extra_info=user_found,
  )
  response = siemplify.authentication.log_in_for_test(
      email=new_user.email,
      password="Password1!",
  )
  soft_assert(
      compare=response.status_code,
      to=200,
      success_message="Test user can log in",
      failure_message="Test user can not log in",
  )
  siemplify.authentication.relog_for_test()
  siemplify.users.delete_user(username=new_user.username)
  with pytest.raises(AssertionError) as error:
    siemplify.authentication.log_in_for_test(
        email=new_user.email,
        password="Password1!",
    )
  received = str(error)
  expected = "Authentication failed!"
  strong_assert(
      is_true=expected in received,
      success_message="Couldn't log in as deleted user",
      failure_message="Logged in as deleted user",
  )
