"""Module for testing Siemplify Data Retension module.
"""
from siemplify_utils import siemplify
from source import enums
from source.utils import strong_assert
from tests.conftest import tags


@tags(["RETENTION", "SEQUENCE"])
def test_default_data_retention():
  """Validate "Default data retention time: 3 month" test.
  Steps:
  1) Simulate a case
  2) Validate the default data retention time.
  3) Trigger the data retention.
  4) Validate case present in case queue after triggering the data retention.
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  last_case = siemplify.cases.get_last_case_details_for_test()
  required_title = "Virus Found Or security risk found"
  strong_assert(
      compare=last_case.name,
      to=required_title,
      success_message=f"Correct case title received: {required_title}",
      failure_message=(
          f"Wrong title received. Expected: {required_title}, ",
          f"received: {last_case.name}"
      ),
  )
  response = siemplify.retention.get_retention_configuration()
  strong_assert(
      compare=response.retention_period,
      to=3,
      success_message=(
          f"Default retention period is  {response.retention_period} months"
          ),
      failure_message=(
          "Wrong default retention period. Expected 3 months. "
          f"Received {response.retention_period} months"
      ),
  )
  strong_assert(
      compare=response.retention_per_environment,
      to=False,
      success_message=(
          "Default retention per Environment is."
          f"{response.retention_per_environment}"
      ),
      failure_message=(
          "Wrong default retention per Environment."
          f"Expected False. Received {response.retention_per_environment}"
      ),
  )
  siemplify.retention.trigger_data_retention()
  last_case = siemplify.cases.get_last_case_details_for_test()
  validate_title = "Virus Found Or security risk found"
  strong_assert(
      compare=last_case.name,
      to=validate_title,
      success_message=f"Correct case title received: {validate_title}",
      failure_message=(
          f"Wrong title received. Expected: {validate_title}, ",
          f"received: {last_case.name}"
      ),
  )
