"""Module for testing Siemplify Services.
"""
from siemplify_utils import siemplify
from source import enums
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags


@tags(["SERVICES", "SEQUENCE"])
def test_all_services():
  """Checks all services status test.

  Steps:
  1) Checks main services status
  2) Checks Webhooks management status
  3) Create Integration Instance and Configure
  4) Simulate case and ingest alert as a case test
  5) Get IDE Item data
  6) Run IDE with paramters.
  7) Check all service status.
  8) Close complete case
  """
  # Checking main services
  response = siemplify.services.check_services_status_for_test()
  services = response.json()
  running_services = []
  not_running_services = []
  for service in services:
    service_status = service["state"]
    service_name = service["name"]
    if service_status == "Active":
      running_services.append(service_name)
    else:
      not_running_services.append(service_name)
  strong_assert(
      is_true=response,
      success_message="Status for services retrieved",
      failure_message="Status for services could not be retrieved",
      extra_info=f"Main Services: {len(running_services)}/5",
  )
  # Checking webhooks management services
  response = siemplify.services.check_webhooks_management_status_for_test()
  expected_res = "Siemplify <> API Controller is Alive"
  if response.text == expected_res:
    running_services.append("Webhooks-Management")
  else:
    not_running_services.append("Webhook-Management")
  soft_assert(
      compare=response.text,
      to=expected_res,
      success_message="Status for webhooks retrieved",
      failure_message="Status for webhooks could not be retrieved",
      extra_info=f"{response.text}"
  )
  # Create and configure siemplify instance
  integration_id = siemplify.integrations.create_integration_instance(
      integration_id="Siemplify",
      environment="Default Environment"
  )
  instance_id = integration_id.json()["identifier"]
  siemplify.integrations.configure_integration(
      integration_id=instance_id,
  )
  # Simulate case and ingest alert as a case test
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.FAILED_LOGIN]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_id = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["identifier"]
  siemplify.cases.ingest_alert_as_a_case_test(
      alert_id=alert_id,
      case_id=case_id,
      environment="Default Environment"
  )
  # Get IDE Item data
  custom_action_data = siemplify.ide.get_ide_item_data_by_id(
      item_type=1,
      item_id=34,  # Add Tag IDE Id
  )
  strong_assert(
      is_true=(custom_action_data.status_code == 200),
      success_message="Add Tag Action Created in IDE.",
      failure_message="Add Tag Action cannot be created in IDE.",
  )
  # Run IDE with paramters.
  scope = "All entities"
  action_case_id = case_id+1
  parameters = custom_action_data.parameters
  parameters[0]["defaultValue"] = "exampleTestTag"
  action_run = siemplify.ide.run_item_test_ide(
      integration_name="Siemplify",
      creator=custom_action_data.creator,
      action_case_id=action_case_id,
      integration_instance=instance_id,
      item_id=custom_action_data.id,
      item_name=custom_action_data.name,
      creator_name=custom_action_data.creator_full_name,
      script=custom_action_data.script,
      parameters=parameters,
      test_scope=scope,
      item_type=1,
  )
  strong_assert(
      is_true=action_run.result_value,
      success_message="Status of Python Services retrieved successfully",
      failure_message=(
          f"failed to run test from IDE, returned {action_run.result_value}"
      ),
  )
  if action_run.status_code == 200:
    running_services.append("Python Services")
  else:
    not_running_services.append("Python Services")
  status_1 = f"Services Running : {running_services}"
  status_2 = f"Services Not Running : {not_running_services}"
  strong_assert(
      is_true=running_services,
      success_message="All services status retrieved",
      failure_message="No Services Running",
      extra_info=f"{status_1} \n {status_2}"
  )
