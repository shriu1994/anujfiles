"""Module for testing Siemplify tasks module.
"""
from siemplify_utils import siemplify
from siemplify_utils.tasks import get_user_tasks_count
from source import enums
from source.utils import strong_assert
from tests.conftest import tags


@tags(["TASKS", "PARALLEL"])
def test_create_task_for_role():
  """Performs a test with a name listed below.

  "Create and get task for specific role"
  Steps:
  1) Create task for @Tier1 role
  2) Create a user with Tier1 role
  3) Log in as new user
  4) Get user tasks
  """
  new_role = siemplify.users.create_role_for_test()
  siemplify.tasks.add_task(assign_to=f"@{new_role.name}")
  user = siemplify.users.create_user_for_test(role=new_role.id)
  siemplify.authentication.log_in_for_test(
      email=user.email,
      password="Password1!",
  )
  tasks = siemplify.tasks.get_tasks(
  ).response_json
  total_user_tasks = siemplify.tasks.wait_for_task_count(count=1)
  strong_assert(
      compare=total_user_tasks,
      to=1,
      success_message="1 task received",
      extra_info=tasks,
      failure_message=(
          "Wrong number of tasks received. Expected: 1, ",
          f"received: {total_user_tasks}"
      )
  )

@tags(["TASKS", "PARALLEL"])
def test_create_task_for_user():
  """Performs a test with a name listed below.

  "Create and get task for specific user"
  Steps:
  1) Create a user
  2) Create task for the specific user
  3) Log in as new user
  4) Get user tasks
  """

  new_user = siemplify.users.create_user_for_test()
  siemplify.tasks.add_task(assign_to=new_user.username)
  siemplify.authentication.log_in_for_test(
      email=new_user.email,
      password="Password1!",
  )
  total_user_tasks = get_user_tasks_count()
  strong_assert(
      compare=total_user_tasks,
      to=1,
      success_message="1 task received",
      failure_message=(
          "Wrong number of task received. Expected: 1, ",
          f"received: {total_user_tasks}"
      )
  )



@tags(["TASKS", "PARALLEL"])
def test_create_task_for_user_and_role():
  """Performs a test with a name listed below.

  "Create and get task for user and role"
  Steps:
  1) Create a user with role
  2) Create task for the specific user
  3) Create task for the user soc role
  4) Log in as new user
  5) Get user tasks
  """
  new_role = siemplify.users.create_role_for_test()
  new_user = siemplify.users.create_user_for_test(role=new_role.id)
  siemplify.tasks.add_task(assign_to=new_user.username)
  siemplify.tasks.add_task(assign_to=f"@{new_role.name}")
  siemplify.authentication.log_in_for_test(
      email=new_user.email,
      password="Password1!",
  )
  siemplify.tasks.wait_for_task_count(count=2)
  total_user_tasks = get_user_tasks_count()
  strong_assert(
      compare=total_user_tasks,
      to=2,
      success_message="2 task received",
      failure_message=(
          "Wrong number of task received. Expected: 2, ",
          f"received: {total_user_tasks}"
      )
  )


@tags(["TASKS", "PARALLEl"])
def test_create_case_task_for_role():
  """Performs a test with a name listed below.

  "Create and get case task for specific role"
  Steps:
  1) Simulate case
  2) Create case task for @Tier1 role
  3) Create a user with Tier1 role
  4) Log in as new user
  5) Get user tasks
  """

  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.tasks.add_case_task(
      case_id=case_id,
      assignee=enums.SocRoleNames.TIER1,
  )
  new_user = siemplify.users.create_user_for_test(role=enums.SocRoleId.TIER1)
  siemplify.authentication.log_in_for_test(
      email=new_user.email,
      password="Password1!",
  )
  total_user_tasks = get_user_tasks_count()
  strong_assert(
      compare=total_user_tasks,
      to=1,
      success_message="1 task received",
      failure_message=(
          "Wrong number of task received. Expected: 1, ",
          f"received: {total_user_tasks}"
      )
  )


@tags(["TASKS", "PARALLEL"])
def test_create_case_task_for_user():
  """Performs a test with a name listed below.

  "Create and get case task for specific user"
  Steps:
  1) Simulate case
  2) Create a user
  3) Create case task for the user
  4) Log in as new user
  5) Get user tasks
  """

  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  new_user = siemplify.users.create_user_for_test()
  siemplify.tasks.add_case_task(
      case_id=case_id,
      assignee=new_user.username,
  )
  siemplify.authentication.log_in_for_test(
      email=new_user.email,
      password="Password1!",
  )
  tasks = siemplify.tasks.get_tasks(
    test_name="test_create_case_task_for_user"
  ).response_json
  total_user_tasks = siemplify.tasks.wait_for_task_count(count=1)
  strong_assert(
      compare=total_user_tasks,
      to=1,
      success_message="1 task received",
      extra_info=tasks,
      failure_message=(
          "Wrong number of task received. Expected: 1, ",
          f"received: {total_user_tasks}"
      )
  )


@tags(["TASKS", "PARALLEL"])
def test_create_multiple_tasks():
  """Performs a test with a name listed below.

  "Create task and case task"
  Steps:
  1) Simulate case
  2) Create a user
  3) Create case task
  4) Create task
  5) Log in as new user
  6) Get user tasks
  """

  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  new_user = siemplify.users.create_user_for_test()
  siemplify.tasks.add_case_task(
      case_id=case_id,
      assignee=new_user.username,
  )
  siemplify.tasks.add_task(assign_to=new_user.username)
  siemplify.authentication.log_in_for_test(
      email=new_user.email,
      password="Password1!",
  )
  total_user_tasks = siemplify.tasks.wait_for_task_count(count=2)
  strong_assert(
      compare=total_user_tasks,
      to=2,
      success_message="2 tasks received",
      failure_message=(
          "Wrong number of task received. Expected: 2, ",
          f"received: {total_user_tasks}"
      )
  )


@tags(["TASKS", "PARALLEL"])
def test_create_task_different_environment():
  """Performs a test with a name listed below.

  "Create case task with different case environment"
  The purpose of this test is to very that user will not be exposed to
  case task when the user has no permission to view the case.

  Steps:
  1) create new environment
  2) Simulate case on the new environment
  3) Create case task for admin role
  5) Create user with admin role, with only default environment access
  6)
  7) Get user tasks
  """

  new_env = siemplify.environments.create_environment_for_test()
  siemplify.cases.simulate_cases_in_environment(
      cases=[enums.DefaultCases.DATA_EXFILTRATION],
      environment=new_env.name,
  )
  case_id = siemplify.cases.get_last_case_id_in_environments(
      environments=[new_env.name]
  )
  siemplify.tasks.add_case_task(
      case_id=case_id,
      assignee=enums.SocRoleNames.ADMIN,
  )
  user = siemplify.users.create_user_for_test(
      permission_group=enums.PermissionGroups.READERS
  )
  siemplify.authentication.log_in_for_test(
      email=user.email,
      password="Password1!",
  )
  total_user_tasks = get_user_tasks_count()
  strong_assert(
      compare=total_user_tasks,
      to=0,
      success_message="No task received",
      failure_message=(
          "Wrong number of task received. Expected: 0, ",
          f"received: {total_user_tasks}"
      )
  )
