"""Module for testing Siemplify views module.
"""
from siemplify_utils import siemplify
from source import enums
from source.utils import soft_assert
from tests.conftest import tags


@tags(["VIEWS", "SEQUENCE"])
def test_case_and_alert_view_widgets():
  """Performs a "View case and alert widgets" test.

  Steps:
  1) Set default case view widgets to
    "Alerts", "Entities Highlights", "Entities Graph"
  2) Set default alert view widgets to "Entities Highlights", "Entities Graph"
  3) Verify the default views match the views that were set
  4) Simulate a "Data Exfiltration" case
  5) Verify the case and alert views for the case match the templates
  6) Close the case
  """
  # Saving view templates
  siemplify.views.save_template(
      template_type="Alert",
      widgets=["entities highlights", "entities graph"],
  )
  siemplify.views.save_template(
      template_type="Case",
      widgets=["alerts", "entities highlights", "entities graph"],
  )
  # Checking if widgets appear in case template data
  case_id = siemplify.views.get_default_case_view_id()
  data = siemplify.views.get_template_data(template_id=case_id)
  widgets = siemplify.utils.find_key_in_json(json_data=data, key="widgets")
  meta = siemplify.utils.find_key_in_json(json_data=widgets, key="metadata")
  titles = siemplify.utils.find_key_in_json(json_data=meta, key="title")
  needed_titles = {"Alerts", "Entities Highlights", "Entities Graph"}
  soft_assert(
      compare=set(titles),
      to=needed_titles,
      success_message="Case view widgets match",
      failure_message="Case view widgets don't match",
      extra_info=titles,
  )
  # Checking if widgets appear in alert template data
  alert_id = siemplify.views.get_default_alert_view_id()
  data = siemplify.views.get_template_data(template_id=alert_id)
  widgets = siemplify.utils.find_key_in_json(json_data=data, key="widgets")
  meta = siemplify.utils.find_key_in_json(json_data=widgets, key="metadata")
  titles = siemplify.utils.find_key_in_json(json_data=meta, key="title")
  needed_titles = {"Entities Highlights", "Entities Graph"}
  soft_assert(
      compare=set(titles),
      to=needed_titles,
      success_message="Alert view widgets match",
      failure_message="Alert view widgets don't match",
      extra_info=titles,
  )
  # Simulating a case
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  # Checking case view data
  case_data = siemplify.cases.get_case_overview_data(case_id=case_id)
  widgets = siemplify.utils.find_key_in_json(
      json_data=case_data,
      key="widgets",
  )
  case_titles = siemplify.utils.find_key_in_json(
      json_data=widgets,
      key="title",
  )
  needed_titles = {"Alerts", "Entities Highlights", "Entities Graph"}
  soft_assert(
      compare=set(case_titles),
      to=needed_titles,
      success_message="Case view widgets match",
      failure_message="Case view widgets don't match",
      extra_info=case_titles,
  )
  # Checking alert view data
  case_id = siemplify.cases.get_last_case_id_for_test()
  alert_identifier = siemplify.cases.get_case_full_details(
      case_id=case_id
  ).alerts[0].additional_properties["identifier"]
  alert_data = siemplify.cases.get_alert_overview_data(
      case_id=case_id,
      alert_identifier=alert_identifier,
  )
  widgets = siemplify.utils.find_key_in_json(
      json_data=alert_data,
      key="widgets",
  )
  alert_titles = siemplify.utils.find_key_in_json(
      json_data=widgets,
      key="title",
  )
  needed_titles = {"Entities Highlights", "Entities Graph"}
  soft_assert(
      compare=set(alert_titles),
      to=needed_titles,
      success_message="Alert view widgets match",
      failure_message="Alert view widgets don't match",
      extra_info=alert_titles,
  )
