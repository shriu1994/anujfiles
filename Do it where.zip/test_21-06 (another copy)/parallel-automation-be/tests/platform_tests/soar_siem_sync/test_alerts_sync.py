"""Module for testing SOAR Alerts Sync to Chronicle SIEM."""
import json
import time
import uuid

from siemplify_utils import siemplify
from siemplify_utils.sdk import ApiSyncNewAlertResult
from source import enums
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags

MAX_ALERTS_TO_FETCH = 100
MAX_SYNC_FAILURES_ALLOWED = 5


@tags(["SEQUENCE", "SOAR_SIEM_SYNC"])
def test_no_new_alerts_to_sync():
  """Performs a test with a name listed below.

  "Verify that when no new alerts, nothing is marked for synchronization"

  Steps:
  1) Query alerts for synchronization
  2) Verify that no alerts were marked for synchronization
  """
  # We ignore old alerts.
  now_ms = time.time() * 1000
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH
  )
  for alert in response.alerts_to_sync:
    soft_assert(
        compare=alert.creation_time < now_ms,
        to=[],
        failure_message=(
            "Found SOAR alerts to sync with the SIEM, although no new alerts"
        ),
        extra_info=response.response_json,
    )


@tags(["SEQUENCE", "SOAR_SIEM_SYNC"])
def test_new_alerts_to_sync():
  """Performs a test with a name listed below.

  "Verify that new alerts are being marked for synchronization"

  Steps:
  1) Query alerts for synchronization
  2) Verify that new alerts were marked for synchronization
  """
  now_ms = int(time.time()) * 1000
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  for alert in response.alerts_to_sync:
    soft_assert(
        is_true=alert.creation_time < now_ms,
        success_message="No SOAR alerts to sync with the SIEM",
        failure_message=(
            "Found SOAR alerts to sync with the SIEM, although no new alerts"
        ),
        extra_info=response.response_json,
    )
  siemplify.cases.simulate_cases_for_test(
      cases=[
          enums.DefaultCases.DATA_EXFILTRATION,
          enums.DefaultCases.FAILED_LOGIN,
      ]
  )
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  total_new_alerts = 0
  for alert in response.alerts_to_sync:
    if alert.creation_time > now_ms:
      total_new_alerts += 1
  strong_assert(
      compare=total_new_alerts,
      to=4,
      success_message="No SOAR alerts to sync with the SIEM",
      failure_message=(
          "Found SOAR alerts to sync with the SIEM, although no new alerts"
      ),
      extra_info=response.response_json,
  )


@tags(["SEQUENCE", "SOAR_SIEM_SYNC"])
def test_alert_sync_flow():
  """Performs a test with a name listed below.

  "Verify new alerts are marked for synchronization and update them as synced"

  Steps:
  1) Simulate a case with an alert
  2) Verify the new alert is being marked for synchronization
  3) Verify the new alert and its events
  5) Update the new alert as synced
  6) Verify that the new alert is not being returned as an alert
  for synchronization.
  """
  now_ms = int(time.time()) * 1000
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  alerts_to_sync = []
  for alert in response.alerts_to_sync:
    if alert.creation_time > now_ms:
      alerts_to_sync.append(alert)
  strong_assert(
      compare=len(alerts_to_sync),
      to=1,
      success_message="There is exactly 1 new alert to sync",
      failure_message="Wrong number of alerts to sync",
      extra_info=response.response_json,
  )
  alert = alerts_to_sync[0]
  strong_assert(
      compare=alert.product,
      to="DLP_Product",
      success_message="Found expected SOAR alert to sync with SIEM",
      failure_message=(
          "SOAR alerts to sync have been found, however, don't match expected"
      ),
      extra_info=response.response_json,
  )

  alert_dict = alert.__dict__
  alert_dict["events"] = [alert_dict["events"][0].__dict__]
  diff = siemplify.utils.get_dicts_diff(
      actual=alert.__dict__,
      expected=siemplify.payloads.alerts.data_exfiltration_alert_to_sync(
          alert.environment
      ),
      ignore_order=True,
      exclude_paths=[
          "root['alert_identifier']",
          "root['alert_group_identifier']",
          "root['creation_time']",
          "root['start_time']",
          "root['end_time']",
          "root['detection_time']",
          "root['ticket_id']",
          "root['events'][0]['event_time_epoch_time_in_ms']",
          "root['events'][0]['event_id']",
          "root['events'][0]['start_time']",
          "root['events'][0]['end_time']",
      ],
  )
  strong_assert(
      is_false=diff,
      success_message="No diff found for Data Exfiltration alert and events",
      failure_message="Diff found for Data Exfiltration alert and events",
      extra_info=json.dumps(dict(diff)),
  )
  new_alert_sync_result = ApiSyncNewAlertResult({
      "alertGroupIdentifier": alert.alert_group_identifier,
      "environment": alert.environment,
      "creationTime": alert.creation_time,
      "createdInSiem": True,
      "siemAlertId": "sa_" + str(uuid.uuid4()),
      "message": None,
  })

  response = siemplify.sdk.update_new_alerts_sync_status(
      alert_sync_results=[new_alert_sync_result]
  )
  strong_assert(
      compare=response.total_count,
      to=1,
      success_message="Expected number of result is correct",
      failure_message="Unexpected number of results",
      extra_info=response.response_json,
  )
  strong_assert(
      compare=response.alert_sync_results[0].alert_group_identifier,
      to=new_alert_sync_result.alert_group_identifier,
      success_message="Result AlertGroupIdentifier is correct",
      failure_message="Result AlertGroupIdentifier is incorrect",
      extra_info=response.response_json,
  )
  strong_assert(
      compare=response.alert_sync_results[0].environment,
      to=new_alert_sync_result.environment,
      success_message="Result Environment is correct",
      failure_message="Result Environment is incorrect",
      extra_info=response.response_json,
  )
  strong_assert(
      compare=response.alert_sync_results[0].creation_time,
      to=new_alert_sync_result.creation_time,
      success_message="Result Creation Time is correct",
      failure_message="Result Creation Time is incorrect",
      extra_info=response.response_json,
  )
  strong_assert(
      compare=response.alert_sync_results[0].created_in_siem,
      to=new_alert_sync_result.created_in_siem,
      success_message="Result CreatedInSiem is correct",
      failure_message="Result CreatedInSiem is incorrect",
      extra_info=response.response_json,
  )
  strong_assert(
      compare=response.alert_sync_results[0].siem_alert_id,
      to=new_alert_sync_result.siem_alert_id,
      success_message="Result SiemAlertId is correct",
      failure_message="Result SiemAlertId is incorrect",
      extra_info=response.response_json,
  )
  strong_assert(
      compare=response.alert_sync_results[0].message,
      to=new_alert_sync_result.message,
      success_message="Result Message is correct",
      failure_message="Result Message is incorrect",
      extra_info=response.response_json,
  )
  strong_assert(
      is_true=response.alert_sync_results[0].updated_in_soar,
      success_message="Result UpdatedInSoar is correct",
      failure_message="Result UpdatedInSoar is incorrect",
      extra_info=response.response_json,
  )
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  for alert in response.alerts_to_sync:
    soft_assert(
        is_true=alert.creation_time < now_ms,
        success_message="Non-synced SOAR alerts with the SIEM were not found",
        failure_message="Found SOAR alerts to sync with the SIEM",
        extra_info=response.response_json,
    )


@tags(["SEQUENCE", "SOAR_SIEM_SYNC"])
def test_new_alerts_sync_failure():
  """Performs a test with a name listed below.

  "Verify that alerts which crossed the failures limit are no longer marked
  as candidates for synchronization"

  Steps:
  1) Query alerts for synchronization
  2) Verify that new alerts were marked for synchronization
  3) Record part of the alerts as failed for synchroniation.
  4) Verify that alerts which crossed the failures limit, are no longer
  marked as candidates for synchronization.
  """
  now_ms = int(time.time()) * 1000
  siemplify.cases.simulate_cases_for_test(
      cases=[
          enums.DefaultCases.DATA_EXFILTRATION,
          enums.DefaultCases.FAILED_LOGIN,
      ]
  )
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  alerts_to_sync = []
  for alert in response.alerts_to_sync:
    if alert.creation_time > now_ms:
      alerts_to_sync.append(alert)
  strong_assert(
      compare=len(alerts_to_sync),
      to=4,
      success_message="Found SOAR alerts to sync with the SIEM",
      failure_message="SOAR alerts to sync with the SIEM were not found",
      extra_info=response.response_json,
  )
  alert_sync_failures = []
  for alert in alerts_to_sync[:2]:
    alert_sync_failures.append(
        ApiSyncNewAlertResult({
            "alertGroupIdentifier": alert.alert_group_identifier,
            "environment": alert.environment,
            "creationTime": alert.creation_time,
            "createdInSiem": False,
            "message": "Invalid Priority",
        })
    )
  siemplify.sdk.update_new_alerts_sync_status(
      alert_sync_results=alert_sync_failures
  )
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  alerts_to_sync = []
  for alert in response.alerts_to_sync:
    if alert.creation_time > now_ms:
      alerts_to_sync.append(alert)
  strong_assert(
      compare=len(alerts_to_sync),
      to=4,
      success_message="Found SOAR alerts to sync with the SIEM",
      failure_message="SOAR alerts to sync with the SIEM were not found",
      extra_info=response.response_json,
  )
  for _ in range(MAX_SYNC_FAILURES_ALLOWED - 1):
    siemplify.sdk.update_new_alerts_sync_status(
        alert_sync_results=alert_sync_failures,
    )
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  alerts_to_sync = []
  for alert in response.alerts_to_sync:
    if alert.creation_time > now_ms:
      alerts_to_sync.append(alert)
  strong_assert(
      compare=len(alerts_to_sync),
      to=2,
      success_message="Expected SOAR alerts for synchronization were returned",
      failure_message="Found unexpected SOAR alerts for synchronization",
      extra_info=response.response_json,
  )


@tags(["SEQUENCE", "SOAR_SIEM_SYNC"])
def test_new_alerts_order():
  """Performs a test with a name listed below.

  "Verify the order of new alerts which are candidates for synchronization"

  Steps:
  1) Simulate alerts
  2) Query alerts for synchronization
  3) Verify that alerts are sorted by creation time in ascending order.
  """
  now_ms = int(time.time()) * 1000
  siemplify.cases.simulate_cases_for_test(
      cases=[
          enums.DefaultCases.DATA_EXFILTRATION,
          enums.DefaultCases.FAILED_LOGIN,
          enums.DefaultCases.FAILED_LOGIN,
      ]
  )
  siemplify.cases.wait_for_alert_count_for_test(count=7)
  response = siemplify.sdk.fetch_new_alerts_to_sync_for_test(
      items_count=MAX_ALERTS_TO_FETCH,
  )
  alerts_to_sync = []
  for alert in response.alerts_to_sync:
    if alert.creation_time > now_ms:
      alerts_to_sync.append(alert)
  strong_assert(
      compare=len(alerts_to_sync),
      to=7,
      success_message="Found SOAR alerts to sync with the SIEM",
      failure_message="SOAR alerts to sync with the SIEM were not found",
      extra_info=response.response_json,
  )
  for i in range(len(alerts_to_sync) - 1):
    alert = alerts_to_sync[i]
    consecutive_alert = alerts_to_sync[i + 1]
    soft_assert(
        is_true=alert.creation_time <= consecutive_alert.creation_time,
        success_message="SOAR alerts for synchronization are ordered correctly",
        failure_message=(
            "SOAR alerts for synchronization are not ordered correctly"
        ),
        extra_info=response.response_json,
    )
