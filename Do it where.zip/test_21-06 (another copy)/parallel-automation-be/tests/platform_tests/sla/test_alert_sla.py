"""Module for testing Siemplify Alert SLA module.
"""
import datetime as dt
import time
from siemplify_utils import siemplify
from source import enums
from source.utils import strong_assert
from tests.conftest import tags


MINS_7 = 7
MINS_5 = 5
MINS_4 = 4
MINS_3 = 3
MINS_2 = 2
MINS_1 = 1


@tags(["SLA", "PARALLEL"])
def test_alert_sla_for_case_calculation():
  """Performs a test with the name listed below.

  "Test alert SLA for case calculation"
  """
  # STEP 1: simulate case without alert sla
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # STEP 2: define alert sla 5 and 2 and simulate case
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_5_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id)
  strong_assert(
      is_true=len(case_details.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_5_time,
  )
  # STEP 3: define alert sla 7 and 3 and simulate case
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_7,
      critical_period=MINS_3,
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id)
  strong_assert(
      is_true=len(case_details.alert_cards) == 3,
      success_message="Case has exactly three alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_5_time,
  )
  # STEP 4: define alert sla 3 and 1 and simulate case
  alert_3_time = dt.datetime.now()
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_3,
      critical_period=MINS_1,
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id)
  strong_assert(
      is_true=len(case_details.alert_cards) == 4,
      success_message="Case has exactly four alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )


@tags(["SLA", "PARALLEL"])
def test_alert_sla_with_merge_cases():
  """Performs a test with the name listed below.

  "Test alert SLA with merge cases"
  """
  user = siemplify.users.get_test_user_data().username
  # STEP 1: simulate case without alert sla
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  strong_assert(
      is_true=case_id1,
      success_message="Case found",
      failure_message="No cases found",
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # STEP 2: simulate different case without sla
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  case_id2 = siemplify.cases.get_last_case_id_for_test()
  strong_assert(
      is_true=case_id2,
      success_message="Case found",
      failure_message="No cases found",
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # STEP 3: merge cases - both cases without sla -
  # validate that the merge case (case_id1) has no sla
  # assign both cases to me
  siemplify.cases.assign_case_to_user(case_id=case_id1, user_id=user)
  siemplify.cases.assign_case_to_user(case_id=case_id2, user_id=user)
  # merge cases into case1
  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id2],
      merge_to=case_id1
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )
  # STEP 4: define alert sla 5 and 2 and simulate another case with sla 5 2
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_5_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id3 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id3)
  strong_assert(
      is_true=len(case_details.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_5_time,
  )
  # STEP 5: merge cases - case without sla and case with sla 5 2
  # (into the case without sla) - validate that the merged case has sla 5 2
  # assign new case to me
  siemplify.cases.assign_case_to_user(case_id=case_id3, user_id=user)
  # merge cases into case1
  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id3],
      merge_to=case_id1
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details.alert_cards) == 3,
      success_message="Case has exactly three alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_5_time,
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )
  # STEP 6: define alert sla 3 and 1 and simulate another case with sla 3 1
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_3,
      critical_period=MINS_1,
  )
  alert_3_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.ACCESS_TO_DISABLED_ACCOUNT]
  )
  case_id4 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id4)
  strong_assert(
      is_true=len(case_details.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )
  # STEP 7: merge cases - case sla 5 2 and case with sla 3 1
  # (into the case without 5 2) - validate that the merged case has sla 3 2
  # assign new case to me
  siemplify.cases.assign_case_to_user(case_id=case_id4, user_id=user)
  # merge cases into case1
  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id4],
      merge_to=case_id1
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details.alert_cards) == 4,
      success_message="Case has exactly four alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )
  # STEP 8: close all cases
  siemplify.cases.close_cases_for_test()
  # STEP 9: define alert sla 7 and 4 and case with sla 7 4
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_7,
      critical_period=MINS_4,
  )
  alert_7_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_4,
      case_ingestion_time=alert_7_time,
  )
  # STEP 10: define alert sla 4 and 2 and case with sla 4 2
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_4,
      critical_period=MINS_2,
  )
  alert_4_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id2 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_4,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_4_time,
  )
  # STEP 11: merge cases - case sla 7 4 and case with sla 4 2
  # (into the case with 4 2) - validate that the merged case has sla 4 2
  # assign cases to me
  siemplify.cases.assign_case_to_user(case_id=case_id1, user_id=user)
  siemplify.cases.assign_case_to_user(case_id=case_id2, user_id=user)
  # merge cases into case1
  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id2],
      merge_to=case_id2
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_4,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_4_time,
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )


@tags(["SLA", "PARALLEL"])
def test_alert_sla_with_moving_alert_between_cases_both_cases_no_sla():
  """Performs a test with the name listed below.

  "Test alert SLA with moving cases (both cases no sla)"
  """
  user = siemplify.users.get_test_user_data().username
  # STEP 1: simulate case with 2 alerts without alert sla
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # STEP 2: simulate different case with 1 alert without sla
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  case_id2 = siemplify.cases.get_last_case_id_for_test()
  strong_assert(
      is_true=case_id2,
      success_message="Case found",
      failure_message="No cases found",
  )
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  siemplify.cases.assign_case_to_user(case_id=case_id1, user_id=user)
  siemplify.cases.assign_case_to_user(case_id=case_id2, user_id=user)
  # STEP 3: move alert from case 1 to case 2 - both cases without sla -
  # validate that both cases have no sla
  siemplify.cases.move_alert_to_case(
      alert_identifier=case_details1.alert_cards[0].identifier,
      destination_case_id=case_id2,
      source_case_id=case_id1,
  )
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )


@tags(["SLA", "PARALLEL"])
def test_alert_sla_with_moving_alert_between_cases_one_sla_one_no_sla():
  """Performs a test with the name listed below.

  "Test alert SLA with moving cases (one case sla and one case no sla)"
  """
  user = siemplify.users.get_test_user_data().username
  # STEP 1: simulate case1 with 2 alerts without alert sla
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # STEP 2: define sla 7 5 simulate different case (case2)
  # with 1 alert with sla 7 5
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_7,
      critical_period=MINS_5,
  )
  alert_7_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  case_id2 = siemplify.cases.get_last_case_id_for_test()
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_5,
      case_ingestion_time=alert_7_time,
  )
  siemplify.cases.assign_case_to_user(case_id=case_id1, user_id=user)
  siemplify.cases.assign_case_to_user(case_id=case_id2, user_id=user)
  # STEP 3: move alert from case 1 to case 2 - validate that case 1
  # has no sla and case 2 has sla 7 5
  siemplify.cases.move_alert_to_case(
      alert_identifier=case_details1.alert_cards[0].identifier,
      destination_case_id=case_id2,
      source_case_id=case_id1,
  )
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_5,
      case_ingestion_time=alert_7_time,
  )
  # now the case 1 has one alert no sla and case 2 has 2 alerts
  # (no sla and sla 7 5)
  # STEP 4: move alert with sla from case 2 to case 1 -
  # validate that case 1 has sla 7 5 and case 2 has no sla
  alert_with_sla = next(
      (a for a in case_details2.alert_cards
       if a.sla.sla_expiration_time is not None
       ), None
  )
  strong_assert(
      is_true=alert_with_sla,
      success_message="Alert with SLA found",
      failure_message="No alert with SLA found",
  )
  siemplify.cases.move_alert_to_case(
      alert_identifier=alert_with_sla.identifier,
      destination_case_id=case_id1,
      source_case_id=case_id2
  )
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_5,
      case_ingestion_time=alert_7_time,
  )
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  siemplify.cases.move_alert_to_new_case(
      alert_identifier=alert_with_sla.identifier,
      source_case_id=case_id1
  )
  case_id3 = siemplify.cases.get_last_case_id_for_test()
  case_details1 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  case_details3 = siemplify.cases.get_case_details(case_id=case_id3)
  strong_assert(
      is_true=len(case_details3.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details3.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details3.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_5,
      case_ingestion_time=alert_7_time,
  )


@tags(["SLA", "SEQUENCE"])
def test_alert_sla_with_moving_alert_between_cases_all_have_sla():
  """Performs a test with the name listed below.

  "Test alert SLA with moving cases (all cases have sla)"
  """
  user = siemplify.users.get_test_user_data().username
  # STEP 1: define sla 3 1 simulate case with 1 alert with sla 3 1
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_3,
      critical_period=MINS_1,
  )
  alert_3_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  # get the alert identifier
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  alert3_identifier = case_details1.alert_cards[0].identifier
  # STEP 2: define sla 5 2 simulate alert with 1 alert with sla 5 2
  # (for the same case)
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_5_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )
  # get the alert identifier of the second alert
  alert5 = next(
      (a for a in case_details1.alert_cards
       if a.identifier != alert3_identifier
       ), None
  )
  strong_assert(
      is_true=alert5,
      success_message="Alert 5 found",
      failure_message="No alert 5 found",
  )
  # STEP 3: define sla 7 4 simulate alert with 1 alert with sla 5 2
  # (for ta new case)
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_7,
      critical_period=MINS_4,
  )
  alert_7_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  case_id2 = siemplify.cases.get_last_case_id_for_test()
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_4,
      case_ingestion_time=alert_7_time,
  )
  alert7_identifier = case_details2.alert_cards[0].identifier
  siemplify.cases.assign_case_to_user(case_id=case_id1, user_id=user)
  siemplify.cases.assign_case_to_user(case_id=case_id2, user_id=user)
  # STEP 4: move alert with sla 3 from case 1 to case 2 -
  # validate that case 1 has sla 5 2 and case 2 has sla 3 1
  siemplify.cases.move_alert_to_case(
      alert_identifier=alert3_identifier,
      destination_case_id=case_id2,
      source_case_id=case_id1,
  )
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_5_time,
  )
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )
  # STEP 5: move alert with sla 7 3 from case 2 to case 1 -
  # validate that case 1 has sla 5 2 and case 2 has 3 1
  siemplify.cases.move_alert_to_case(
      alert_identifier=alert7_identifier,
      destination_case_id=case_id1,
      source_case_id=case_id2,
  )
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_5_time,
  )
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )
  # STEP 6: move alert with sla 7 3 from case 1 to case 2
  # validate that case 1 has sla 5 2 and case 2 has 3 1
  siemplify.cases.move_alert_to_case(
      alert_identifier=alert7_identifier,
      destination_case_id=case_id2,
      source_case_id=case_id1,
  )
  case_details1 = siemplify.cases.get_case_details(case_id=case_id1)
  strong_assert(
      is_true=len(case_details1.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details1.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details1.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_5_time,
  )
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 2,
      success_message="Case has exactly two alerts",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )
  # STEP 7: move alert to new case
  siemplify.cases.move_alert_to_new_case(
      alert_identifier=alert3_identifier,
      source_case_id=case_id2,
  )
  case_id3 = siemplify.cases.get_last_case_id_for_test()
  case_details2 = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=len(case_details2.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details2.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_4,
      case_ingestion_time=alert_7_time,
  )
  case_details3 = siemplify.cases.get_case_details(case_id=case_id3)
  strong_assert(
      is_true=len(case_details3.alert_cards) == 1,
      success_message="Case has exactly one alert",
      failure_message="Wrong number of alerts in a case",
      extra_info=case_details3.response_json
  )
  siemplify.sla.validate_sla(
      sla=case_details3.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_3,
      expected_critical_expiration_since_ingestion=MINS_1,
      case_ingestion_time=alert_3_time,
  )


@tags(["SLA", "PARALLEL"])
def test_pause_resume_alert_sla():
  """Performs a test with the name listed below.

  "Test pausing and resuming alert SLA"
  """
  # STEP 1: simulate case with alert sla 5 2
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_1_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  alert_1_identifier = case_details.alert_cards[0].identifier
  case_id = case_details.id
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
  )
  alert_1_pause_time = dt.datetime.now()
  siemplify.sla.pause_alert_sla(
      alert_identifier=alert_1_identifier,
      case_id=case_id
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.PAUSED,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
      pause_time=alert_1_pause_time,
  )
  # sleep before resume
  time.sleep(30)
  # validate that remaining time is not influenced by time
  case_details = siemplify.cases.get_last_case_details_for_test()
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.PAUSED,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
      pause_time=alert_1_pause_time,
  )
  alert_1_resume_time = dt.datetime.now()
  siemplify.sla.resume_alert_sla(
      alert_identifier=alert_1_identifier,
      case_id=case_id
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  # add to expected expiration the time the alert was paused
  pause_time = (alert_1_resume_time - alert_1_pause_time).total_seconds() / 60
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5+pause_time,
      expected_critical_expiration_since_ingestion=MINS_2+pause_time,
      case_ingestion_time=alert_1_time,
      pause_time=alert_1_pause_time,
  )
  # ingest one more alert
  alert_2_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  strong_assert(
      is_true=case_details.id == case_id
  )
  strong_assert(
      is_true=len(case_details.alert_cards) == 2
  )
  alert_2 = next(
      a for a in case_details.alert_cards
      if a.identifier != alert_1_identifier
  )
  strong_assert(
      is_true=alert_2 is not None and alert_2.identifier != alert_1_identifier
  )
  siemplify.sla.validate_sla(
      sla=alert_2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_2_time,
  )
  # pause alert 2 and validate it is paused
  alert_2_pause_time = dt.datetime.now()
  siemplify.sla.pause_alert_sla(
      alert_identifier=alert_2.identifier,
      case_id=case_id
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  alert_2 = next(
      a for a in case_details.alert_cards
      if a.identifier != alert_1_identifier
  )
  alert_1 = next(
      a for a in case_details.alert_cards
      if a.identifier == alert_1_identifier
  )
  siemplify.sla.validate_sla(
      sla=alert_2.sla,
      expected_expiration_status=enums.SlaExpiration.PAUSED,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_2_time,
      pause_time=alert_2_pause_time,
  )
  # validate alert 1 is not paused
  siemplify.sla.validate_sla(
      sla=alert_1.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5 + pause_time,
      expected_critical_expiration_since_ingestion=MINS_2 + pause_time,
      case_ingestion_time=alert_1_time,
      pause_time=alert_1_pause_time,
  )

  # sleep before resume
  time.sleep(20)  # seconds
  alert_2_resume_time = dt.datetime.now()
  siemplify.sla.resume_alert_sla(
      alert_identifier=alert_2.identifier,
      case_id=case_id
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  alert_2 = next(
      a for a in case_details.alert_cards
      if a.identifier != alert_1_identifier
  )
  alert_1 = next(
      a for a in case_details.alert_cards
      if a.identifier == alert_1_identifier
  )
  # add to expected expiration the time the alert was paused
  pause_2_time = (alert_2_resume_time - alert_2_pause_time).total_seconds() / 60
  siemplify.sla.validate_sla(
      sla=alert_2.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5 + pause_2_time,
      expected_critical_expiration_since_ingestion=MINS_2 + pause_2_time,
      case_ingestion_time=alert_2_time,
      pause_time=alert_2_pause_time,
  )

  siemplify.sla.validate_sla(
      sla=alert_1.sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5 + pause_time,
      expected_critical_expiration_since_ingestion=MINS_2 + pause_time,
      case_ingestion_time=alert_1_time,
      pause_time=alert_1_pause_time,
  )


@tags(["SLA", "SEQUENCE"])
def test_alert_priority_definition_sla_calculated_on_alert_ingestion():
  """Performs a test with the name listed below.

  "Test changing alert priority definition sla"
  """
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_PRIORITY,
      value='["High"]',
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_1_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
  )


@tags(["SLA", "PARALLEL"])
def test_alert_priority_definition_and_type_sla_calculated_on_alert_ingestion():
  """Performs a test with the name listed below.

  "Test changing alert priority definition and type sla"
  """
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_PRIORITY,
      value='["High"]',
      sla_period=MINS_7,
      critical_period=MINS_3,
  )
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_RULE,
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_1_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
  )


@tags(["SLA", "SEQUENCE"])
def test_change_alert_priority():
  """Performs a test with the name listed below.

  "Test changing alert priority"
  """
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_PRIORITY,
      value='["Critical"]',
      sla_period=MINS_7,
      critical_period=MINS_3,
  )
  alert_1_time = dt.datetime.now()
  # alert ingested as High
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  alert = case_details.alert_cards[0]
  siemplify.sla.validate_sla(
      sla=alert.sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA
  )
  # Change priority to Critical
  siemplify.cases.change_alert_priority(
      alert_identifier=alert.identifier,
      alert_name=alert.name,
      case_id=case_details.id,
      previous_priority=alert.priority,
      priority=100
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_3,
      case_ingestion_time=alert_1_time,
  )


@tags(["SLA", "SEQUENCE"])
def test_change_alert_priority_two_definitions():
  """Performs a test with the name listed below.

  "Test changing alert priority with two SLA definitions"
  """
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_PRIORITY,
      value='["Critical"]',
      sla_period=MINS_7,
      critical_period=MINS_3,
  )
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.ALERT_PRIORITY,
      value='["High"]',
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_1_time = dt.datetime.now()
  # alert ingested as High
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  alert = case_details.alert_cards[0]
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
  )
  # Change priority to Critical
  siemplify.cases.change_alert_priority(
      alert_identifier=alert.identifier,
      alert_name=alert.name,
      case_id=case_details.id,
      previous_priority=alert.priority,
      priority=100
  )
  case_details = siemplify.cases.get_last_case_details_for_test()
  siemplify.sla.validate_sla(
      sla=case_details.alert_cards[0].sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_3,
      case_ingestion_time=alert_1_time,
  )
