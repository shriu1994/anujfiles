"""Module for testing Siemplify Case SLA module.
"""
import datetime as dt
from siemplify_utils import siemplify
from source import enums
from source.utils import strong_assert
from tests.conftest import tags


MINS_7 = 7
MINS_5 = 5
MINS_4 = 4
MINS_3 = 3
MINS_2 = 2
MINS_1 = 1


@tags(["SLA", "BUG"])
def test_case_same_stage_sla_with_merge_cases():
  """Performs a test with the name listed below.

  "Test case SLA with merge cases with stage sla with identical stage"
  """
  # STEP 1: simulate case without case sla
  alert_1_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  strong_assert(
      is_true=case_id1,
      success_message="Case found",
      failure_message="No cases found",
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # STEP 2: simulate different case without sla
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  case_id2 = siemplify.cases.get_last_case_id_for_test()
  strong_assert(
      is_true=case_id2,
      success_message="Case found",
      failure_message="No cases found",
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id2)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # STEP 3: merge cases - both cases without sla -
  # validate that the merge case (case_id1) has no sla
  # assign both cases to me
  user = siemplify.users.get_test_user_data().username
  siemplify.cases.assign_case_to_user(case_id=case_id1, user_id=user)
  siemplify.cases.assign_case_to_user(case_id=case_id2, user_id=user)
  # merge cases into case1
  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id2],
      merge_to=case_id1
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.NO_SLA,
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )
  # STEP 4: define stage sla 5 and 2 & simulate another case with stage sla 5 2
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.CASE_STAGE,
      value='["Triage"]',
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_3_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id3 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id3)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_3_time,
  )
  # STEP 5: merge cases - case without sla and case with sla 5 2
  # (into the case without sla) - validate that the merged case has sla 5 2
  # assign new case to me
  siemplify.cases.assign_case_to_user(case_id=case_id3, user_id=user)
  # merge cases into case1
  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id3],
      merge_to=case_id1,
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )
  # STEP 6: define stage sla 7 and 5 & simulate another case with stage sla 7 5
  siemplify.sla.delete_all_sla_definitions_for_test()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.CASE_STAGE,
      value='["Triage"]',
      sla_period=MINS_7,
      critical_period=MINS_5,
  )
  alert_4_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.ACCESS_TO_DISABLED_ACCOUNT]
  )
  case_id4 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id4)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_5,
      case_ingestion_time=alert_4_time,
  )
  # STEP 7: merge cases - case with sla 7 5 and case with sla 5 2
  # (into the case with sla 5 2) - because the stage wasn't changed the 
  # sla will not be recalculated
  # Assign new case to me
  siemplify.cases.assign_case_to_user(case_id=case_id4, user_id=user)
  # merge cases into case3
  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id4],
      merge_to=case_id1,
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )


@tags(["SLA", "SEQUENCE"])
def test_case_different_stage_sla_with_merge_cases():
  """Performs a test with the name listed below.

  "Test case SLA with merge cases"
  """
  # STEP 1: define stage sla 5 and 2 and simulate case with stage sla 5 2
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.CASE_STAGE,
      value='["Triage"]',
      sla_period=MINS_5,
      critical_period=MINS_2,
  )
  alert_1_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_id1 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_1_time,
  )
  # STEP 2: simulate another case with stage sla 5 2
  alert_2_time = dt.datetime.now()
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id2 = siemplify.cases.get_last_case_id_for_test()
  case_details = siemplify.cases.get_case_details(case_id=case_id2)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_5,
      expected_critical_expiration_since_ingestion=MINS_2,
      case_ingestion_time=alert_2_time,
  )
  # STEP 3: define stage "Incident" sla 7 and 3
  siemplify.sla.delete_all_sla_definitions_for_test()
  incident_stage_time = dt.datetime.now()
  siemplify.sla.add_sla_definition_for_test(
      value_type=enums.ApiSlaProviderType.CASE_STAGE,
      value='["Incident"]',
      sla_period=MINS_7,
      critical_period=MINS_3,
  )
  # STEP 4: move case2 to stage Incident
  siemplify.cases.change_stage(
      stage="Incident",
      case_id=case_id2,
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id2)
  strong_assert(
      is_true=case_details.stage == "Incident"
  )
  # STEP 5: merge cases
  # merge cases into case1
  # assign new case to me
  user = siemplify.users.get_test_user_data().username
  siemplify.cases.assign_case_to_user(
      case_id=case_id1,
      user_id=user,
  )
  siemplify.cases.assign_case_to_user(
      case_id=case_id2,
      user_id=user,
  )

  siemplify.cases.merge_cases_for_test(
      cases_ids=[case_id1, case_id2],
      merge_to=case_id1,
  )
  case_details = siemplify.cases.get_case_details(case_id=case_id1)
  siemplify.sla.validate_sla(
      sla=case_details.stage_sla,
      expected_expiration_status=enums.SlaExpiration.OPEN_SLA,
      expected_expiration_since_ingestion=MINS_7,
      expected_critical_expiration_since_ingestion=MINS_3,
      case_ingestion_time=incident_stage_time,
  )
  strong_assert(
      is_true=case_details.stage == "Incident"
  )
  # validate there is only one case
  response = siemplify.cases.get_cases_for_test()
  strong_assert(
      is_true=response.total_count == 1,
      success_message="There is exactly one case",
      failure_message="Wrong number of cases",
      extra_info=response.response_json
  )
