"""Module for testing Siemplify cases module.
"""
import json
import pytest
import inspect
import time
import os
from resources.expected_outputs.case_alerts import alert_events
from resources.expected_outputs.case_details import address_entity
from resources.expected_outputs.case_details import username_entity
from siemplify_utils import siemplify
from source import enums
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags

RAW_DATA_FOLDER_PATH = os.path.join(
  os.getcwd() + "/resources/raw_data")


@tags(["CASES", "PARALLEL"])
def test_ingest_case():
  """Performs an "Ingest simulated case" test.

  Steps:
  1) Simulate a case
  2) Verify that case appeared in the queue
  """
  # Simulate a case
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  last_case = siemplify.cases.get_last_case_details_for_test()
  required_title = "Virus Found Or security risk found"
  strong_assert(
    compare=last_case.name,
    to=required_title,
    success_message=f"Correct case title received: {required_title}",
    failure_message=(
      f"Wrong title received. Expected: {required_title}, ",
      f"received: {last_case.name}"
    ),
  )


@tags(["CASES", "PARALLEL"])
def test_simulate_case_without_specifying_name():
  """Try to simulate case without specifying its name.

  Steps:
  1) Simulate a case
  2) Verify that case appeared in the queue
  3) Try to simulate case without specifying its name
  4) Verify that server won't allow to do so
  5) Fetch all cases
  6) Amount of cases is still 1
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  last_case = siemplify.cases.get_last_case_details_for_test()
  required_title = "Data Exfiltration"
  strong_assert(
    compare=last_case.name,
    to=required_title,
    success_message=f"Correct case title received: {required_title}",
    failure_message=(
      f"Wrong title received. Expected: {required_title}, ",
      f"received: {last_case.name}"
    ),
  )
  with pytest.raises(Exception):
    resp = siemplify.cases.simulate_cases_for_test(
      cases=[],
      ignore_400=True,
      allow_empty_cases=True
    )
    strong_assert(
      compare=resp.status_code,
      to=400,
      success_message=
      'Could not simulate case without specifying its name',
      failure_message=f'Case was simulated without specifying its name'
    )
    expected_server_error_msg = "'Custom Cases' must not be empty."
    strong_assert(
      compare=resp.json()['errors']['customCases'][0],
      to=expected_server_error_msg,
      success_message=
      f"Server error message should be {expected_server_error_msg}",
      failure_message=
      f"Server error was {resp.json()['errors']['customCases'][0]}"
    )
    raise Exception(expected_server_error_msg)
  cases_count = siemplify.cases.get_cases_for_test()
  strong_assert(
    compare=cases_count.total_count,
    to=1,
    success_message='Amount of cases is still 1',
    failure_message=f'Amount of cases was not 1 as expected got '
                    f'{cases_count} instead'
  )


@tags(["CASES", "PARALLEL"])
def test_assigned_case_displayed():
  """Performs an "Assigned case displayed in my Cases tab" test.

  Steps:
  1) Simulate a case
  2) Assign current user to that case
  3) Verify that case is displayed in "my cases" tab
  4) Close case
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.assign_case_to_user(case_id=case_id)
  assigned_cases = siemplify.cases.get_assigned_cases_for_test()
  objects = siemplify.utils.find_key_in_json(
    json_data=assigned_cases,
    key="objectsList",
  )
  check_case_id = siemplify.utils.find_key_in_json(
    json_data=objects,
    key="caseId",
  )
  strong_assert(
    compare=check_case_id,
    to=case_id,
    success_message=f"Case {case_id} found in assigned cases",
    failure_message=f"Case {case_id} not found in assigned cases",
  )


@tags(["CASES", "PARALLEL"])
def test_change_case_priority():
  """Performs a "Search for phishing case" test.

  Steps:
  1) Simulate a case
  2) Run the action "Change case priority to critical"
  3) Verify that case priority is 100
  4) Close the case
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.change_priority(case_id=case_id)
  priority = siemplify.cases.get_case_full_details(case_id=case_id).priority
  strong_assert(
    compare=priority,
    to=100,
    success_message=f"Case priority is {priority}",
    failure_message=f"Wrong case priority. Expected 100. Received {priority}",
  )


@tags(["CASES", "PARALLEL"])
def test_check_case_wall():
  """Performs a "Check case wall" test.

  Steps:
  1) Simulate a case
  2) Add task to the case
  3) Assign case to current user
  4) Add tag to the case
  5) Add comment to the case
  6) Change case stage to "Investigation"
  7) Change case priority to "Critical"
  8) Verify that all changes are present on the case wall
  9) Close the case
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  data_ex_case_identifier = siemplify.cases.get_case_details(
    case_id=case_id).alert_cards[0].identifier
  siemplify.tasks.add_case_task(case_id=case_id)
  siemplify.cases.assign_case_to_user(case_id=case_id)
  siemplify.cases.add_tag(tag="Test", case_id=case_id)
  siemplify.cases.add_case_wall_comment(
    case_id=case_id,
    alert_identifier=data_ex_case_identifier
  )
  siemplify.cases.change_stage(case_id=case_id)
  siemplify.cases.change_priority(case_id=case_id)
  data = siemplify.cases.get_case_full_details(case_id=case_id)
  check = siemplify.utils.check_case_wall(
    case_data=data.response_json,
    requirements={
      "comment": True,
      "task": True,
      "assigned": True,
      "tag": True,
      "stage": True,
      "priority": True,
    }
  )
  strong_assert(
    compare=check,
    to=True,
    success_message="All required changes on the case wall",
    failure_message="Not all required changes on the case wall",
  )


@tags(["CASES", "PARALLEL"])
def test_add_entity_to_case_as_unsuspicios_and_noninternal():
  """Performs a test with a name listed below.

  "Add entity to case with unselected Suspicious and Internal marks"

  Steps:
  1) Simulate a case
  2) Add a new entity to an alert in case (PhoneNumber) with unselected Mark
  as Internal / Suspicious
  3) Verify entity added to an alert and not marked as suspicious and as
  internal
  4) Close the case
  """
  case = siemplify.cases.create_manual_case_for_test()
  siemplify.entities.add_entity_to_case_for_test(
    case_id=case.id,
    entity_id="55555",
    entity_type=enums.EntityType.ADRESS,
    suspicious=False,
    internal=False,
  )
  entities = siemplify.cases.get_case_full_details(case_id=case.id).entities
  soft_assert(
    is_true=entities,
    success_message="Entities key listed in case details",
    failure_message="Entities key not listed in case details",
  )
  soft_assert(
    is_false=entities[0]["isSuspicious"],
    success_message="Correct isSuspicious value: False",
    failure_message="Wrong isSuspicious value, Expected: False",
  )
  soft_assert(
    is_false=entities[0]["isInternal"],
    success_message="Correct isInternal value: False",
    failure_message="Wrong isInternal value, Expected: False",
  )


@tags(["CASES", "PARALLEL"])
def test_add_entity_to_case_as_suspicios_and_internal():
  """Performs a test with a name listed below.

  "Add entity to case with selected Suspicious and Internal marks"

  Steps:
  1) Simulate a case
  2) Add a new entity to an alert in case (PhoneNumber) with unselected
  Mark as Internal / Suspicious
  3) Verify entity added to an alert and not marked as suspicious and not
  as internal
  4) Close the case
  """
  case = siemplify.cases.create_manual_case_for_test()
  siemplify.entities.add_entity_to_case_for_test(
    case_id=case.id,
    entity_id="55555",
    entity_type=enums.EntityType.ADRESS,
    suspicious=True,
    internal=True,
  )
  entities = siemplify.cases.get_case_full_details(case_id=case.id).entities
  soft_assert(
    is_true=entities,
    success_message="Entities key listed in case details",
    failure_message="Entities key not listed in case details",
  )
  soft_assert(
    is_true=entities[0]["isSuspicious"],
    success_message="Correct isSuspicious value: True",
    failure_message="Wrong isSuspicious value, Expected: True",
  )
  soft_assert(
    is_true=entities[0]["isInternal"],
    success_message="Correct isInternal value: True",
    failure_message="Wrong isInternal value, Expected: True",
  )


@tags(["CASES", "PARALLEL"])
def test_configure_network_and_simulate_case():
  """Performs a test with a name listed below.

  "Configure a network"

  Steps:
  1) Add a new network to settings -> environments -> networks
  2) Simulate a case with an IP from the range (Data exfiltration)
  3) Verify entity with IP is saved as internal (IsInternalAsset = true)
  4) Close the case
  """
  siemplify.networks.add_network_for_test(
    address="10.0.0.25/8",
    priority=1,
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  entities = siemplify.cases.get_case_full_details(case_id=case_id).entities
  address_entity = siemplify.utils.find_dict_by_key_in_dicts_list(
    dicts_list=entities,
    key="entityType",
    value="ADDRESS",
  )
  field_item = siemplify.utils.find_dict_by_key_in_dicts_list(
    dicts_list=siemplify.utils.find_dict_by_key_in_dicts_list(
      dicts_list=address_entity["fields"],
      key="groupName",
      value="Default"
    )["items"],
    key="originalName",
    value="IsInternalAsset"
  )
  soft_assert(
    is_true=field_item["value"],
    success_message="IsInternalAsset field IS True",
    failure_message="IsInternalAsset field IS False"
  )


@tags(["CASES", "PARALLEL"])
def test_add_domain_and_simulate_case():
  """Performs a test with a name listed below.

  "Domains - the domain is displayed as internal"
  Steps:
  1) Add a new domain to settings -> environments -> domains
  2) Simulate a case with an IP from the range (Data exfiltration)
  3) Verify entity with domain is saved as internal (IsInternalAsset = true)
  4) Close the case
  """

  siemplify.domains.add_domain_for_test(
    name="gmail.com",
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  entities = siemplify.cases.get_case_full_details(case_id=case_id).entities
  domain_entity = siemplify.utils.find_dict_by_key_in_dicts_list(
    dicts_list=entities,
    key="identifier",
    value="XWZNR1L@GMAIL.COM",
  )
  field_item = siemplify.utils.find_dict_by_key_in_dicts_list(
    dicts_list=siemplify.utils.find_dict_by_key_in_dicts_list(
      dicts_list=domain_entity["fields"],
      key="groupName",
      value="Default"
    )["items"],
    key="originalName",
    value="IsInternalAsset"
  )
  soft_assert(
    is_true=field_item["value"],
    success_message="IsInternalAsset field IS True",
    failure_message="IsInternalAsset field IS False",
  )


@tags(["CASES", "PARALLEL"])
def test_save_cases_filters():
  """Performs a test with a name listed below.

  "Save cases filters"
  Steps:
  1) Save a filter with any parameters to the case queue
  2) Filter the case queue using the filter
  3) Verify the case queue contains the cases that are corresponding to
  the saved filter
  4) Close the case
  """

  siemplify.cases.simulate_cases_for_test()
  filter1 = siemplify.cases.create_case_filter_criteria(
    criteria_type="alert names",
    operator=True,
    values=["SUSPICIOUS PHISHING EMAIL"]
  )
  filtered_cases = siemplify.cases.get_cases_for_test(
    filters=[filter1]
  )
  case_cards = filtered_cases.case_cards
  check = siemplify.utils.find_key_value_in_json(
    json_data=case_cards,
    key="title",
    value="Phishing email detector"
  )
  soft_assert(
    is_true=check,
    success_message="Filter applied properly",
    failure_message="Filter not properly applied",
    extra_info=json.dumps(case_cards, indent=4)
  )


@tags(["CASES", "BUG"])
def test_merge_cases():
  """Performs a test with a name listed below.

  "Merge cases"
  Steps:
  1) Simulate 2 different cases
  2) Assign both on current user
  3) Merge one case with second one
  4) Validate alerts of both cases are merged to the selected one
  5) Close the case
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_1_id = siemplify.cases.get_last_case_id_for_test()
  user_id = siemplify.users.get_test_user_data().username
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case_2_id = siemplify.cases.get_last_case_id_for_test()
  assigned = siemplify.cases.get_assigned_cases_for_admin_user()
  siemplify.cases.assign_case_to_user(case_id=case_1_id, user_id=user_id)
  siemplify.cases.assign_case_to_user(case_id=case_2_id, user_id=user_id)
  siemplify.cases.merge_cases_for_test(
    cases_ids=[case_1_id, case_2_id], merge_to=case_1_id
  )
  details = siemplify.cases.get_case_full_details(case_id=case_1_id)
  merged_case_alerts = siemplify.utils.find_key_in_json(
    json_data=details.response_json,
    key="alerts"
  )
  expected_alerts = ["DATA EXFILTRATION", "PHISHING EMAIL"]
  soft_assert(
    is_true=len(
      [alert for alert in merged_case_alerts if any(
        expected in alert["identifier"] for expected in expected_alerts
      )
       ]
    ) == 2,
    success_message="Cases alerts merged successfully",
    failure_message="Cases alerts NOT merged properly",
    extra_info=json.dumps(merged_case_alerts, indent=4),
  )


@tags(["CASES", "SEQUENCE"])
def test_move_cases_between_environments():
  """Performs a test with a name listed below.

  "Move cases between environments"

  Steps:
  1) Enable the "Allow users to move cases between environments" setting
  2) Create 1 new environment
  3) Create a user that is allowed only to default environment
  4) Move a case from one environment to another
  """
  siemplify.settings.allow_move_cases_between_envs_sequence_only(on=True)
  env = siemplify.environments.create_environment_for_test()
  siemplify.users.create_user_for_test(
    environments=[env.name],
    permission_group="Readers"
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  old_case = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.move_case_to_different_environment(
    case_id=old_case,
    move_to=env.name,
  )
  cases = siemplify.cases.get_cases_for_test().case_cards
  # check that there is still a case in the test
  strong_assert(
    compare=len(cases),
    to=1,
    success_message="There is 1 open cases in test environment",
    failure_message="There are less or more then 1 open case in test env",
  )
  # check that the old case is still open
  strong_assert(
    compare=cases[0]["id"],
    to=old_case,
    success_message="The old case still exists",
    failure_message=f"The old cases with id {old_case} is not exist",
  )
  filter1 = siemplify.cases.create_case_filter_criteria(
    criteria_type="environments",
    operator=True,
    values=[env.name]
  )
  new_cases = siemplify.cases.get_cases_in_all_environments(
    filters=[filter1]
  ).case_cards
  # check that the new case environment was updated
  strong_assert(
    compare=len(new_cases),
    to=1,
    success_message="There is 1 open cases in new environment",
    failure_message="There are less or more then 1 open case in new env",
  )
  siemplify.utils.remove_keys_from_json(
    cases[0],
    ["id", "environment", "creationTimeUnixTimeInMs",
     "modificationTimeUnixTimeInMs"]
  )
  siemplify.utils.remove_keys_from_json(
    new_cases[0],
    ["id", "environment", "creationTimeUnixTimeInMs",
     "modificationTimeUnixTimeInMs"]
  )
  results = siemplify.utils.get_dicts_diff(cases, new_cases)
  # compare the values of the old and new case
  strong_assert(
    is_false=results,
    success_message="The 2 cases are identical",
    failure_message=(
      "There are some values that changed when moving the cases "
      f"between the environments: {results}"
    ),
  )
  siemplify.settings.allow_move_cases_between_envs_sequence_only(on=False)


@tags(["CASES", "PARALLEL"])
def test_run_entity_insight():
  """Performs a test with a name listed below.

  "Run manual action on entity (add entity insight)"
  Steps:
  1) Simulate a case
  2) Run manual action "Add entity insight" on an entity in the case
  3) Verify the insight has been added
  4) Close the case
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.run_manual_action(
    case_id=case_id,
    action_name="Siemplify_Add Entity Insight",
    action_data={"Message": "Test!"},
    target_entities=["XWZNR1L@GMAIL.COM"]
  )
  case_data = siemplify.cases.get_case_full_details(case_id=case_id)
  find_action = siemplify.utils.find_key_value_in_json(
    json_data=case_data.wall_data,
    key="triggeredBy",
    value="Siemplify",
  )
  title = siemplify.utils.find_key_in_json(
    json_data=find_action,
    key="title",
  )
  strong_assert(
    compare=title,
    to="Entity insight",
    success_message="Entity insight successfully found in a case!",
    failure_message="Entity insight not found in the case!"
  )


@tags(["CASES", "PARALLEL"])
def test_filter_case_queue_by_alert_and_product():
  """Performs a "Filter cases In queue by alert and product" test.

  Steps:
  1) Simulate all OOTB cases
  2) Filter cases by alert name
  3) Verify only case with chosen alert is shown
  4) Filter cases by product
  5) Verify only case with chosen product is shown
  """
  siemplify.cases.simulate_cases_for_test()
  alert_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="alert names",
    operator=True,
    values=["Data Exfiltration"]
  )
  product_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="products",
    operator=True,
    values=["Phishing Email Detector"]
  )
  cases_with_alert_filter = siemplify.cases.get_cases_for_test(
    filters=[alert_filter]
  )
  cases_found = cases_with_alert_filter.total_count
  find_data_exfiltration = siemplify.utils.find_key_value_in_json(
    json_data=cases_with_alert_filter.case_cards,
    key="title",
    value="Data Exfiltration",
  )
  soft_assert(
    compare=cases_found,
    to=1,
    success_message="One case found in the queue",
    failure_message="More than one case found in the queue",
    extra_info=cases_with_alert_filter.response_json,
  )
  soft_assert(
    is_true=find_data_exfiltration,
    success_message="Data Exfiltration found in cases",
    failure_message="Data exfiltration not found in cases!",
    extra_info=cases_with_alert_filter.response_json,
  )
  cases_product_filter = siemplify.cases.get_cases_for_test(
    filters=[product_filter]
  )
  cases_found = cases_product_filter.total_count
  find_phishing = siemplify.utils.find_key_value_in_json(
    json_data=cases_product_filter.case_cards,
    key="title",
    value="Phishing email detector",
  )
  soft_assert(
    compare=cases_found,
    to=1,
    success_message="One case found in the queue",
    failure_message="More than one case found in the queue",
    extra_info=cases_product_filter.response_json,
  )
  strong_assert(
    is_true=find_phishing,
    success_message="Phishing email detector found in cases",
    failure_message="Phishing email detector not found in cases!",
    extra_info=cases_product_filter.response_json,
  )


@tags(["CASES", "PARALLEL"])
def test_filter_cases_by_tags():
  """Performs a "Filter cases In queue by tag" test.

  Steps:
  1) Simulate a "Data Exfiltration" case
  2) Add tag to the case
  3) Filter case queue to show only tests with the tag
  4) Verify case with the tag is present in case queue
  5) Filter case queue to show only tests without the tag
  6) Verify case with the tag is not present in case queue
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.add_tag(tag="TestTag", case_id=case_id)
  tag_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="tags",
    operator=True,
    values=["TestTag"]
  )
  no_tag_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="tags",
    operator=False,
    values=["TestTag"]
  )
  cases_with_tag = siemplify.cases.get_cases_for_test(
    filters=[tag_filter]
  )
  cases_with_tag_count = cases_with_tag.total_count
  soft_assert(
    compare=cases_with_tag_count,
    to=1,
    success_message="One case with tag found in the queue",
    failure_message="More or less than one case found in the queue",
    extra_info=cases_with_tag.response_json,
  )
  case_details = siemplify.cases.get_case_full_details(case_id=case_id)
  tag_exists = siemplify.utils.find_key_value_in_json(
    json_data=case_details.tags,
    key="tag",
    value="TestTag"
  )
  soft_assert(
    is_true=tag_exists,
    success_message="Tag 'TestTag' found in case details",
    failure_message="Tag 'TestTag' not found in case details",
    extra_info=case_details.response_json,
  )
  cases_without_tag = siemplify.cases.get_cases_for_test(
    filters=[no_tag_filter]
  )
  cases_without_tag_count = cases_without_tag.total_count
  strong_assert(
    compare=cases_without_tag_count,
    to=0,
    success_message="No cases with the tag found in the queue",
    failure_message="At lesat one case with the tag found in the queue",
    extra_info=cases_without_tag.response_json,
  )


@tags(["CASES", "PARALLEL"])
def test_filter_cases_multiple_filters_with_or_operator():
  """Performs a test with the name listed below.

  "Filter cases In queue with multiple filters with OR operator"

  Steps:
  1) Simulate all OOTB cases
  2) Filter case queue to show tests containing alerts named
    "Data Exfiltration" OR "Phishing email detector"
  3) Verify only 2 cases are present in the queue
  """
  siemplify.cases.simulate_cases_for_test()
  data_exfiltration_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="alert names",
    operator=True,
    values=["Data Exfiltration"]
  )
  phishing_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="alert names",
    operator=True,
    values=["SUSPICIOUS PHISHING EMAIL"]
  )
  cases = siemplify.cases.get_cases_for_test(
    filters=[data_exfiltration_filter, phishing_filter],
    filter_operator="or",
  )
  cases_count = cases.total_count
  soft_assert(
    compare=cases_count,
    to=2,
    success_message="Two cases found in the queue",
    failure_message="More or less than two cases found in the queue",
    extra_info=cases.response_json,
  )
  find_phishing = siemplify.utils.find_key_value_in_json(
    json_data=cases.case_cards,
    key="title",
    value="Phishing email detector",
  )
  find_data_exfiltration = siemplify.utils.find_key_value_in_json(
    json_data=cases.case_cards,
    key="title",
    value="Data Exfiltration",
  )
  soft_assert(
    is_true=find_phishing,
    success_message="Phishing email detector found in cases",
    failure_message="Phishing email detector not found in cases!",
    extra_info=cases.response_json,
  )
  strong_assert(
    is_true=find_data_exfiltration,
    success_message="Data Exfiltration found in cases",
    failure_message="Data Exfiltration not found in cases!",
    extra_info=cases.response_json,
  )


@tags(["CASES", "PARALLEL"])
def test_sort_case_queue():
  """Performs a "Filter Cases In Queue" test.

  Steps:
  1) Simulate all OOTB cases
  2) Sort cases by ID (high to low)
  3) Verify cases are sorted by id
  4) Change the priority of the "Data Exfiltration" case to "critical"
  5) Sort cases by priority
  6) Verify IDs in the queue are different and "Data Exfiltration" is the first
  """
  siemplify.cases.simulate_cases_for_test()
  fetched_cases = siemplify.cases.get_cases_for_test(sort_type="id high")
  cases_found = fetched_cases.case_cards
  case_ids = [case["id"] for case in cases_found]
  sorted_list = sorted(case_ids, reverse=True)
  strong_assert(
    compare=case_ids,
    to=sorted_list,
    success_message="Cases queue is sorted properly",
    failure_message="Cases queue is not sorted properly",
    extra_info=fetched_cases.response_json,
  )
  data_exfiltration = siemplify.utils.find_key_value_in_json(
    json_data=cases_found,
    key="title",
    value="Data Exfiltration"
  )
  found_id = data_exfiltration["id"]
  siemplify.cases.change_priority(case_id=found_id)
  new_fetched_cases = siemplify.cases.get_cases_for_test(
    sort_type="priority high"
  )
  new_cases_found = new_fetched_cases.case_cards
  new_case_ids = [case["id"] for case in new_cases_found]
  soft_assert(
    is_false=case_ids == new_case_ids,
    success_message="Case queue is different",
    failure_message="Case queue is the same",
    extra_info=new_fetched_cases.response_json,
  )
  first_case = new_cases_found[0]
  is_data_exfiltration = siemplify.utils.find_key_value_in_json(
    json_data=first_case,
    key="title",
    value="Data Exfiltration"
  )
  strong_assert(
    is_true=is_data_exfiltration,
    success_message="First case in the queue is 'Data Exfiltration'",
    failure_message="First case in the queue is not 'Data Exfiltration'",
    extra_info=new_fetched_cases.response_json,
  )


@tags(["CASES", "PARALLEL"])
def test_close_case_and_reopen():
  """Performs a "Close case and reopen it" test.

  Steps:
  1) Simulate a "Data Exfiltration" case
  2) Close the case
  3) Verify the case queue is empty
  4) Reopen the case
  5) Verify the case queue has 1 case and it is "Data Exfiltration"
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.close_cases_for_test()
  case_queue = siemplify.cases.get_cases_for_test()
  soft_assert(
    compare=case_queue.total_count,
    to=0,
    success_message="Case queue is empty",
    failure_message="Case queue is not empty",
    extra_info=case_queue.response_json,
  )
  siemplify.cases.reopen_cases(cases_id=[case_id])
  new_case_queue = siemplify.cases.get_cases_for_test()
  soft_assert(
    compare=new_case_queue.total_count,
    to=1,
    success_message="Case queue is empty",
    failure_message="Case queue is not empty",
    extra_info=new_case_queue.response_json,
  )
  data_exfiltration_found = siemplify.utils.find_key_value_in_json(
    json_data=new_case_queue.case_cards,
    key="title",
    value="Data Exfiltration"
  )
  strong_assert(
    is_true=data_exfiltration_found,
    success_message="The case in the queue is 'Data Exfiltration'",
    failure_message="The case in the queue is not 'Data Exfiltration'",
    extra_info=new_case_queue.response_json,
  )


@tags(["CASES", "PARALLEL"])
def test_simulate_cases_in_different_environments():
  """Performs a "Simulate cases in different environments" test.

  Steps:
  1) Create a new environment
  2) Simulate "Phishing Email" case in created environment
  3) Simulate "Data Exfiltration" case in Default Environment
  4) Verify both cases are in case queue and have correct environments
  5) Search for cases sorted by "Default Environment" and verify it has 1 case
  6) Search for cases sorted by created environment and verify it has 1 case
  """
  env1 = siemplify.environments.create_environment_for_test()
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  test_case = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.simulate_cases_in_environment(
    cases=[enums.DefaultCases.PHISHING_EMAIL],
    environment=env1.name,
  )
  env_case = siemplify.cases.get_last_case_id_in_environments(
    environments=[env1.name],
  )
  cases = siemplify.cases.get_cases_in_all_environments()
  phishing_case = siemplify.utils.find_key_value_in_json(
    json_data=cases.case_cards,
    key="id",
    value=env_case,
  )
  phishing_env = siemplify.utils.find_key_value_in_json(
    json_data=phishing_case["environment"],
    key="name",
    value=env1.name,
  )
  data_exfiltration_case = siemplify.utils.find_key_value_in_json(
    json_data=cases.case_cards,
    key="id",
    value=test_case,
  )
  data_exfiltration_env = siemplify.utils.find_key_value_in_json(
    json_data=data_exfiltration_case["environment"],
    key="name",
    value="test_simulate_cases_in_different_environments",
  )
  soft_assert(
    is_true=phishing_env,
    success_message="Phishing email detector is in Environment A",
    failure_message="Phishing email detector is not in Environment A",
    extra_info=phishing_env,
  )
  soft_assert(
    is_true=data_exfiltration_env,
    success_message="Data Exfiltration is in Default Environment",
    failure_message="Data Exfiltration is not in Default Environment",
    extra_info=data_exfiltration_env,
  )
  search_phishing = siemplify.search.search_cases_in_all_environments(
    environments=[env1.name],
    is_closed=False,
  )
  search_exfiltration = siemplify.search.search_cases_in_all_environments(
    environments=["test_simulate_cases_in_different_environments"],
    is_closed=False,
  )
  phishing_found = siemplify.utils.find_key_value_in_json(
    json_data=search_phishing.json()["results"],
    key="title",
    value="Phishing email detector",
  )
  data_exfiltration_found = siemplify.utils.find_key_value_in_json(
    json_data=search_exfiltration.json()["results"],
    key="title",
    value="Data Exfiltration",
  )
  soft_assert(
    is_true=phishing_found,
    success_message="Phishing email detector found in the search",
    failure_message="Phishing email detector not found in the search",
    extra_info=phishing_found,
  )
  strong_assert(
    is_true=data_exfiltration_found,
    success_message="Data Exfiltration found in the search",
    failure_message="Data Exfiltration not found in the search",
    extra_info=data_exfiltration_found,
  )


@tags(["CASES", "PARALLEL"])
def test_validate_simulate_case_audit():
  """Performs a test with a name listed below.

  "Check audit record of simulate case"

  Steps:
  1) Create a new unique user using Audit auxiliary functions.
  2) Simulate a case.
  3) Call get audits and verify a new audit was created for the simulate case.
  """
  user_name = siemplify.audit.create_audit_user()
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  audit_response = siemplify.audit.get_audit_data(users_names=[user_name])
  simulate_cases_audit_response = next(
    (x for x in audit_response.audit_records
     if x.operation == enums.AuditOperations.SIMULATE_CASES),
    None)

  strong_assert(
    is_true=simulate_cases_audit_response,
    success_message="There is 1 audit log for the user for simulate cases",
    failure_message="There is no audit log for the user",
  )

  strong_assert(
    compare=simulate_cases_audit_response.user_guid,
    to=user_name,
    success_message="The user in the audit log is the correct user",
    failure_message="The user in the audit log is not the correct user",
  )


@tags(["BUG"])
def test_add_entity_to_blocklist_and_simulate_case():
  """Performs a test with a name listed below.

  "Add entity to blocklist - entity is not created"
  Steps:
  1) Add an entity to settings -> environments -> blocklist
  (choose "do not create entity")
  2) Simulate a case with this entity
  3) Verify entity is not created and not saved as part of the alert
  4) Close the case
  """
  siemplify.blocklist.add_blocklist_entity(
    identifier="LAB@SIEMPLIFY.LOCAL",
    entity_type="HOSTNAME",
    action="Do not create entity",
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  entities = siemplify.cases.get_case_full_details(case_id=case_id).entities
  soft_assert(
    is_false=list(
      filter(lambda d: d["entityType"] == "HOSTNAME", entities)
    ),
    success_message="Block list entity WAS NOT added to case",
    failure_message="Block list entity WAS added to case",
    extra_info=json.dumps(entities)
  )


@tags(["CASES", "PARALLEL"])
def test_view_entities_details():
  """Performs a test with a name listed below.

  "View entities details"
  Steps:
  1) Simulate Data Exfiltration case
  2) Validate IP and EMAIL entities are equal to predefined json
  3) Close the case
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  entities = siemplify.cases.get_case_full_details(case_id=case_id).entities
  entity = siemplify.utils.find_dict_by_key_in_dicts_list(
    dicts_list=entities,
    key="entityType",
    value="ADDRESS",
  )
  diff = siemplify.utils.get_dicts_diff(
    actual=entity,
    expected=address_entity,
    ignore_order=True,
    exclude_paths=[
      "root['caseId']",
      "root['fields'][0]['items'][3]['value']",
      "root['fields'][0]['items'][4]['value']",
      "root['environment']",
    ],
  )
  soft_assert(
    is_false=diff,
    success_message="No diff found for IP ADDRESS entity",
    failure_message="Diff found for IP ADDRESS entity",
    extra_info=json.dumps(diff)
  )
  entity = siemplify.utils.find_dict_by_key_in_dicts_list(
    dicts_list=entities,
    key="entityType",
    value="USERUNIQNAME",
  )

  diff = siemplify.utils.get_dicts_diff(
    actual=entity,
    expected=username_entity,
    ignore_order=True,
    exclude_paths=[
      "root['caseId']",
      "root['fields'][0]['items'][3]['value']",
      "root['fields'][0]['items'][4]['value']",
      "root['environment']",
    ],
  )
  soft_assert(
    is_false=diff,
    success_message="No diff found for USERNAME entity",
    failure_message="Diff found for USERNAME entity",
    extra_info=json.dumps(diff)
  )


@tags(["CASES", "PARALLEL"])
def test_view_event_details():
  """Performs a test with a name listed below.

  "View event details"
  Steps:
  1) Simulate Data Exfiltration case
  2) Validate event fields are equal to predefined json
  3) Close the case
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  diff = siemplify.utils.get_dicts_diff(
    actual=siemplify.cases.get_alert_events(case=case_id)[0].response_json,
    expected=alert_events,
    ignore_order=True,
    exclude_paths=[
      "root['fields'][0]['items'][13]['value']",
      "root['fields'][0]['items'][14]['value']",
      "root['identifier']",
      "root['caseId']",
      "root['alertIdentifier']",
      "root['time']",
      "root['fields'][9]['items'][2]",
      "root['fields'][9]['items'][1]",
      "root['fields'][9]['items'][0]",
    ],
  )
  soft_assert(
    is_false=diff,
    success_message="No diff found for alert events",
    failure_message="Diff found for alert events",
    extra_info=json.dumps(diff)
  )


@tags(["CASES", "PARALLEL"])
def test_filter_cases_with_and_operator():
  """Performs a test with the name listed below.

  "Filter cases in queue with multiple filters with AND operator"
  Steps:
  1) Create 2 new environments
  2) Simulate "IRC Connections" case in created environment
  3) Simulate "IRC Connections" case in another environment
  4) Verify both cases are in case queue and have correct environments
  5) Filter cases with created environment and "IPS_Product"
  6) Verify only 1 case is shown.
  7) Remove all test environments
  8) Verify that there are not cases
  """
  new_env = siemplify.environments.create_environment_for_test()
  another_env = siemplify.environments.create_environment_for_test()
  siemplify.cases.simulate_cases_in_environment(
    cases=[enums.DefaultCases.IRC_CONNECTIONS],
    environment=another_env.name
  )
  siemplify.cases.simulate_cases_in_environment(
    cases=[enums.DefaultCases.IRC_CONNECTIONS],
    environment=new_env.name,
  )
  cases = siemplify.cases.get_cases_in_environments(
    environments=[new_env.name, another_env.name]
  )
  irc_case = siemplify.utils.find_key_value_in_json(
    json_data=cases.case_cards,
    key="title",
    value="IRC Connections",
  )
  environments = siemplify.utils.find_key_in_json(
    json_data=irc_case,
    key="environment",
  )
  irc_aaa_env = siemplify.utils.find_key_value_in_json(
    json_data=environments,
    key="name",
    value=new_env.name,
  )
  irc_another_env = siemplify.utils.find_key_value_in_json(
    json_data=environments,
    key="name",
    value=another_env.name,
  )
  soft_assert(
    is_true=irc_another_env,
    success_message=
    f"IRC Connection is in test environment {another_env.name}",
    failure_message=
    f"IRC Connection is not in Test Environment {another_env.name}",
    extra_info=another_env.name,
  )
  soft_assert(
    is_true=irc_aaa_env,
    success_message="IRC Connection is in Custom Environment",
    failure_message="IRC Connection is not in Custom Environment",
    extra_info=irc_aaa_env,
  )
  environment_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="environments",
    operator=True,
    values=[new_env.name]
  )
  product_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="products",
    operator=True,
    values=["IPS_Product"]
  )
  filtered_cases = siemplify.cases.get_cases_in_all_environments(
    filters=[environment_filter, product_filter],
    filter_operator="and",
  )
  irc_connection_found = siemplify.utils.find_key_value_in_json(
    json_data=filtered_cases.case_cards,
    key="title",
    value="IRC Connections",
  )
  aaa_env_found = siemplify.utils.find_key_value_in_json(
    json_data=irc_connection_found["environment"],
    key="name",
    value=new_env.name,
  )
  de_env_found = siemplify.utils.find_key_value_in_json(
    json_data=irc_connection_found["environment"],
    key="name",
    value="test_filter_cases_with_and_operator",
  )
  cases_found = filtered_cases.total_count
  soft_assert(
    compare=cases_found,
    to=1,
    success_message="One case found in the queue",
    failure_message="More than one cases found in the queue",
    extra_info=filtered_cases.response_json,
  )
  strong_assert(
    is_true=aaa_env_found,
    success_message="IRC in Environment AAA is in the filtered cases",
    failure_message="IRC in Environment AAA is not in the filtered cases",
    extra_info=aaa_env_found,
  )
  strong_assert(
    is_false=de_env_found,
    success_message="IRC in Default Environment is not in the filtered cases",
    failure_message="IRC in Default Environment is in the filtered cases",
    extra_info=de_env_found,
  )
  siemplify.environments.delete_environment(
    name=new_env.name
  )
  siemplify.environments.delete_environment(
    name=another_env.name
  )
  cases_after_envs_removal = siemplify.cases.get_cases_in_environments(
    environments=[new_env.name, another_env.name]
  )
  strong_assert(
    is_true=cases_after_envs_removal.total_count == 0,
    success_message='All cases should be deleted along with environments',
    failure_message=f'Environments were deleted but cases were not'
                    f'expected 0 cases '
                    f'got {cases_after_envs_removal.total_count} instead'
  )


@tags(["CASES", "PARALLEL"])
def test_filter_case_with_high_priority():
  """Validation: Only the: "high" priority case is returned test.

  Steps:
  1) Create 2 cases
  2) Apply "High" priority to one case
  3) Apply "Low" priority to the second case
  4) Apply filter to the case queue configured as "priority = high"
  """
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.change_priority(case_id=case_id, priority=80)
  priority = siemplify.cases.get_last_case_full_details_for_test().priority
  soft_assert(
    compare=priority,
    to=80,
    success_message=f"Case priority is {priority}",
    failure_message=f"Wrong case priority. Expected 80. Received {priority}",
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  case2_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.change_priority(case_id=case2_id, priority=40)
  priority = siemplify.cases.get_last_case_full_details_for_test().priority
  soft_assert(
    compare=priority,
    to=40,
    success_message=f"Case priority is {priority}",
    failure_message=f"Wrong case priority. Expected 40. Received {priority}",
  )
  priority_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type="Priorities",
    operator=True,
    values=["High"]
  )
  priority_cases_filter = siemplify.cases.get_cases_for_test(
    filters=[priority_filter]
  )
  cases_found = priority_cases_filter.total_count
  find_data_exfiltration = siemplify.utils.find_key_value_in_json(
    json_data=priority_cases_filter.case_cards,
    key="title",
    value="Data Exfiltration",
  )
  strong_assert(
    compare=cases_found,
    to=1,
    success_message="One case found in the queue",
    failure_message="More than one case found in the queue",
    extra_info=priority_cases_filter.response_json,
  )
  strong_assert(
    is_true=find_data_exfiltration,
    success_message="Data Exfiltration found in cases",
    failure_message="Data Exfiltration not found in cases!",
    extra_info=priority_cases_filter.response_json,
  )


@tags(["CASES", "PARALLEL"])
def test_add_tags_fail():
  """To test adding tags to an non existing case.

  Steps:
  1) Define example parameters
  2) Adding tag
  3) Reporting success if addition fails
  """
  alert_name = "example_alert"
  case_id = 999999
  response = siemplify.cases.add_tag_to_fail(
    case_id=case_id,
    tag="exampleTAG",
    alert_name=alert_name
  )
  strong_assert(
    is_false=(response.status_code == 200),
    success_message="Tag not added",
    failure_message="Tag ADDED",
    extra_info=f"Response from API: {response.status_code}"
  )


@tags(["CASES", "SEQUENCE"])
def test_case_card_request():
  """Performs a test to validate the GetCaseCard Request for Page Size.

  Steps:
  1) Simulate a case
  2) Fetch the Get case card request with App key and admin credentials.
  3) Compare the json responses recieved.
  """

  # Simulate a case
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  # Fetch Get Case Card Request using App Key.
  response_appkey = siemplify.cases.get_case_card_request_test(
    validate_admincreds=False)
  # Fetch Get Case Card Request using admin credentials.
  response_admin_creds = siemplify.cases.get_case_card_request_test()
  results = siemplify.utils.get_dicts_diff(
    response_appkey, response_admin_creds)
  # compare the values of the two responses
  strong_assert(
    is_false=results,
    success_message=(
      "The  responses recieved from app key and admin creds are identical"
    ),
    failure_message=(
      "There are some values that changed in the two responses "
      f": {results}"
    ),
  )


@tags(["CASES", "PARALLEL"])
def test_case_cards_properties():
  """Examines cases from 2 environments

  1) Create a new environment with custom base 64 image
  2) Create a new user - Admins + all available envs
  3) Simulate "Phishing Email" case in created environment
  4) Simulate "Data Exfiltration" case in Default Environment
  5) Verify that test environment has no base64 image
  6) Verify that new environment has base64 image
  7) Assign new user to case from created environment
  8) Edit created user -> envs -> test env only
  9) Verify that only one case is assigned to new user
  10) Add a case description to case from test env
  11) Add a case tag to case from test env
  12) Verify both cases are in case queue and have correct environments
  13) Verify that case from new environment has correct base64 image
  14) Verify that case from test environment has no base64 image
  15) Verify that case description was added to case
  16) Verify that case tag was added to case
  17) Search for cases sorted by "Default Environment" and verify it has 1 case
  18) Search for cases sorted by created environment and verify it has 1 case
  """
  logo_file_path = "resources/raw_data"
  logo_file_name = "cloud_smaller_logo.png"
  env1_base64_logo = siemplify.utils.get_base64_from_image(
    file_path=logo_file_path,
    file_name=logo_file_name
  )
  env1 = siemplify.environments.create_environment_for_test()
  test_env_name = inspect.stack()[0][3]
  env1.base64_image = env1_base64_logo
  env1 = siemplify.environments.update_existing_environment(env1)
  test_user = siemplify.users.create_user_for_test(
    environments=[test_env_name, env1.name],
    permission_group=test_env_name
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  test_env = siemplify.environments.get_environment_data(
    environment_name=test_env_name
  )
  test_case = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.simulate_cases_in_environment(
    cases=[enums.DefaultCases.PHISHING_EMAIL],
    environment=env1.name,
  )
  env_case = siemplify.cases.get_last_case_id_in_environments(
    environments=[env1.name],
  )
  soft_assert(
    compare=test_env.base64_image,
    to=None,
    success_message='Test environment should not have any base64 image',
    failure_message='Test environment had base64 image but should not'
  )
  soft_assert(
    is_true=env1.base64_image,
    success_message='New environment should have a changed base64 image',
    failure_message='New environment did not have base64 image but should'
  )
  siemplify.cases.assign_case_to_user(
    case_id=env_case,
    user_id=test_user.username
  )
  siemplify.authentication.log_in_for_test(
    email=test_user.email,
    password="Password1!",
  )
  cases_assigned_to_new_user = siemplify.cases.get_assigned_cases_for_test()
  cases_assigned_to_new_user_count = \
    cases_assigned_to_new_user.json().get('casesCount')[0]['count']
  soft_assert(
    compare=cases_assigned_to_new_user_count,
    to=1,
    success_message=f"Only one case should be assigned to {test_user.login}",
    failure_message=f"Only one case should be assigned to {test_user.login}"
                    f"got {cases_assigned_to_new_user_count} instead"
  )
  test_user.environments = [test_env_name]
  siemplify.users.edit_existing_user(
    user_details=test_user,
    permission_group=test_env_name
  )
  case_description = "CaseDescriptionTest"
  siemplify.cases.change_case_description(
    case_id=test_case,
    description=case_description
  )
  case_tag = "CaseTagTest"
  siemplify.cases.add_tag(
    case_id=test_case,
    tag=case_tag
  )
  cases = siemplify.cases.get_cases_in_all_environments()
  phishing_case = siemplify.utils.find_key_value_in_json(
    json_data=cases.case_cards,
    key="id",
    value=env_case,
  )
  phishing_env = siemplify.utils.find_key_value_in_json(
    json_data=phishing_case["environment"],
    key="name",
    value=env1.name,
  )
  data_exfiltration_case = siemplify.utils.find_key_value_in_json(
    json_data=cases.case_cards,
    key="id",
    value=test_case,
  )
  phishing_case_description = siemplify.utils.find_key_value_in_json(
    json_data=data_exfiltration_case,
    key="description",
    value=case_description
  )
  phishing_case_tags = siemplify.utils.find_key_value_in_json(
    json_data=data_exfiltration_case,
    key="tags",
    value=[case_tag]
  )
  data_exfiltration_env = siemplify.utils.find_key_value_in_json(
    json_data=data_exfiltration_case["environment"],
    key="name",
    value=test_env_name,
  )
  soft_assert(
    is_true=phishing_case['environment']['base64Image'],
    success_message=
    "Phishing email detector's env base64 image was properly uploaded",
    failure_message=
    "Phishing email detector's env base64 image was not properly uploaded",
  )
  soft_assert(
    compare=data_exfiltration_case['environment']['base64Image'],
    to=None,
    success_message="Data Exfiltration's env base64 image was None",
    failure_message="Data Exfiltration's env base64 image was not None"
  )
  soft_assert(
    compare=phishing_case_description['description'],
    to=case_description,
    success_message=
    f"Phishing email detector's description should was {case_description}",
    failure_message=
    f"Phishing email detector's description was not {case_description}",
    extra_info=phishing_case_description,
  )
  soft_assert(
    compare=phishing_case_tags['tags'],
    to=[case_tag],
    success_message=
    f"Phishing email detector's  tags should was {case_tag}",
    failure_message=
    f"Phishing email detector's  tags were not {case_tag}",
    extra_info=phishing_case_tags,
  )
  soft_assert(
    is_true=phishing_env,
    success_message=f"Phishing email detector is in {env1.name}",
    failure_message=f"Phishing email detector is not in {env1.name}",
    extra_info=phishing_env,
  )
  soft_assert(
    is_true=data_exfiltration_env,
    success_message=f"Data Exfiltration is in {test_env_name}",
    failure_message=f"Data Exfiltration is not in {test_env_name}",
    extra_info=data_exfiltration_env,
  )
  search_phishing = siemplify.search.search_cases_in_all_environments(
    environments=[env1.name],
    is_closed=False,
  )
  search_exfiltration = siemplify.search.search_cases_in_all_environments(
    environments=[test_env_name],
    is_closed=False,
  )
  soft_assert(
    compare=search_phishing.json()["totalCount"],
    to=1,
    success_message=f"Only one case found in {env1.name}",
    failure_message=
    f"Only one case expected "
    f"got {search_phishing.json()['totalCount']} instead",
  )
  strong_assert(
    compare=search_exfiltration.json()["totalCount"],
    to=1,
    success_message=f"Only one case found in {test_env_name}",
    failure_message=
    f"Only one case expected "
    f"got {search_exfiltration.json()['totalCount']} instead",
  )


@tags(['PARALLEL', 'CASES'])
def test_sort_case_alert_and_stage_filter():
  """Perform case queue filtering by case and alert sla.

Steps:
  1) Create new SLA - slaPeriod 50, criticalperiod 20, AlertType: Specific alert, Data Exfiltration
  2) Create new SLA - slaPeriod 70, criticalperiod 20, AlertType: Specific alert, Phishing email detector
  3) Create new SLA - slaPeriod 90, criticalperiod 20, AlertType: Specific alert, Virus Found Or security risk found
  4) Simulate 4 cases: 2x Phishing email, Data Exfiltration, Malware Detected - one by one in given order
  5) Create new SLA - slaPeriod 80, criticalperiod 40, AlertType: CaseStage - Triage
  7) Create new SLA - slaPeriod 50, criticalperiod 10, AlertType: CaseStage - Assessment
  8) Change case stage - Malware Detected - Assessment
  9) Sort case queue by Stage SLA DESCENDING
  10) Virus found case is last in case queue
  11) Sort case queue by Stage SLA ASCENDING
  12) Virus found case is first in case queue
  13) Sort case queue by SLA ASCENDING
  14) Phishing email case is second, Data Exfiltration first
  15) Sort case queue by SLA DESCENDING
  16) Phishing email case is second, Data Exfiltration last

  """
  data_ex_sla = siemplify.sla.add_sla_definition_for_test(
    value_type=enums.ApiSlaProviderType.ALERT_RULE,
    alert_type=enums.ApiSlaAlertType.SPECIFIC_ALERTS,
    value="[\"Data Exfiltration\"]",
    sla_period=50,
    critical_period=20,
  )
  phishing_sla = siemplify.sla.add_sla_definition_for_test(
    value_type=enums.ApiSlaProviderType.ALERT_RULE,
    alert_type=enums.ApiSlaAlertType.SPECIFIC_ALERTS,
    value="[\"Phishing email detector\"]",
    sla_period=70,
    critical_period=20,
  )
  virus_sla = siemplify.sla.add_sla_definition_for_test(
    value_type=enums.ApiSlaProviderType.ALERT_RULE,
    alert_type=enums.ApiSlaAlertType.SPECIFIC_ALERTS,
    value="[\"Virus Found Or security risk found\"]",
    sla_period=90,
    critical_period=20,
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  phishing_case_1 = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  phishing_case_2 = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  data_ex_case = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.MALWARE_DETECTED]
  )
  virus_case = siemplify.cases.get_last_case_id_for_test()
  siemplify.sla.add_sla_definition_for_test(
    value_type=enums.ApiSlaProviderType.CASE_STAGE,
    value='["Triage"]',
    sla_period=80,
    critical_period=40,
  )
  siemplify.sla.add_sla_definition_for_test(
    value_type=enums.ApiSlaProviderType.CASE_STAGE,
    value='["Assessment"]',
    sla_period=50,
    critical_period=10,
  )
  siemplify.cases.change_stage(
    case_id=virus_case,
    stage=enums.CaseStages.ASSESSMENT
  )
  cases_sorted_by_stage_sla_descending = siemplify.cases.get_cases_for_test(
    sort_type="case stage longest"
  )
  strong_assert(
    compare=cases_sorted_by_stage_sla_descending.case_cards[-1].get('id'),
    to=virus_case,
    success_message=
    "Virus Found Or security risk found case was last after sorting",
    failure_message=
    "Virus Found Or security risk found case should be last after sorting "
    "but was not"
  )
  cases_sorted_by_stage_sla_ascending = siemplify.cases.get_cases_for_test(
    sort_type="case stage shortest"
  )
  strong_assert(
    compare=cases_sorted_by_stage_sla_ascending.case_cards[0].get('id'),
    to=virus_case,
    success_message=
    "Virus Found Or security risk found case was first after sorting",
    failure_message=
    "Virus Found Or security risk found case should be first after sorting "
    "but was not"
  )
  cases_sorted_by_sla_ascending = siemplify.cases.get_cases_for_test(
    sort_type="alert type shortest"
  )
  strong_assert(
    compare=cases_sorted_by_sla_ascending.case_cards[1].get('id'),
    to=phishing_case_1,
    success_message=
    "Phishing email detector case was second after sorting",
    failure_message=
    "Phishing email detector case should be second after sorting "
    "but was not"
  )
  strong_assert(
    compare=cases_sorted_by_sla_ascending.case_cards[0].get('id'),
    to=data_ex_case,
    success_message=
    f"{enums.DefaultCases.DATA_EXFILTRATION} case was first after sorting",
    failure_message=
    f"{enums.DefaultCases.DATA_EXFILTRATION} case should be first after sorting"
    f"but was not"
  )
  cases_sorted_by_sla_descending = siemplify.cases.get_cases_for_test(
    sort_type="alert type longest"
  )
  strong_assert(
    compare=cases_sorted_by_sla_descending.case_cards[1].get('id'),
    to=phishing_case_1,
    success_message=
    "Phishing email detector case was second after sorting",
    failure_message=
    "Phishing email detector case should be second after sorting "
    "but was not"
  )
  strong_assert(
    compare=cases_sorted_by_sla_descending.case_cards[-1].get('id'),
    to=data_ex_case,
    success_message=
    f"{enums.DefaultCases.DATA_EXFILTRATION} case was last after sorting",
    failure_message=
    f"{enums.DefaultCases.DATA_EXFILTRATION} case should be last after sorting"
    f"but was not"
  )


@tags(["PARALLEL", "CASES"])
def test_filter_case_queue_by_analyst():
  """Filters case queue by analyst name.

  Steps:
  1) Create 2 users
  2) Simulate any case
  3) Assign it to first user
  4) Simulate another case
  5) Assign it to second user
  6) Filter case queue - Analyst IS first user name
  7) Only one case assigned to user is shown

  """
  test_env_name = inspect.stack()[0][3]
  user_1 = siemplify.users.create_user_for_test(
    permission_group=test_env_name,
    environments=[test_env_name]
  )
  user_2 = siemplify.users.create_user_for_test(
    permission_group=test_env_name,
    environments=[test_env_name]
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  data_ex_case = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.assign_case_to_user(
    case_id=data_ex_case,
    user_id=user_1.username
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.PHISHING_EMAIL]
  )
  phishing_case = siemplify.cases.get_last_case_id_for_test()
  siemplify.cases.assign_case_to_user(
    case_id=phishing_case,
    user_id=user_2.username
  )
  user_1_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type='analysts',
    operator=True,
    values=[user_1.username]
  )
  user_1_filtered_case_queue = siemplify.cases.get_cases_for_test(
    filters=[user_1_filter]
  )
  strong_assert(
    compare=user_1_filtered_case_queue.case_cards[0].get('id'),
    to=data_ex_case,
    success_message="Assigned Data Exfiltration case found after filtering",
    failure_message=
    "Assigned Data Exfiltration case was not found after filtering"
  )
  strong_assert(
    is_true=user_1_filtered_case_queue.total_count == 1,
    success_message="Only one case should be found after filtering",
    failure_message=f"Expected one case after filtering"
                    f", got {user_1_filtered_case_queue.total_count} instead"
  )
  user_2_filter = siemplify.cases.create_case_filter_criteria(
    criteria_type='analysts',
    operator=True,
    values=[user_2.username]
  )
  user_2_filtered_case_queue = siemplify.cases.get_cases_for_test(
    filters=[user_2_filter]
  )
  strong_assert(
    compare=user_2_filtered_case_queue.case_cards[0].get('id'),
    to=phishing_case,
    success_message="Assigned Phishing email case found after filtering",
    failure_message=
    "Assigned Phishing email case was not found after filtering"
  )
  strong_assert(
    is_true=user_2_filtered_case_queue.total_count == 1,
    success_message="Only one case should be found after filtering",
    failure_message=f"Expected one case after filtering"
                    f", got {user_2_filtered_case_queue.total_count} instead"
  )


# Disabled due to https://b.corp.google.com/issues/293807051
# @tags(["PARALLEL", "CASES"])
# def test_add_comment_to_case_from_different_env():
#   """Verifies that user who belongs to environment
#   can't add comment to case from different environment
#
#   Steps:
#     1) Create a new environment
#     2) Simulate any case in test environment
#     3) Create new user in the Basic permission group, env - new environment
#     4) Try to add comment to case from test environment
#   """
#   test_env_name = inspect.stack()[0][3]
#   env_1 = siemplify.environments.create_environment_for_test()
#   siemplify.cases.simulate_cases_in_environment(
#     cases=[enums.DefaultCases.DATA_EXFILTRATION],
#     environment=test_env_name,
#   )
#   data_ex_case_id = siemplify.cases.get_last_case_id_for_test()
#   data_ex_case_identifier = siemplify.cases.get_case_details(
#     case_id=data_ex_case_id).alert_cards[0].identifier
#   user_1 = siemplify.users.create_user_for_test(
#     environments=[env_1.name],
#     permission_group="Basic"
#   )
#   siemplify.authentication.log_in_for_test(
#     email=user_1.email,
#     password="Password1!"
#   )
#   siemplify.cases.add_case_wall_comment(
#     case_id=data_ex_case_id,
#     alert_identifier=data_ex_case_identifier,
#     comment='Whatever',
#     ignore_403=True
#   )
#   all_case_wall_items = siemplify.cases.get_all_case_wall_activities(
#     case_id=data_ex_case_id
#   )
#   strong_assert(
#     is_true=len(all_case_wall_items) == 1,
#     success_message="Only one comment should be visible in simulated case",
#     failure_message=f"Expected only one comment in case,"
#                     f" got {len(all_case_wall_items)} instead"
#   )

@tags(["PARALLEL", "CASES"])
def test_add_upgrade_case_wall_comment():
  """Verifies addition and upgrade of case wall comments

  Steps:
    1) Simulate Data Exfiltration case
    2) Add case comment -> comment -> "love you"
    3) Verify that comment was added, content of it is correct, user is correct,
    last editor is correct, modificationTimeUnixTimeInMs should be current time,
    creation time is current date
    4) Edit added comment -> comment -> "kidding"
    5)Verify that comment was edited, content of it is updated, user is correct,
    last editor is correct, modification_time should be current time,
    creation time remains unchanged
    6) Add another comment with attachment -> cloud_smaller_logo.png
    7) Verify that comment was added, content of it is correct, user is correct,
    last editor is correct, modification_time should be current time,
    creation time is current date, file was updated properly
    8) Edit comment with attachment - change original text and
    attach different file
    9) Verify that comment was edited, id remain the same, content changed,
    user is still the same, modification_time should be current time,
    attached file was changed to new one, last editor should be current user,
    creation time remains unchanged
    10) Edit comment with attachment - change its text and
    remove file from comment
    11) Verify that comment was edited, id remain the same, content changed,
    user is still the same, modification_time should be current time,
    attached file should be deleted, last editor should be current user,
    creation time remains unchanged

    NOTE: Update comment part is commented out as endpoint doesn't work
  """
  test_name = inspect.stack()[0][3]
  test_user_details = [user for user in siemplify.users.get_users().objects_list
                       if user['firstName'] == test_name]
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  data_ex_case_id = siemplify.cases.get_last_case_id_for_test()
  data_ex_case_identifier = siemplify.cases.get_case_details(
    case_id=data_ex_case_id).alert_cards[0].identifier
  # Adding text comments
  curr_time = time.time()
  delta_time = 1000
  case_comment = siemplify.cases.add_case_wall_comment(
    case_id=data_ex_case_id,
    comment="love you",
    alert_identifier=data_ex_case_identifier
  )
  # Validate comment's fields
  strong_assert(
    compare=case_comment.comment,
    to="love you",
    success_message="Comment 'love you' was added successfully",
    failure_message="Failed to add 'love you' comment to case"
  )
  strong_assert(
    compare=test_user_details[0].get('userName'),
    to=case_comment.creator_user_id,
    success_message="Creator of case comment was test user",
    failure_message="Creator of case comment was not test user"
  )
  strong_assert(
    compare=test_user_details[0].get('userName'),
    to=case_comment.last_editor_id,
    success_message="Last editor of case comment was test user",
    failure_message="Last editor of case comment was not test user"
  )
  strong_assert(
    is_true=case_comment.modification_time_unix_in_ms ==
            case_comment.creation_time_unix_time_in_ms,
    success_message="Case wall modification time was the same as creation",
    failure_message="Case wall modification time was not the same as creation"
  )
  strong_assert(
    is_true=(case_comment.creation_time_unix_time_in_ms - curr_time)
            > delta_time,
    success_message="Case wall creation time was as current time",
    failure_message="Case wall creation time was not as current time"
  )
  # Update comment's text
  # Commented out as update case wall comment endpoint doesn't work
  # curr_time = time.time()
  # updated_comment = siemplify.cases.update_case_wall_comment(
  #   case_id=data_ex_case_id,
  #   comment_id=case_comment.id,
  #   updated_comment="kidding"
  # )
  # Validate updated comment's fields
  # strong_assert(
  #   compare=updated_comment.comment_for_client,
  #   to="kidding",
  #   success_message="Comment was updated successfully",
  #   failure_message="Failed to update comment to case"
  # )
  # strong_assert(
  #   compare=test_user_details[0].get('userName'),
  #   to=updated_comment.creator_user_id,
  #   success_message="Creator of case comment was test user",
  #   failure_message="Creator of case comment was not test user"
  # )
  # strong_assert(
  #   compare=test_user_details[0].get('userName'),
  #   to=updated_comment.last_editor,
  #   success_message="Last editor of case comment was test user",
  #   failure_message="Last editor of case comment was not test user"
  # )
  # strong_assert(
  #   is_true=updated_comment.modification_time_unix_time_in_ms == 0,
  #   success_message="Case wall modification time was 0",
  #   failure_message="Case wall modification time was not 0 as expected"
  # )
  # strong_assert(
  #   is_true=updated_comment.creation_time_unix_time_in_ms == curr_time,
  #   success_message="Case wall creation time was as current time",
  #   failure_message="Case wall creation time was not as current time"
  # )
  # Fetching example attachment blob64 value
  with open(RAW_DATA_FOLDER_PATH + '/cloud_smaller_logo_blob', 'r') as blob:
    attachment_blob = blob.read()
  # Adding case comment with attachment
  curr_time = time.time()
  attachment_comment = siemplify.cases.add_case_wall_comment(
    case_id=data_ex_case_id,
    alert_identifier=data_ex_case_identifier,
    comment="attachment comment",
    file_name="cloud_smaller_logo",
    file_type=".png",
    base_64_blob=attachment_blob
  )
  strong_assert(
    compare=attachment_comment.comment,
    to="attachment comment",
    success_message="Comment 'attachment comment' was added successfully",
    failure_message="Failed to add 'attachment comment' comment to case"
  )
  strong_assert(
    compare=attachment_comment.file_name,
    to="cloud_smaller_logo",
    success_message="Comment's attachment was added successfully",
    failure_message="Failed to add attachment to comment to case"
  )
  strong_assert(
    compare=test_user_details[0].get('userName'),
    to=attachment_comment.creator_user_id,
    success_message="Creator of case comment was test user",
    failure_message="Creator of case comment was not test user"
  )
  strong_assert(
    compare=test_user_details[0].get('userName'),
    to=attachment_comment.last_editor_id,
    success_message="Last editor of case comment was test user",
    failure_message="Last editor of case comment was not test user"
  )
  strong_assert(
    is_true=attachment_comment.modification_time_unix_in_ms ==
            attachment_comment.creation_time_unix_time_in_ms,
    success_message="Case wall modification time was the same as creation",
    failure_message="Case wall modification time was not the same as creation"
  )
  strong_assert(
    is_true=
    (attachment_comment.creation_time_unix_time_in_ms - curr_time) > delta_time,
    success_message="Case wall comment's creation time was as current time",
    failure_message="Case wall comment's creation time was not as current time"
  )
  downloaded_attachment = siemplify.cases.get_case_evidence_data(
    attachment_id=attachment_comment.file_id,
    case_id=data_ex_case_id
  )
  logo_file_path = "resources/raw_data"
  logo_file_name = "cloud_smaller_logo.png"
  original_attachment = siemplify.utils.get_base64_from_image(
    file_path=logo_file_path,
    file_name=logo_file_name
  )
  strong_assert(
    is_true=downloaded_attachment == original_attachment,
    success_message="Attachment was successfully downloaded",
    failure_message="Failed to download attachment"
  )
  # Commented out as update case wall comment endpoint doesn't work
  # with open(RAW_DATA_FOLDER_PATH + '/logo_blob', 'r') as blob:
  #   updated_attachment_blob = blob.read()
  # curr_time = time.time()
  # edited_attachment_comment = siemplify.cases.update_case_wall_comment(
  #   case_id=data_ex_case_id,
  #   comment_id=attachment_comment.comment_id,
  #   base_64_blob=updated_attachment_blob,
  #   name="logo",
  #   type=".png",
  #   updated_comment="updated attachment",
  #   attachment_id=attachment_comment.evidence_id
  # )
  # strong_assert(
  #   compare=edited_attachment_comment.comment_for_client,
  #   to="updated attachment",
  #   success_message="Content of attachment comment was updated successfully",
  #   failure_message="Failed to update attachment comment's content"
  # )
  # strong_assert(
  #   compare=edited_attachment_comment.id,
  #   to=attachment_comment.id,
  #   success_message="Comment id should remained the same after editing",
  #   failure_message="Comment id was changed to different after editing"
  # )
  # strong_assert(
  #   compare=edited_attachment_comment.evidence_name,
  #   to="logo",
  #   success_message="Comment's attachment was added successfully",
  #   failure_message="Failed to update comment's attachment"
  # )
  # strong_assert(
  #   compare=test_user_details[0].get('userName'),
  #   to=edited_attachment_comment.creator_user_id,
  #   success_message="Creator of case comment was test user",
  #   failure_message="Creator of case comment was not test user"
  # )
  # strong_assert(
  #   compare=test_user_details[0].get('userName'),
  #   to=edited_attachment_comment.last_editor,
  #   success_message="Last editor of case comment was test user",
  #   failure_message="Last editor of case comment was not test user"
  # )
  # strong_assert(
  #   is_true=edited_attachment_comment.modification_time_unix_time_in_ms == 0,
  #   success_message="Case wall comment's modification time was 0",
  #   failure_message=
  #   "Case wall comment's modification time was not 0 as expected"
  # )
  # strong_assert(
  #   is_true=edited_attachment_comment.
  #           creation_time_unix_time_in_ms == curr_time,
  #   success_message="Case wall comment's creation time was as current time",
  #   failure_message="Case wall comment's creation time was not as current time"
  # )
  # curr_time = time.time()
  # attachment_comment_with_removed_attachment = \
  #   siemplify.cases.update_case_wall_comment(
  #     case_id=data_ex_case_id,
  #     comment_id=edited_attachment_comment.comment_id,
  #     base_64_blob=None,
  #     name=None,
  #     type=None,
  #     updated_comment="Comment with removed attachment"
  #   )
  # strong_assert(
  #   compare=attachment_comment_with_removed_attachment.comment,
  #   to="Comment with removed attachment",
  #   success_message="Content of attachment comment was updated successfully",
  #   failure_message="Failed to update attachment comment's content"
  # )
  # strong_assert(
  #   compare=attachment_comment_with_removed_attachment.id,
  #   to=attachment_comment_with_removed_attachment.id,
  #   success_message="Comment id should remained the same after editing",
  #   failure_message="Comment id was changed to different after editing"
  # )
  # strong_assert(
  #   is_true=attachment_comment_with_removed_attachment.evidence_name is None,
  #   success_message="Comment's attachment was removed successfully",
  #   failure_message="Failed to delete comment's attachment"
  # )
  # strong_assert(
  #   compare=test_user_details[0].get('userName'),
  #   to=attachment_comment_with_removed_attachment.creator_user_id,
  #   success_message="Creator of case comment was test user",
  #   failure_message="Creator of case comment was not test user"
  # )
  # strong_assert(
  #   compare=test_user_details[0].get('userName'),
  #   to=attachment_comment_with_removed_attachment.last_editor,
  #   success_message="Last editor of case comment was test user",
  #   failure_message="Last editor of case comment was not test user"
  # )
  # strong_assert(
  #   is_true=attachment_comment_with_removed_attachment.
  #           modification_time_unix_time_in_ms == 0,
  #   success_message="Case wall comment's modification time was 0",
  #   failure_message=
  #   "Case wall comment's modification time was not 0 as expected"
  # )
  # strong_assert(
  #   is_true=attachment_comment_with_removed_attachment.
  #           creation_time_unix_time_in_ms == curr_time,
  #   success_message="Case wall comment's creation time was as current time",
  #   failure_message="Case wall comment's creation time was not as current time"
  # )


@tags(["PARALLEL", "CASES"])
def test_delete_case_wall_comment():
  """Adds and deletes case wall comment

  Steps:
    1) Simulate Data Exfiltration case
    2) Add new case wall comment with attachment
    3) Delete just added case wall comment
    4) Verify that case wall comment was deleted
  """
  test_name = inspect.stack()[0][3]
  test_user_details = [user for user in siemplify.users.get_users().objects_list
                       if user['firstName'] == test_name]
  test_user_name = siemplify.utils.find_key_in_json(
    json_data=test_user_details[0],
    key='userName'
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  data_ex_case_id = siemplify.cases.get_last_case_id_for_test()
  data_ex_case_identifier = siemplify.cases.get_case_details(
    case_id=data_ex_case_id).alert_cards[0].identifier
  curr_time = time.time()
  delta_time = 1000
  with open(RAW_DATA_FOLDER_PATH + '/logo_blob', 'r') as blob:
    attachment_blob = blob.read()
  attachment_comment = siemplify.cases.add_case_wall_comment(
    case_id=data_ex_case_id,
    alert_identifier=data_ex_case_identifier,
    comment="attachment comment",
    file_name="logo",
    file_type=".png",
    base_64_blob=attachment_blob
  )
  strong_assert(
    compare=attachment_comment.comment,
    to="attachment comment",
    success_message="Comment 'attachment comment' was added successfully",
    failure_message="Failed to add 'attachment comment' comment to case"
  )
  strong_assert(
    compare=attachment_comment.file_name,
    to="logo",
    success_message="Comment's attachment was added successfully",
    failure_message="Failed to add attachment to comment to case"
  )
  strong_assert(
    compare=test_user_name,
    to=attachment_comment.creator_user_id,
    success_message="Creator of case comment was test user",
    failure_message="Creator of case comment was not test user"
  )
  strong_assert(
    compare=test_user_name,
    to=attachment_comment.last_editor_id,
    success_message="Last editor of case comment was test user",
    failure_message="Last editor of case comment was not test user"
  )
  strong_assert(
    is_true=attachment_comment.modification_time_unix_in_ms ==
            attachment_comment.creation_time_unix_time_in_ms,
    success_message="Case wall modification time was the same as creation",
    failure_message="Case wall modification time was not the same as creation"
  )
  strong_assert(
    is_true=
    (attachment_comment.creation_time_unix_time_in_ms - curr_time) > delta_time,
    success_message="Case wall comment's creation time was as current time",
    failure_message="Case wall comment's creation time was not as current time"
  )
  siemplify.cases.mark_case_wall_comment_as_deleted(
    comment_id=attachment_comment.id,
    case_id=data_ex_case_id
  )
  all_remaining_comments = siemplify.cases.get_all_case_wall_activities(
    case_id=data_ex_case_id
  )
  deleted_comment = all_remaining_comments[0]
  strong_assert(
    is_true=deleted_comment.is_deleted,
    success_message="Comment was deleted successfully",
    failure_message="Failed to delete comment"
  )
  strong_assert(
    is_true=deleted_comment.comment is None,
    success_message="Comment was deleted successfully",
    failure_message="Failed to delete comment"
  )


@tags(["PARALLEL", "CASES"])
def test_case_wall_pending_actions_in_time():
  """Verifies case comment pending action executed within timeout

  1) Try to create a playbook with manual action and
  set timeout to less than 5 minutes (300 secs)
  2) Verify it's impossible to create a pb with manual action
  with timeout less than 300 seconds (5 minutes)
  3) Create new playbook:
  Case Comments - set this action as manual, timeout 5 minutes (300 secs),
  skip when fails
  4) Simulate Data Exfiltration
  5) Get all pending actions for user
  6) Verify that there's one pending action waiting for user
  7) Get GetWorkflowInstanceSummary
  8) Verify that it contains UserActionRequiredStep key, and it's not a null
  9) Execute Pending Action
  10) Verify that case comment was added
  11) Get all pending actions for user
  12) Verify that there's no pending actions after execution
  """
  test_name = inspect.stack()[0][3]
  test_user_details = [user for user in siemplify.users.get_users().objects_list
                       if user['firstName'] == test_name]
  test_user_name = siemplify.utils.find_key_in_json(
    json_data=test_user_details[0],
    key='userName'
  )
  trigger = siemplify.playbooks.create_trigger()
  manual_case_tag_with_wrong_timeout = \
    siemplify.payloads.playbook_actions.add_case_tag(
      tag='wrong',
      is_automatic=False,
      is_skippable=True,
      skip_on_fail=True,
      pending_timeout="200",
    )
  wrong_playbook = siemplify.playbooks.create_playbook_for_test(
    trigger=trigger,
    actions=[manual_case_tag_with_wrong_timeout],
    ignore_500=True
  )
  strong_assert(
    is_true=wrong_playbook.status_code == 500,
    success_message="Couldn't create playbook with manual action with"
                    "timeout less than 300 seconds (5 minutes)",
    failure_message="Playbook with manual action with timeout less than "
                    "300 seconds was created but it shouldn't"
  )
  manual_case_comment_action = \
    siemplify.payloads.playbook_actions.add_case_comment(
      comment='correct one',
      is_automatic=False,
      is_skippable=True,
      skip_on_fail=True,
      pending_timeout="300",
      assigned_users="{}".format('["' + test_user_name + '"]')
    )
  correct_pb = siemplify.playbooks.create_playbook_for_test(
    trigger=trigger,
    actions=[manual_case_comment_action]
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  data_ex_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
    case_id=data_ex_id,
    playbook_name=correct_pb.name,
    cadence=1
  )
  all_pending_actions = siemplify.homepage.get_all_pending_actions_for_user()
  pending_action = all_pending_actions.pending_steps[0]
  strong_assert(
    is_true=all_pending_actions.pending_steps_count == 1,
    success_message="Got only one pending action",
    failure_message="Expected only one pending action got "
                    f"{all_pending_actions.pending_steps_count} instead"
  )
  strong_assert(
    is_true=data_ex_id == pending_action.case_id,
    success_message="Pending action comes from correct case",
    failure_message=f"Pending action should come from case with {data_ex_id} id"
                    f"but came from {pending_action.case_id}"
  )
  data_ex_details = siemplify.cases.get_case_details(
    case_id=data_ex_id
  )
  data_ex_alert = data_ex_details.alert_cards[0]
  data_ex_alert_identifier = data_ex_alert.alert_group_identifier
  playbook_instance_summary = \
    siemplify.playbooks.get_playbook_instance_summmary(
      case_id=data_ex_id,
      alert_identifier=data_ex_alert_identifier,
      definition_id=correct_pb.identifier
    )
  pb_instance_summary_user_act_req = siemplify.utils.find_key_in_json(
    json_data=playbook_instance_summary.json(),
    key="userActionRequiredStep"
  )
  strong_assert(
    is_true=pb_instance_summary_user_act_req is not None,
    success_message="Playbook summary has userActionRequiredStep value",
    failure_message="Playbook summary didn't have userActionRequiredStep value"
  )
  step_to_execute_id = siemplify.utils.find_key_in_json(
    json_data=correct_pb.steps[0],
    key="originalStepIdentifier"
  )
  alert_identifier = siemplify.cases.get_case_full_details(
    case_id=data_ex_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  execute_action = siemplify.cases.get_workflow_step_instance(
    case_id=data_ex_id,
    alert_identifier=alert_identifier,
    step_identifier=step_to_execute_id,
    workflow_identifier=correct_pb.identifier
  )
  execute_json = execute_action.json()
  properties = {
    "AssignedUsers": "{}".format('["' + test_user_name + '"]'),
    "FallbackIntegrationInstance": None,
    "HasApprovalLink": None,
    "IntegrationInstance":
      all_pending_actions.pending_steps[0].integration_instance_name,
    "MessageToAssignee": None,
    "PendingActionTimeout": "300",
    "ScriptName": "Siemplify_Case Comment",
    "ScriptParametersEntityFields": "{\"Comment\":\"correct one\"}",
    "SelectedScopeName": "All entities"
  }
  execute_json['properties'].update(properties)
  all_case_wall_activities_before_execution = \
    siemplify.cases.get_all_case_wall_activities(
      case_id=data_ex_id
    )
  siemplify.cases.execute_pending_action(json_params=execute_json)
  all_pending_actions_after_execution_resp = \
    siemplify.homepage.get_all_pending_actions_for_user()
  all_pending_actions_after_execution = \
    all_pending_actions_after_execution_resp.pending_steps_count
  strong_assert(
    is_true=all_pending_actions_after_execution == 0,
    success_message="Got 0 pending actions after "
                    "executing the only existing one",
    failure_message=f"Expected 0 pending actions after executing the only one"
                    f" got {all_pending_actions_after_execution} instead"
  )
  all_case_wall_activities_after_execution = \
    siemplify.cases.get_all_case_wall_activities(
      case_id=data_ex_id
    )
  strong_assert(
    is_true=len(all_case_wall_activities_after_execution) >
            len(all_case_wall_activities_before_execution),
    success_message="Manual Case Comment action was executed properly",
    failure_message="Manual Case Comment action wasn't executed properly"
  )


@tags(["PARALLEL", "CASES"])
def test_case_wall_pending_actions_unassigned_user():
  """Verifies that user won't see any pending actions
  after pb with such was deleted

  1) Create New user -> permission group - Basic
  2) Create pb with manual action
  3) Simulate Data Exfiltration case
  4) Delete all playbooks
  5) Get all pending actions for new user
  6) Verify there's no pending actions whatsoever
  """
  test_name = inspect.stack()[0][3]
  test_user = siemplify.users.create_user_for_test(
    permission_group="Basic",
    environments=[test_name]
  )
  trigger = siemplify.playbooks.create_trigger()
  manual_case_comment_action = \
    siemplify.payloads.playbook_actions.add_case_comment(
      comment='correct one',
      is_automatic=False,
      is_skippable=True,
      skip_on_fail=True,
      pending_timeout="300",
      assigned_users="{}".format('["' + test_user.username + '"]')
    )
  correct_pb = siemplify.playbooks.create_playbook_for_test(
    trigger=trigger,
    actions=[manual_case_comment_action]
  )
  siemplify.playbooks.delete_playbook(
    playbook=correct_pb.identifier
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  siemplify.authentication.log_in_for_test(
    email=test_user.email,
    password="Password1!"
  )
  new_user_pending_actions = \
    siemplify.homepage.get_all_pending_actions_for_user()
  new_user_pending_actions_count = new_user_pending_actions.pending_steps_count
  strong_assert(
    is_true=new_user_pending_actions_count == 0,
    success_message="New user got 0 pending actions",
    failure_message="New user should've gotten 0 pending actions"
                    f"got {new_user_pending_actions_count} instead"
  )


@tags(["PARALLEL", "CASES"])
def test_case_wall_pending_actions_collaborator_user():
  """Pending actions with collaborator user

  1) Create new Collaborator user
  2) Create pb with pending action assigned to collaborator user
  3) Simulate Data Exfiltration case
  4) Get all pending actions
  5) Execute pending action
  """
  test_name = inspect.stack()[0][3]
  test_user = siemplify.users.create_user_for_test(
    permission_group="Collaborators",
    permission_type=2,
    environments=[test_name]
  )
  manual_case_comment_action = \
    siemplify.payloads.playbook_actions.add_case_comment(
      comment='collaborator',
      is_automatic=False,
      is_skippable=True,
      skip_on_fail=True,
      pending_timeout="300",
      assigned_users="{}".format('["' + test_user.username + '"]')
    )
  trigger = siemplify.playbooks.create_trigger()
  correct_pb = siemplify.playbooks.create_playbook_for_test(
    trigger=trigger,
    actions=[manual_case_comment_action]
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  data_ex_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
    case_id=data_ex_id,
    playbook_name=correct_pb.name,
    cadence=1
  )
  all_pending_actions = siemplify.homepage.get_all_pending_actions_for_user()
  strong_assert(
    is_true=all_pending_actions.pending_steps_count == 0,
    success_message="Collaborator user got 0 pending actions as expected",
    failure_message="Collaborator supposed to have 0 pending actions"
                    f" got {all_pending_actions.pending_steps_count} instead"
  )
  step_to_execute_id = siemplify.utils.find_key_in_json(
    json_data=correct_pb.steps[0],
    key="originalStepIdentifier"
  )
  alert_identifier = siemplify.cases.get_case_full_details(
    case_id=data_ex_id
  ).alerts[0].additional_properties["alertGroupIdentifier"]
  execute_action = siemplify.cases.get_workflow_step_instance(
    case_id=data_ex_id,
    alert_identifier=alert_identifier,
    step_identifier=step_to_execute_id,
    workflow_identifier=correct_pb.identifier
  )
  execute_json = execute_action.json()
  action_def = siemplify.utils.find_key_in_json(
    json_data=execute_json,
    key="actionDef"
  )
  integration_instances = siemplify.utils.find_key_in_json(
    json_data=action_def,
    key="integrationInstances"
  )
  integration_instance = siemplify.utils.find_key_in_json(
    json_data=integration_instances,
    key='identifier'
  )
  properties = {
    "AssignedUsers": "{}".format('["' + test_user.username + '"]'),
    "FallbackIntegrationInstance": None,
    "HasApprovalLink": None,
    "IntegrationInstance": integration_instance,
    "MessageToAssignee": None,
    "PendingActionTimeout": "300",
    "ScriptName": "Siemplify_Case Comment",
    "ScriptParametersEntityFields": "{\"Comment\":\"collaborator\"}",
    "SelectedScopeName": "All entities"
  }
  execute_json['properties'].update(properties)
  all_case_wall_activities_before_execution = \
    siemplify.cases.get_all_case_wall_activities(
      case_id=data_ex_id
    )
  siemplify.cases.execute_pending_action(json_params=execute_json)
  all_pending_actions_after_execution_resp = \
    siemplify.homepage.get_all_pending_actions_for_user()
  all_pending_actions_after_execution = \
    all_pending_actions_after_execution_resp.pending_steps_count
  strong_assert(
    is_true=all_pending_actions_after_execution == 0,
    success_message="Got 0 pending actions after "
                    "executing the only existing one",
    failure_message=f"Expected 0 pending actions after executing the only one"
                    f" got {all_pending_actions_after_execution} instead"
  )
  all_case_wall_activities_after_execution = \
    siemplify.cases.get_all_case_wall_activities(
      case_id=data_ex_id
    )
  strong_assert(
    is_true=len(all_case_wall_activities_after_execution) >
            len(all_case_wall_activities_before_execution),
    success_message="Manual Case Comment action was executed properly",
    failure_message="Manual Case Comment action wasn't executed properly"
  )


@tags(["SEQUENCE", "CASES"])
def test_case_wall_pending_action_got_timeout():
  """Verifies pending action timeout + rerun

  1) Create pb with pending action
  2) Simulate any case
  3) Fetch all pending action
  4) Verify that there's only one pending action
  5) Sleep for 5,5 minutes
  6) Check workflowSummary
  7) Verify UserActionRequiredStep field is not null
  8) Check GetWorkflowStepInstance
  9) Verify failure message
  10) Fetch all pending actions
  11) Verify there's no more pending actions
  12) Verify that playbook failed
  13) Rerun failed action
  14) Verify that case comment was added
  """
  test_name = inspect.stack()[0][3]
  test_user_details = [user for user in siemplify.users.get_users().objects_list
                       if user['firstName'] == test_name]
  test_user_name = siemplify.utils.find_key_in_json(
    json_data=test_user_details[0],
    key='userName'
  )
  trigger = siemplify.playbooks.create_trigger()
  manual_case_comment_action = \
    siemplify.payloads.playbook_actions.add_case_comment(
      comment='comment',
      is_automatic=False,
      is_skippable=True,
      skip_on_fail=False,
      pending_timeout="300",
      assigned_users="{}".format('["' + test_user_name + '"]')
    )
  correct_pb = siemplify.playbooks.create_playbook_for_test(
    trigger=trigger,
    actions=[manual_case_comment_action]
  )
  siemplify.cases.simulate_cases_for_test(
    cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  data_ex_id = siemplify.cases.get_last_case_id_for_test()
  siemplify.playbooks.wait_for_playbook_in_case(
    case_id=data_ex_id,
    playbook_name=correct_pb.name,
    cadence=1
  )
  all_pending_actions = siemplify.homepage.get_all_pending_actions_for_user()
  strong_assert(
    is_true=all_pending_actions.pending_steps_count == 1,
    success_message="Got 0 pending actions after "
                    "executing the only existing one",
    failure_message=f"Expected 0 pending actions after executing the only one"
                    f" got {all_pending_actions.pending_steps_count} instead"
  )
  time.sleep(350)
  data_ex_details = siemplify.cases.get_case_details(
    case_id=data_ex_id
  )
  data_ex_alert = data_ex_details.alert_cards[0]
  data_ex_alert_identifier = data_ex_alert.alert_group_identifier
  playbook_instance_summary = \
    siemplify.playbooks.get_playbook_instance_summmary(
      case_id=data_ex_id,
      alert_identifier=data_ex_alert_identifier,
      definition_id=correct_pb.identifier
    )
  pb_instance_summary_user_act_req = siemplify.utils.find_key_in_json(
    json_data=playbook_instance_summary.json(),
    key="userActionRequiredStep"
  )
  strong_assert(
    is_true=pb_instance_summary_user_act_req is not None,
    success_message="Playbook summary has userActionRequiredStep value",
    failure_message="Playbook summary didn't have userActionRequiredStep value"
  )
  pb_instance_summary_failed_msg = siemplify.utils.find_key_in_json(
    json_data=pb_instance_summary_user_act_req,
    key="message"
  )
  strong_assert(
    compare=pb_instance_summary_failed_msg,
    to="This pending action failed as the user did not respond"
       " within the required response time",
    success_message="Timeout failure message was right",
    failure_message="Timeout failure message was different than expected"
  )
  all_pending_actions_after_timeout = \
    siemplify.homepage.get_all_pending_actions_for_user()
  strong_assert(
    is_true=all_pending_actions_after_timeout.pending_steps_count == 0,
    success_message="Got 0 pending actions when action failed on timeout",
    failure_message="Expected 0 pending actions after action timeout"
                    f"got {all_pending_actions_after_timeout.pending_steps_count} instead"
  )
  step_to_execute_id = siemplify.utils.find_key_in_json(
    json_data=correct_pb.steps[0],
    key="originalStepIdentifier"
  )
  execute_action = siemplify.cases.get_workflow_step_instance(
    case_id=data_ex_id,
    alert_identifier=data_ex_alert_identifier,
    step_identifier=step_to_execute_id,
    workflow_identifier=correct_pb.identifier
  )
  execute_json = execute_action.json()
  properties = {
    "AssignedUsers": "{}".format('["' + test_name + '"]'),
    "FallbackIntegrationInstance": None,
    "HasApprovalLink": None,
    "IntegrationInstance":
      all_pending_actions.pending_steps[0].integration_instance_name,
    "MessageToAssignee": None,
    "PendingActionTimeout": "300",
    "ScriptName": "Siemplify_Case Comment",
    "ScriptParametersEntityFields": "{\"Comment\":\"comment\"}",
    "SelectedScopeName": "All entities"
  }
  execute_json['properties'].update(properties)
  all_case_wall_activities_before_execution = \
    siemplify.cases.get_all_case_wall_activities(
      case_id=data_ex_id
    )
  timeouted_action_status = siemplify.utils.find_key_in_json(
    json_data=execute_json,
    key="status"
  )
  strong_assert(
    is_true=timeouted_action_status == 11,
    success_message="Timeouted action failed playbook",
    failure_message="Timeouted action didn't fail the playbook"
  )
  siemplify.cases.execute_pending_action(json_params=execute_json)
  all_case_wall_activities_after_execution = \
    siemplify.cases.get_all_case_wall_activities(
      case_id=data_ex_id
    )
  strong_assert(
    is_true=len(all_case_wall_activities_after_execution) >
            len(all_case_wall_activities_before_execution),
    success_message="Manual Case Comment action was executed properly",
    failure_message="Manual Case Comment action wasn't executed properly"
  )
