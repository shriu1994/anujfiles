"""Module for testing Siemplify ETL module service.
"""
import json
from os import path
from siemplify_utils import siemplify
from source import enums
from source.utils import soft_assert
from source.utils import strong_assert
from tests.conftest import tags


@tags(["SEQUENCE", "ETL"])
def test_ingestion_with_domain_settings():
  """Ingest a alert with event field name of a domain, verify case is ingested.

  The test is covering a bug report - 278996099

  Steps:
  1) Add domain name in Settings 
  2) Import custom viusal famliy
  3) Import a json case with domain and username entities
  4) Simulate the case, verify case is ingested
  """
  siemplify.domains.add_domain_for_test(name="google.com")
  vf_path = path.relpath("resources/raw_data/visualfamily_file")
  with open(vf_path) as f:
    vf_file = f.read()
  ontology_path = path.relpath("resources/raw_data/ontology_file")
  with open(ontology_path) as f:
    ontology_file = f.read()
  custom_case = path.relpath("resources/raw_data/case_rawdata_file")
  with open(custom_case, "r") as f:
    case_file = json.load(f)
  siemplify.ontology.upload_visual_family(
      blob=vf_file,
      file_name="1_visualFamily_5_1_2023.zip"
  )
  siemplify.ontology.upload_ontology_file(
      blob=ontology_file,
      file_name="1_ontology_5_1_2023.zip"
  )
  siemplify.cases.import_custom_case(cases=case_file)
  siemplify.cases.simulate_cases_for_test(cases=["AutomationTest"])
  siemplify.cases.wait_for_case_for_test(data="AutomationTest")
  case_queue = siemplify.cases.get_cases_for_test().case_cards
  strong_assert(
      is_true=case_queue,
      success_message="Cases queue exists",
      failure_message="Cases queue is empty",
  )


@tags(["PARALLEL", "ETL"])
def test_extracted_entity():
  """Test extracted mapped of address type entity.

  Steps:
    1) Simulate a case
    2) Get entities list
    3) Verify entity found in the case
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  entities = siemplify.cases.get_last_case_full_details_for_test().entities
  soft_assert(
      is_true=list(
          filter(lambda d: d["entityType"] == "ADDRESS", entities)
      ),
      success_message="Found address entity in the case",
      failure_message="Didnt found address entity",
      extra_info=json.dumps(entities, indent=4)
  )


@tags(["PARALLEL", "ETL"])
def test_extracted_rawdata():
  """Test extracted raw data of event.

  Steps:
    1) Simulate a case
    2) Get alert event data
    3) Verify event raw data is in the alert
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  case_id = siemplify.cases.get_last_case_id_for_test()
  raw_data = siemplify.cases.get_alert_events(case=case_id)[0].response_json
  strong_assert(
      is_true=raw_data,
      success_message="Found raw event data in the case",
      failure_message=f"Didnt found any raw data, output: {raw_data}",
  )


@tags(["SEQUENCE", "ETL"])
def test_etl_queue_in_progress_records():
  """Test in progress cases queue records.

  Steps:
    1) Simulate a case 
    2) Get records data from inprogress queue
    3) Verify queue records is empty
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  queue_res = siemplify.cases.get_cases_in_progress_queue()
  result = queue_res.json()
  records = result.get("records")
  strong_assert(
      is_false=records,
      success_message="Queue Records is empty, no stuck cases",
      failure_message=f"Queue Records is not empty, output: {records}",
  )


@tags(["SEQUENCE", "ETL"])
def test_etl_queue_pending_records():
  """Test in pending cases queue records.

  Steps:
    1) Simulate a case
    2) Get records data from pending queue
    3) Verify queue records is empty
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  queue_res = siemplify.cases.get_cases_pending_queue()
  result = queue_res.json()
  records = result.get("records")
  strong_assert(
      is_false=records,
      success_message="Queue Records is empty, no stuck cases",
      failure_message=f"Queue Records is not empty, output: {records}",
  )


@tags(["SEQUENCE", "ETL"])
def test_etl_queue_done_records():
  """Test done cases queue records.

  Steps:
    1) Simulate a case
    2) Get records data from done queue
    3) Verify queue records is empty
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  queue_res = siemplify.cases.get_cases_done_queue()
  result = queue_res.json()
  records = result.get("records")
  strong_assert(
      is_false=records,
      success_message="Queue Records is empty, no stuck cases",
      failure_message=f"Queue Records is not empty, output: {records}",
  )


@tags(["SEQUENCE", "ETL"])
def test_etl_pending_queue_error_records():
  """Test in progress cases error queue records.

  Steps:
    1) Simulate a case
    2) Get records data from cases error queue
    3) Verify queue records is empty
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  queue_res = siemplify.cases.get_cases_pending_queue_error()
  result = queue_res.json()
  records = result.get("records")
  strong_assert(
      is_false=records,
      success_message="Queue Records is empty, no stuck cases",
      failure_message=f"Queue Records is not empty, output: {records}",
  )


@tags(["SEQUENCE", "ETL"])
def test_etl_done_queue_error_records():
  """Test cases error done queue records.
  
  Steps:
    1) Simulate a case 
    2) Get records data from cases error done queue 
    3) Verify queue records is empty
  """
  siemplify.cases.simulate_cases_for_test(
      cases=[enums.DefaultCases.DATA_EXFILTRATION]
  )
  queue_res = siemplify.cases.get_cases_done_queue_error()
  result = queue_res.json()
  records = result.get("records")
  strong_assert(
      is_false=records,
      success_message="Queue Records is empty, no stuck cases",
      failure_message=f"Queue Records is not empty, output: {records}",
  )


@tags(["SEQUENCE", "ETL"])
def test_etl_queue_error_ingested_duplicated_alerts():
  """Test cases error queue records with duplicated alerts.
  
  Steps:
    1) Import custom connector to generate duplicated alert
    2) Create connector instance
    3) Get error queue done records with duplicated alerts error
    4) Verify cases queue done error is not empty
  """
  file = path.relpath("resources/raw_data/custom_connector_data")
  with open(file) as f:
    file = f.read()
  siemplify.ide.import_ide_item(
      data=file,
      integration_name="Siemplify"
  )
  connector_ins = siemplify.connectors.create_connector_instance_for_test(
      connector_name="test_connector",
  ).identifier
  records_result = siemplify.cases.records_waiter()
  if records_result:
    siemplify.connectors.update_connector_instance(
        identifier=connector_ins,
        is_enabled=False,
    )
  queue_res = siemplify.cases.get_cases_queue_error()
  result = queue_res.json()
  records = result.get("records")
  strong_assert(
      is_true=records,
      success_message="Queue Records is not Empty, found error cases",
      failure_message=f"Error Queue Records is empty, output: {records}",
  )


# @tags(["BUG-282010418", "ETL"])
# @cleanup(modules=["cases", "connectors"])
# def test_etl_system_notification():
#     """Test system notification message for etl errors
#     Steps:
#     1) Import custom connector to generate duplicated alerts 
#     2) Wait for system notification message  
#     3) Verify that system published message with etl error
#     """
#     file = path.relpath("payload_templates/custom_connector_data")
#     with open(file) as f:
#       file = f.read()
#     siemplify.ide.import_ide_item(
#         data=file,
#         integration_name="Siemplify"
#     )
#     siemplify.connectors.create_connector_instance(
#         connector_name="test_connector",
#         instance_display_name="test_connector"
#     )
#     siemplify.notifications.system_notification_waiter()
#     system_msg=siemplify.notifications.system_notifications()
#     msg_id = system_msg.json()
#     soft_assert(
#         to=msg_id[0]['messageId'],
#         compare="SDK_JOB_ETL_ALERT_DIGESTION_ERRORS",
#         success_message="ETL system notification was displayed",
#         failure_message=f"Didnt found ETL system notification, output: {msg_id[0]['messageId']}",
#     )

@tags(["SEQUENCE", "ETL"])
def test_ingestion_with_alias_environment():
  """Test cases error queue records with duplicated alerts.
  
  Steps:
    1) Grouping must be set to default settings 
    2) Define Environment with alias
    3) Ingest alert that has Environment value as the alias defined
    4) Verify that case was ingested, verify number of events
    5) Ingest exactly the same case
    6) Verify that the case was not ingested and the alert of the previous case has the same number of events as before

  """
  siemplify.settings.edit_alert_grouping_sequence_only()
  env_name = siemplify.utils.generate_random_name()
  alias_name = siemplify.utils.generate_random_name()
  siemplify.environments.create_custom_environment(
      name=env_name,
      alias_env=[alias_name]
  )
  siemplify.cases.create_data_exfiltration_case(environment=alias_name)
  siemplify.cases.wait_for_case_in_environments(
      data="Data Exfiltration",
      environments=[env_name]
  )
  case = siemplify.cases.get_cases_in_environments(environments=[env_name])
  env = case.case_cards[0]['environment'].get("name", "Error in getting name environment")
  strong_assert(
      compare=env,
      to=env_name,
      success_message=f"Case was ingested correctly under environment name: {env}",
      failure_message=f"Error case wasnt ingested to the environment, Case environment: {env}",
  )
  case_id = siemplify.cases.get_last_case_id_in_environments(
      environments=[env_name]
  )
  event_count_before = siemplify.cases.get_case_details(
      case_id=case_id
  ).response_json.get("alertCards")[0]["eventsCount"]
  strong_assert(
      compare=event_count_before,
      to=1,
      success_message=f"Number of events is correct: {event_count_before}",
      failure_message=f"Number of events should be 1, events {event_count_before}",
  )
  siemplify.cases.create_data_exfiltration_case(
      environment=alias_name
  )
  case_id = siemplify.cases.get_last_case_id_in_environments(
      environments=[env_name]
  )
  event_count_before = siemplify.cases.get_case_details(
      case_id=case_id
  ).response_json.get("alertCards")[0]["eventsCount"]
  event_count_after = siemplify.cases.get_case_details(
      case_id=case_id
  ).response_json.get("alertCards")[0]["eventsCount"]
  strong_assert(
      compare=event_count_after,
      to=1,
      success_message=f"Number of events is correct: {event_count_after}",
      failure_message=f"Number of events should be 1, events {event_count_after}",
  )
