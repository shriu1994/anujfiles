"""Module for testing Siemplify Webhooks module.
"""

import time
from siemplify_utils import siemplify
from source.utils import strong_assert
from tests.conftest import tags


@tags(["WEBHOOKS", "SEQUENCE"])
def test_create_webhooks():
  """Preforms a "Create webhooks and verify the case occurrence" test.

  Steps:
  1) Create a Webhook
  2) Edit the mapping
  3) Test Webhook
  4) Verify that Phishmonger case is generated
  """
  name = siemplify.utils.generate_random_name()
  web_obj = siemplify.webhooks.create_webhook(
      webhook_name=name, environment="test_create_webhooks")
  siemplify.webhooks.update_webhook_mapping_test(
      webhook_name=web_obj.json()["name"],
      description=web_obj.json()["description"],
      environment=web_obj.json()["defaultEnvironment"],
      identifier=web_obj.json()["identifier"])
  req = siemplify.webhooks.send_webhook_request_test(web_obj.json()["postfix"])
  strong_assert(
      compare=req.status_code,
      to=200,
      success_message="Webhook tested successfully",
      failure_message="Webhook test failed",
  )
  time.sleep(5)
  search = siemplify.search.search_cases_for_test(
      title="Phishmonger"
  )
  sr = siemplify.utils.find_key_in_json(
      json_data=search,
      key="results",
  )
  strong_assert(
      compare=len(sr),
      to=1,
      success_message=f"Cases search is {len(sr)} items long",
      failure_message=f"Cases search is wrong length: {len(sr)}",
  )