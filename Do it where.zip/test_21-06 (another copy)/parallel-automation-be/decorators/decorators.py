"""A module containing all decorators.
"""
import functools
import json
import os
from typing import Optional
from siemplify_utils import siemplify

INTEGRATION_PATH = os.path.join(
    os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "integration_data.json"
)
JSON_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auth.json"
)
CLEANUP_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cleanup.json"
)
LOG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "log.json"
)


def integrations_required(
    integrations: list[str],
    environment: Optional[str] = None,
):
  """Wrapper to install integration.

  This decorator will install the listed integrations with settings from a file 
    "integration_data.json". If you want to use custom settings install the
    integrations separately using install_and_cofigure() method.

  Args:
    integrations: list of needed integrations
    environment: name of the environment for the integration
      (Defaults to "Default Environment" if None)
  Returns:
    A wrapped function
  """
  if not environment:
    environment = "Default Environment"

  def integrations_wrapper(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
      with open(INTEGRATION_PATH, "r") as f:
        data = json.load(f)
        for integration_name in integrations:
          if data.get(integration_name):
            siemplify.integrations.install_and_configure(name=integration_name)

      return func(*args, **kwargs)

    return wrapper

  return integrations_wrapper


def ingestion_setup():
  """Wrapper to setup for ingestion tests.

  This decorator will currently only set alert grouping to the system default.

  Returns:
    A wrapped function
  """
  
  def ingestion_wrapper(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
      siemplify.settings.edit_alert_grouping_sequence_only()

      return func(*args, **kwargs)

    return wrapper

  return ingestion_wrapper
