"""A module for action working with management endpoints in siemplify.
"""
from typing import Optional
# Endpoints
from endpoints.management import API_GET_CASES_QUEUE_ENDPOINT
from endpoints.management import API_GET_CASES_QUEUE_ERRORS_ENDPOINT
from endpoints.management import API_GET_INDEXER_QUEUE_ERRORS_ENDPOINT
from endpoints.management import API_GET_INDEXER_QUEUE_ITEMS_ENDPOINT
from endpoints.management import API_GET_QUEUE_WEIGHTS_ENDPOINT
from endpoints.management import API_GET_SUMMARY_ENDPOINT
from endpoints.management import API_GET_WORKFLOW_QUEUE_ERRORS_ENDPOINT
from endpoints.management import API_GET_WORKFLOW_QUEUE_ITEMS_ENDPOINT
# Requests
from requests import Response
# Source
from source.utils import check_test_name_can_be_none
from source.utils import get_with_appkey
from source.utils import log_and_assert


def get_summary(test_name: Optional[str] = None) -> Response:
  """Fetches queue summary.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_SUMMARY_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched queue summary for {test_name}",
      failure_message=f"Failed to fetch queue summary for {test_name}",
  )


def get_cases_queue_items(test_name: Optional[str] = None) -> Response:
  """Fetches cases queue summary.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_CASES_QUEUE_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched cases queue summary for {test_name}",
      failure_message=f"Failed to fetch cases queue summary for {test_name}",
  )


def get_indexer_queue_items(test_name: Optional[str] = None) -> Response:
  """Fetches indexer queue summary.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_INDEXER_QUEUE_ITEMS_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched indexer queue summary for {test_name}",
      failure_message=f"Failed to fetch indexer queue for {test_name}",
  )


def get_workflow_queue_items(test_name: Optional[str] = None) -> Response:
  """Fetches workflow queue summary.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_WORKFLOW_QUEUE_ITEMS_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched workflow queue summary for {test_name}",
      failure_message=f"Failed to fetch workflow queue for {test_name}",
  )


def get_cases_queue_errors(test_name: Optional[str] = None) -> Response:
  """Fetches all cases queue errors.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_CASES_QUEUE_ERRORS_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched cases queue errors for {test_name}",
      failure_message=f"Failed to fetch cases queue errors for {test_name}",
  )


def get_indexer_queue_errors(test_name: Optional[str] = None) -> Response:
  """Fetches all idexer queue errors.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_INDEXER_QUEUE_ERRORS_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched idexer queue errors for {test_name}",
      failure_message=f"Failed to fetch indexer queue errors for {test_name}",
  )


def get_workflow_queue_errors(test_name: Optional[str] = None) -> Response:
  """Fetches all workflow queue errors.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_WORKFLOW_QUEUE_ERRORS_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched workflow queue errors for {test_name}",
      failure_message=f"Failed to fetch workflow queue errors for {test_name}",
  )


def get_queue_weights(test_name: Optional[str] = None) -> Response:
  """Fetches queue weights.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_QUEUE_WEIGHTS_ENDPOINT,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched queue weights for {test_name}",
      failure_message=f"Failed to fetch queue weights for {test_name}",
  )
