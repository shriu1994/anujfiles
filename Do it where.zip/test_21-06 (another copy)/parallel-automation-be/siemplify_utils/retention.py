"""Module containing actions to manipulate Data Retention in siemplify client.
"""
from typing import Optional
# Endpoints
from endpoints.retention import API_GET_RETENTION_ENDPOINT
from endpoints.retention import API_TRIGGER_RETENTION_ENDPOINT
# Requests
from requests import Response
# Other modules
# Source
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_appkey


# Classes for Response DTOs
class RetentionResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.retention_period = self.response_json.get(
        "dataRetentionPeriodInMonths", None)
    self.retention_per_environment = self.response_json.get(
        "enableDataRetentionPerEnvironment", None)


def get_retention_configuration(
    test_name: Optional[str] = None,
) -> RetentionResponse:

  """Fetches default retention data.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A RetentionResponse object with all the default retention configurations
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_RETENTION_ENDPOINT,
      test_name=test_name,
  )
  return RetentionResponse(response=response)


def trigger_data_retention(
    test_name: Optional[str] = None,
    batch_size: Optional[int] = 0,
    skip_vacuum: Optional[bool] = True,
) -> Response:
  """Triggers Data Retention.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "batchSize": batch_size,
      "skipVacuum": skip_vacuum,
  }
  response = post_with_appkey(
      url=API_TRIGGER_RETENTION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Triggered Retention for {test_name}",
      failure_message=f"Failed to trigger retention for {test_name}",
  )
  return response
