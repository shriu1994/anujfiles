"""Module containing actions to install integrations in siemplify client.
"""
import json
import os
import time
from typing import Optional, Union
# Endpoints
from endpoints.integrations import API_CONFIGURE_INTEGRATION_ENDPOINT
from endpoints.integrations import API_CREATE_CUSTOM_INTEGRATION_ENDPOINT
from endpoints.integrations import API_CREATE_INTEGRATION_INSTANCE_ENDPOINT
from endpoints.integrations import API_DELETE_CUSTOM_INTEGRATION_ENDPOINT
from endpoints.integrations import API_DELETE_INTEGRATION_ENDPOINT
from endpoints.integrations import API_DELETE_INTEGRATION_INSTANCE_ENDPOINT
from endpoints.integrations import (
    API_GET_INSTALLED_INTEGRATIONS_BY_ENV_ENDPOINT
)
from endpoints.integrations import API_GET_INSTALLED_INTEGRATIONS_ENDPOINT
from endpoints.integrations import API_GET_INTEGRATION_FULL_DETAILS_ENDPOINT
from endpoints.integrations import API_GET_INTEGRATION_ID_ENDPOINT
from endpoints.integrations import API_GET_INTEGRATIONS_INSTANCE_SETTINGS
from endpoints.integrations import API_GET_INTEGRATIONS_STORE_DATA_ENDPOINT
from endpoints.integrations import API_GET_OPTIONAL_INSTANCES_ENDPOINT
from endpoints.integrations import API_INSTALL_INTEGRATION_ENDPOINT
from endpoints.integrations import API_TEST_INTEGRATION_ENDPOINT
# Requests
from requests import Response
# Other modules
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


JSON_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "integration_data.json"
)


class CustomIntegrationResponse:
  """Class to represent integration full detail response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.identifier = self.response_json.get("identifier")
    self.version = self.response_json.get("version")
    self.display_name = self.response_json.get("displayName")
    self.description = self.response_json.get("description")
    self.image = self.response_json.get("image")
    self.categories = self.response_json.get("categories")
    self.svg_image = self.response_json.get("svgImage")
    self.python_version = self.response_json.get("pythonVersion")
    self.properties = self.response_json.get("properties")


class IntegrationFullDetailsResponse:
  """Class to represent integration full detail response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = response.json()
    self.identifier = self.response_json.get("identifier")
    self.minimum_system_version = self.response_json.get("minimumSystemVersion")
    self.actions = self.response_json.get("actions", [])
    self.jobs = self.response_json.get("jobs", [])
    self.connectors = self.response_json.get("connectors", [])
    self.managers = self.response_json.get("managers", [])
    self.custom_families = self.response_json.get("customFamilies", [])
    self.example_usecases = self.response_json.get("exampleUseCases", [])
    self.mapping_rules = self.response_json.get("mappingRules", [])
    self.version = self.response_json.get("version")
    self.is_custom = self.response_json.get("isCustom")
    self.integration_properties = self.response_json.get(
        "integrationProperties", []
    )
    self.release_notes = self.response_json.get("releaseNotes", [])
    self.documentation_link = self.response_json.get("documentationLink")
    self.description = self.response_json.get("description")
    self.name = self.response_json.get("displayName")


class IntegrationStoreData:
  """Class to represent integration store data.
  """

  def __init__(self, item: dict):
    self.version_for_display = item.get("versionForDisplay")
    self.installed_version_for_display = item.get("installedVersionForDisplay")
    self.status = item.get("status")
    self.documentation_link = item.get("documentationLink")
    self.identifier = item.get("identifier")
    self.is_available_for_community = item.get("isAvailableForCommunity")
    self.integration_type = item.get("integrationType")
    self.has_connectors = item.get("hasConnectors")
    self.version = item.get("version")
    self.latest_release_publish_time = item.get(
        "latestReleasePublishTimeUnixTime"
    )
    self.installed_version = item.get("installedVersion")
    self.name = item.get("displayName")
    self.description = item.get("description")
    self.image_base64 = item.get("imageBase64")
    self.small_image_base64 = item.get("smallImageBase64")
    self.svg_image = item.get("svgImage")
    self.is_configured = item.get("isConfigured")
    self.is_custom = item.get("isCustom")
    self.categories = item.get("categories", [])
    self.is_certified = item.get("isCertified")
    self.uploader_email = item.get("uploaderEmail")
    self.uploader_full_name = item.get('uploaderFullName')
    self.uploader_image_base64 = item.get("uploaderImageBase64")
    self.marketplace_update_status = item.get("marketplaceItemUpdateStatus")
    self.uploader_profile_link = item.get("uploaderProfileLink")
    self.properties = item.get("properties", [])
    self.integration_supported_actions = item.get(
        "integrationSupportedActions", []
    )


class IntegrationsStoreDataResponse:
  """Class to represent integrations store data response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = response.json()
    integrations = self.response_json.get("integrations", [])
    self.integrations = [IntegrationStoreData(x) for x in integrations]
    self.categories = self.response_json.get("categories", [])

  def get_store_data(self, integration_name: str) -> IntegrationStoreData:
    integration = list(
        filter(lambda x: x.name == integration_name, self.integrations)
    )
    if not integration:
      raise KeyError(
          f"Integration store data is missed for '{integration_name}'"
      )
    return integration[0]


def install_integration(name: str, version: Optional[int] = None):
  """Fetches a version and installs an integration with the given name.

  Args:
    name: name of the integration to install
    version: version of the integration to install. If None fetches it from
      integration_data.json file

  Returns:
    A response object
  """
  if not version:
    with open(JSON_PATH, "r") as f:
      data = json.load(f)
      if data.get(name):
        version = data[name].get("version", None)
        if not version:
          raise ValueError("Integration version not specified")
  response = _install(name=name, version=version)
  time.sleep(2)

  return response


def reinstall_integration(name: str, version: Optional[int] = None):
  """Deletes an integration if it's already installed and installs it again.

  Args:
    name: name of the integration to install
    version: version of the integration to install. If None fetches it from
      integration_data.json file

  Returns:
    A response object
  """
  if not version:
    with open(JSON_PATH, "r") as f:
      data = json.load(f)
      if data.get(name):
        version = data[name].get("version", None)
        if not version:
          raise ValueError("Integration version not specified")
  check = check_if_installed(name=name)
  if check:
    delete_integration(name=name)
  response = _install(name=name, version=version)
  time.sleep(2)

  return response


def configure_integration(
    name: Optional[str] = None,
    integration_id: Optional[str] = None,
    json_settings: Optional[Union[str, list[dict]]] = None,
    update_json: Optional[dict] = None,
) -> Response:
  """Configures an integration with the chosen name.

  Args:
    name: name of the integration. Required if you do not specify integration
      id to fetch the default one from the name. (Defaults to None)
    integration_id: id of the integration instance. If None fetches default
      id with the specified name
    json_settings: name of the JSON file with settings for the integration in
      the main folder (with or without .json) OR list of dicts with settings
    update_json: dict with params to update integration default params

  Returns:
    A response object
  """
  if not integration_id:
    if name:
      integration_id = get_integration_id(name)
    else:
      raise ValueError("Name not specified! Can't fetch default integration ID")
  if not update_json:
    update_json = {}
  if json_settings and isinstance(json_settings, list):
    for key, value in update_json.items():
      for json_setting in json_settings:
        if json_setting["propertyName"] == key:
          json_setting["value"] = value
    for setting in json_settings:
      setting["integrationInstance"] = integration_id
    return _configure(settings=json_settings, integration_id=integration_id)
  if json_settings and isinstance(json_settings, str):
    if not json_settings.endswith(".json"):
      file_name = json_settings.lower() + ".json"
    else:
      file_name = json_settings.lower()
  else:
    file_name = "integration_data.json"
  path = os.path.join(
      os.path.dirname(os.path.dirname(os.path.abspath(__file__))), file_name
  )
  with open(path, "r") as f:
    data = json.load(f)
    if data.get(name):
      settings = []
      for key, value in update_json.items():
        if data[name]["settings"].get(key):
          data[name]["settings"][key]["value"] = value
      for setting in data[name]["settings"].values():
        setting["integrationInstance"] = integration_id
        settings.append(setting)
      return _configure(settings=settings, integration_id=integration_id)


def _configure(
    settings: list[dict],
    integration_id: str,
) -> Response:
  """Installs a VirusTotalV3 integration.

  Args:
    settings: list of settings
    integration_id: id of the virustotal integration installation

  Returns:
    A response object
  """
  payload = {
      "settings": settings,
      "instanceIdentifier": integration_id,
      "instanceDescription": None,
      "instanceName": "System Default Instance",
  }
  return post_with_admin_credentials(
      url=API_CONFIGURE_INTEGRATION_ENDPOINT,
      payload=payload,
  )


def _install(
    name: str,
    version: int,
) -> Response:
  """Installs an integration with the specified name.

  Args:
    name: name of the integration
    version: version of the integration

  Returns:
    A response object
  """
  payload = {
      "identifier": name,
      "name": name,
      "isCertified": True,
      "version": version,
      "overrideMapping": True
  }
  return post_with_admin_credentials(
      url=API_INSTALL_INTEGRATION_ENDPOINT,
      payload=payload,
  )


def delete_integration(name: str) -> Response:
  """Deletes an integration with the specified name.

  Args:
    name: name of the integration to delete

  Returns:
    A response object
  """
  return post_with_admin_credentials(
      url=API_DELETE_INTEGRATION_ENDPOINT.format(name),
  )


def get_installed_integrations() -> Response:
  """Fetches a list of installed integrations.

  Returns:
    A response object (contains JSON with integrations)
  """
  return get_with_admin_credentials(
      url=API_GET_INSTALLED_INTEGRATIONS_ENDPOINT,
  )


def get_installed_by_environment(
    environment: str = "Default Environment",
) -> Response:
  """Fetches a list of installed integrations in an environment.

  Args:
    environment: name of the environment to check
      (Defaults to "Default Environment" if not specified)

  Returns:
    A response object (contains JSON with integrations)
  """
  return post_with_admin_credentials(
      url=API_GET_INSTALLED_INTEGRATIONS_BY_ENV_ENDPOINT,
      payload={"name": environment},
  )


def check_if_configured_in_environment(
    name: str,
    environment: Optional[str] = None,
) -> bool:
  """Checks if integration is already installed.

  Args:
    name: name of the integration to check for
    environment: name of the environment to check in
    (Defaults to "Default Environment" if not specified)

  Returns:
    True if integration already installed, False if not
  """
  if not environment:
    environment = "Default Environment"
  all_integrations = get_installed_by_environment(
      environment=environment
  )
  integrations_list = all_integrations.json()["instances"]
  for integration in integrations_list:
    integration_name = integration["integrationIdentifier"]
    configured = integration["isConfigured"]
    if integration_name == name and configured:
      return True

  return False


def check_if_installed(
    name: str,
) -> bool:
  """Checks if integration is already installed.

  Args:
    name: name of the integration to check for

  Returns:
    True if integration already installed, False if not
  """
  all_integrations = get_installed_integrations()
  integrations_list = all_integrations.json()
  for integration in integrations_list:
    integration_name = integration["identifier"]
    if integration_name == name:
      return True

  return False


def check_if_configured(
    name: str,
) -> bool:
  """Checks if integration is already configured.

  Args:
    name: name of the integration to check for
  Returns:
    True if integration already configured, False if not
  """
  all_integrations = get_installed_integrations()
  integrations_list = all_integrations.json()
  for integration in integrations_list:
    integration_name = integration["identifier"]
    configured = integration["isConfigured"]
    if integration_name == name and configured:
      return True

  return False


def get_integration_id(
    name: str,
) -> str:
  """Fetch an integration id of the chosen integration.

  Args:
    name: name of the integration

  Returns:
    A string with the id
  """
  response = get_with_admin_credentials(
      url=API_GET_INTEGRATION_ID_ENDPOINT.format(name)
  )
  response_json = response.json()

  return response_json["identifier"]


def get_integration_full_details(
    integration_name: str,
    is_custom: bool = False,
    is_certified: bool = True,
) -> IntegrationFullDetailsResponse:
  """Fetches integration data of the chosen integration.

  Args:
    integration_name: name of the integration
    is_custom: is integration custom
    is_certified: is integration ceritifed

  Returns:
    A response object (contains json with integration data)
  """
  payload = {
      "integrationIdentifier": integration_name,
      "isCustom": is_custom,
      "isCertified": is_certified,
  }
  response = post_with_admin_credentials(
      url=API_GET_INTEGRATION_FULL_DETAILS_ENDPOINT,
      payload=payload,
  )
  return IntegrationFullDetailsResponse(response=response)


def get_integrations_store_data():
  """Fetches all integrations store data.

  Returns:
    List of all integrations data OR specific one if name passed
  """
  response = get_with_admin_credentials(
      url=API_GET_INTEGRATIONS_STORE_DATA_ENDPOINT,
  )
  return IntegrationsStoreDataResponse(response=response)


def install_and_configure(
    name: str,
    version: Optional[int] = None,
    environment: str = "Default Environment",
    json_settings: Optional[Union[str, list[dict]]] = None,
) -> Response:
  """Installs and configures the integration with the specified name.

  Args:
    name: name of the integration
    version: version of the integration. If None will fetch the version from 
      integration_data.json
    environment: name of the environment
      (defaults to "Default Environment)
    json_settings: name of the JSON file with settings for the integration in
      the main folder (with or without .json) OR list of dicts with settings

  Returns:
    A response object
  """
  configured = check_if_configured_in_environment(
      name=name,
      environment=environment,
  )
  if configured:
    return None
  # If not configured check if integration is installed
  installed = check_if_installed(name=name)
  if not installed:
    install_integration(name=name, version=version)
  return configure_integration(name=name, json_settings=json_settings)


def reinstall_and_configure(
    name: str,
    json_settings: Optional[Union[str, list[dict]]] = None,
) -> Response:
  """Deletes, installs and configures the integration with the specified name.

  Args:
    name: name of the integration
    json_settings: name of the JSON file with settings for the integration in
      the main folder (with or without .json) OR list of dicts with settings

  Returns:
    A response object
  """
  installed = check_if_installed(name=name)
  if installed:
    delete_integration(name=name)
  time.sleep(2)
  install_integration(name=name)
  time.sleep(2)
  return configure_integration(name=name, json_settings=json_settings)


def create_integration_instance(
    integration_id: str,
    environment: str = "Default Environment",
) -> Response:
  """Creates a instance of integration.

  Args:
    integration_id: name of the integration
    environment: name of the environment (defaults to "Default Environment)

  Returns:
    A response object
  """
  payload = {
      "integrationIdentifier": integration_id,
      "environment": environment,
  }
  return post_with_admin_credentials(
      url=API_CREATE_INTEGRATION_INSTANCE_ENDPOINT,
      payload=payload,
  )


def run_integration_test(integration_instance_id: str) -> Response:
  """Run an integration test.

  Args:
    integration_instance_id: id of the integration instance to test

  Returns:
    A response object
  """
  return get_with_admin_credentials(
      url=API_TEST_INTEGRATION_ENDPOINT.format(integration_instance_id),
  )


def create_custom_integration(
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> CustomIntegrationResponse:
  """Creates a custom integration from IDE.

  Args:
    test_name: name of the test (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A CustomIntegrationResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  identifier = siemplify.utils.generate_random_name(start="Integration-")
  response = post_with_admin_credentials(
      url=API_CREATE_CUSTOM_INTEGRATION_ENDPOINT,
      payload={"identifier": identifier},
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="custom_integration",
        item_name=identifier,
    )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created custom integration '{identifier}'"
            f" for {test_name}"
        ),
        failure_message=f"Failed to create custom integration for {test_name}",
    )
  return CustomIntegrationResponse(response=response)


def delete_custom_integration(integration_name: str) -> Response:
  """Deletes a custom integration.

  Args:
    integration_name: name of the integration to delete

  Returns:
    A response object
  """
  return post_with_admin_credentials(
      url=API_DELETE_CUSTOM_INTEGRATION_ENDPOINT.format(integration_name),
  )


def check_if_installed_in_environment(
    name: str,
    environment: Optional[str] = None,
) -> Response:
  """Fetches a list of installed integrations in an environment.

  Args:
    name: name of the integration
    environment: name of the environment to check
    (Defaults to "Default Environment" if not specified)

  Returns:
    A response object (contains JSON with integrations)
  """
  installed = get_installed_by_environment(environment=environment)
  int_list = installed.json()["integrations"]
  check_installed = filter(
      lambda integrations: integrations["displayName"] == name, int_list
  )
  return True if list(check_installed) else False


def delete_all_custom_integrations():
  """Deletes all custom integrations.
  """
  installed = get_installed_by_environment(environment="*")
  integrations_list = installed.json()["integrations"]
  custom = siemplify.utils.find_key_value_in_json(
      json_data=integrations_list,
      key="isCustom",
      value=True,
  )
  if isinstance(custom, list):
    for integration in custom:
      int_id = integration["identifier"]
      delete_custom_integration(integration_name=int_id)
  if isinstance(custom, dict):
    int_id = custom["identifier"]
    delete_custom_integration(integration_name=int_id)


def delete_all_nondefault_integrations():
  """Deletes all non default integrations.
  """
  installed = get_installed_by_environment(environment="*")
  integrations_list = installed.json()["integrations"]
  default_integrations = ("Siemplify", "SiemplifyUtilities")
  for integration in integrations_list:
    if integration["identifier"] not in default_integrations:
      delete_integration(name=integration["identifier"])


def delete_integration_instance(
    integration_id: str,
    integration_name: str,
    instance_name: str
) -> Response:
  """Deletes a custom integration.

  Args:
    integration_id: integration identifier
    integration_name: name of the integration
    instance_name: instnace name in Integrations page

  Returns:
    A response object
  """
  payload = {
      "identifier": integration_id,
      "integrationIdentifier": integration_name,
      "environmentIdentifier": "Default Environment",
      "instanceName": instance_name,
      "instanceDescription": None,
      "isConfigured": True,
      "isRemote": False,
      "isSystemDefault": False
  }
  return post_with_admin_credentials(
      url=API_DELETE_INTEGRATION_INSTANCE_ENDPOINT,
      payload=payload,
  )


def get_integration_instance_settings(
    integration_id: str,
) -> str:
  """Fetch an integration id of the chosen integration.

  Args:
    integration_id: identifiter of the integration

  Returns:
    A string with the id
  """
  return get_with_admin_credentials(
      url=API_GET_INTEGRATIONS_INSTANCE_SETTINGS.format(integration_id),
  )


def get_optional_integration_instances(
    environments: list[str],
    integration_name: str,
) -> Response:
  """Fetches a list of optional integration instances for environments.

  Args:
    environments: list of environments
    integration_name: name of the integration

  Returns:
    A response object
  """
  payload = {
      "environments": environments,
      "integrationIdentifier": integration_name,
  }
  return post_with_admin_credentials(
      url=API_GET_OPTIONAL_INSTANCES_ENDPOINT,
      payload=payload,
  )


def delete_all_optional_instances_in_environment(
    environment: str,
):
  """Deletes all optional instances in a chosen environment.

  Args:
    environment: name of the environment
  """
  installed = siemplify.integrations.get_installed_by_environment(
      environment=environment,
  )
  instances = installed.json().get("instances")
  for instance in instances:
    siemplify.integrations.delete_integration_instance(
        integration_id=instance.get("identifier"),
        integration_name=instance.get("integrationIdentifier"),
        instance_name=instance.get("instanceName"),
    )


def check_if_integration_remote(integration_name: str) -> bool:
  """Checks if intergartion is remote.

  Args:
    integration_name: name of the integration

  Returns:
    True if integration is remote, False if not
  """
  res = []
  installed_int = (
      get_installed_by_environment(
          environment="Default Environment"
      )
  )
  for is_remote_integration in installed_int.json()["instances"]:
    if (
        is_remote_integration["integrationIdentifier"] == integration_name
        and is_remote_integration["isRemote"]
    ):
      res = is_remote_integration["isRemote"]
  return res
