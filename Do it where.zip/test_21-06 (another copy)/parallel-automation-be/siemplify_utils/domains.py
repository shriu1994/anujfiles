"""Module containing actions to manipulate domains in siemplify client.
"""
from typing import Optional
# API endpoints
from endpoints.domains import API_ADD_DOMAIN_ENDPOINT
from endpoints.domains import API_DELETE_DOMAIN_ENDPOINT
from endpoints.domains import API_GET_ALL_DOMAINS_ENDPOINT
# Requests
from requests import Response
# Siemplify
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


def add_domain_to_environments(
    name: str,
    environments: Optional[list[str]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Adds a domain to settings.

  Args:
    name: domain name to be added
    environments: environments to be used
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_ADD_DOMAIN_ENDPOINT,
      payload={"domain": name, "environments": environments},
      test_name=test_name,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_name=name,
        item_type="domain",
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created domain '{name}' for {test_name}"
        ),
        failure_message=(
            f"Failed to create domain '{name}' for {test_name}"
        ),
    )
  return response


def add_domain_for_test(
    name: str,
    test_name: Optional[str] = None,
) -> Response:
  """Adds a domain to settings.

  Args:
    name: domain name to be added
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  response = post_with_admin_credentials(
      url=API_ADD_DOMAIN_ENDPOINT,
      payload={"domain": name, "environments": [test_name]},
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Created domain '{name}' for {test_name}",
      failure_message=f"Failed to create domain '{name}' for {test_name}",
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_name=name,
        item_type="domain",
    )
  return response


def delete_domain(
    payload: dict,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a domain.

  Args:
    payload: dict object with fields to delete domain
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_DOMAIN_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted domain for {test_name}"
        ),
        failure_message=(
            f"Failed to delete domain for {test_name}"
        ),
    )
  return response


def get_all_domains(
    page: int = 0,
    search: str = "",
    page_size: int = 100,
    test_name: Optional[str] = None,
) -> Response:
  """Get all domains.

  Args:
    page: pagination page
    search: domain search template
    page_size: count of domains returned per page
    test_name: name of the test (Defaults to None)

  Returns:
    A Request object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "requestedPage": page,
      "searchTerm": search,
      "pageSize": page_size
  }
  response = post_with_admin_credentials(
      url=API_GET_ALL_DOMAINS_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched all domains for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch all domains for {test_name}"
        ),
    )
  return response


def delete_all_domains() -> None:
  """Deletes all domains.
  """
  domains_response = get_all_domains()
  domain_objects = siemplify.utils.find_key_in_json(
      json_data=domains_response,
      key="objectsList",
  )
  for item in domain_objects:
    delete_domain(item)
