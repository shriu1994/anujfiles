"""Module containing actions to manipulate settings in siemplify client.
"""

# API endpoints
from endpoints.settings import API_ADD_UPDATE_LOCALIZATION_ENDPOINT
from endpoints.settings import API_CHANGE_EMAIL_VERIFICATION_ENDPOINT
from endpoints.settings import API_GET_EMAIL_SETTINGS_ENDPOINT
from endpoints.settings import API_SAVE_EMAIL_SETTINGS_ENDPOINT
from endpoints.settings import API_SAVE_ALERT_GROUPING_SETTINGS_ENDPOINT
from endpoints.settings import API_TEST_EMAIL_SETTINGS_ENDPOINT
from endpoints.settings import API_UPDATE_CASE_ASSIGNMENT_ENDPOINT
from endpoints.settings import API_UPDATE_MOVE_CASES_BETWEEN_ENVS_ENDPOINT
# Requests
from requests import Response
# Siemplify
# Source
from source.utils import post_with_admin_credentials
from source.utils import get_with_admin_credentials


def change_email_verification_sequence_only(enabled: bool) -> Response:
  """Changes email verification requirement for new users.

  This function should not be used in parallel testing!

  Args:
    enabled: status of email verification

  Returns:
    A response object
  """
  return post_with_admin_credentials(
      url=API_CHANGE_EMAIL_VERIFICATION_ENDPOINT,
      payload={"emailInvitationEnabled": enabled},
  )


def edit_alert_grouping_sequence_only(
    max_alerts: str = "20",
    timeframe_for_grouping: int = 2,
) -> Response:
  """Edits and saves alert grouping settings.

  This function should not be used in parallel testing!

  Args:
    max_alerts: maximum alerts grouped to one case
    timeframe_for_grouping: timeframe for grouping alerts (in hours)

  Returns:
    A response object (contains JSON updated settings)
  """
  payload = {
      "overflowTimeframeForGroupingInHours": 2,
      "overflowMaxAGroupingForAlerts": 50,
      "maxAGroupingForAlerts": max_alerts,
      "maxConfigurableGroupingForAlerts": 30,
      "groupingType": 0,
      "entitiesGroupingSettings": {
          "timeframeForGroupingInHours": timeframe_for_grouping
      },
      "fallbackToMatchOnEntities": False
  }
  return post_with_admin_credentials(
      url=API_SAVE_ALERT_GROUPING_SETTINGS_ENDPOINT,
      payload=payload,
  )


def allow_move_cases_between_envs_sequence_only(on: bool) -> Response:
  """Changes setting "allow users to move cases between environments".

  This function should not be used in parallel testing!

  Args:
    on: state of the setting

  Returns:
    A Response object
  """
  allow_value = 1 if on else 0
  return post_with_admin_credentials(
      url=API_UPDATE_MOVE_CASES_BETWEEN_ENVS_ENDPOINT,
      payload={"moveCaseBetweenEnvironmentsPolicy": allow_value},
  )


def allow_assign_cases_between_envs_sequence_only(on: bool) -> Response:
  """Changes "allow users to assign cases to users from other environments".

  This function should not be used in parallel testing!

  Args:
    on: state of the setting

  Returns:
    A Response object
  """
  allow_value = 1 if on else 0
  return post_with_admin_credentials(
      url=API_UPDATE_CASE_ASSIGNMENT_ENDPOINT,
      payload={"assignmentPolicy": allow_value},
  )


def add_update_localization(
    zone_id: str = "Europe/London",
    dateFormat: str = "yyyy-MM-dd",
    timeFormat: str = "HH:mm:ss",
  ) -> Response:

  """Adds/updates Localization.

  Args:
    zone_id: Zone of the localization (Defaults to 'Europe/London')
    dateFormat: Date format to set (Defaults to 'yyyy-MM-dd')
    timeFormat: Time format to set (Defaults to 'HH:mm:ss')

  Returns:
    A localization object with all the default localization configurations
  """
  payload = {
      "zoneId": zone_id,
      "dateFormat": dateFormat,
      "timeFormat": timeFormat
  }
  return post_with_admin_credentials(
      url=API_ADD_UPDATE_LOCALIZATION_ENDPOINT,
      payload=payload,
  )


def test_email_settings(
    senderDisplayName: str = "siemplifytest",
    senderEmailAddress: str = "siemplifyautomation@siemplify.co",
    username: str = "siemplifyautomation@siemplify.co",
    password: str = "siemplifyautomation1234567",
    smtpPort: int = 587,
    smtpServerAddress: str = "smtp.gmail.com",
    useSsl: bool = False,
    isRequireAuthentication: bool = True,
    trustCertificate: bool = False,
    useOauthToken: bool = False
  ) -> Response:

  """Tests email settings.

  Args:
    senderDisplayName: Display Name (Defaults to "siemplifytest")
    senderEmailAddress: senderEmailAddress
    ... (Defaults to "siemplifyautomation@siemplify.co")
    username: username (Defaults to "siemplifyautomation@siemplify.co")
    password: password (Defaults to "siemplifyautomation1234567")
    smtpPort: smtpPort (Defaults to "587")
    smtpServerAddress: smtpServerAddress (Defaults to "smtp.gmail.com")
    useSsl: useSsl (Defaults to "False")
    isRequireAuthentication: isRequireAuthentication (Defaults to "True")
    trustCertificate: trustCertificate (Defaults to "False")
    useOauthToken: useOauthToken (Defaults to "False")

  Returns:
    A test email settings object
  """
  payload = {
             "senderDisplayName":senderDisplayName,
             "senderEmailAddress":senderEmailAddress,
             "username":username,
             "password":password,
             "smtpPort":smtpPort,
             "smtpServerAddress":smtpServerAddress,
             "useSsl":useSsl,
             "isRequireAuthentication":isRequireAuthentication,
             "trustCertificate":trustCertificate,
             "useOauthToken":useOauthToken,
             }

  return post_with_admin_credentials(
      url=API_TEST_EMAIL_SETTINGS_ENDPOINT,
      payload=payload,
  )


def save_email_settings(
    useCustomSettings: bool = True,
    senderDisplayName: str = "siemplifytest",
    senderEmailAddress: str = "siemplifyautomation@siemplify.co",
    username: str = "siemplifyautomation@siemplify.co",
    password: str = "siemplifyautomation1234567",
    smtpPort: int = 587,
    smtpServerAddress: str = "smtp.gmail.com",
    useSsl: bool = False,
    isRequireAuthentication: bool = True,
    trustCertificate: bool = False,
    useOauthToken: bool = False,
    mailServerProvider: str = None,
    azureTenantId: str = None,
    azureClientId: str = None
  ) -> Response:

  """Saves email settings.

  Args:
    useCustomSettings: Flag to use custom settings (Defaults to 'True')
    senderDisplayName: Display Name (Defaults to "siemplifytest")
    senderEmailAddress: senderEmailAddress
    ... (Defaults to "siemplifyautomation@siemplify.co")
    username: username (Defaults to "siemplifyautomation@siemplify.co")
    password: password (Defaults to "siemplifyautomation1234567")
    smtpPort: smtpPort (Defaults to "587")
    smtpServerAddress: smtpServerAddress (Defaults to "smtp.gmail.com")
    useSsl: useSsl (Defaults to "False")
    isRequireAuthentication: isRequireAuthentication (Defaults to "True")
    trustCertificate: trustCertificate (Defaults to "False")
    useOauthToken: useOauthToken (Defaults to "False")
    mailServerProvider: (Defaults to 'None')
    azureTenantId: azureTenantId (Defaults to 'None')
    mailServerProvider: mailServerProvider (Defaults to 'None')

  Returns:
    A save email settings object
  """
  payload = {"useCustomSettings":useCustomSettings,
              "customSettings":
                {"senderDisplayName":senderDisplayName,
                "senderEmailAddress":senderEmailAddress,
                "username":username,
                "password":password,
                "smtpPort":smtpPort,
                "smtpServerAddress":smtpServerAddress,
                "useSsl":useSsl,
                "isRequireAuthentication":isRequireAuthentication,
                "trustCertificate":trustCertificate,
                "useOauthToken":useOauthToken,
                "mailServerProvider":mailServerProvider,
                "azureTenantId":azureTenantId,
                "azureClientId":azureClientId,
             }
            }

  return post_with_admin_credentials(
      url=API_SAVE_EMAIL_SETTINGS_ENDPOINT,
      payload=payload,
  )


def get_email_settings() -> Response:

  """Fetches email settings.

  Returns:
    An email settings object
  """

  return get_with_admin_credentials(
      url=API_GET_EMAIL_SETTINGS_ENDPOINT,
  )