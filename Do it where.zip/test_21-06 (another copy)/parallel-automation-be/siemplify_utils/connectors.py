"""A module for action manipulating connectors in siemplify.
"""
import json
import os
from typing import Optional, Union
# Endpoints
from endpoints.connectors import API_ADD_OR_UPDATE_CONNECTOR_INSTANCE_ENDPOINT
from endpoints.connectors import API_ADD_TEMPLATE_ENDPOINT
from endpoints.connectors import API_DELETE_CONNECTOR_INSTANCE_ENDPOINT
from endpoints.connectors import API_ENABLE_CONNECTOR_LOGS_COLLECTION_ENDPOINT
from endpoints.connectors import API_GET_CONNECTOR_INSTANCES_ENDPOINT
from endpoints.connectors import API_GET_CONNECTOR_LOGS_ENDPONT
from endpoints.connectors import API_RUN_CONNECTOR_ONCE_ENDPOINT
from endpoints.ide import API_ADD_OR_UPDATE_IDE_ITEM_ENDPOINT
# Requests
from requests import Response
# Resources
from payloads.connectors import default_params_for_custom_connnector
from resources.strings import strings
# Siemplify
from siemplify_utils import siemplify
# Source
from source.config import DEFAULT_INTEGRATION_NAME
from source.config import DEFAULT_INTEGRATION_VERSION
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import delete_with_admin_credentials
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials
from source.utils import post_with_test_credentials
from source.utils import put_with_admin_credentials


CONNECTOR_PARAMS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "resources/json/connector_params.json"
)
INTEGRATION_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "integration_data.json"
)


# Classes for Response DTOs
class ConnectorResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response, name: str):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.id = self.response_json
    self.name = name


class CreateConnectorInstanceResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.identifier = self.response_json.get("identifier")
    self.connector_definition_name = self.response_json.get(
        "connectorDefinitionName"
    )
    self.display_name = self.response_json.get("displayName")
    self.description = self.response_json.get("description")
    self.environment = self.response_json.get("environment")
    self.is_custom = self.response_json.get("isCustom")
    self.is_enabled = self.response_json.get("isEnabled")
    self.is_remote = self.response_json.get("isRemote")
    self.agent_identifier = self.response_json.get("agentIdentifier")
    self.integration = self.response_json.get("integration", {})
    self.parameters = self.response_json.get("parameters", [])
    self.is_allow_list_supported = self.response_json.get(
        "isAllowlistSupported"
    )
    self.allow_list = self.response_json.get("allowList", [])
    self.run_interval_seconds = self.response_json.get("runIntervalInSeconds")
    self.device_product_field = self.response_json.get("deviceProductField")
    self.event_name_field = self.response_json.get("eventNameField")
    self.version = self.response_json.get("version")
    self.documentation_link = self.response_json.get("documentationLink")
    self.is_update_available = self.response_json.get("isUpdateAvailable")
    self.logging_enabled_until_unix_ms = self.response_json.get(
        "loggingEnabledUntilUnixMs"
    )


class ConnectorTemplateResponse:
  """Class to represent connector template response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.agent_identifier = self.response_json.get("agentIdentifier")
    self.allow_list = self.response_json.get("allowList", [])
    self.connector_definition_name = self.response_json.get(
        "connectorDefinitionName"
    )
    self.description = self.response_json.get("description")
    self.device_product_field = self.response_json.get("deviceProductField")
    self.display_name = self.response_json.get("displayName")
    self.documentation_link = self.response_json.get("documentationLink")
    environment = self.response_json.get("environment")
    self.environment = environment or "Default Environment"
    self.event_name_field = self.response_json.get("eventNameField")
    self.identifier = self.response_json.get("identifier")
    integration = self.response_json.get("integration")
    if isinstance(integration, dict):
      self.integration_name = integration.get("identifier")
      self.integration_version = integration.get("version")
    else:
      self.integration_name = integration
      self.integration_version = self.response_json.get("integrationVersion")
    self.is_allow_list_supported = self.response_json.get(
        "isAllowlistSupported"
    )
    self.is_custom = self.response_json.get("isCustom")
    self.is_enabled = self.response_json.get("isEnabled")
    self.is_remote = self.response_json.get("isRemote")
    self.is_update_available = self.response_json.get("isUpdateAvailable")
    self.logging_enabled_until_unix_ms = self.response_json.get(
        "loggingEnabledUntilUnixMs"
    )
    self.parameters = self.response_json.get("parameters")
    self.run_interval = self.response_json.get("runIntervalInSeconds")
    self.version = self.response_json.get("version")


class RunConnectorOnceResponse:
  """Class to represent run connector once respose.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.is_success = self.response_json.get("isSuccess")
    self.debug_output = self.response_json.get("debugOutput")
    self.sample_cases = self.response_json.get("sampleCases")


class LogsResponse:
  """Class to represent logs response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.metadata = self.response_json.get("metadata")
    self.pages_number = self.metadata.get("totalNumberOfPages")
    self.logs = self.response_json.get("objectsList")


def create_custom_connector(
    name: str,
    description: str = "Test Description",
    integration: str = DEFAULT_INTEGRATION_NAME,
    creator: Optional[str] = None,
    is_enabled: bool = True,
    product_field_name: str = "Test_field",
    event_field_name: str = "Test_field",
    polling_timeout: int = 30,
    client_id: str = "0_1_Connector_Siemplify",
    script: str = strings.DEFAULT_CUSTOM_CONNECTOR_SCRIPT,
    add_parameters: Optional[list[dict]] = None,
    test_name: Optional[str] = None,
) -> ConnectorResponse:
  """Creates a custom connector.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    name: name of connector
    description: description of the connector (defaults to "Test Description")
    integration: To create in (defaults to "Siemplify")
    creator: instance owner (user_id)
    is_enabled: create connector as enabled (defaults to True)
    product_field_name: default connector param
    event_field_name: default connector param
    polling_timeout: timeout for running script
    client_id: client id in string
    script: connector script (defaults to default script)
    add_paramters: additional parameter in list
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (does not contain JSON with connector data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not creator:
    creator = siemplify.users.get_admin_user_data().username
  parameters = default_params_for_custom_connnector(
    event_field_name=event_field_name,
    product_field_name=product_field_name,
    polling_timeout=polling_timeout
  )
  if add_parameters:
    parameters += add_parameters
  payload = {
      "id": 0,
      "type": 0,
      "name": name,
      "description": description,
      "script": script,
      "integration": integration,
      "creator": creator,
      "creatorFullName": None,
      "isEnabled": is_enabled,
      "isCustom": True,
      "version": 1,
      "parameters": parameters,
      "connectorRules": [],
      "isConnectorRulesSupported": False,
      "documentationLink": None,
      "pythonVersion": "V3_7",
      "clientId": client_id,
      "pythonVersionRep": "V3.7",
  }
  response = post_with_admin_credentials(
      url=API_ADD_OR_UPDATE_IDE_ITEM_ENDPOINT,
      payload=payload,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Successfully created connector {name} for {test_name}",
      failure_message=f"Failed to create connector {name} for {test_name}",
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="connector",
        item_name=response.json(),
    )
  return ConnectorResponse(response=response, name=name)


def create_connector_for_test(
    description: str = "Test Description",
    integration: str = "Siemplify",
    is_enabled: bool = True,
    product_field_name: str = "Test_field",
    event_field_name: str = "Test_field",
    polling_timeout: int = 30,
    script: str = strings.DEFAULT_CUSTOM_CONNECTOR_SCRIPT,
    test_name: Optional[str] = None,
) -> ConnectorResponse:
  """Creates a custom connector.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not work!

  Args:
    description: description of the connector (defaults to "Test Description")
    integration: To create in (defaults to "Siemplify")
    is_enabled: create connector as enabled (defaults to True)
    product_field_name: default connector param
    event_field_name: default connector param
    polling_timeout: timeout for running script
    script: connector script (defaults to default script)
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (does not contain JSON with connector data)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  creator = siemplify.users.get_test_user_data(test_name=test_name).username
  name = siemplify.utils.generate_random_name(start="Connector_")
  payload = {
      "id": 0,
      "type": 0,
      "name": name,
      "description": description,
      "script": script,
      "integration": integration,
      "creator": creator,
      "creatorFullName": None,
      "isEnabled": is_enabled,
      "isCustom": True,
      "version": 1,
      "parameters": [{
          "isMandatory": True,
          "isAdvanced": False,
          "name": "Product Field Name",
          "defaultValue": product_field_name,
          "type": 2,
          "description": "The field name used to determine the device product",
          "mode": 0,
          "optionalValues": None
      }, {
          "isMandatory": True,
          "isAdvanced": False,
          "name": "Event Field Name",
          "defaultValue": event_field_name,
          "type": 2,
          "description": "Used to determine the event name (sub-type)",
          "mode": 0,
          "optionalValues": None
      }, {
          "isMandatory": True,
          "isAdvanced": False,
          "name": "Polling Timeout",
          "defaultValue": str(polling_timeout),
          "type": 17,
          "description": "Timeout (seconds) for python process running script",
          "mode": 0,
          "optionalValues": None
      }],
      "connectorRules": [],
      "isConnectorRulesSupported": False,
      "documentationLink": None,
      "pythonVersion": "V3_7",
      "clientId": "0_1_Connector_Siemplify",
      "pythonVersionRep": "V3.7"
  }
  response = post_with_admin_credentials(
      url=API_ADD_OR_UPDATE_IDE_ITEM_ENDPOINT,
      payload=payload,
      test_name=test_name,
      ignore_404=True,
  )
  if response.status_code == 404:
    final_response = siemplify.ide.get_ide_item_data_by_name(
      item_name=name,
      integration_name=integration
  )
  else:
    final_response = ConnectorResponse(response=response, name=name)
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Successfully created connector '{name}' for {test_name}"
      ),
      failure_message=f"Failed to create connector '{name}' for {test_name}",
      ignore_404=True
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="connector",
        item_name=response.json(),
    )
  return final_response


def create_emailv2_connector(agent_id: str) -> Response:
  """Creates an emailv2 connector.

  Args:
    agent_id: id of the agent

  Returns:
    A Response object
  """
  email_params = "siemplify.payloads.integrations.emailv2_connector_params()"
  payload = {
      "identifier": None,
      "connectorDefinitionName": "Generic IMAP Email Connector",
      "displayName": "Generic IMAP Email Connector",
      "description": "",
      "environment": "Default Environment",
      "isCustom": False,
      "isEnabled": True,
      "isRemote": True,
      "agentIdentifier": agent_id,
      "integration": {
          "identifier": "EmailV2",
          "version": 21,
      },
      "parameters": email_params,
      "isAllowlistSupported": False,
      "allowList": [
          "subject: (?<=Subject: ).*",
          "to: (?m)(?<=^To: ).*",
      ],
      "runIntervalInSeconds": 10,
      "deviceProductField": "Mail",
      "eventNameField": "event_name_mail_type",
      "version": 1,
      "documentationLink":
          "https://integrations.siemplify.co/doc/email-v2#connectors",
      "isUpdateAvailable": False,
      "loggingEnabledUntilUnixMs": 0,
      "isNew": True
  }
  response = post_with_admin_credentials(
      url=API_ADD_OR_UPDATE_CONNECTOR_INSTANCE_ENDPOINT,
      payload=payload,
  )
  return response


def create_custom_connector_instance(
    connector_name: str,
    instance_display_name: str,
    environment: str,
    description: str = "Test Description",
    parameters: list[dict] = strings.DEFAULT_CUSTOM_CONNECTOR_PARAMS,
    integration_name: str = DEFAULT_INTEGRATION_NAME,
    integration_version: int = DEFAULT_INTEGRATION_VERSION,
    is_enabled: bool = True,
    is_remote: bool = False,
    run_interval_in_sec: int = 10,
    device_product_field: str = "Test",
    event_name_field: str = "Test",
    agent_id: Optional[str] = None,
    is_custom: bool = True,
    test_name: Optional[str] = None,
) -> ConnectorTemplateResponse:
  """Creates connector instance.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    connector_name: name of connector IDE item
    instance_display_name: name of instance to create
    environment: environment to create instance in
    description: description of the connector (defaults to "Test Description")
    parameters: connector parameters json list (defaults to system default)
    integration_name: defaults to "Siemplify"
    integration_version: defaults to 65
    is_enabled: create as enabled connector (defaults to True)
    is_remote: is connector remote
    run_interval_in_sec: run interval in seconds (defaults to 10)
    device_product_field: default connector param
    event_name_field: default connector param
    agent_id: id of the remote agent
    is_custom: if connector instance is custom use it as true
    test_name: name of the test (Defaults to None)

  Returns:
    ConnectorTemplateResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if parameters == "use_csv_params":
    parameters = strings.USE_CSV_CONNECTOR_PARAMS
  payload = {
      "identifier": None,
      "connectorDefinitionName": connector_name,
      "displayName": instance_display_name,
      "description": description,
      "environment": environment,
      "isCustom": is_custom,
      "isEnabled": is_enabled,
      "isRemote": is_remote,
      "agentIdentifier": agent_id,
      "integration": {
          "identifier": integration_name,
          "version": integration_version
      },
      "parameters": parameters,
      "isAllowlistSupported": True,
      "allowList": [],
      "runIntervalInSeconds": run_interval_in_sec,
      "deviceProductField": device_product_field,
      "eventNameField": event_name_field,
      "version": 1,
      "documentationLink": None,
      "isUpdateAvailable": False,
      "loggingEnabledUntilUnixMs": 0,
      "isNew": True
  }
  response = post_with_admin_credentials(
      url=API_ADD_OR_UPDATE_CONNECTOR_INSTANCE_ENDPOINT,
      payload=payload,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="connector_instance",
        item_name=response.json().get("identifier"),
    )
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created connector instance for {test_name}"
        ),
        failure_message=f"Failed to create connector instance for {test_name}",
    )
    return ConnectorTemplateResponse(response=logged_response)

  return ConnectorTemplateResponse(response=response)


def create_connector_instance_for_test(
    connector_name: str,
    description: str = "Test Description",
    parameters: list[dict] = strings.DEFAULT_CUSTOM_CONNECTOR_PARAMS,
    integration_name: str = DEFAULT_INTEGRATION_NAME,
    integration_version: int = DEFAULT_INTEGRATION_VERSION,
    is_enabled: bool = True,
    is_remote: bool = False,
    run_interval_in_sec: int = 10,
    device_product_field: str = "Test",
    event_name_field: str = "Test",
    agent_id: Optional[str] = None,
    is_custom: bool = True,
    test_name: Optional[str] = None,
) -> ConnectorTemplateResponse:
  """Creates connector instance.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    connector_name: name of connector IDE item
    description: description of the connector (defaults to "Test Description")
    parameters: connector parameters json list (defaults to system default)
    integration_name: defaults to "Siemplify"
    integration_version: defaults to 65
    is_enabled: create as enabled connector (defaults to True)
    is_remote: is connector remote
    run_interval_in_sec: run interval in seconds (defaults to 10)
    device_product_field: default connector param
    event_name_field: default connector param
    agent_id: id of the remote agent
    is_custom: if connector instance is custom use it as true
    test_name: name of the test (Defaults to None)

  Returns:
    ConnectorTemplateResponse object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if parameters == "use_csv_params":
    parameters = strings.USE_CSV_CONNECTOR_PARAMS
  if parameters:
    parameters += strings.DEFAULT_CUSTOM_CONNECTOR_PARAMS
  payload = {
      "identifier": None,
      "connectorDefinitionName": connector_name,
      "displayName": f"{connector_name}_1",
      "description": description,
      "environment": test_name,
      "isCustom": is_custom,
      "isEnabled": is_enabled,
      "isRemote": is_remote,
      "agentIdentifier": agent_id,
      "integration": {
          "identifier": integration_name,
          "version": integration_version
      },
      "parameters": parameters,
      "isAllowlistSupported": True,
      "allowList": [],
      "runIntervalInSeconds": run_interval_in_sec,
      "deviceProductField": device_product_field,
      "eventNameField": event_name_field,
      "version": 1,
      "documentationLink": None,
      "isUpdateAvailable": False,
      "loggingEnabledUntilUnixMs": 0,
      "isNew": True
  }
  response = post_with_test_credentials(
      url=API_ADD_OR_UPDATE_CONNECTOR_INSTANCE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Successfully created connector instance for {test_name}"
      ),
      failure_message=f"Failed to create connector instance for {test_name}",
  )
  add_created_item_to_test(
      test_name=test_name,
      item_type="connector_instance",
      item_name=response.json().get("identifier"),
  )
  return ConnectorTemplateResponse(response=response)


def delete_connector_instance(
    identifier: str,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes connector instance.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    identifier: connector instance identifier
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = delete_with_admin_credentials(
      url=API_DELETE_CONNECTOR_INSTANCE_ENDPOINT.format(identifier)
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted connector instance #{identifier}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to delete connector instance #{identifier} for {test_name}"
        ),
    )
    return logged_response

  return response


def get_connector_instance(
    identifier: Union[str, Response],
    test_name: Optional[str] = None,
) -> Response:
  """Gets connector instance.

  Args:
    identifier: connector instance identifier or response
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains json data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if isinstance(identifier, Response):
    connector_instance_json = identifier.json()
    identifier = connector_instance_json["identifier"]
  response = get_with_admin_credentials(
      url=API_DELETE_CONNECTOR_INSTANCE_ENDPOINT.format(identifier),
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched connector #{identifier} details"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch connector #{identifier} details for {test_name}"
        ),
    )
    return logged_response

  return response


def get_connector_instances(test_name: Optional[str] = None) -> Response:
  """Fetches all connector instances.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains status code)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_CONNECTOR_INSTANCES_ENDPOINT,
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched all connector instances for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch all connector instances for {test_name}"
        ),
    )
    return logged_response

  return response


def get_connector_cards(integration_name: str = "Siemplify") -> list[dict]:
  """Fetches all connector cards for chosen integration.

  Args:
    integration_name: name of the integration (Defaults to "Siemplify")

  Returns:
    A list of dicts with connector cards
  """
  connectors = get_connector_instances()
  connectors_json = connectors.json()
  for integration in connectors_json:
    if integration["integration"] == integration_name:
      return integration["cards"]


def delete_all_connector_instances():
  """Deletes all connector instances and all custom actions."""
  all_connectors = get_connector_instances()
  connectors_json = all_connectors.json()
  for integration in connectors_json:
    active_connectors = integration["cards"]
    for connector in active_connectors:
      identifier = connector["identifier"]
      delete_connector_instance(identifier=identifier)


def update_connector(
    connector_id: int,
    connector_rules: Optional[list[dict]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Updates connector.

  Args:
    connector_id: connector id
    connector_rules: rules list (dynamic list)
    test_name: name of the test (Defaults to None)

  Returns:
    IdeItemResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  fetched_data = siemplify.ide.get_ide_item_data_by_id(
      item_type=0,
      item_id=connector_id,
  ).response_json
  params = {
      "id": connector_id,
      "connectorRules": connector_rules,
  }
  changes = dict(
      (key, value) for (key, value) in params.items() if value is not None
  )
  fetched_data.update(**changes)
  response = post_with_admin_credentials(
      url=API_ADD_OR_UPDATE_IDE_ITEM_ENDPOINT,
      payload=fetched_data,
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully updated connector #{connector_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to update connector #{connector_id} for {test_name}"
        ),
    )
    return logged_response

  return response


def update_connector_instance(
    identifier: Union[str, ConnectorTemplateResponse],
    instance_display_name: Optional[str] = None,
    description: Optional[str] = None,
    environment: Optional[str] = None,
    parameters: Optional[dict] = None,
    is_enabled: Optional[bool] = None,
    run_interval_in_sec: Optional[int] = None,
    device_product_field: Optional[str] = None,
    event_name_field: Optional[str] = None,
    test_name: Optional[str] = None,
) -> ConnectorTemplateResponse:
  """Updates connector instance only with given values.

  Args:
    identifier: identifier of connector to update (mandatory)
    instance_display_name: name of instance to create (optional)
    description: description of the connector (optional)
    environment: to move instance to (optional)
    parameters: connector parameters json list (optional)
    is_enabled:  enable/disable connector (optional)
    run_interval_in_sec: run interval in seconds (optional)
    device_product_field: default connector param (optional)
    event_name_field: default connector param (optional)
    test_name: name of the test (Defaults to None)

  Returns:
    ConnectorTemplateResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if isinstance(identifier, ConnectorTemplateResponse):
    identifier = identifier.identifier
  params = {
      "displayName": instance_display_name,
      "description": description,
      "environment": environment,
      "parameters": parameters,
      "isEnabled": is_enabled,
      "runIntervalInSeconds": run_interval_in_sec,
      "deviceProductField": device_product_field,
      "eventNameField": event_name_field
  }
  changes = dict(
      (key, value) for (key, value) in params.items() if value is not None
  )
  fetched_data = get_connector_instance(identifier)
  fetched_dict = fetched_data.json()
  fetched_dict.update(changes)
  response = post_with_admin_credentials(
      url=API_ADD_OR_UPDATE_CONNECTOR_INSTANCE_ENDPOINT,
      payload=fetched_dict,
  )
  con_id = identifier
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully updated connector instance #{con_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to update connector intsance #{con_id} for {test_name}"
        ),
    )
    return ConnectorTemplateResponse(response=logged_response)

  return ConnectorTemplateResponse(response=response)


def run_connector_once(
    identifier: Optional[str] = "",
    event_name_field: Optional[str] = "",
    device_product_field: Optional[str] = "",
    environment: Optional[str] = "",
    parameters: Optional[list[dict]] = None,
    display_name: Optional[str] = "",
    connector_definition_name: Optional[str] = "",
    connector_details: Optional[ConnectorTemplateResponse] = None,
    test_name: Optional[str] = None,
) -> RunConnectorOnceResponse:
  """Creates a connector instance and runs it once.

  Args:
    identifier: id of the connector
    event_name_field: event name
    device_product_field: device product
    environment: environment for connector instance
    parameters: parameters of the connector (Defaults to None)
    display_name: display name of the connector
    connector_definition_name: system name of the connector
    connector_details: additional connector details (Defaults to None)
    test_name: name of the test (Defaults to None)

  Returns:
    A RunConnectorOnceResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not parameters:
    parameters = [
        {
            "name": "PythonProcessTimeout",
            "value": "30",
            "description": "The timeout limit (in seconds)",
            "type": 2,
            "isMandatory": True,
            "isAdvanced": False
        }
    ]
  payload = {
      "identifier": getattr(connector_details, "identifier", identifier),
      "eventNameField": getattr(
          connector_details, "event_name_field", event_name_field
      ),
      "deviceProductField": getattr(
          connector_details, "device_product_field", device_product_field
      ),
      "environment": getattr(connector_details, "environment", environment),
      "parameters": getattr(connector_details, "parameters", parameters),
      "displayName": getattr(connector_details, "display_name", display_name),
      "connectorDefinitionName": getattr(
          connector_details,
          "connector_definition_name",
          connector_definition_name
      )
  }
  response = post_with_admin_credentials(
      url=API_RUN_CONNECTOR_ONCE_ENDPOINT,
      payload=payload,
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully ran connector #{identifier} once for {test_name}"
        ),
        failure_message=(
            f"Failed to run connector #{identifier} once for {test_name}"
        ),
    )
    return RunConnectorOnceResponse(response=logged_response)

  return RunConnectorOnceResponse(response=response)


def configure_connectors_logs_collection(
    identifier: str,
    enabled: bool,
    test_name: Optional[str] = None,
) -> ConnectorTemplateResponse:
  """Enables / disables logs capturing for connector.

  Args:
    identifier: connector's identiifer, required
    enabled: True / False, required
    test_name: name of the test (Defaults to None)

  Returns:
    ConnectorTemplateResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = put_with_admin_credentials(
      url=API_ENABLE_CONNECTOR_LOGS_COLLECTION_ENDPOINT.format(identifier),
      payload={"enabled": enabled},
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully set log collection to {enabled}"
            f" for connector #{identifier} for {test_name}"
        ),
        failure_message=(
            f"Failed to set log collection to {enabled}"
            f" for connector #{identifier} for {test_name}"
        ),
    )
    return ConnectorTemplateResponse(response=logged_response)
  return ConnectorTemplateResponse(response=response)


def get_connector_logs(
    identifier: str,
    log_level: int = 1,
    page_size: int = 20,
    requested_page: int = 0,
    search: str = "",
    sort_by: int = None,
    sort_order: str = None,
    test_name: Optional[str] = None,
):
  """Fetches connectors logs.

  Args:
    identifier: connector's identifier, required
    log_level: 3 - Error, 2 - Warning, 1 - Info
    page_size: amount of items to return on 1 page
    requested_page: page of results
    search: search criteria
    sort_by: 1 - time, 2 - log level, 3 - reason
    sort_order: asc or desc
    test_name: name of the test (Defaults to None)

  Returns:
    LogsResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "logLevel": log_level,
      "pageSize": page_size,
      "requestedPage": requested_page,
      "searchTerm": search,
      "sortBy": sort_by,
      "sortOrder": sort_order,
  }
  response = post_with_admin_credentials(
      url=API_GET_CONNECTOR_LOGS_ENDPONT.format(identifier),
      payload=payload,
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched connector #{identifier} logs for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch connector #{identifier} logs for {test_name}"
        ),
    )
    return LogsResponse(response=logged_response)

  return LogsResponse(response=response)


def get_connector_details(
    integration_name: str,
    connector_def_name: str,
    is_remote: bool,
) -> ConnectorTemplateResponse:
  """Creates connector template.

  Args:
    integration_name: integration name,
    connector_def_name: connector defenition name
    is_remote: if using agent

  Returns:
    ConnectorTemplateResponse object
  """
  payload = {
      "integration": integration_name,
      "connectorDefinitionName": connector_def_name,
      "isRemote": is_remote
  }
  response = post_with_admin_credentials(
      url=API_ADD_TEMPLATE_ENDPOINT,
      payload=payload,
  )

  return ConnectorTemplateResponse(response=response)


def get_default_version(integration_name: str) -> int:
  """Gets default integration version from template.

  Args:
    integration_name: name of integration

  Returns:
    Default version of integration or 0
  """
  with open(INTEGRATION_PATH, "r") as f:
    ingtegration_data = json.load(f)
  integration = ingtegration_data.get(integration_name, None)
  if not integration:
    raise ValueError(f"Not found integration data with name {integration_name}")
  return integration.get("version", 0)
