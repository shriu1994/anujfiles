"""A module for action manipulating SLA in siemplify.
"""
import datetime as dt
from typing import Optional
# Endpoints
from endpoints.sla import API_ADD_SLA_DEFINITION_ENDPOINT
from endpoints.sla import API_DELETE_SLA_DEFINITION_ENDPOINT
from endpoints.sla import API_GET_SLA_DEFINITIONS_ENDPOINT
from endpoints.sla import API_PAUSE_ALERT_SLA
from endpoints.sla import API_RESUME_ALERT_SLA
# Requests
from requests import Response
# Other siemplify modules
from siemplify_utils import siemplify
# Source
from source import enums
from source.utils import add_created_item_to_test
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import log_and_assert
from source.utils import log_event
from source.utils import post_with_admin_credentials


class Sla:
  """Class to represent Alert or Case Sla.
  """

  def __init__(self, item: dict):
    self.sla_expiration_time = item.get("slaExpirationTime")
    self.critical_expiration_time = item.get("criticalExpirationTime")
    self.expiration_status = item.get("expirationStatus")
    self.remaining_time_since_last_pause = item.get(
        "remainingTimeSinceLastPause"
    )


def pause_alert_sla(
    alert_identifier: str,
    case_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Pauses alert SLA.

  Args:
    alert_identifier: identifier of an alert
    case_id: id of the case
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "alertIdentifier": alert_identifier,
      "caseId": case_id,
      "message": None
  }
  response = post_with_admin_credentials(
      url=API_PAUSE_ALERT_SLA,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully paused alert SLA for alert '{alert_identifier}'"
            f"for {test_name}"
        ),
        failure_message=(
            f"Failed to pause alert SLA for alert '{alert_identifier}'"
            f"for {test_name}"
        ),
    )
  return response


def resume_alert_sla(
    alert_identifier: str,
    case_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Resumes alert SLA.

  Args:
    alert_identifier: identifier of an alert
    case_id: id of the case
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "alertIdentifier": alert_identifier,
      "caseId": case_id,
  }
  response = post_with_admin_credentials(
      url=API_RESUME_ALERT_SLA,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully resumed alert SLA for alert '{alert_identifier}'"
            f"for {test_name}"
        ),
        failure_message=(
            f"Failed to resume alert SLA for alert '{alert_identifier}'"
            f"for {test_name}"
        ),
    )
  return response


def validate_sla(
    sla,
    expected_expiration_status: enums.SlaExpiration,
    expected_expiration_since_ingestion: Optional[float] = None,
    expected_critical_expiration_since_ingestion: Optional[float] = None,
    case_ingestion_time: Optional[dt.datetime] = None,
    pause_time: Optional[int] = None,
    test_name: Optional[str] = None,
):
  """Validates an alert sla.

  Args:
    sla: the sla object from case details
    expected_expiration_status: expected expiration status, types
      stored in enums.SlaExpiration
    expected_expiration_since_ingestion: expected expiration time
      since ingestion in MINUTES (Defaults to None)
    expected_critical_expiration_since_ingestion: expected critical
      expiration time since ingestion in MINUTES (Defaults to None)
    case_ingestion_time: the time case was ingested (Defaults to None)
    pause_time: the pause time
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  assert sla is not None, "Sla not found"
  grace_period_ms = 5000
  if sla is not None:
    print(f"SLA Not Found, SLA Value Returned: {sla}")
  if expected_expiration_since_ingestion is None:
    assert not sla.sla_expiration_time, "Sla expiration time is not None"
  else:
    diff = (
        sla.sla_expiration_time -
        (
            dt.datetime.timestamp(case_ingestion_time) * 1000 +
            expected_expiration_since_ingestion * 60 * 1000
        )
    )
    if (abs(diff) > grace_period_ms):
      log_event(
          test_name=test_name,
          message="SLA diff found",
          details=f"diff: {diff}",
          success=False,
      )
    assert (abs(diff) <= grace_period_ms), (
        f"diff: {diff}, expiration: {sla.sla_expiration_time/1000}",
        f"ingestion time: {dt.datetime.timestamp(case_ingestion_time)}",
        "expected_expiration_since_ingestion: "
        f"{expected_expiration_since_ingestion}"
    )

  if expected_critical_expiration_since_ingestion is None:
    assert not sla.critical_expiration_time, (
        "Critical expiration time not None"
    )
  else:
    diff = (
        sla.critical_expiration_time -
        (
            dt.datetime.timestamp(case_ingestion_time) * 1000 +
            expected_critical_expiration_since_ingestion * 60 * 1000
        )
    )
    if (abs(diff) > grace_period_ms):
      log_event(
          test_name=test_name,
          message="SLA diff found",
          details=f"diff: {diff}",
          success=False,
      )
    assert (abs(diff) <= grace_period_ms), (
        f"diff: {diff}, expiration: {sla.critical_expiration_time}",
        f"ingestion time: {dt.datetime.timestamp(case_ingestion_time)}"
    )

  received_status = sla.expiration_status
  if received_status != sla.expiration_status:
    log_event(
        test_name=test_name,
        message="Sla Expiration status doesn't match ",
        details=(
            f"Expected: {expected_expiration_status} "
            f"Received: {received_status}"
        ),
        success=False,
    )
  assert received_status == expected_expiration_status, (
      "Sla Expiration status doesn't match",
      f"Expected: {expected_expiration_status}",
      f"Received: {received_status}"
  )

  if received_status != enums.SlaExpiration.PAUSED:
    return

  expected_remaining_time_ms = (
      expected_expiration_since_ingestion * 1000 * 60 - (
          pause_time - case_ingestion_time
      ).total_seconds() * 1000
  )
  diff = expected_remaining_time_ms - sla.remaining_time_since_last_pause
  if (abs(diff) > grace_period_ms):
    log_event(
        test_name=test_name,
        message="SLA diff found",
        details=f"diff: {diff}",
        success=False,
    )
  assert (abs(diff) <= grace_period_ms), (
      f"diff: {diff}, expected_remaining_time: {expected_remaining_time_ms}",
      f"remaining_time_since_last_pause: {sla.remaining_time_since_last_pause}"
  )


def delete_sla_definition(
    payload: dict,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes an SLA definition.

  Args:
    payload: dict object with fields of SLA definition to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_SLA_DEFINITION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted SLA definition for {test_name}"
        ),
        failure_message=(
            f"Failed to delete SLA definition for {test_name}"
        ),
    )
  return response


def delete_all_sla_definitions() -> None:
  """Deletes all sla definitions.
  """
  response = get_sla_definitions()
  objects = siemplify.utils.find_key_in_json(
      json_data=response,
      key="objectsList",
  )
  for item in objects:
    delete_sla_definition(item)


def delete_all_sla_definitions_for_test(
    test_name: Optional[str] = None,
) -> None:
  """Deletes all sla definitions for test.

  Args:
    test_name: name of the test (Defaults to None)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  response = get_sla_definitions(search=f"{test_name}")
  objects = siemplify.utils.find_key_in_json(
      json_data=response,
      key="objectsList",
  )
  for item in objects:
    delete_sla_definition(item)


def get_sla_definitions(
    page: int = 0,
    search: str = "",
    page_size: int = 100,
    test_name: Optional[str] = None,
) -> Response:
  """Get all SLA definitions.

  Args:
    page: pagination page
    search: sla definition search template
    page_size: count of sla definitions returned per page
    test_name: name of the test (Defaults to None)

  Returns:
    A Request object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "requestedPage": page,
      "searchTerm": search,
      "pageSize": page_size
  }
  response = post_with_admin_credentials(
      url=API_GET_SLA_DEFINITIONS_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched SLA definitions for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch SLA definitions for {test_name}"
        ),
    )
  return response


def add_sla_definition_for_test(
    value_type: enums.ApiSlaProviderType,
    sla_period: int,
    critical_period: int,
    sla_period_type: Optional[enums.ApiPeriodType] = None,
    critical_period_type: Optional[enums.ApiPeriodType] = None,
    alert_type: Optional[enums.ApiSlaAlertType] = None,
    value: Optional[str] = "",
    test_name: Optional[str] = None,
):
  """Adding SLA definition for alert(s) or case.

  Args:
    value_type: type of the sla
    sla_period: unix timestamp that represents when the sla will be expired
    critical_period: unix timestamp that represents when the sla will exter
      a critical period before expiring
    sla_period_type: the units for the sla_period
    critical_period_type: the units for the critical_period
    alert_type: relevant only if value_type = ALERT_RULE; represents whether
      this definition applies all alerts or only a specific alert
    value: the value depends on the value_type and alert_type, represents the
      name of the relevant alert/case configuration
    test_name: name of the test (Defaults to None)

  Returns:
      A Response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if not sla_period_type:
    sla_period_type = enums.ApiPeriodType.MINUTES
  if not critical_period_type:
    critical_period_type = enums.ApiPeriodType.MINUTES
  if not alert_type:
    alert_type = enums.ApiSlaAlertType.ALL_ALERTS
  payload = {
      "id": 0,
      "valueType": value_type,
      "alertType": alert_type,
      "criticalPeriod": str(critical_period),
      "criticalPeriodType": critical_period_type,
      "slaPeriod": str(sla_period),
      "slaPeriodType": sla_period_type,
      "value": value,
      "environments": [test_name],
    }
  response = post_with_admin_credentials(
      url=API_ADD_SLA_DEFINITION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_name="sla",
        item_type="sla_definition",
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created SLA definition for {test_name}"
        ),
        failure_message=(
            f"Failed to create SLA definition for {test_name}"
        ),
    )
  return response


def add_sla_definition_in_environments(
    value_type: enums.ApiSlaProviderType,
    sla_period: int,
    critical_period: int,
    environments: list[str],
    sla_period_type: Optional[enums.ApiPeriodType] = None,
    critical_period_type: Optional[enums.ApiPeriodType] = None,
    alert_type: Optional[enums.ApiSlaAlertType] = None,
    value: Optional[str] = "",
    test_name: Optional[str] = None,
):
  """Adding SLA definition for alert(s) or case.

  Args:
    value_type: type of the sla
    sla_period: unix timestamp that represents when the sla will be expired
    critical_period: unix timestamp that represents when the sla will exter 
      a critical period before expiring
    environments: list of environments to add SLA in
    sla_period_type: the units for the sla_period
    critical_period_type: the units for the critical_period
    alert_type: relevant only if value_type = ALERT_RULE; represents whether 
      this definition applies all alerts or only a specific alert
    value: the value depends on the value_type and alert_type, represents the
      name of the relevant alert/case configuration
    test_name: name of the test (Defaults to None)

  Returns:
      A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not sla_period_type:
    sla_period_type = enums.ApiPeriodType.MINUTES
  if not critical_period_type:
    critical_period_type = enums.ApiPeriodType.MINUTES
  if not alert_type:
    alert_type = enums.ApiSlaAlertType.ALL_ALERTS
  payload = {
      "id": 0,
      "valueType": value_type,
      "alertType": alert_type,
      "criticalPeriod": str(critical_period),
      "criticalPeriodType": critical_period_type,
      "slaPeriod": str(sla_period),
      "slaPeriodType": sla_period_type,
      "value": value,
      "environments": environments,
    }
  response = post_with_admin_credentials(
      url=API_ADD_SLA_DEFINITION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_name="sla",
        item_type="sla_definition",
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created SLA definition for {test_name}"
        ),
        failure_message=(
            f"Failed to create SLA definition for {test_name}"
        ),
    )
  return response
