"""A module for action manipulating networks in siemplify.
"""
from typing import Optional
# Endpoints
from endpoints.networks import API_ADD_NETWORK_ENDPOINT
from endpoints.networks import API_DELETE_ALL_NETWORKS_ENDPOINT
from endpoints.networks import API_GET_NETWORKS_ENDPOINT
from endpoints.networks import API_DELETE_NETWORK_ENDPOINT
# Requests
from requests import Response
# Other module functions
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import delete_with_admin_credentials
from source.utils import log_and_assert
from source.utils import log_event
from source.utils import post_with_admin_credentials
from source.utils import post_with_test_credentials
from source.utils import delete_with_admin_credentials


# Classes for Response DTOs
class NetworkResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response, name: str):
    self.status_code = response.status_code
    self.response_json = {}
    self.name = name


def add_network_to_environments(
    name: str,
    address: str,
    environments: list[str],
    priority: int = 1,
    test_name: Optional[str] = None,
):
  """Adds a network to selected environments.

  Args:
    name: name of network to be added
    address: network's IP address
    environments: environments to be used
    priority: network's priority
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "name": name,
      "address": address,
      "priority": priority,
      "environments": environments,
    }
  response = post_with_admin_credentials(
      url=API_ADD_NETWORK_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_name=name,
        item_type="network",
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created network '{name}' for {test_name}"
        ),
        failure_message=(
            f"Failed to create network '{name}' for {test_name}"
        ),
    )
  return NetworkResponse(response=response, name=name)


def add_network_for_test(
    address: str,
    priority: int = 1,
    test_name: Optional[str] = None,
):
  """Adds a network to the test environment.

  Args:
    address: network's IP address
    priority: network's priority
    test_name: name of the test (Defaults to None)

  Returns:
    A tuple of (name,Response object)
  """
  # TODO: (b/292466385) should change the return value
  # to response only when this bug is resolved.
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  name = siemplify.utils.generate_random_name(start="Network_")
  payload = {
      "name": name,
      "address": address,
      "priority": priority,
      "environments": [test_name],
    }
  response = post_with_test_credentials(
      url=API_ADD_NETWORK_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created network '{name}' for {test_name}"
        ),
        failure_message=(
            f"Failed to create network '{name}' for {test_name}"
        ),
    )
  return name, NetworkResponse(response=response, name=name)


def delete_all_networks(test_name: Optional[str] = None,) -> Response:
  """Deletes all added networks.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = delete_with_admin_credentials(
      url=API_DELETE_ALL_NETWORKS_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully deleted all networks for {test_name}",
        failure_message=f"Failed to delete all networks for {test_name}",
    )
  return response


def get_networks(
    search_term: Optional[str] = "",
    requested_page: Optional[int] = 0,
    page_size: Optional[int] = 20,
    test_name = None
) -> Response:
  """
  Fetches existing networks.

  Args:
    search_term: string to search by
    requested_page: requested page
    page_size: number of networks to fetch in one bulk

  Returns:
    Response object representing networks list and metadata
  """
  if not test_name:
    test_name = check_test_name_can_be_none()

  payload = {
    "searchTerm": search_term,
    "requestedPage": requested_page,
    "pageSize": page_size
  }

  response = post_with_admin_credentials(
    url = API_GET_NETWORKS_ENDPOINT,
    payload=payload,
    test_name=test_name
  )

  log_and_assert(
    response=response,
    success_message="successfully fetched networks",
    failure_message="failed to fetch networks",
    test_name=test_name
  )

  return response


def delete_network(
    network_id: Optional[int] = None,
    network_name: Optional[str] = None,
    cidr_format: Optional[str] = None,
    environments: Optional[list[str]] = None,
    test_name = None
) -> None:
  """
  Deletes a network

  Args:
    network_id: id of network to delete. Can be sent alone.
    network_name: name of network to search and delete
    cidr_format: address of network to search and delete
    environments: environments of network. Defaults to [test_name], 
      if the funcstion is called by a test
    test_name: name of calling test
  
  Returns:
    Response of deletion operation
  """
  if not test_name:
    test_name = check_test_name_can_be_none()

  if not network_id:
    if not environments and test_name:
      environments = [test_name]

    search_term = network_id if network_id else ""
    networks_response = get_networks(
      search_term=search_term,
      test_name=test_name
    )
    networks = networks_response.json().get("objectsList")

    if len(networks) == 1:
      network_id = networks[0].get("id")
    else:
      network_to_delete_list = [
        nw for nw in networks
        if (cidr_format and nw.get("address") == cidr_format)
        and (network_name and nw.get("name") == network_name)
             and (all(env in nw.get("environments") for env in environments))
      ]
      if len(network_to_delete_list) != 1:
        log_event(
          test_name=test_name,
          message="Could not find one speific network to delete",
          details=str(network_to_delete_list),
          success=False)
        return None
      network_id = network_to_delete_list[0].get("id")

  url = API_DELETE_NETWORK_ENDPOINT.format(network_id)
  response = delete_with_admin_credentials(
    url=url,
    test_name=test_name
  )

  log_and_assert(
    response=response,
    success_message=f"successfully deleted network",
    failure_message="failed to delete network",
    test_name=test_name
  )

  return response
