"""Module containing actions to authenticate users in siemplify client.
"""
import datetime
import json
import os
import time
from typing import Optional
# Endpoints
from endpoints.authentication import API_AUTHZ_METADATA_ENDPOINT
from endpoints.authentication import API_LOGIN_ENDPOINT
# Logger
from logger.html_logger import log_event
# Requests module
from requests import exceptions as exc
from requests import Response
# Credentials
from source.config import AUTH_LOGIN
from source.config import AUTH_PASSWORD
from source.config import SESSION
from source.config import VERIFY
from source.utils import check_test_name_can_not_be_none
from source.utils import generate_test_id

RETRIES = 3
SUCCESS_CODES = (200, 201, 202, 203, 204)

JSON_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auth.json"
)
TESTS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests.json"
)
LOGS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
)


def authenticate(
    username: Optional[str] = None,
    password: Optional[str] = None,
) -> Response:
  """Fetches an authentication token from the siemplify_client.

  Args:
    username: username to log in (uses .env credentials if None)
    password: password to log in (uses .env credentials if None)

  Returns:
    A Response object
  """
  if not username:
    username = AUTH_LOGIN
  if not password:
    password = AUTH_PASSWORD
  starting_headers = {"Content-Type": "application/json"}
  payload = {
      "userName": username,
      "password": password,
      "enablementToken": None,
      "screenSize": "1512x982"
  }
  attempts = 0
  response = None
  # Fetch token
  while attempts < RETRIES:
    try:
      response = SESSION.post(
          url=API_LOGIN_ENDPOINT,
          data=json.dumps(payload),
          headers=starting_headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  code = response.status_code
  assert code == 200, "Authentication failed!" + f" Code: {code}"
  token = response.text
  auth_token = f"Bearer {token}"
  headers = {
      "Content-Type": "application/json",
      "Authorization": auth_token,
  }
  timestamp = datetime.datetime.now()
  string_timestamp = timestamp.strftime("%m-%d-%Y-%H-%M-%S")
  # Fetch username and email
  attempts = 0
  authz_response = None
  while attempts < RETRIES:
    try:
      authz_response = SESSION.get(
          url=API_AUTHZ_METADATA_ENDPOINT,
          headers=headers,
          verify=VERIFY,
      )
      if authz_response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  code = authz_response.status_code
  assert code == 200, "Getting Auth metadata failed!" + f" Code: {code}"
  username = authz_response.json()["userName"]
  email = authz_response.json()["email"]
  auth_data = {
      "username": username,
      "email": email,
      "headers": headers,
      "timestamp": string_timestamp,
  }
  json_object = json.dumps(auth_data, indent=4)
  with open(JSON_PATH, "w") as outfile:
    outfile.write(json_object)

  return response


def log_in_for_test(
    email: str,
    password: str,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches an authentication token and stores it in tests.json.

  Args:
    email: username email to log in with
    password: password to log in with
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  starting_headers = {"Content-Type": "application/json"}
  payload = {
      "userName": email,
      "password": password,
      "enablementToken": None,
      "screenSize": "1512x982"
  }
  # Fetch token
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.post(
          url=API_LOGIN_ENDPOINT,
          data=json.dumps(payload),
          headers=starting_headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  code = response.status_code
  if code != 200:
    log_event(
        test_name=test_name,
        message="Authentication failed!",
        details=(
            f"Failed to authenticate as user {email} after {attempts} retries"
        ),
        success=False,
    )
  assert code == 200, "Authentication failed!" + f" Code: {code}"
  token = response.text
  auth_token = f"Bearer {token}"
  headers = {
      "Content-Type": "application/json",
      "Authorization": auth_token,
  }
  # Fetch username and email
  attempts = 0
  authz_response = None
  while attempts < RETRIES:
    try:
      authz_response = SESSION.get(
          url=API_AUTHZ_METADATA_ENDPOINT,
          headers=headers,
          verify=VERIFY,
      )
      if authz_response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  authz_code = authz_response.status_code
  custom_creds = {}
  if authz_code == 200:
    full_response = authz_response.json()
    username = full_response.get("userName")
    email = full_response.get("email")
    custom_creds = {
        "username": username,
        "password": password,
        "email": email,
        "auth_token": auth_token,
        "headers": headers,
    }
    log_event(
        test_name=test_name,
        message="Fetched metadata successfully!",
        details=f"Fetched metadata for user {email} ({username})",
        success=True,
    )
  else:
    log_event(
        test_name=test_name,
        message="Getting Auth metadata failed!",
        details=(
            f"Failed to get metadata after {attempts} retries"
        ),
        success=False,
    )
  assert authz_code == 200, "Failed to get metadata!" + f" Code: {code}"
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as readfile:
    data = json.load(readfile)
    data["custom_login"] = True,
    data["custom_credentials"] = custom_creds
  json_test_log_data = json.dumps(data)
  with open(path, "w") as outfile:
    outfile.write(json_test_log_data)
  return response


def authenticate_first_time_for_test(
    username: str,
    password: str,
    test_name: str,
    permission_group_id: str,
) -> Response:
  """Fetches an authentication token and stores it in tests.json.

  Args:
    username: username to log in
    password: password to log in
    test_name: name of the test for which to log in
    permission_group_id: id of the permission group created for the test

  Returns:
    A Response object
  """
  # Create an empty file first
  test_data = {
      "email": "",
      "password": "",
      "username": "",
      "headers": "",
      "environment": "",
      "permission_group_id": "",
      "timestamp": "",
      "test_status": None,
      "test_steps": [],
      "test_id": "",
      "created": {},
      "to_restore": {},
      "test_start": "",
      "test_end": None,
      "custom_login": False,
      "custom_credentials": {},
      "next_request_should_fail": False,
  }
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  json_object = json.dumps(test_data, indent=4)
  with open(path, "w") as outfile:
    outfile.write(json_object)
  # Log in
  headers = {"Content-Type": "application/json"}
  payload = {
      "userName": username,
      "password": password,
      "enablementToken": None,
      "screenSize": "1512x982"
  }
  # Fetching the token
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.post(
          url=API_LOGIN_ENDPOINT,
          data=json.dumps(payload),
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  code = response.status_code
  token = response.text
  auth_token = f"Bearer {token}"
  auth_headers = {
      "Content-Type": "application/json",
      "Authorization": auth_token,
  }
  # Fetching the username and email
  attempts = 0
  authz_response = None
  while attempts < RETRIES:
    try:
      authz_response = SESSION.get(
          url=API_AUTHZ_METADATA_ENDPOINT,
          headers=auth_headers,
          verify=VERIFY,
      )
      if authz_response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  authz_code = authz_response.status_code
  assert authz_code == 200, "Failed to get metadata!" + f" Code: {code}"
  full_response = authz_response.json()
  username = full_response.get("userName")
  email = full_response.get("email")
  timestamp = datetime.datetime.now()
  string_timestamp = timestamp.strftime("%d/%m/%Y, %H:%M:%S")
  test_id = generate_test_id()
  correlation_id = f"{test_name}_{test_id}"
  headers = {
      "Content-Type": "application/json",
      "Authorization": auth_token,
      "correlation-id": correlation_id,
  }
  test_data = {
      "email": email,
      "password": password,
      "username": username,
      "headers": headers,
      "environment": test_name,
      "permission_group_id": permission_group_id,
      "timestamp": string_timestamp,
      "test_status": None,
      "test_steps": [],
      "test_id": test_id,
      "created": {},
      "to_restore": {},
      "test_start": string_timestamp,
      "test_end": None,
      "custom_login": False,
      "custom_credentials": {},
      "next_request_should_fail": False,
  }
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  json_object = json.dumps(test_data, indent=4)
  with open(path, "w") as outfile:
    outfile.write(json_object)
  if code == 200:
    log_event(
        test_name=test_name,
        message="Authenticated successfully!",
        details=f"Authenticated as user {username}",
        success=True,
    )
  else:
    log_event(
        test_name=test_name,
        message="Authentication failed!",
        details=(
            f"Failed to authenticate as user {email} after {attempts} retries"
        ),
        success=False,
    )
  assert code == 200, "Authentication failed!" + f" Code: {code}"

  return response


def relog_for_test(
    test_name: Optional[str] = None,
) -> Response:
  """Re-logs in, fetches an authentication token and stores it in tests.json.

  Args:
    test_name: name of the test for which to relog in (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  email = data.get("email")
  password = data.get("password")
  headers = {"Content-Type": "application/json"}
  payload = {
      "userName": email,
      "password": password,
      "enablementToken": None,
      "screenSize": "1512x982"
  }
  attempts = 0
  while attempts < RETRIES:
    try:
      response = SESSION.post(
          url=API_LOGIN_ENDPOINT,
          data=json.dumps(payload),
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  code = response.status_code
  if code == 200:
    log_event(
        test_name=test_name,
        message="Authenticated successfully!",
        details=f"Authenticated as user {email}",
        success=True,
    )
  else:
    log_event(
        test_name=test_name,
        message="Authentication failed!",
        details=(
            f"Failed to authenticate as user {email} after {attempts} retries"
        ),
        success=False,
    )
  assert code == 200, "Authentication failed!" + f" Code: {code}"
  code = response.status_code
  token = response.text
  auth_token = f"Bearer {token}"
  headers = {
      "Content-Type": "application/json",
      "Authorization": auth_token,
  }
  data["headers"] = headers
  data["custom_login"] = False
  data["custom_credentials"] = {}
  json_object = json.dumps(data, indent=4)
  with open(path, "w") as outfile:
    outfile.write(json_object)
  assert code == 200, "Authentication failed!" + f" Code: {code}"

  return response
