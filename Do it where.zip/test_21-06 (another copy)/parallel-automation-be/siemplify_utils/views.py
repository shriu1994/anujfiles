"""Module with actions to change case/alert view widgets in siemplify client.
"""
from typing import Optional
# API endpoints
from endpoints.views import API_DELETE_VIEW_TEMPLATE_ENDPOINT
from endpoints.views import API_GET_VIEW_TEMPLATE_DETAILS_ENDPOINT
from endpoints.views import API_GET_VIEW_TEMPLATES_ENDPOINT
from endpoints.views import API_SAVE_VIEW_TEMPLATE_ENDPOINT
# Requests
from requests import Response
# Other siemplify utils
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


def save_template(
    template_type: str,
    widgets: list[str],
    identifier: Optional[str] = None,
    user_id: Optional[str] = None,
    test_name: Optional[str] = None,
    playbook_id: Optional[str] = None,
) -> Response:
  """Creates a view template.

  Args:
    template_type: type of template: can be "Alert" or "Case"
    widgets: list of widgets to add to a template
    identifier: ID of the view (Auto sets based on the template_type if None)
    user_id: id of the user creating a template
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (contains JSON with template data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not user_id:
    user_id = siemplify.users.get_admin_user_data().username
  if not identifier and template_type.lower() == "alert":
    identifier = get_default_alert_view_id()
  elif not identifier and template_type.lower() == "case":
    identifier = get_default_case_view_id()
  payload = siemplify.payloads.views.save_view_payload(
      user_id=user_id,
      widgets=widgets,
      identifier=identifier,
      template_type=template_type,
      playbook_id=playbook_id,
  )
  response = post_with_admin_credentials(
      url=API_SAVE_VIEW_TEMPLATE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="view_template",
        item_name="template",
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Saved view template for {test_name}",
        failure_message=f"Failed to save view template for {test_name}",
    )
  return response


def delete_template(
    template_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a view template.

  Args:
    template_id: id of template to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_VIEW_TEMPLATE_ENDPOINT,
      payload={"overviewTemplateIdentifier": template_id},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Deleted view template #{template_id} for {test_name}",
        failure_message=f"Failed to delete view template for {test_name}",
    )
  return response


def get_templates(test_name: Optional[str] = None):
  """Get all case view templates.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (contains JSON with template data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_VIEW_TEMPLATES_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched view templates for {test_name}",
        failure_message=f"Failed to fetch view templates for {test_name}",
    )
  return response


def get_template_data(
    template_id: str,
    test_name: Optional[str] = None
) -> Response:
  """Get data of a view template.

  Args:
    template_id: id of template to get data of
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (contains JSON with template data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_VIEW_TEMPLATE_DETAILS_ENDPOINT.format(template_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched template #{template_id} data for {test_name}",
        failure_message=(
            f"Failed to fetch template #{template_id} data for {test_name}"
        ),
    )
  return response


def get_template_ids() -> list[str]:
  """Get all case view templates ID's.

  Returns:
    A list of all template ID's
  """
  templates = get_templates()
  templates_json = templates.json()

  return [temp["identifier"] for temp in templates_json]


def get_default_case_view_id() -> str:
  """Fetches the identifier of a default case view.

  Returns:
    Default case view's ID
  """
  templates = get_templates()
  templates_json = templates.json()

  for template in templates_json:
    if template["type"] == 3:
      return template["identifier"]


def get_default_alert_view_id():
  """Fetches the identifier of a default alert view.

  Returns:
    Default alert view's ID
  """
  templates = get_templates()
  templates_json = templates.json()

  for template in templates_json:
    if template["type"] == 2:
      return template["identifier"]


def set_case_view_to_default(
    test_name: Optional[str] = None
) -> Response:
  """Sets the case view to default values.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  creator = siemplify.users.get_admin_user_data().username
  identifier = get_default_case_view_id()
  payload = siemplify.payloads.views.default_case_view_payload(
      identifier=identifier,
      creator=creator,
  )
  response = post_with_admin_credentials(
      url=API_SAVE_VIEW_TEMPLATE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message="Case view template set to default",
        failure_message="Failed to set case view template to default",
    )
  return response


def set_alert_view_to_default(
    test_name: Optional[str] = None
) -> Response:
  """Sets the alert view to default values.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  creator = siemplify.users.get_admin_user_data().username
  identifier = get_default_alert_view_id()
  payload = siemplify.payloads.views.default_alert_view_payload(
      identifier=identifier,
      creator=creator,
  )
  response = post_with_admin_credentials(
      url=API_SAVE_VIEW_TEMPLATE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message="Alert view template set to default",
        failure_message="Failed to set alert view template to default",
    )
  return response


def set_all_views_to_default(
    test_name: Optional[str] = None
):
  """Sets both case and alert views to default values.

  Args:
    test_name: name of the test (Defaults to None)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  set_alert_view_to_default(test_name=test_name)
  set_case_view_to_default(test_name=test_name)
