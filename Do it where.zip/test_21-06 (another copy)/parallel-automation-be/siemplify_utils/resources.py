"""Module used as a hub unifying different parts of the siemplify client.
"""
from resources.strings import strings

__all__ = (
    strings,
)
