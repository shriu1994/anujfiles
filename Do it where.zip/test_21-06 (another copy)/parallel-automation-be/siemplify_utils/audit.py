"""Module to work with audit.
"""
from typing import Optional, Union, List
from endpoints.audit import API_GET_AUDIT_DATA_V2_ENDPOINT
from requests import Response
from siemplify_utils import siemplify
from source import enums
from source.utils import check_test_name_can_be_none
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


class CountData:
  """Class to represent audit records count data per distribution.
  """

  def __init__(self, item: dict):
    self.name = item.get("name")
    self.count = item.get("count")
    self.count_label = item.get("countLabel")


class MostActiveUsersCountData(CountData):
  """Class to represent the most active users in the audit records distribution.
  """

  def __init__(self, item: dict):
    super().__init__(item)
    self.user_full_name = item.get("userFullName")


class AuditRecord:
  """Class to represent audit records in the response.
  """

  def __init__(self, item: dict):
    self.activity_item = item.get("activityItem")
    self.address = item.get("address")
    self.browser = item.get("browser")
    self.creation_time_unix_time_in_ms = item.get("creationTimeUnixTimeInMs")
    self.current_activity = item.get("currentActivity")
    self.id = item.get("id")
    self.modification_time_unix_time_in_ms = item.get(
        "modificationTimeUnixTimeInMs"
    )
    self.module = item.get("module")
    self.operation = item.get("operation")
    self.previous_activity = item.get("previousActivity")
    self.screen_size = item.get("screenSize")
    self.source = item.get("source")
    self.user = item.get("user")
    self.user_guid = item.get("userGuid")


# Classes for Response DTOs
class AuditSettingsResponse:
  """Class to represent entire audit records and metadata in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = response.json()
    self.audit_records = [
        AuditRecord(item=x) for x in self.response_json.get("auditRecords", [])
    ]
    self.most_common_operations = [
        CountData(item=x)
        for x in self.response_json.get("mostCommonOperations")
    ]
    self.most_common_resolutions = [
        CountData(item=x)
        for x in self.response_json.get("mostCommonResulations")
    ]
    self.most_common_active_users = [
        MostActiveUsersCountData(item=x)
        for x in self.response_json.get("mostCommonActiveUsers")
    ]
    self.most_common_browsers = self.most_common_resolutions = [
        CountData(item=x) for x in self.response_json.get("mostCommonBrowsers")
    ]
    self.most_common_addresses = self.most_common_resolutions = [
        CountData(item=x) for x in self.response_json.get("mostCommonAddresses")
    ]
    self.operations_distribution = self.most_common_resolutions = [
        CountData(item=x)
        for x in self.response_json.get("operationsDistribution")
    ]


def create_audit_user(
    role: Union[int, Response] = 1,
    environments: Optional[list[str]] = None,
    permission_group: str = "Admins",
    test_name: Optional[str] = None
) -> str:
  """Creates a unique audit user.

  Creates a new unique user before running action.
  This will make audit response easier to filter.

  Args:
    role: id of the role for the created user or Response from create_role
    environments: environments for created user, (defaults to All environments)
    permission_group: permission group of the user
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (contains JSON with user data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  user_name = "AuditTest@siemplify.co"
  users = siemplify.users.get_users().objects_list
  user_exists = siemplify.utils.find_key_value_in_json(
      json_data=users,
      key="loginIdentifier",
      value=user_name,
  )
  if user_exists and test_name:
    siemplify.authentication.log_in_for_test(
        email=user_name,
        password="Password1!",
        test_name=test_name,
    )
  elif user_exists and not test_name:
    siemplify.authentication.authenticate(
        username=user_name,
        password="Password1!",
    )
  elif not user_exists and test_name:
    new_user = siemplify.users.create_custom_user(
        email=user_name,
        role=role,
        environments=environments,
        permission_group=permission_group,
    )
    siemplify.authentication.log_in_for_test(
        email=user_name,
        password="Password1!",
        test_name=test_name,
    )
  elif not user_exists and not test_name:
    new_user = siemplify.users.create_custom_user(
        email=user_name,
        role=role,
        environments=environments,
        permission_group=permission_group,
    )
    siemplify.authentication.authenticate(
        username=user_name,
        password="Password1!",
    )
  if user_exists:
    return user_exists.get("userName")
  else:
    return new_user.username


def get_audit_data(
    page_number: int = 0,
    audit_settings_request_type: enums.AuditSettingsRequestType
    = enums.AuditSettingsRequestType.COUNT,
    users_names: List[str] = None,
    api_keys: List[str] = None,
    test_name: Optional[str] = None
) -> Response:
  """Retrieves audit data from the server.

  When no usernames are specified audit data for all users will be returned.

  Args:
    page_number: the page of the results (used in pagination).
    audit_settings_request_type: the audit request type.
    users_names: list of usernames for filtering in the server.
    api_keys: list of api keys used for filtering in the server.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "PageNumber": page_number,
      "AuditSettingsRequestType": audit_settings_request_type,
      "UsersNames": users_names,
      "ApiKeys": api_keys,
  }
  response = post_with_admin_credentials(
      url=API_GET_AUDIT_DATA_V2_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched audit data for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch audit data for {test_name}"
        ),
    )
  return AuditSettingsResponse(response=response)
