"""Module containing actions to manipulate services in siemplify client.
"""


from typing import Optional
# API endpoints
from endpoints.services import API_CHECK_SERVICES_ENDPOINT
from endpoints.services import API_WEBHOOKS_KEEPALIVE_ENDPOINT
# Requests
from requests import Response
# Source
from source.utils import check_test_name_can_not_be_none
from source.utils import get_with_test_credentials
from source.utils import get_with_appkey


def check_services_status_for_test(
    test_name: Optional[str] = None,
) -> Response:
  """Checks the status for all services.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains JSON with status result)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()

  response = get_with_appkey(
      url=API_CHECK_SERVICES_ENDPOINT,
      test_name=test_name,
  )
  return response


def check_webhooks_management_status_for_test(
    test_name: Optional[str] = None,
) -> Response:
  """Checks the status for webhook management.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains JSON with status result)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()

  response = get_with_test_credentials(
      url=API_WEBHOOKS_KEEPALIVE_ENDPOINT,
      test_name=test_name,
  )
  return response
