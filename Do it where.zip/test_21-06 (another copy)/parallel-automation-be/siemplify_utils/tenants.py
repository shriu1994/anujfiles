"""A module for action manipulating entities in siemplify.
"""
from typing import Optional
# Endpoints
from endpoints.tenants import API_ADD_TENANT_ENDPOINT
from endpoints.tenants import API_CHANGE_TENANT_PYTHON_POD_ENDPOINT
from endpoints.tenants import API_DELETE_TENANT_ENDPOINT
from endpoints.tenants import API_GET_QUEUE_WEIGHTS_ENDPOINT
from endpoints.tenants import API_GET_TENANT_BY_EMAIL_ENDPOINT
from endpoints.tenants import API_GET_TENANT_BY_ID_ENDPOINT
from endpoints.tenants import API_GET_TENANTS_ENDPOINT
from endpoints.tenants import API_REGISTER_TENANT_ENDPOINT
# Requests
from requests import JSONDecodeError
from requests import Response
# Source
from source.utils import check_test_name_can_be_none
from source.utils import delete_with_appkey
from source.utils import get_with_appkey
from source.utils import log_and_assert
from source.utils import post_with_appkey


# Classes for Response DTOs
class TenantsResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    try:
      self.response_json = response.json()
    except JSONDecodeError:
      self.response_json = {}


def get_tenants(test_name: Optional[str] = None) -> Response:
  """Fetches all tenants.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_TENANTS_ENDPOINT,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched all tenants for {test_name}",
      failure_message=f"Failed to fetch all tenants for {test_name}",
  )
  return response


def get_tenant_by_email(
    email: str,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches a tenant by email.

  Args:
    email: email of the tenant to look for
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_TENANT_BY_EMAIL_ENDPOINT.format(email),
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched a tenant by email for {test_name}",
      failure_message=f"Failed to fetch tenant by email for {test_name}",
  )
  return response


def update_tenant_queue_weight(
    tenant_id: str,
    weight: int,
    test_name: Optional[str] = None,
) -> Response:
  """Updates tenant's queue weight.

  Args:
    tenant_id: id of the tenant to update
    weight: the new weight of tenant
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  payload = {
      "tenantId": tenant_id,
      "weight": weight
  }
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_appkey(
      url=API_GET_QUEUE_WEIGHTS_ENDPOINT,
      payload=payload,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Updated tenant #{tenant_id} queue weight to {weight}"
          f" for {test_name}"
      ),
      failure_message=(
          f"Failed to update tenant #{tenant_id} queue weight for {test_name}"
      ),
  )
  return response


def get_tenant_by_id(
    tenant_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches a tenant by id.

  Args:
    tenant_id: id of the tenant
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_TENANT_BY_ID_ENDPOINT.format(tenant_id),
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched a tenant by id #{tenant_id} for {test_name}",
      failure_message=(
          f"Failed to fetch tenant by by id #{tenant_id} for {test_name}"
      ),
  )
  return response


def add_tenant(
    tenant_name: str,
    admin_email: str,
    admin_password: str,
    admin_first_name: str,
    admin_last_name: str,
    private_python_pod: str,
    test_name: Optional[str] = None,
) -> Response:
  """Adds a new tenant.

  Args:
    tenant_name: name of the new tenant
    admin_email: email of the administrator
    admin_password: password of the administrator
    admin_first_name: first name of the administrator
    admin_last_name: last name of the administrator
    private_python_pod: name of the private python pod
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "tenantName": tenant_name,
      "adminEmail": admin_email,
      "adminPassword": admin_password,
      "adminFirstName": admin_first_name,
      "adminLastName": admin_last_name,
      "privatePythonPod": private_python_pod,
  }
  response = post_with_appkey(
      url=API_ADD_TENANT_ENDPOINT,
      payload=payload,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Tenant added for {test_name}",
      failure_message=f"Failed to add tenant for {test_name}",
  )
  return response


def register_tenant(
    tenant_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Registers a new tenant.

  Args:
    tenant_id: id of the tenant
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_REGISTER_TENANT_ENDPOINT.format(tenant_id),
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Tenant #{tenant_id} registered for {test_name}",
      failure_message=(
          f"Failed to register a tenant #{tenant_id} for {test_name}"
      ),
  )
  return response


def change_tenant_python_pod(
    tenant_id: str,
    python_pod: str,
    test_name: Optional[str] = None,
) -> Response:
  """Changes tenant's python pod.

  Args:
    tenant_id: id of the tenant
    python_pod: new python pod
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "tenantId": tenant_id,
      "privatePythonPod": python_pod,
  }
  response = post_with_appkey(
      url=API_CHANGE_TENANT_PYTHON_POD_ENDPOINT,
      payload=payload
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Tenant #{tenant_id} python pod changed for {test_name}",
      failure_message=(
          f"Failed to change python pod for tenant #{tenant_id} for {test_name}"
      ),
  )
  return response


def delete_tenant(
    tenant_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Changes tenant's python pod.

  Args:
    tenant_id: id of the tenant
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = delete_with_appkey(
      url=API_DELETE_TENANT_ENDPOINT.format(tenant_id),
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Tenant #{tenant_id} deleted for {test_name}",
      failure_message=f"Failed to delete tenant #{tenant_id} for {test_name}",
  )
  return response
