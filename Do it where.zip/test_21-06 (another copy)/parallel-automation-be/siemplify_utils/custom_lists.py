"""Module containing actions to manipulate custom lists in siemplify client.
"""
import json
from typing import Optional
# API endpoints
from endpoints.custom_lists import API_ADD_OR_UPDATE_CUSTOM_LIST
from endpoints.custom_lists import API_REMOVE_CUSTOM_LIST
from endpoints.custom_lists import API_GET_CUSTOM_LISTS
# Requests
from requests import Response
# Source
from source.utils import add_created_item_to_test
from source.utils import delete_created_item_from_test
from source.utils import check_test_name_can_be_none
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials
from source.utils import get_with_admin_credentials


def add_or_update_custom_list(
    category: str,
    entity_identifier: str,
    id: int = 0,
    test_name = None
    ) -> Response:
  """
  Adds/updates custom list.

  Args:
    category: custom list category
    entity_identifier: custom list entity identifier
    id: id of custom list (if edit is the wanted action)
    test_name: name of the calling test

  Returns: a Response object representing the created/edited custom list

  """
  if not test_name:
    test_name = check_test_name_can_be_none()

  payload = {
    "entityIdentifier": entity_identifier,
    "category": category,
    "forDBMigration": False,
    "environments": [
      test_name
    ],
    "id": id,
  }

  response = post_with_admin_credentials(
    url = API_ADD_OR_UPDATE_CUSTOM_LIST,
    payload=payload,
    test_name=test_name
  )

  log_and_assert(
    response=response,
    success_message="successfully added/edited custom list",
    failure_message="failed to add/edit custom list",
    test_name=test_name
  )

  if test_name:
    add_created_item_to_test(
      test_name=test_name,
      item_type="custom_list",
      item_name=json.dumps(response.json())
    )

  return response


def remove_all_custom_lists(
    test_name = None
) -> None:
  """
  Removes all custom lists.

  Args:
    test_name: name of calling test
  """
  if not test_name:
    test_name = check_test_name_can_be_none()

  custom_lists_res = get_custom_lists()
  custom_lists = custom_lists_res.json()
  for lst_item in custom_lists:
    remove_custom_list(
      full_payload=lst_item,
      test_name=test_name
    )


def remove_custom_list(
    category: Optional[str] = None,
    entity_identifier: Optional[str] = None,
    id: Optional[int] = None,
    full_payload: Optional[dict] = None,
    test_name = None
 ) -> Response:
  """
  Removes a custom list.
  Either full_payload, id, or both category & entity_identifier must be given.
  
  Args:
    category: custom list category
    entity_identifier: custom list entity identifier
    id: id of custom list
    full_payload: payload in the form of a response object 
      of a created/fetched custom list
    test_name: name of calling test

  Returns:
    The response of the custom list remove operation
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  
  payload = full_payload

  if not payload:
    all_custom_lists = get_custom_lists()
    if id:
      wanted = [lst for lst in all_custom_lists if list.get("id") == id]
    else:
      wanted = [lst for lst in all_custom_lists 
                if lst.get("category") == category
                and lst.get("entityIdentifier") == entity_identifier
                and test_name in lst.get("environments") if test_name]
    payload = wanted[0]
  
  response = post_with_admin_credentials(
    url=API_REMOVE_CUSTOM_LIST,
    payload=payload,
    test_name=test_name
  )

  log_and_assert(
    response=response,
    success_message="successfully deleted custom list",
    failure_message="failed to delete custom list",
    test_name=test_name
  )

  if test_name:
    delete_created_item_from_test(
      test_name=test_name,
      item_type="custom_list",
      item_name=json.dumps(payload)
    )

  return response


def get_custom_lists(
    test_name=None
) -> Response:
  """
  Fetches custom lists

  Args:
    test_name: name of calling test

  Retruns:
    A resppone with a list of dicts representing each custom list in the system
  """
  response = get_with_admin_credentials(
    url=API_GET_CUSTOM_LISTS,
    test_name=test_name,
    log_request_enabled=True
  )

  log_and_assert(
    response=response,
    success_message="successfully fetched custom lists",
    failure_message="failed to fetch custom lists",
    test_name=test_name
  )

  return response