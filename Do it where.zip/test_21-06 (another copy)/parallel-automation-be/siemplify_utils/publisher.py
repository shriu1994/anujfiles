"""Module which is responsible to run functions of an agent.
"""
from typing import Optional
# Endpoints
from endpoints.publishers import API_DELETE_PUBLISHER_ENDPOINT
from endpoints.publishers import API_GET_PUBLISHER_DATA_ENDPOINT
from endpoints.publishers import API_TEST_PUBLISHER_PING_ENDPOINT
from endpoints.publishers import API_UPDATE_PUBLISHER_ENDPOINT
# Requests
from requests import Response
# Source
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


def get_publishers_data(test_name: Optional[str] = None) -> Response:
  """Fetches a list of all publishers (activated, disabled and deleted).

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (list of all publishers)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_PUBLISHER_DATA_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched publishers data for {test_name}",
        failure_message=f"Failed to fetch publishers data for {test_name}",
    )
  return response


def test_publisher_connectivity(
    publisher_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Run test connectivity of a publisher.

  Args:
    publisher_id: id of the publisher
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_TEST_PUBLISHER_PING_ENDPOINT.format(publisher_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Publisher #{publisher_id} connectivity tested successfully"
            f" for {test_name}"
        ),
        failure_message=(
            f"Publisher #{publisher_id} connectivity test failed"
            f" for {test_name}"
        ),
    )
  return response


def update_publisher(
    agent_run_time: int,
    api_token: str,
    publisher_id: int,
    name: str,
    server_api: str,
    test_name: Optional[str] = None,
) -> Response:
  """Updates a publisher.

  Args:
    agent_run_time:  agent Communication Time In Seconds
    api_token: publisher token
    publisher_id: id of the publisher to update
    name: name of the publisher
    server_api: url of the publisher
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  payload = {
      "id": publisher_id,
      "name": name,
      "serverApiRoot": server_api,
      "agentCommunicationTimeInSeconds": agent_run_time,
      "apiToken": api_token,
      "slavePublisherId": None
  }
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_UPDATE_PUBLISHER_ENDPOINT,
      test_name=test_name,
      payload=payload,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Publisher #{publisher_id} updated for {test_name}"
        ),
        failure_message=(
            f"Failed to update publisher #{publisher_id} for {test_name}"
        ),
    )
  return response


def delete_publisher(
    publisher_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a publisher.

  Args:
    publisher_id: id of the publisher to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_PUBLISHER_ENDPOINT,
      test_name=test_name,
      payload={"id": publisher_id},
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Publisher #{publisher_id} deleted for {test_name}"
        ),
        failure_message=(
            f"Failed to delete publisher #{publisher_id} for {test_name}"
        ),
    )
  return response
