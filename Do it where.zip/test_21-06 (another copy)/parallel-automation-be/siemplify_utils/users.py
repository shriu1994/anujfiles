"""Module containing actions to manipulate settings in siemplify client.
"""
import json
import os
import time
from typing import Optional, Union
# API endpoints
from endpoints.users import API_ADD_ROLE_ENDPOINT
from endpoints.users import API_ADD_USER_ENDPOINT
from endpoints.users import API_CREATE_PERMISSION_GROUP_ENDPOINT
from endpoints.users import API_DELETE_PERMISSION_GROUP_ENDPOINT
from endpoints.users import API_DELETE_ROLE_ENDPOINT
from endpoints.users import API_DELETE_USER_ENDPOINT
from endpoints.users import API_GET_PERMISSION_GROUPS_ENDPOINT
from endpoints.users import API_GET_ROLE_BY_ID_ENDPOINT
from endpoints.users import API_GET_ROLES_ENDPOINT
from endpoints.users import API_GET_USERS_ENDPOINT
from endpoints.users import API_ADD_OR_UPDATE_USER_PROFILE
# Requests
from requests import Response
# Siemplify
from siemplify_utils import siemplify
# Config
from source.config import VERIFY
# Utils
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import delete_created_item_from_test
from source.utils import delete_with_admin_credentials
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import log_event
from source.utils import post_with_admin_credentials

LOGS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
)
AUTH_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auth.json"
)


class CreatedRoleResponse:
  """Class to represent a created role in the response.
  """

  def __init__(self, response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.id = self.response_json


class CreatedPermissionGroupResponse:
  """Class to represent ontology mapping rules in the response.
  """

  def __init__(self, response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.id = self.response_json.get("id")
    self.name = self.response_json.get("name")
    self.type = self.response_json.get("type")
    self.is_system_group = self.response_json.get("isSystemGroup")
    self.is_read_only = self.response_json.get("isReadOnly")
    self.landing_page = self.response_json.get("landingPage")
    self.creation_time_unix = self.response_json.get("creationTimeUnixTimeInMs")
    self.modification_time_unix = (
        self.response_json.get("modificationTimeUnixTimeInMs")
    )
    self.permission_nodes = self.response_json.get("permissionNodes")
    self.restriction_ids = (
        self.response_json.get("permissionsGroupRestrictionIds")
    )
    self.group_ad_mapping = self.response_json.get("permissionsGroupAdMapping")
    self.is_visible = self.response_json.get("isVisible")


class CreatedUserResponse:
  """Class to represent ontology mapping rules in the response.
  """

  def __init__(self, response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.login = self.response_json.get("loginIdentifier")
    self.first_name = self.response_json.get("firstName")
    self.last_name = self.response_json.get("lastName")
    self.permission_type = self.response_json.get("permissionType")
    self.role = self.response_json.get("role")
    self.soc_role_id = self.response_json.get("socRoleId")
    self.email = self.response_json.get("email")
    self.username = self.response_json.get("userName")
    self.image_base64 = self.response_json.get("imageBase64")
    self.user_type = self.response_json.get("userType")
    self.identity_provider = self.response_json.get("identityProvider")
    self.provider_name = self.response_json.get("providerName")
    self.advanced_reports_access = (
        self.response_json.get("advancedReportsAccess")
    )
    self.account_state = self.response_json.get("accountState")
    self.last_login_time = self.response_json.get("lastLoginTime")
    self.previous_login_time = self.response_json.get("previousLoginTime")
    self.last_password_change_time = (
        self.response_json.get("lastPasswordChangeTime")
    )
    self.last_password_change_notification_time = (
        self.response_json.get("lastPasswordChangeNotificationTime")
    )
    self.login_wrong_password_count = (
        self.response_json.get("loginWrongPasswordCount")
    )
    self.is_deleted = self.response_json.get("isDeleted")
    self.deletion_time_unix = self.response_json.get("deletionTimeUnixTimeInMs")
    self.environments = self.response_json.get("environments")
    self.id = self.response_json.get("id")
    self.creation_time_unix = self.response_json.get("creationTimeUnixTimeInMs")
    self.modification_time_unix = (
        self.response_json.get("modificationTimeUnixTimeInMs")
    )


class UsersResponse:
  """Class to represent ontology mapping rules in the response.
  """

  def __init__(self, response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.objects_list = self.response_json.get("objectsList", {})


class CurrentTestUser:
  """Class to represent current test user data.
  """

  def __init__(self, data):
    self.email = data.get("email")
    self.password = data.get("password")
    self.username = data.get("username")
    self.permission_group_id = data.get("permission_group_id")


class CurrentAdminUser:
  """Class to represent current test user data.
  """

  def __init__(self, data):
    self.email = data.get("email")
    self.username = data.get("username")


class RoleResponse:
  """Class to represent ontology mapping rules in the response.
  """

  def __init__(self, response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.id = self.response_json.get("id")
    self.name = self.response_json.get("name")
    self.is_default = self.response_json.get("isDefault")
    self.users_assigned = self.response_json.get("usersAssigned")
    self.additional_roles = self.response_json.get("additionalRoleAccesses")


def create_custom_user(
    first_name: str = "TestFirstName",
    last_name: str = "TestLastName",
    email: str = "testuser@siemplify.co",
    password: str = "Password1!",
    role: Union[int, Response] = 1,
    environments: Optional[list[str]] = None,
    permission_group: str = "Admins",
) -> CreatedUserResponse:
  """Creates a custom new user.

  !!! This functions is not intended to be used inside a test! Please use
    create_user_for_test instead!

  Args:
    first_name: first name of the created user
    last_name: last name of the created user
    email: email of the created user
    password: password of the created user
    role: id of the role for the created user or Response from create_role
    environments: environments for created user, (defaults to All environments)
    permission_group: permission group of the user

  Returns:
    A response object (contains JSON with user data)
  """
  if permission_group == "Admins" and not environments:
    environments = ["*"]
  elif permission_group != "Admins" and not environments:
    environments = ["Default Environment"]
  if isinstance(role, Response):
    role_id = role.json()
  else:
    role_id = role
  payload = {
      "identityProvider": -1,
      "userType": 1,
      "firstName": first_name,
      "lastName": last_name,
      "loginIdentifier": email,
      "socRoleId": role_id,
      "permissionGroup": permission_group,
      "environments": environments,
      "email": email,
      "isDisabled": False,
      "permissionType": 0,
      "advancedReportsAccess": 0,
      "password": password,
      "confirmPassword": password,
  }
  response = post_with_admin_credentials(
      url=API_ADD_USER_ENDPOINT,
      payload=payload,
  )
  # Verify the user was created
  retries = 3
  attempts = 0
  while attempts < retries:
    users = get_users()
    objects = users.objects_list
    names = [user.get("firstName") for user in objects]
    if first_name in names:
      attempts += retries
    else:
      attempts += 1
      if attempts > retries:
        log_event(
            test_name=first_name,
            message=f"Failed to create a user with name {first_name}",
            success=False,
            details=f"Status code: {response.status_code}",
        )
      time.sleep(2)
  return CreatedUserResponse(response=response)


def create_user_for_test(
    test_name: Optional[str] = None,
    password: str = "Password1!",
    role: Union[int, Response] = 1,
    environments: Optional[list[str]] = None,
    permission_group: str = "Admins",
    permission_type: Optional[int] = 0
) -> CreatedUserResponse:
  """Creates a new user.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    test_name: name of the test (Defaults to None)
    password: password of the created user
    role: id of the role for the created user or Response from create_role
    environments: environments for created user, (defaults to All environments)
    permission_group: permission group of the user

  Returns:
    A response object (contains JSON with user data)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  name = siemplify.utils.generate_random_name(start="User_")
  if permission_group == "Admins" and not environments:
    environments = ["*"]
  elif permission_group != "Admins" and not environments:
    environments = [test_name]
  if isinstance(role, Response):
    role_id = role.json()
  else:
    role_id = role
  payload = {
      "identityProvider": -1,
      "userType": 1,
      "firstName": name,
      "lastName": name,
      "loginIdentifier": f"{name}@siemplify.co",
      "socRoleId": role_id,
      "permissionGroup": permission_group,
      "environments": environments,
      "email": f"{name}@siemplify.co",
      "isDisabled": False,
      "permissionType": permission_type,
      "advancedReportsAccess": 0,
      "password": password,
      "confirmPassword": password,
  }
  response = post_with_admin_credentials(
      url=API_ADD_USER_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  logged_response = log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Successfully created user {name} for {test_name}",
      failure_message=f"Failed to create user for {test_name}",
  )
  final_response = CreatedUserResponse(response=logged_response)
  add_created_item_to_test(
      test_name=test_name,
      item_type="user",
      item_name=final_response.username,
  )
  return final_response

def edit_existing_user(
  user_details: CreatedUserResponse,
  permission_group: str = "Admins",
  test_name: Optional[str] = None
) -> CreatedUserResponse:
  payload = siemplify.payloads.users.add_or_update_user_profile(
    user_details=user_details,
    permission_group=permission_group
  )
  response = post_with_admin_credentials(
    url=API_ADD_OR_UPDATE_USER_PROFILE,
    payload=payload,
    test_name=test_name,
    log_request_enabled=True
  )
  logged_response = log_and_assert(
    response=response,
    test_name=test_name,
    success_message=
    f"Successfully edited user {user_details.login} for {test_name}",
    failure_message=f"Failed to edit user for {test_name}",
  )
  final_response = CreatedUserResponse(response=logged_response)
  return final_response

def delete_user(
    username: str,
    test_name: Optional[str] = None
) -> Response:
  """Deletes a user with specified ID.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    username: id of the user to delete
    test_name: name of the test this is called in (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_USER_ENDPOINT,
      payload={"userName": username},
      test_name=test_name,
  )
  if test_name:
    delete_created_item_from_test(
        test_name=test_name,
        item_type="user",
        item_name=username,
    )
    return log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully deleted user {username} for {test_name}",
        failure_message=f"Failed to delete user {username} for {test_name}",
    )

  return response


def create_custom_role(role_name: str = "TestRole") -> Response:
  """Creates a new user role.

  !!! This functions is not intended to be used inside a test! Please use
    create_role_for_test instead!

  Args:
    role_name: name of the role to create

  Returns:
    A response object (contains JSON with new role ID)
  """
  payload = {
      "id": 0,
      "name": role_name,
      "additionalRoleAccess": [1, 2, 3, 4, 5, 6],
      "setAsDefault": False
  }
  response = post_with_admin_credentials(
      url=API_ADD_ROLE_ENDPOINT,
      payload=payload,
  )
  return CreatedRoleResponse(response=response)


def create_role_for_test(
    test_name: Optional[str] = None
) -> RoleResponse:
  """Creates a new user role.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (contains JSON with new role ID)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  name = siemplify.utils.generate_random_name(start="Role_")
  payload = {
      "id": 0,
      "name": name,
      "additionalRoleAccess": [1, 2, 3, 4, 5, 6],
      "setAsDefault": False
  }
  response = post_with_admin_credentials(
      url=API_ADD_ROLE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Successfully created role {name} for {test_name}",
      failure_message=f"Failed to create a role for {test_name}",
  )
  role_id = response.json()
  role_data = get_role_by_id(role_id=role_id, test_name=test_name)
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="role",
        item_name=role_data.id,
    )
  return role_data


def get_role_by_id(
    role_id: int,
    test_name: Optional[str] = None
) -> RoleResponse:
  """Fetches all the users' data.

  Args:
    role_id: id of the role
    test_name: name of the test (Defaults to None)

  Returns:
    A RoleResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_ROLE_BY_ID_ENDPOINT.format(role_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched data for role #{role_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch data for role #{role_id} for {test_name}"
        ),
    )
  return RoleResponse(response=response)


def delete_role(role_id: int, test_name: Optional[str] = None) -> Response:
  """Deletes a user role with specified ID.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    role_id: id of the role to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_ROLE_ENDPOINT,
      payload={"socRoleId": role_id, "reassignCasesToDefaultRole": False},
      test_name=test_name,
  )
  if test_name:
    delete_created_item_from_test(
        test_name=test_name,
        item_type="role",
        item_name=role_id,
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted role #{role_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to delete role #{role_id} for {test_name}"
        ),
    )

  return response


def delete_all_extra_users():
  """Deletes all users except the default.
  """
  users_response = get_users()
  users_objects = users_response.objects_list
  users_check = 2 if VERIFY else 1
  for user in users_objects:
    if user["id"] > users_check:
      delete_id = user["userName"]
      delete_user(username=delete_id)


def delete_all_extra_roles():
  """Deletes all roles except the default.
  """
  roles_response = get_roles()
  role_objects = siemplify.utils.find_key_in_json(
      json_data=roles_response,
      key="objectsList",
  )
  role_ids = siemplify.utils.find_key_in_json(
      json_data=role_objects,
      key="id",
  )
  for role in role_ids:
    if role > 6:
      delete_role(role_id=role)


def get_users(
    test_name: Optional[str] = None
) -> UsersResponse:
  """Fetches all the users' data.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A UsersResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "requestedPage": 0,
      "pageSize": 20,
      "searchTerm": "",
      "filterDisabledUsers": False,
      "filterRole": False,
      "filterPermissionTypes": []
  }
  response = post_with_admin_credentials(
      url=API_GET_USERS_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully fetched users for {test_name}",
        failure_message=f"Failed to fetch users for {test_name}",
    )
  return UsersResponse(response=response)


def get_roles(
    test_name: Optional[str] = None
) -> Response:
  """Fetches all the roles' data.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_GET_ROLES_ENDPOINT,
      payload={"searchTerm": "", "requestedPage": 0, "pageSize": 20},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully fetched roles for {test_name}",
        failure_message=f"Failed to fetch roles for {test_name}",
    )
  return response


def create_custom_permission_group(
    name: str,
    playbooks_permission: bool = False,
    playbooks_editing_playbooks: bool = False,
    playbooks_managing_folders: bool = False,
    marketplace_permisson: bool = False,
    marketplace_allow_marketplace_actions: bool = False,
    jobs_permission: bool = False,
    jobs_editing_jobs: bool = False,
    settings_permission: bool = False,
    settings_editing_settings: bool = False,
    settings_editing_self_branding: bool = False,
    settings_editing_environments: bool = False,
    settings_editing_agents: bool = False,
    views_permission: bool = False,
    connectors_permission: bool = False,
    connectors_editing_connectors: bool = False,
    webhooks_permission: bool = False,
    webhooks_editing_webhooks: bool = False,
    dashboards_permission: bool = False,
    dashboards_editing_dashboards: bool = False,
    search_permission: bool = False,
    search_view_case_search: bool = False,
    search_actions: bool = False,
    cases_permission: bool = False,
    cases_case_management_actions: bool = False,
    cases_case_playbooks_tab: bool = False,
    cases_attach_playbooks: bool = False,
    cases_respond_to_actions: bool = False,
    cases_rerun_playbooks: bool = False,
    cases_case_wall: bool = False,
    cases_adding_comments: bool = False,
    cases_pinning_chat_messages: bool = False,
    cases_case_simulation: bool = False,
    cases_ingest_alerts: bool = False,
    cases_manual_actions: bool = False,
    cases_creating_manual_cases: bool = False,
    cases_responding_to_case_actions: bool = False,
    cases_case_chat: bool = False,
    cases_adding_entity_properties: bool = False,
    entity_explorer_permission: bool = False,
    entity_explorer_adding_entity_comments: bool = False,
    entity_explorer_editing_entity_properties: bool = False,
    homepage_permission: bool = False,
    homepage_my_tasks: bool = False,
    homepage_create_tasks: bool = False,
    homepage_announcements: bool = False,
    homepage_create_announcements: bool = False,
    homepage_requests: bool = False,
    homepage_pending_actions: bool = False,
    homepage_workspace: bool = False,
    investigation_permission: bool = False,
    investigation_manual_actions: bool = False,
    investigation_editing_enities: bool = False,
    reports_permission: bool = False,
    reports_editing_reports: bool = False,
    reports_advanced_reports: bool = False,
    reports_editing_advanced_reports: bool = False,
    ontology_permission: bool = False,
    ontology_event_configuration: bool = False,
    ide_permission: bool = False,
    command_center_permission: bool = False,
    all_environments_permission: bool = False,
    sla_permission: bool = False,
    sla_pause_sla: bool = False,
    remote_agents_permission: bool = False,
    generate_user_auth_permission: bool = False,
) -> CreatedPermissionGroupResponse:
  """Creates a new permission group.

  !!! This functions is not intended to be used inside a test! Please use
    create_permission_group_for_test instead!

  Args:
    name: name of the permission group
    playbooks_permission: "Playbooks". Defaults to False.
    playbooks_editing_playbooks: "Allow editing playbook". Defaults to False.
    playbooks_managing_folders: "Allow managing folders. Defaults to False.
    marketplace_permisson: "Marketplace". Defaults to False.
    marketplace_allow_marketplace_actions: "Allow all Marketplace actions".
      Defaults to False.
    jobs_permission: "Jobs". Defaults to False.
    jobs_editing_jobs: "Allow editing Jobs". Defaults to False.
    settings_permission: "Settings". Defaults to False.
    settings_editing_settings: "Allow editing Settings". Defaults to False.
    settings_editing_self_branding: "Allow editing self branding".
      Defaults to False.
    settings_editing_environments: "Allow editing Environments".
      Defaults to False.
    settings_editing_agents: "Allow editing Agents". Defaults to False.
    views_permission: "Views". Defaults to False.
    connectors_permission: "Connectors". Defaults to False.
    connectors_editing_connectors: "Allow editing Connectors".
      Defaults to False.
    webhooks_permission: "Webhooks". Defaults to False.
    webhooks_editing_webhooks: "Allow editing Webhooks". Defaults to False.
    dashboards_permission: "Dashboards". Defaults to False.
    dashboards_editing_dashboards: "Allow editing Dashboards".
      Defaults to False.
    search_permission: "Search". Defaults to False.
    search_view_case_search: "View Case Search". Defaults to False.
    search_actions: "Allow Search actions". Defaults to False.
    cases_permission: "Cases". Defaults to False.
    cases_case_management_actions: "Allow Case Management actions".
      Defaults to False.
    cases_case_playbooks_tab: "View Case Playbooks tab". Defaults to False.
    cases_attach_playbooks: "Allow attach Playbooks manually".
      Defaults to False.
    cases_respond_to_actions: "Allow Respond to Actions". Defaults to False.
    cases_rerun_playbooks: "Allow rerun attached playbooks". Defaults to False.
    cases_case_wall: "View Case Wall tab". Defaults to False.
    cases_adding_comments: "Allow adding comments and attachments".
      Defaults to False.
    cases_pinning_chat_messages: "Allow pinning case chat messages to Case wall"
      Defaults to False.
    cases_case_simulation: "Allow case simulation". Defaults to False.
    cases_ingest_alerts: "Allow ingest alert as test case". Defaults to False.
    cases_manual_actions: "Allow performing Manual Actions". Defaults to False.
    cases_creating_manual_cases: "Allow creating Manual Cases".
      Defaults to False.
    cases_responding_to_case_actions: "Allow Respond to Actions". 
      Defaults to False.
    cases_case_chat: "Allow Case Chat". Defaults to False.
    cases_adding_entity_properties: "Allow adding/editing entity properties".
      Defaults to False.
    entity_explorer_permission: "Entity Explorer". Defaults to False.
    entity_explorer_adding_entity_comments: "Allow Adding comments".
      Defaults to False.
    entity_explorer_editing_entity_properties:
      "Allow adding/editing entity properties". Defaults to False.
    homepage_permission: "Homepage". Defaults to False.
    homepage_my_tasks: "My Tasks". Defaults to False.
    homepage_create_tasks: "Allow create/edit Tasks". Defaults to False.
    homepage_announcements: "Announcements". Defaults to False.
    homepage_create_announcements: "Allow create/edit Announcements".
      Defaults to False.
    homepage_requests: "Requests". Defaults to False.
    homepage_pending_actions: "Pending Actions". Defaults to False.
    homepage_workspace: "Workspace". Defaults to False.
    investigation_permission: "Investigation". Defaults to False.
    investigation_manual_actions: "Allow performing manual actions".
      Defaults to False.
    investigation_editing_enities: "Allow adding/editing entity properties".
      Defaults to False.
    reports_permission: "Reports". Defaults to False.
    reports_editing_reports: "Allow editing Reports". Defaults to False.
    reports_advanced_reports: "View Advanced Reports". Defaults to False.
    reports_editing_advanced_reports: "Allow editing Advanced reports".
      Defaults to False.
    ontology_permission: "Ontology". Defaults to False.
    ontology_event_configuration: "Allow Event configuration screen".
      Defaults to False.
    ide_permission: "IDE". Defaults to False.
    command_center_permission: "Command Center". Defaults to False.
    all_environments_permission: "All Environments". Defaults to False.
    sla_permission: "SLA". Defaults to False.
    sla_pause_sla: "Allow Pause/Resume SLA". Defaults to False.
    remote_agents_permission: "Remote Agents". Defaults to False.
    generate_user_auth_permission: "Generate user authorization".
      Defaults to False.

  Returns:
    A Response object
  """
  landing_page = 7
  landing_pages = {
      7: playbooks_permission,
      5: dashboards_permission,
      6: reports_permission,
      8: search_permission,
      9: command_center_permission,
  }
  for key, value in landing_pages.items():
    if value:
      landing_page = key
      break
  payload = {
      "id": 0,
      "name": name,
      "type": 0,
      "landingPage": landing_page,
      "permissionNodes": [
          {
              "displayName": "Playbooks",
              "isEnabled": playbooks_permission,
              "permissionIdentifier": "Playbooks",
              "nodes": [
                  {
                      "displayName": "Allow editing playbook",
                      "isEnabled": playbooks_editing_playbooks,
                      "permissionIdentifier": "Playbooks_PlaybooksActions",
                      "nodes": [
                          {
                              "displayName": "Allow managing folders",
                              "isEnabled": playbooks_managing_folders,
                              "permissionIdentifier":
                                  "Playbooks_PlaybooksActions_Manage",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Marketplace",
              "isEnabled": marketplace_permisson,
              "permissionIdentifier": "Marketplace",
              "nodes": [
                  {
                      "displayName": "Allow all Marketplace actions",
                      "isEnabled": marketplace_allow_marketplace_actions,
                      "permissionIdentifier": "Marketplace_MarketplaceActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Jobs",
              "isEnabled": jobs_permission,
              "permissionIdentifier": "Jobs",
              "nodes": [
                  {
                      "displayName": "Allow editing Jobs",
                      "isEnabled": jobs_editing_jobs,
                      "permissionIdentifier": "Jobs_JobsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Settings",
              "isEnabled": settings_permission,
              "permissionIdentifier": "Settings",
              "nodes": [
                  {
                      "displayName": "Allow editing Settings",
                      "isEnabled": settings_editing_settings,
                      "permissionIdentifier": "Settings_SettingsActions",
                      "nodes": [
                          {
                              "displayName": "Allow editing self branding",
                              "isEnabled": settings_editing_self_branding,
                              "permissionIdentifier":
                                  "Settings_SettingsActions_SelfBranding",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow editing Environments",
                              "isEnabled": settings_editing_environments,
                              "permissionIdentifier":
                                  "Settings_SettingsActions_Environments",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow editing Agents",
                              "isEnabled": settings_editing_agents,
                              "permissionIdentifier":
                                  "RemoteAgents_RemoteAgentsActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Views",
              "isEnabled": views_permission,
              "permissionIdentifier": "Views",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Connectors",
              "isEnabled": connectors_permission,
              "permissionIdentifier": "Connectors",
              "nodes": [
                  {
                      "displayName": "Allow editing Connectors",
                      "isEnabled": connectors_editing_connectors,
                      "permissionIdentifier": "Connectors_ConnectorsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Webhooks",
              "isEnabled": webhooks_permission,
              "permissionIdentifier": "Webhooks",
              "nodes": [
                  {
                      "displayName": "Allow editing Webhooks",
                      "isEnabled": webhooks_editing_webhooks,
                      "permissionIdentifier": "Webhooks_WebhooksActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Dashboards",
              "isEnabled": dashboards_permission,
              "permissionIdentifier": "Dashboards",
              "nodes": [
                  {
                      "displayName": "Allow editing Dashboards",
                      "isEnabled": dashboards_editing_dashboards,
                      "permissionIdentifier": "Dashboards_DashboardsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Search",
              "isEnabled": search_permission,
              "permissionIdentifier": "Search",
              "nodes": [
                  {
                      "displayName": "View Case Search",
                      "isEnabled": search_view_case_search,
                      "permissionIdentifier": "Search_CasesSearch",
                      "nodes": [
                          {
                              "displayName": "Allow Search actions",
                              "isEnabled": search_actions,
                              "permissionIdentifier":
                                  "Search_CasesSearch_SearchActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Cases",
              "isEnabled": cases_permission,
              "permissionIdentifier": "Cases",
              "nodes": [
                  {
                      "displayName": "Allow Case Management actions",
                      "isEnabled": cases_case_management_actions,
                      "permissionIdentifier": "Cases_CaseManagementActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "View Case Playbooks tab",
                      "isEnabled": cases_case_playbooks_tab,
                      "permissionIdentifier": "Cases_CasePlaybooks",
                      "nodes": [
                          {
                              "displayName": "Allow attach Playbooks manually",
                              "isEnabled": cases_attach_playbooks,
                              "permissionIdentifier":
                                  "Cases_CasePlaybooks_AttachPlaybooksManually",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow Respond to Actions",
                              "isEnabled": cases_responding_to_case_actions,
                              "permissionIdentifier":
                                  "Cases_CasePlaybooks_RespondToActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow rerun attached playbooks",
                              "isEnabled": cases_rerun_playbooks,
                              "permissionIdentifier":
                                  "Cases_CasePlaybooks_RerunPlaybooks",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "View Case Wall tab",
                      "isEnabled": cases_case_wall,
                      "permissionIdentifier": "Cases_CaseWall",
                      "nodes": [
                          {
                              "displayName":
                                  "Allow adding comments and attachments",
                              "isEnabled": cases_adding_comments,
                              "permissionIdentifier":
                                  "Cases_CaseWall_AddCaseCommentAndAttachment",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName":
                                  (
                                      "Allow pinning case chat messages"
                                      " to Case wall"
                                  ),
                              "isEnabled": cases_pinning_chat_messages,
                              "permissionIdentifier":
                                  "Cases_CaseWall_PinCaseChatMessages",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow case simulation",
                      "isEnabled": cases_case_simulation,
                      "permissionIdentifier": "Cases_CaseSimulation",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow ingest alert as test case",
                      "isEnabled": cases_ingest_alerts,
                      "permissionIdentifier": "Cases_AlertSimulation",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow performing Manual Actions",
                      "isEnabled": cases_manual_actions,
                      "permissionIdentifier": "Cases_ManualActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow creating Manual Cases",
                      "isEnabled": cases_creating_manual_cases,
                      "permissionIdentifier": "Cases_ManualCases",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow Respond to Actions",
                      "isEnabled": cases_respond_to_actions,
                      "permissionIdentifier": "Cases_RespondToActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow Case Chat",
                      "isEnabled": cases_case_chat,
                      "permissionIdentifier": "Cases_CaseChat",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow adding/editing entity properties",
                      "isEnabled": cases_adding_entity_properties,
                      "permissionIdentifier": "Cases_EntityPropertiesActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Entity Explorer",
              "isEnabled": entity_explorer_permission,
              "permissionIdentifier": "EntityExplorer",
              "nodes": [
                  {
                      "displayName": "Allow Adding comments",
                      "isEnabled": entity_explorer_adding_entity_comments,
                      "permissionIdentifier":
                          "EntityExplorer_EntityExplorerAction",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow adding/editing entity properties",
                      "isEnabled": entity_explorer_editing_entity_properties,
                      "permissionIdentifier":
                          "EntityExplorer_EntityPropertiesActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Homepage",
              "isEnabled": homepage_permission,
              "permissionIdentifier": "Homepage",
              "nodes": [
                  {
                      "displayName": "My Tasks",
                      "isEnabled": homepage_my_tasks,
                      "permissionIdentifier": "Homepage_MyTasks",
                      "nodes": [
                          {
                              "displayName": "Allow create/edit Tasks",
                              "isEnabled": homepage_create_tasks,
                              "permissionIdentifier":
                                  "Homepage_MyTasks_TasksActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Announcements",
                      "isEnabled": homepage_announcements,
                      "permissionIdentifier": "Homepage_Announcements",
                      "nodes": [
                          {
                              "displayName": "Allow create/edit Announcements",
                              "isEnabled": homepage_create_announcements,
                              "permissionIdentifier":
                                  "Homepage_Announcements_AnnouncementsActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Requests",
                      "isEnabled": homepage_requests,
                      "permissionIdentifier": "Homepage_Requests",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Pending Actions",
                      "isEnabled": homepage_pending_actions,
                      "permissionIdentifier": "Homepage_PendingActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Workspace",
                      "isEnabled": homepage_workspace,
                      "permissionIdentifier": "Homepage_Workspace",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Investigation",
              "isEnabled": investigation_permission,
              "permissionIdentifier": "Investigation",
              "nodes": [
                  {
                      "displayName": "Allow performing manual actions",
                      "isEnabled": investigation_manual_actions,
                      "permissionIdentifier":
                          "Investigation_InvestigationActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow adding/editing entity properties",
                      "isEnabled": investigation_editing_enities,
                      "permissionIdentifier":
                          "Investigation_EntityPropertiesActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Reports",
              "isEnabled": reports_permission,
              "permissionIdentifier": "Reports",
              "nodes": [
                  {
                      "displayName": "Allow editing Reports",
                      "isEnabled": reports_editing_reports,
                      "permissionIdentifier": "Reports_ReportsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "View Advanced Reports",
                      "isEnabled": reports_advanced_reports,
                      "permissionIdentifier": "Reports_AdvancedReports",
                      "nodes": [
                          {
                              "displayName": "Allow editing Advanced reports",
                              "isEnabled": reports_editing_advanced_reports,
                              "permissionIdentifier": (
                                  "Reports_AdvancedReports_"
                                  "AdvancedReportsActions"
                              ),
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Ontology",
              "isEnabled": ontology_permission,
              "permissionIdentifier": "Ontology",
              "nodes": [
                  {
                      "displayName": "Allow Event configuration screen",
                      "isEnabled": ontology_event_configuration,
                      "permissionIdentifier": "Ontology_OntologyActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "IDE",
              "isEnabled": ide_permission,
              "permissionIdentifier": "Ide",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Command Center",
              "isEnabled": command_center_permission,
              "permissionIdentifier": "CommandCenter",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "All Environments",
              "isEnabled": all_environments_permission,
              "permissionIdentifier": "AllEnvironments",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "SLA",
              "isEnabled": sla_permission,
              "permissionIdentifier": "Sla",
              "nodes": [
                  {
                      "displayName": "Allow Pause/Resume SLA",
                      "isEnabled": sla_pause_sla,
                      "permissionIdentifier": "Sla_SlaActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Remote Agents",
              "isEnabled": remote_agents_permission,
              "permissionIdentifier": "RemoteAgents",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Generate user authorization",
              "isEnabled": generate_user_auth_permission,
              "permissionIdentifier": "Settings_GenerateUserAuthorization",
              "nodes": [],
              "shouldPresentWarning": False
          }
      ],
      "permissionsGroupAdMapping": [],
      "permissionsGroupRestrictionIds": [],
      "isSystemGroup": False,
      "isReadOnly": False
  }
  response = post_with_admin_credentials(
      url=API_CREATE_PERMISSION_GROUP_ENDPOINT,
      payload=payload,
  )
  return CreatedPermissionGroupResponse(response=response)


def create_permission_group_for_test(
    test_name: Optional[str] = None,
    playbooks_permission: bool = False,
    playbooks_editing_playbooks: bool = False,
    playbooks_managing_folders: bool = False,
    marketplace_permisson: bool = False,
    marketplace_allow_marketplace_actions: bool = False,
    jobs_permission: bool = False,
    jobs_editing_jobs: bool = False,
    settings_permission: bool = False,
    settings_editing_settings: bool = False,
    settings_editing_self_branding: bool = False,
    settings_editing_environments: bool = False,
    settings_editing_agents: bool = False,
    views_permission: bool = False,
    connectors_permission: bool = False,
    connectors_editing_connectors: bool = False,
    webhooks_permission: bool = False,
    webhooks_editing_webhooks: bool = False,
    dashboards_permission: bool = False,
    dashboards_editing_dashboards: bool = False,
    search_permission: bool = False,
    search_view_case_search: bool = False,
    search_actions: bool = False,
    cases_permission: bool = False,
    cases_case_management_actions: bool = False,
    cases_case_playbooks_tab: bool = False,
    cases_attach_playbooks: bool = False,
    cases_respond_to_actions: bool = False,
    cases_rerun_playbooks: bool = False,
    cases_case_wall: bool = False,
    cases_adding_comments: bool = False,
    cases_pinning_chat_messages: bool = False,
    cases_case_simulation: bool = False,
    cases_ingest_alerts: bool = False,
    cases_manual_actions: bool = False,
    cases_creating_manual_cases: bool = False,
    cases_responding_to_case_actions: bool = False,
    cases_case_chat: bool = False,
    cases_adding_entity_properties: bool = False,
    entity_explorer_permission: bool = False,
    entity_explorer_adding_entity_comments: bool = False,
    entity_explorer_editing_entity_properties: bool = False,
    homepage_permission: bool = False,
    homepage_my_tasks: bool = False,
    homepage_create_tasks: bool = False,
    homepage_announcements: bool = False,
    homepage_create_announcements: bool = False,
    homepage_requests: bool = False,
    homepage_pending_actions: bool = False,
    homepage_workspace: bool = False,
    investigation_permission: bool = False,
    investigation_manual_actions: bool = False,
    investigation_editing_enities: bool = False,
    reports_permission: bool = False,
    reports_editing_reports: bool = False,
    reports_advanced_reports: bool = False,
    reports_editing_advanced_reports: bool = False,
    ontology_permission: bool = False,
    ontology_event_configuration: bool = False,
    ide_permission: bool = False,
    command_center_permission: bool = False,
    all_environments_permission: bool = False,
    sla_permission: bool = False,
    sla_pause_sla: bool = False,
    remote_agents_permission: bool = False,
    generate_user_auth_permission: bool = False,
) -> Response:
  """Creates a new permission group.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    test_name: name of the test (Defaults to None)
    playbooks_permission: "Playbooks". Defaults to False.
    playbooks_editing_playbooks: "Allow editing playbook". Defaults to False.
    playbooks_managing_folders: "Allow managing folders. Defaults to False.
    marketplace_permisson: "Marketplace". Defaults to False.
    marketplace_allow_marketplace_actions: "Allow all Marketplace actions".
      Defaults to False.
    jobs_permission: "Jobs". Defaults to False.
    jobs_editing_jobs: "Allow editing Jobs". Defaults to False.
    settings_permission: "Settings". Defaults to False.
    settings_editing_settings: "Allow editing Settings". Defaults to False.
    settings_editing_self_branding: "Allow editing self branding".
      Defaults to False.
    settings_editing_environments: "Allow editing Environments".
      Defaults to False.
    settings_editing_agents: "Allow editing Agents". Defaults to False.
    views_permission: "Views". Defaults to False.
    connectors_permission: "Connectors". Defaults to False.
    connectors_editing_connectors: "Allow editing Connectors".
      Defaults to False.
    webhooks_permission: "Webhooks". Defaults to False.
    webhooks_editing_webhooks: "Allow editing Webhooks". Defaults to False.
    dashboards_permission: "Dashboards". Defaults to False.
    dashboards_editing_dashboards: "Allow editing Dashboards".
      Defaults to False.
    search_permission: "Search". Defaults to False.
    search_view_case_search: "View Case Search". Defaults to False.
    search_actions: "Allow Search actions". Defaults to False.
    cases_permission: "Cases". Defaults to False.
    cases_case_management_actions: "Allow Case Management actions".
      Defaults to False.
    cases_case_playbooks_tab: "View Case Playbooks tab". Defaults to False.
    cases_attach_playbooks: "Allow attach Playbooks manually".
      Defaults to False.
    cases_respond_to_actions: "Allow Respond to Actions". Defaults to False.
    cases_rerun_playbooks: "Allow rerun attached playbooks". Defaults to False.
    cases_case_wall: "View Case Wall tab". Defaults to False.
    cases_adding_comments: "Allow adding comments and attachments".
      Defaults to False.
    cases_pinning_chat_messages: "Allow pinning case chat messages to Case wall"
      Defaults to False.
    cases_case_simulation: "Allow case simulation". Defaults to False.
    cases_ingest_alerts: "Allow ingest alert as test case". Defaults to False.
    cases_manual_actions: "Allow performing Manual Actions". Defaults to False.
    cases_creating_manual_cases: "Allow creating Manual Cases".
      Defaults to False.
    cases_responding_to_case_actions: "Allow Respond to Actions". 
      Defaults to False.
    cases_case_chat: "Allow Case Chat". Defaults to False.
    cases_adding_entity_properties: "Allow adding/editing entity properties".
      Defaults to False.
    entity_explorer_permission: "Entity Explorer". Defaults to False.
    entity_explorer_adding_entity_comments: "Allow Adding comments".
      Defaults to False.
    entity_explorer_editing_entity_properties:
      "Allow adding/editing entity properties". Defaults to False.
    homepage_permission: "Homepage". Defaults to False.
    homepage_my_tasks: "My Tasks". Defaults to False.
    homepage_create_tasks: "Allow create/edit Tasks". Defaults to False.
    homepage_announcements: "Announcements". Defaults to False.
    homepage_create_announcements: "Allow create/edit Announcements".
      Defaults to False.
    homepage_requests: "Requests". Defaults to False.
    homepage_pending_actions: "Pending Actions". Defaults to False.
    homepage_workspace: "Workspace". Defaults to False.
    investigation_permission: "Investigation". Defaults to False.
    investigation_manual_actions: "Allow performing manual actions".
      Defaults to False.
    investigation_editing_enities: "Allow adding/editing entity properties".
      Defaults to False.
    reports_permission: "Reports". Defaults to False.
    reports_editing_reports: "Allow editing Reports". Defaults to False.
    reports_advanced_reports: "View Advanced Reports". Defaults to False.
    reports_editing_advanced_reports: "Allow editing Advanced reports".
      Defaults to False.
    ontology_permission: "Ontology". Defaults to False.
    ontology_event_configuration: "Allow Event configuration screen".
      Defaults to False.
    ide_permission: "IDE". Defaults to False.
    command_center_permission: "Command Center". Defaults to False.
    all_environments_permission: "All Environments". Defaults to False.
    sla_permission: "SLA". Defaults to False.
    sla_pause_sla: "Allow Pause/Resume SLA". Defaults to False.
    remote_agents_permission: "Remote Agents". Defaults to False.
    generate_user_auth_permission: "Generate user authorization".
      Defaults to False.

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  name = siemplify.utils.generate_random_name(start="Group_")
  landing_page = 7
  landing_pages = {
      7: playbooks_permission,
      5: dashboards_permission,
      6: reports_permission,
      8: search_permission,
      9: command_center_permission,
  }
  for key, value in landing_pages.items():
    if value:
      landing_page = key
      break
  payload = {
      "id": 0,
      "name": name,
      "type": 0,
      "landingPage": landing_page,
      "permissionNodes": [
          {
              "displayName": "Playbooks",
              "isEnabled": playbooks_permission,
              "permissionIdentifier": "Playbooks",
              "nodes": [
                  {
                      "displayName": "Allow editing playbook",
                      "isEnabled": playbooks_editing_playbooks,
                      "permissionIdentifier": "Playbooks_PlaybooksActions",
                      "nodes": [
                          {
                              "displayName": "Allow managing folders",
                              "isEnabled": playbooks_managing_folders,
                              "permissionIdentifier":
                                  "Playbooks_PlaybooksActions_Manage",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Marketplace",
              "isEnabled": marketplace_permisson,
              "permissionIdentifier": "Marketplace",
              "nodes": [
                  {
                      "displayName": "Allow all Marketplace actions",
                      "isEnabled": marketplace_allow_marketplace_actions,
                      "permissionIdentifier": "Marketplace_MarketplaceActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Jobs",
              "isEnabled": jobs_permission,
              "permissionIdentifier": "Jobs",
              "nodes": [
                  {
                      "displayName": "Allow editing Jobs",
                      "isEnabled": jobs_editing_jobs,
                      "permissionIdentifier": "Jobs_JobsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Settings",
              "isEnabled": settings_permission,
              "permissionIdentifier": "Settings",
              "nodes": [
                  {
                      "displayName": "Allow editing Settings",
                      "isEnabled": settings_editing_settings,
                      "permissionIdentifier": "Settings_SettingsActions",
                      "nodes": [
                          {
                              "displayName": "Allow editing self branding",
                              "isEnabled": settings_editing_self_branding,
                              "permissionIdentifier":
                                  "Settings_SettingsActions_SelfBranding",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow editing Environments",
                              "isEnabled": settings_editing_environments,
                              "permissionIdentifier":
                                  "Settings_SettingsActions_Environments",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow editing Agents",
                              "isEnabled": settings_editing_agents,
                              "permissionIdentifier":
                                  "RemoteAgents_RemoteAgentsActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Views",
              "isEnabled": views_permission,
              "permissionIdentifier": "Views",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Connectors",
              "isEnabled": connectors_permission,
              "permissionIdentifier": "Connectors",
              "nodes": [
                  {
                      "displayName": "Allow editing Connectors",
                      "isEnabled": connectors_editing_connectors,
                      "permissionIdentifier": "Connectors_ConnectorsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Webhooks",
              "isEnabled": webhooks_permission,
              "permissionIdentifier": "Webhooks",
              "nodes": [
                  {
                      "displayName": "Allow editing Webhooks",
                      "isEnabled": webhooks_editing_webhooks,
                      "permissionIdentifier": "Webhooks_WebhooksActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Dashboards",
              "isEnabled": dashboards_permission,
              "permissionIdentifier": "Dashboards",
              "nodes": [
                  {
                      "displayName": "Allow editing Dashboards",
                      "isEnabled": dashboards_editing_dashboards,
                      "permissionIdentifier": "Dashboards_DashboardsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Search",
              "isEnabled": search_permission,
              "permissionIdentifier": "Search",
              "nodes": [
                  {
                      "displayName": "View Case Search",
                      "isEnabled": search_view_case_search,
                      "permissionIdentifier": "Search_CasesSearch",
                      "nodes": [
                          {
                              "displayName": "Allow Search actions",
                              "isEnabled": search_actions,
                              "permissionIdentifier":
                                  "Search_CasesSearch_SearchActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Cases",
              "isEnabled": cases_permission,
              "permissionIdentifier": "Cases",
              "nodes": [
                  {
                      "displayName": "Allow Case Management actions",
                      "isEnabled": cases_case_management_actions,
                      "permissionIdentifier": "Cases_CaseManagementActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "View Case Playbooks tab",
                      "isEnabled": cases_case_playbooks_tab,
                      "permissionIdentifier": "Cases_CasePlaybooks",
                      "nodes": [
                          {
                              "displayName": "Allow attach Playbooks manually",
                              "isEnabled": cases_attach_playbooks,
                              "permissionIdentifier":
                                  "Cases_CasePlaybooks_AttachPlaybooksManually",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow Respond to Actions",
                              "isEnabled": cases_responding_to_case_actions,
                              "permissionIdentifier":
                                  "Cases_CasePlaybooks_RespondToActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName": "Allow rerun attached playbooks",
                              "isEnabled": cases_rerun_playbooks,
                              "permissionIdentifier":
                                  "Cases_CasePlaybooks_RerunPlaybooks",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "View Case Wall tab",
                      "isEnabled": cases_case_wall,
                      "permissionIdentifier": "Cases_CaseWall",
                      "nodes": [
                          {
                              "displayName":
                                  "Allow adding comments and attachments",
                              "isEnabled": cases_adding_comments,
                              "permissionIdentifier":
                                  "Cases_CaseWall_AddCaseCommentAndAttachment",
                              "nodes": [],
                              "shouldPresentWarning": False
                          },
                          {
                              "displayName":
                                  (
                                      "Allow pinning case chat messages"
                                      " to Case wall"
                                  ),
                              "isEnabled": cases_pinning_chat_messages,
                              "permissionIdentifier":
                                  "Cases_CaseWall_PinCaseChatMessages",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow case simulation",
                      "isEnabled": cases_case_simulation,
                      "permissionIdentifier": "Cases_CaseSimulation",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow ingest alert as test case",
                      "isEnabled": cases_ingest_alerts,
                      "permissionIdentifier": "Cases_AlertSimulation",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow performing Manual Actions",
                      "isEnabled": cases_manual_actions,
                      "permissionIdentifier": "Cases_ManualActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow creating Manual Cases",
                      "isEnabled": cases_creating_manual_cases,
                      "permissionIdentifier": "Cases_ManualCases",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow Respond to Actions",
                      "isEnabled": cases_respond_to_actions,
                      "permissionIdentifier": "Cases_RespondToActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow Case Chat",
                      "isEnabled": cases_case_chat,
                      "permissionIdentifier": "Cases_CaseChat",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow adding/editing entity properties",
                      "isEnabled": cases_adding_entity_properties,
                      "permissionIdentifier": "Cases_EntityPropertiesActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Entity Explorer",
              "isEnabled": entity_explorer_permission,
              "permissionIdentifier": "EntityExplorer",
              "nodes": [
                  {
                      "displayName": "Allow Adding comments",
                      "isEnabled": entity_explorer_adding_entity_comments,
                      "permissionIdentifier":
                          "EntityExplorer_EntityExplorerAction",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow adding/editing entity properties",
                      "isEnabled": entity_explorer_editing_entity_properties,
                      "permissionIdentifier":
                          "EntityExplorer_EntityPropertiesActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Homepage",
              "isEnabled": homepage_permission,
              "permissionIdentifier": "Homepage",
              "nodes": [
                  {
                      "displayName": "My Tasks",
                      "isEnabled": homepage_my_tasks,
                      "permissionIdentifier": "Homepage_MyTasks",
                      "nodes": [
                          {
                              "displayName": "Allow create/edit Tasks",
                              "isEnabled": homepage_create_tasks,
                              "permissionIdentifier":
                                  "Homepage_MyTasks_TasksActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Announcements",
                      "isEnabled": homepage_announcements,
                      "permissionIdentifier": "Homepage_Announcements",
                      "nodes": [
                          {
                              "displayName": "Allow create/edit Announcements",
                              "isEnabled": homepage_create_announcements,
                              "permissionIdentifier":
                                  "Homepage_Announcements_AnnouncementsActions",
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Requests",
                      "isEnabled": homepage_requests,
                      "permissionIdentifier": "Homepage_Requests",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Pending Actions",
                      "isEnabled": homepage_pending_actions,
                      "permissionIdentifier": "Homepage_PendingActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Workspace",
                      "isEnabled": homepage_workspace,
                      "permissionIdentifier": "Homepage_Workspace",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Investigation",
              "isEnabled": investigation_permission,
              "permissionIdentifier": "Investigation",
              "nodes": [
                  {
                      "displayName": "Allow performing manual actions",
                      "isEnabled": investigation_manual_actions,
                      "permissionIdentifier":
                          "Investigation_InvestigationActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "Allow adding/editing entity properties",
                      "isEnabled": investigation_editing_enities,
                      "permissionIdentifier":
                          "Investigation_EntityPropertiesActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Reports",
              "isEnabled": reports_permission,
              "permissionIdentifier": "Reports",
              "nodes": [
                  {
                      "displayName": "Allow editing Reports",
                      "isEnabled": reports_editing_reports,
                      "permissionIdentifier": "Reports_ReportsActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  },
                  {
                      "displayName": "View Advanced Reports",
                      "isEnabled": reports_advanced_reports,
                      "permissionIdentifier": "Reports_AdvancedReports",
                      "nodes": [
                          {
                              "displayName": "Allow editing Advanced reports",
                              "isEnabled": reports_editing_advanced_reports,
                              "permissionIdentifier": (
                                  "Reports_AdvancedReports_"
                                  "AdvancedReportsActions"
                              ),
                              "nodes": [],
                              "shouldPresentWarning": False
                          }
                      ],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Ontology",
              "isEnabled": ontology_permission,
              "permissionIdentifier": "Ontology",
              "nodes": [
                  {
                      "displayName": "Allow Event configuration screen",
                      "isEnabled": ontology_event_configuration,
                      "permissionIdentifier": "Ontology_OntologyActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "IDE",
              "isEnabled": ide_permission,
              "permissionIdentifier": "Ide",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Command Center",
              "isEnabled": command_center_permission,
              "permissionIdentifier": "CommandCenter",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "All Environments",
              "isEnabled": all_environments_permission,
              "permissionIdentifier": "AllEnvironments",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "SLA",
              "isEnabled": sla_permission,
              "permissionIdentifier": "Sla",
              "nodes": [
                  {
                      "displayName": "Allow Pause/Resume SLA",
                      "isEnabled": sla_pause_sla,
                      "permissionIdentifier": "Sla_SlaActions",
                      "nodes": [],
                      "shouldPresentWarning": False
                  }
              ],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Remote Agents",
              "isEnabled": remote_agents_permission,
              "permissionIdentifier": "RemoteAgents",
              "nodes": [],
              "shouldPresentWarning": False
          },
          {
              "displayName": "Generate user authorization",
              "isEnabled": generate_user_auth_permission,
              "permissionIdentifier": "Settings_GenerateUserAuthorization",
              "nodes": [],
              "shouldPresentWarning": False
          }
      ],
      "permissionsGroupAdMapping": [],
      "permissionsGroupRestrictionIds": [],
      "isSystemGroup": False,
      "isReadOnly": False
  }
  response = post_with_admin_credentials(
      url=API_CREATE_PERMISSION_GROUP_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  logged_response = log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Successfully created permission group {name} for {test_name}"
      ),
      failure_message=f"Failed to create a permission group for {test_name}",
  )
  return CreatedPermissionGroupResponse(response=logged_response)


def delete_permission_group(
    group_id: int,
    test_name: Optional[str] = None
) -> Response:
  """Deletes a permission group.

  Args:
    group_id: ID number of the permission group to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = delete_with_admin_credentials(
      url=API_DELETE_PERMISSION_GROUP_ENDPOINT.format(group_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted permission grpup #{group_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to delete permission group #{group_id} for {test_name}"
        ),
    )
  return response


def get_permission_groups(test_name: Optional[str] = None) -> Response:
  """Fetches all permission groups.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_PERMISSION_GROUPS_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched permission groups for {test_name}"
        ),
        failure_message=f"Failed to fetch permission groups for {test_name}",
    )
  return response


def delete_all_custom_permission_groups():
  """Deletes all non-default permission groups.
  """
  default_names = ("Admins", "Readers", "Basic", "View-Only", "Collaborators",
                   "Managed User", "Managed-Plus User")
  resp = get_permission_groups()
  groups_json = resp.json()
  for group in groups_json:
    if group["name"] not in default_names:
      delete_permission_group(group_id=group["id"])


def get_test_user_data(test_name: Optional[str] = None) -> CurrentTestUser:
  """Returns current test user data from json file.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    test_name: name of the test

  Returns:
    A CurrentTestUser object with user data
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  user_data = {
      "email": data.get("email"),
      "password": data.get("password"),
      "username": data.get("username"),
      "permission_group_id": data.get("permission_group_id")
  }
  return CurrentTestUser(data=user_data)


def get_admin_user_data() -> CurrentTestUser:
  """Returns current test user data from json file.

  Returns:
    A CurrentTestUser object with user data
  """
  path = os.path.join(AUTH_PATH)
  with open(path, "r") as file:
    data = json.load(file)
  user_data = {
      "email": data.get("email"),
      "username": data.get("username"),
  }
  return CurrentAdminUser(data=user_data)
