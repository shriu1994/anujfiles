"""Module containing actions to manipulate reports in siemplify client.
"""
import os
from typing import Optional
# Endpoints
from endpoints.reports import API_GENERATE_REPORT_ENDPOINT
from endpoints.reports import API_GET_REPORT_TEMPLATES_ENDPOINT
from logger.html_logger import log_event
# PDF reader
from PyPDF2 import PdfReader
# Requests
from requests import Response
# Siemplify modules
from siemplify_utils import siemplify
# Source
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


REPORTS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reports"
)


def create_open_cases_report(
    file_name: str = "open_cases_report",
    environment: Optional[str] = None,
    days: int = 1,
    test_name: Optional[str] = None,
) -> Response:
  """Creates an OOTB report "Tier-1 Open Cases" and saves it to PDF.

  Available amount of days for the report: 1, 3, 7, 14, 30, 90, 180, 365

  Args:
    file_name: name of pdf file to create in /reports
    environment: name of the environment
    days: amount of days for the report
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environment:
    environment = test_name
  payload = siemplify.payloads.reports.fetch_open_cases_report_payload(
      environment=environment,
      days=days,
  )
  response = post_with_admin_credentials(
      url=API_GENERATE_REPORT_ENDPOINT,
      payload=payload,
  )
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  with open(file_path, "wb") as f:
    f.write(response.content)

  return response


def create_c_level_report(
    file_name: str = "c_level_report",
    environment: Optional[str] = None,
    days: int = 1,
    test_name: Optional[str] = None,
) -> Response:
  """Creates an OOTB report "C-Level overview" and saves it to PDF.

  Available amount of days for the report: 1, 3, 7, 14, 30, 90, 180, 365
  Args:
    file_name: name of pdf file to create in /reports
    environment: name of the environment
    days: amount of days for the report
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environment:
    environment = test_name
  payload = siemplify.payloads.reports.fetch_c_level_overview_report_payload(
      environment=environment,
      days=days,
  )
  response = post_with_admin_credentials(
      url=API_GENERATE_REPORT_ENDPOINT,
      payload=payload,
  )
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  with open(file_path, "wb") as f:
    f.write(response.content)

  return response


def create_stages_report(
    file_name: str = "stages_report",
    environment: Optional[str] = None,
    days: int = 1,
    test_name: Optional[str] = None,
) -> Response:
  """Creates an OOTB report "Stages report" and saves it to PDF.

  Available amount of days for the report: 1, 3, 7, 14, 30, 90, 180, 365
  Args:
    file_name: name of pdf file to create in /reports
    environment: name of the environment
    days: amount of days for the report
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environment:
    environment = test_name
  payload = siemplify.payloads.reports.fetch_stages_report_payload(
      environment=environment,
      days=days,
  )
  response = post_with_admin_credentials(
      url=API_GENERATE_REPORT_ENDPOINT,
      payload=payload,
  )
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  with open(file_path, "wb") as f:
    f.write(response.content)

  return response


def create_soc_status_report(
    file_name: str = "soc_status_report",
    environment: Optional[str] = None,
    days: int = 1,
    test_name: Optional[str] = None,
) -> Response:
  """Creates an OOTB report "Soc status" and saves it to PDF.

  Available amount of days for the report: 1, 3, 7, 14, 30, 90, 180, 365
  Args:
    file_name: name of pdf file to create in /reports
    environment: name of the environment
    days: amount of days for the report
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environment:
    environment = test_name
  payload = siemplify.payloads.reports.fetch_soc_status_report_payload(
      environment=environment,
      days=days,
  )
  response = post_with_admin_credentials(
      url=API_GENERATE_REPORT_ENDPOINT,
      payload=payload,
  )
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  with open(file_path, "wb") as f:
    f.write(response.content)

  return response


def create_overall_status_report(
    file_name: str = "overall_status_report",
    environment: Optional[str] = None,
    days: int = 1,
    test_name: Optional[str] = None,
) -> Response:
  """Creates an OOTB report "Overall Status" and saves it to PDF.

  Available amount of days for the report: 1, 3, 7, 14, 30, 90, 180, 365
  Args:
    file_name: name of pdf file to create in /reports
    environment: name of the environment
    days: amount of days for the report
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environment:
    environment = test_name
  payload = siemplify.payloads.reports.fetch_overall_status_report_payload(
      environment=environment,
      days=days,
  )
  response = post_with_admin_credentials(
      url=API_GENERATE_REPORT_ENDPOINT,
      payload=payload,
  )
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  with open(file_path, "wb") as f:
    f.write(response.content)

  return response


def create_analysts_benchmark_report(
    file_name: str = "analysts_benchmark_report",
    environment: Optional[str] = None,
    days: int = 1,
    test_name: Optional[str] = None,
) -> Response:
  """Creates an OOTB report "Analysts Benchmark" and saves it to PDF.

  Available amount of days for the report: 1, 3, 7, 14, 30, 90, 180, 365
  Args:
    file_name: name of pdf file to create in /reports
    environment: name of the environment
    days: amount of days for the report
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environment:
    environment = test_name
  payload = siemplify.payloads.reports.fetch_analysts_benchmark_report_payload(
      environment=environment,
      days=days,
  )
  response = post_with_admin_credentials(
      url=API_GENERATE_REPORT_ENDPOINT,
      payload=payload,
  )
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  with open(file_path, "wb") as f:
    f.write(response.content)

  return response


def create_closed_cases_report(
    file_name: str = "closed_cases_report",
    environment: Optional[str] = None,
    days: int = 1,
    test_name: Optional[str] = None,
) -> Response:
  """Creates an OOTB report "Closed Cases" and saves it to PDF.

  Available amount of days for the report: 1, 3, 7, 14, 30, 90, 180, 365
  Args:
    file_name: name of pdf file to create in /reports
    environment: name of the environment
    days: amount of days for the report
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environment:
    environment = test_name
  payload = siemplify.payloads.reports.fetch_closed_cases_report_payload(
      environment=environment,
      days=days,
  )
  response = post_with_admin_credentials(
      url=API_GENERATE_REPORT_ENDPOINT,
      payload=payload,
  )
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  with open(file_path, "wb") as f:
    f.write(response.content)

  return response


def get_report_templates(test_name: Optional[str] = None) -> Response:
  """Fetches a list of all report templates.

  Args:
    test_name: name of the test (Defaults to None)
  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_REPORT_TEMPLATES_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched report templates for {test_name}"
        ),
        failure_message=f"Failed to fetch report templates for {test_name}",
    )
  return response


def check_if_report_exists(file_name: str) -> bool:
  """Checks if report with a specified name exists in /reports and is not empty.

  Args:
    file_name: name of the report to check
  Returns:
    True if report exists and isn't empty, False if not
  """
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  reader = PdfReader(file_path)
  for page in reader.pages:
    text = page.extract_text()
    if text:
      return True

  return False


def delete_report(file_name: str) -> bool:
  """Deletes a report with specified name from /reports.

  Args:
    file_name: name of the report to delete
  Returns:
    True if report was deleted
  """
  if not file_name.endswith(".pdf"):
    file_name = f"{file_name}.pdf"
  file_path = os.path.join(REPORTS_PATH, file_name)
  if os.path.exists(file_path):
    os.remove(file_path)
    return True
  else:
    log_event(
        message="Could not delete the report!",
        details=f"Report name: {file_name}",
        success=False,
    )
    raise ValueError(f"Report with name '{file_name}' doesn't exist")


def delete_all_reports():
  """Deletes all reports in /reports folder.
  """
  for filename in os.listdir(REPORTS_PATH):
    if filename.endswith(".pdf"):
      file_path = os.path.join(REPORTS_PATH, filename)
      os.remove(file_path)
