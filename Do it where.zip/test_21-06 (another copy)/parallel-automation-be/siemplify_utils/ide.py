"""Module containing IDE to manipulate actions in siemplify client.
"""
import base64
from typing import Optional, Union
# Endpoints
from endpoints.ide import API_ADD_UPDATE_ITEM_ENDPOINT
from endpoints.ide import API_DELETE_ITEM_ENDPOINT
from endpoints.ide import API_EXPORT_INTEGRATION_ENDPOINT
from endpoints.ide import API_GET_ITEM_DATA_ENDPOINT
from endpoints.ide import API_GET_ITEMS_ENDPOINT
from endpoints.ide import API_IMPORT_INTEGRATION_ENDPOINT
from endpoints.ide import API_IMPORT_ITEM_ENDPOINT
from endpoints.ide import API_RUN_TEST_ITEM_ENDPOINT
# Requests
from requests import Response
# Resources
from resources.strings.strings import DEFAULT_CUSTOM_ACTION_SCRIPT
# Siemplify modules
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


# Classes for data models
class RunIdeItemResponse:
  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.debug_output = self.response_json.get("debugOutput")
    self.output = self.response_json.get("output")
    self.result_name = self.response_json.get("resultName")
    self.result_object_json = self.response_json.get("resultObjectJson")
    self.result_value = self.response_json.get("resultValue")


class ExportIDEIntegrationResponse:
  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = {}
    self.package_zip = response.content


class ImportIDEIntegrationResponse:
  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.is_successful = self.response_json.get("isSuccessful")
    self.error = self.response_json.get("error")
    self.failed_dependencies = self.response_json.get("failedDependencies")


class IdeItemResponse:
  """Class to represent manual action details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.id = self.response_json.get("id")
    self.name = self.response_json.get("name")
    self.script = self.response_json.get("script")
    self.parameters = self.response_json.get("parameters")
    self.creator = self.response_json.get("creator")
    self.creator_full_name = self.response_json.get("creatorFullName")


def run_item_test_ide(
    integration_name: str,
    creator: str,
    integration_instance: str,
    item_id: int,
    item_name: str,
    creator_name: str,
    script: str,
    parameters: list[dict[str]],
    test_scope: str,
    item_type: int,
    action_case_id: Optional[int] = None,
    test_name: Optional[str] = None,
) -> RunIdeItemResponse:
  """Run test on IDE item.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    integration_name: name of the integration
    creator: creator of the ide item
    integration_instance: instance id
    item_id: ide item id
    item_name: ide item name
    creator_name: creator name of the ide item
    script: ide item script
    parameters: ide item parameters
    test_scope: scope of the test
    item_type: ide item type
    action_case_id: id of the case. Defaults to None.
    test_name: name of the test (Defaults to None)

  Returns:
    RunIdeItemResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "agentIdentifier": None,
      "actionTestCaseId": action_case_id,
      "actionTestScope": test_scope,
      "integrationInstanceId": integration_instance,
      "ideItem": {
          "id": item_id,
          "type": item_type,
          "name": item_name,
          "description": "Test description",
          "script": script,
          "integration": integration_name,
          "creator": creator,
          "creatorFullName": creator_name,
          "isEnabled": True,
          "isCustom": True,
          "version": 2,
          "parameters": parameters,
          "connectorRules": None,
          "isConnectorRulesSupported": False,
          "documentationLink": None,
          "pythonVersion": "V3_7",
          "clientId": "1497_1_tCjhK_AJevg",
          "pythonVersionRep": "V3.7"
      }
  }
  response = post_with_admin_credentials(
      url=API_RUN_TEST_ITEM_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Ran IDE item test for {test_name}",
      failure_message=f"Failed to run IDE item test for {test_name}",
  )
  return RunIdeItemResponse(response=response)


def export_ide_integration(
    integration_name: str,
    test_name: Optional[str] = None,
) -> ExportIDEIntegrationResponse:
  """Exports and IDE integration.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    integration_name: name of the integration
    test_name: name of the test (Defaults to None)

  Returns:
    ExportIDEIntegrationResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_EXPORT_INTEGRATION_ENDPOINT.format(integration_name),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Exported IDE integration for {test_name}",
      failure_message=f"Failed to export IDE integration for {test_name}",
  )
  return ExportIDEIntegrationResponse(response=response)


def import_ide_integration_package(
    integration_identifier: str,
    package_data: bytes,
    is_custom: bool = True,
    test_name: Optional[str] = None,
) -> ImportIDEIntegrationResponse:
  """Imports and IDE integration.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    integration_identifier: name of the integration
    package_data: Binary response from the 'ExportPackage' endpoint
    is_custom: boolean
    test_name: name of the test (Defaults to None)

  Returns:
    ExportIDEIntegrationResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  base_64_encoded_package = base64.b64encode(package_data)
  payload = {
      "data": base_64_encoded_package.decode("utf-8"),
      "integrationIdentifier": integration_identifier,
      "isCustom": is_custom
  }
  response = post_with_admin_credentials(
      url=API_IMPORT_INTEGRATION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Imported IDE integration for {test_name}",
      failure_message=f"Failed to import IDE integration for {test_name}",
  )
  return ImportIDEIntegrationResponse(response=response)


def find_ide_item_by_integration_and_name(
    integration_identifier: str,
    item_name: str
):
  """Gets IDE item (card) from IDE by integration and name.

  Given integration name (identifier) and item name,
  returns the item's 'card'

  Args:
    integration_identifier: identifier/name of the integration
    item_name: name of the ide item

  Returns:
    API response - IDE item
  """
  integration = find_integration_details(integration_identifier)
  item_card = siemplify.utils.find_key_value_in_json(
      integration.get("cards"),
      "name",
      item_name
  )
  return item_card


def find_integration_details(integration_identifier: str):
  """Gets integration object with all its items from IDE.

  Given integration name (identifier), returns a dictionary
  with all information about the integration as well as
  a list of its item_cards (actions, managers, connectors
  and jobs)

  Args:
    integration_identifier: identifier/name of the integration

  Returns:
    an object with all the integration's details as well
    as its items
  """
  ide_items = siemplify.ide.get_all_ide_items()
  integration = siemplify.utils.find_key_value_in_json(
      ide_items,
      "identifier",
      integration_identifier
  )

  return integration


def get_all_ide_items() -> Response:
  """Fetches all IDE items.

  Returns:
    A response object (contains JSON with action cards data)
  """
  return get_with_admin_credentials(
      url=API_GET_ITEMS_ENDPOINT,
  )


def get_ide_item_data_by_id(
    item_type: int,
    item_id: int,
) -> IdeItemResponse:
  """Fetches data for specified IDE item.

  Args:
    item_type: type of the action
    item_id: id of the action

  Returns:
    A response object (contains JSON with action data)
  """
  payload = {
      "ideItemType": item_type,
      "itemId": item_id,
  }
  response = post_with_admin_credentials(
      url=API_GET_ITEM_DATA_ENDPOINT,
      payload=payload,
  )
  return IdeItemResponse(response=response)


def get_ide_item_data_by_name(
    item_name: str,
    integration_name: str,
) -> IdeItemResponse:
  """Fetches data for specified IDE item by name.

  Args:
    item_name: name of the IDE item
    integration_name: name of the integration IDE item belongs to

  Returns:
    An IdeItemResponse object with IDE item data
  """
  items = get_all_ide_items()
  all_items = items.json()
  integration_items = siemplify.utils.find_key_value_in_json(
      json_data=all_items,
      key="identifier",
      value=integration_name,
  )
  action_cards = siemplify.utils.find_key_in_json(
      json_data=integration_items,
      key="cards",
  )
  needed_item = siemplify.utils.find_key_value_in_json(
      json_data=action_cards,
      key="name",
      value=item_name,
  )
  item_id = needed_item["id"]
  item_type = needed_item["type"]
  return get_ide_item_data_by_id(item_type=item_type, item_id=item_id)


def add_custom_ide_item(
    description: str = "Test description",
    script: str = DEFAULT_CUSTOM_ACTION_SCRIPT,
    integration: str = "Siemplify",
    creator: Optional[str] = None,
    is_enabled: bool = True,
    item_type: int = 1,
    custom_payload: Optional[Union[dict, list]] = None,
    action_id: int = 0,
    test_name: Optional[str] = None,
) -> IdeItemResponse:
  """Adds a new custom action.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    description: description of the action
    script: script of the action
    integration: name of the integration for the action
    creator: id of the creator of the action
    is_enabled: isEnabled setting for the action
    item_type: enum numbers of custom items.
    custom_payload: (Optional) Entire api payload
    0: connector,
    1: action,
    2: job,
    4: manager
    action_id: For update purposes, the Id of the ide item to update
    test_name: name of the test (Defaults to None)

  Returns:
    An IdeItemResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not creator:
    creator = siemplify.users.get_admin_user_data().username
  name = siemplify.utils.generate_random_name(start="Item_")
  if custom_payload:
    payload = custom_payload
  else:
    payload = {
        "id": action_id,
        "type": item_type,
        "name": name,
        "description": description,
        "script": script,
        "integration": integration,
        "creator": creator,
        "creatorFullName": None,
        "isEnabled": is_enabled,
        "isCustom": True,
        "version": 1,
        "parameters": [{
            "isMandatory": True,
            "isAdvanced": False,
            "name": "Output Name",
            "defaultValue": "Test!",
            "type": 2,
            "description": ("The logical name given to the script result,"
                            " to be displayed in playbook designer"),
            "mode": 0,
            "optionalValues": None
        }, {
            "isMandatory": True,
            "isAdvanced": False,
            "name": "Polling Timeout",
            "defaultValue": "10",
            "type": 17,
            "description": (
                "The time given for an action (including async actions) to "
                "return a result. If the action didn't finish generating a "
                "result value in time, it is possible for it to fallback into"
                " a default value."
            ),
            "mode": 0,
            "optionalValues": None
        }, {
            "isMandatory": False,
            "isAdvanced": False,
            "name": "Default Return Value",
            "defaultValue": "",
            "type": 2,
            "description": ("The default result the action may consider"
                            " returning on a failure or timeout."),
            "mode": 0,
            "optionalValues": None
        }, {
            "isMandatory": True,
            "isAdvanced": False,
            "name": "Result Json Example",
            "defaultValue": "{}",
            "type": 2,
            "description": "A json example of the script result",
            "mode": 2,
            "optionalValues": None
        }, {
            "isMandatory": False,
            "isAdvanced": False,
            "name": "Include JSON Result",
            "defaultValue": "False",
            "type": 0,
            "description": None,
            "mode": 0,
            "optionalValues": None
        }],
        "connectorRules": [],
        "isConnectorRulesSupported": False,
        "documentationLink": None,
        "pythonVersion": "V2_7",
        "clientId": f"0_{type}_{name}_{integration}",
        "pythonVersionRep": "V2.7"
    }
  response = post_with_admin_credentials(
      url=API_ADD_UPDATE_ITEM_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  ide_item_id = response.json()
  item_data_response = get_ide_item_data_by_id(
      item_type=item_type,
      item_id=ide_item_id,
  )
  if test_name and not custom_payload:
    add_created_item_to_test(
        test_name=test_name,
        item_name=f"ide_item_{ide_item_id}",
        item_type={"item_name": name, "integration": integration},
    )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Created IDE item named '{name}' for {test_name}",
      failure_message=f"Failed to create IDE item for {test_name}",
  )
  return item_data_response


def delete_custom_ide_item(
    action_data: Union[Response, dict],
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a new custom action.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    action_data: dictionary with action data OR IdeItemResponse object from
      'add_custom_ide_item'/'get_ide_item_data' functions
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if isinstance(action_data, IdeItemResponse):
    data_json = action_data.response_json
    action_data = data_json
  name = action_data.get("name")
  response = post_with_admin_credentials(
      url=API_DELETE_ITEM_ENDPOINT,
      payload=action_data,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Successfully deleted IDE item '{name}' for {test_name}",
      failure_message=f"Failed to delete IDE item '{name}' for {test_name}",
  )
  return response


def delete_all_custom_ide_items_in_integration(
    integration_name: str = "Siemplify",
):
  """Deletes all custom actions.

  Args:
    integration_name: name of the integration to delete custom actions from
  """
  actions = get_all_ide_items()
  siemplify_actions = siemplify.utils.find_key_value_in_json(
      json_data=actions,
      key="identifier",
      value=integration_name,
  )
  action_cards = siemplify.utils.find_key_in_json(
      json_data=siemplify_actions,
      key="cards",
  )
  custom_actions = siemplify.utils.find_key_value_in_json(
      json_data=action_cards,
      key="isCustom",
      value=True,
  )
  if isinstance(custom_actions, list):
    for action in custom_actions:
      item_type = int(action["type"])
      item_id = int(action["id"])
      action_data = get_ide_item_data_by_id(
          item_type=item_type,
          item_id=item_id,
      )
      delete_custom_ide_item(action_data=action_data)
  if isinstance(custom_actions, dict):
    item_type = int(custom_actions["type"])
    item_id = int(custom_actions["id"])
    action_data = get_ide_item_data_by_id(
        item_type=item_type,
        item_id=item_id,
    )
    delete_custom_ide_item(action_data=action_data)


def import_ide_item(
    data: str,
    integration_name: str,
    test_name: Optional[str] = None,
) -> Response:
  """Import IDE Item.

  Args:
    data: base64 of the imported file
    integration_name: integration name to import the item
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "data": data,
      "integrationIdentifier": integration_name,
  }
  response = post_with_admin_credentials(
      url=API_IMPORT_ITEM_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Imported IDE item for {test_name}",
      failure_message=f"Failed to import IDE item for {test_name}",
  )
  return response
