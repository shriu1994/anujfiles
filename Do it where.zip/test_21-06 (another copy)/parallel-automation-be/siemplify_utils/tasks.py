"""Module with tasks actions.
"""
import time
from typing import Optional
from endpoints.tasks import API_ADD_TASK_ENDPOINT
from endpoints.tasks import API_ADD_UPDATE_CASE_TASK_ENDPOINT
from endpoints.tasks import API_DELETE_TASK_ENDPOINT
from endpoints.tasks import API_GET_TASKS_ENDPOINT
from requests import Response
# Other siemplify modules
from siemplify_utils import siemplify
# Source
from source.enums import TaskStatusType
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import delete_created_item_from_test
from source.utils import delete_with_admin_credentials
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


# Classes for Response DTOs
class TaskResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.case_id = self.response_json.get("caseId")
    self.priority = self.response_json.get("priority")
    self.is_important = self.response_json.get("isImportant")
    self.status = self.response_json.get("status")
    self.owner_comment = self.response_json.get("ownerComment")
    self.content = self.response_json.get("content")
    self.creator = self.response_json.get("creator")
    self.creator_full_name = self.response_json.get("creatorFullName")
    self.owner = self.response_json.get("owner")
    self.owner_full_name = self.response_json.get("ownerFullName")
    self.last_modifier = self.response_json.get("lastModifier")
    self.last_modifier_full_name = self.response_json.get(
        "lastModifierFullName"
    )
    self.case_name = self.response_json.get("caseName")
    self.due_date = self.response_json.get("dueDateUnixTimeInMs")
    self.completion_comment = self.response_json.get("completionComment")
    self.completion_datetime = self.response_json.get(
        "completionDateTimeUnixTimeInMs"
    )
    self.completor = self.response_json.get("completor")
    self.is_favorite = self.response_json.get("isFavorite")
    self.title = self.response_json.get("title")
    self.alert_identifier = self.response_json.get("alertIdentifier")
    self.id = self.response_json.get("id")
    self.creation_time = self.response_json.get("creationTimeUnixTimeInMs")
    self.modification_time = self.response_json.get(
        "modificationTimeUnixTimeInMs"
    )


class FetchedTasksResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.objects_list = self.response_json.get("objectsList")
    self.metadata = self.response_json.get("metadata")


def add_task(
    assign_to: str,
    content: str = "Test",
    title: str = "Test",
    creator: Optional[str] = None,
    test_name: Optional[str] = None,
) -> TaskResponse:
  """Adds a task.

  Args:
    assign_to: user id or sec role to assign the task to
    content: task content
    title: task title
    creator: ID of the user creating the task
    test_name: name of the test, if None looks at the stack (Defaults to None)

  Returns:
    A response object (contains JSON with task data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not creator:
    creator = siemplify.users.get_admin_user_data().username
  payload = {
      "content": content,
      "owner": assign_to,
      "title": title,
      "creator": creator,
      "dueDateUnixTimeInMs": None
  }
  response = post_with_admin_credentials(
      test_name=test_name,
      url=API_ADD_TASK_ENDPOINT,
      payload=payload,
  )
  final_response = TaskResponse(response=response)
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="task",
        item_name=final_response.id,
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully added task to user '{assign_to}' "
            f"for {test_name}"
        ),
        failure_message=(
            f"Failed to add task to user '{assign_to}' for {test_name}"
        ),
    )
  return final_response


def add_case_task(
    case_id: int,
    title: str = "Test",
    content: str = "Test",
    creator: Optional[str] = None,
    assignee: Optional[str] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Adds a task to a specified case.

  Args:
    case_id: id of the case to assign task to
    title: title of the task
    content: body of the task
    creator: creator of the task
    assignee: user task is assigned to
    test_name: name of the test, if None looks at the stack (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if not creator:
    creator = siemplify.users.get_admin_user_data().username
  if not assignee:
    assignee = siemplify.users.get_admin_user_data().username
  payload = {
      "title": title,
      "owner": assignee,
      "content": content,
      "dueDate": None,
      "dueDateUnixTimeInMs": None,
      "creator": creator,
      "caseId": case_id,
  }
  response = post_with_admin_credentials(
      test_name=test_name,
      url=API_ADD_UPDATE_CASE_TASK_ENDPOINT,
      payload=payload,
  )
  final_response = TaskResponse(response=response)
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="task",
        item_name=final_response.id,
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully added task to case #{case_id} "
            f"for {test_name}"
        ),
        failure_message=(
            f"Failed to add task to case #{case_id} for {test_name}"
        ),
    )
  return final_response


def get_tasks(test_name: Optional[str] = None, 
              status: Optional[TaskStatusType] = TaskStatusType.OPEN
              ) -> FetchedTasksResponse:
  """Fetches all the tasks assigned to current user.

  Args:
    test_name: name of the test, if None looks at the stack (Defaults to None)
    status: status of tasks to fetch, default is TaskStatusType.OPEN,
            can be set to TaskStatusType.CLOSE, or None - to fetch all tasks.

  Returns:
    A response object (Contains JSON with tasks data)
  """
  query_params = {
    'statusFilter': status.value
  } if status is not None else None
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      test_name=test_name,
      url=API_GET_TASKS_ENDPOINT,
      params=query_params
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched all tasks for current user "
            f"for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch all tasks for current user for {test_name}"
        ),
    )
  return FetchedTasksResponse(response=response)


def delete_task(
    task_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a task with specified id.

  Args:
    task_id: id of the task to delete
    test_name: name of the test, if None looks at the stack (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = delete_with_admin_credentials(
      url=API_DELETE_TASK_ENDPOINT.format(task_id),
      test_name=test_name,
  )
  if test_name:
    delete_created_item_from_test(
        test_name=test_name,
        item_type="task",
        item_name=task_id,
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted a task #{task_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to deleted a task #{task_id} for {test_name}"
        ),
    )
  return response


def delete_all_tasks():
  """Deletes all tasks.
  """
  data = get_tasks()
  data_json = data.response_json
  for task in data_json["objectsList"]:
    delete_task(task_id=task["id"])


def get_user_tasks_count(test_name: Optional[str] = None,) -> int:
  """Returns the number of tasks user has.

    Args:
      test_name: name of the test, if None looks at the stack (Defaults to None)
    Returns:
      A number of tasks
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  tasks = get_tasks(test_name=test_name)
  total_tasks_found = siemplify.utils.find_key_in_json(
      json_data=tasks.metadata,
      key="totalRecordsCount"
  )

  return total_tasks_found


def wait_for_task_count(
    count: Optional[int] = None,
    more_than: Optional[int] = None,
    less_than: Optional[int] = None,
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> int:
  """Fetches tasks count and looks for specific value.

  Used for widget with cases. If value is not what was specified, waits a set
    amount of seconds, retries it several times if needed.

  Args:
    count: exact task count to look for
    more_than: task count to look for that is more than this value
    less_than: task count to look for that is less than this value
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A total number of cases after the condition is met OR retires are done
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if (count and more_than or count and less_than or
      count and more_than and less_than):
    raise ValueError("Please only use 'count' OR 'less_than' OR 'more_than'")
  attempts = 0
  while attempts < retries:
    tasks = get_tasks(test_name=test_name)
    total_count = siemplify.utils.find_key_in_json(
        json_data=tasks.metadata,
        key="totalRecordsCount",
    )
    if count and total_count == count:
      attempts = retries
      return total_count
    elif more_than and total_count > more_than:
      attempts = retries
      return total_count
    elif less_than and total_count < less_than:
      attempts = retries
      return total_count
    else:
      attempts += 1
      if attempts >= retries:
        return total_count
      time.sleep(cadence)
