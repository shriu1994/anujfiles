"""Module containing actions to manipulate playbooks in siemplify client.
"""
import copy
import json
import time
from typing import Optional, Union
# Endpoints
from endpoints.playbooks import API_CREATE_PLAYBOOK_FOLDER
from endpoints.playbooks import API_DELETE_PLAYBOOK_FOLDERS
from endpoints.playbooks import API_DUPLICATE_PLAYBOOK_ENDPOINT
from endpoints.playbooks import API_EXPORT_PLAYBOOK_ENDPOINT
from endpoints.playbooks import API_GET_PLAYBOOK_DATA_ENDPOINT
from endpoints.playbooks import API_GET_PLAYBOOK_FOLDERS
from endpoints.playbooks import API_GET_PLAYBOOK_SUMMARY_RESULT_ENDPOINT
from endpoints.playbooks import API_GET_PLAYBOOKS_ENDPOINT
from endpoints.playbooks import API_GET_PLAYBOOK_LOG_VERSION_ENDPOINT
from endpoints.playbooks import API_GET_WORKFLOW_INSTANCE_SUMMARY_ENDPOINT
from endpoints.playbooks import API_IMPORT_PLAYBOOK_ENDPOINT
from endpoints.playbooks import API_PLAYBOOK_CREATE_ENDPOINT
from endpoints.playbooks import API_PLAYBOOK_DELETE_ENDPOINT
from endpoints.playbooks import API_PLAYBOOK_SAVE_LOG_VERSION_ENDPOINT
# Requests
from requests import JSONDecodeError
from requests import Response
# Other modules
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import delete_created_item_from_test
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials
from source.utils import post_with_test_credentials

shared_integrations = ("Siemplify", "SiemplifyUtilities")


# Classes for Response DTOs
class PlaybookResponse:
  """Class to represent playbook details in the response.
  """

  def __init__(self, response: Union[Response, dict]):
    if isinstance(response, Response):
      self.status_code = response.status_code
      try:
        self.response_json = check_response_and_return_json(response=response)
      except JSONDecodeError:
        self.response_json = {}
    elif isinstance(response, dict):
      self.response_json = response
    self.id = self.response_json.get("id", None)
    self.identifier = self.response_json.get("identifier", None)
    self.version = self.response_json.get("version", None)
    self.is_enabled = self.response_json.get("isEnabled", None)
    self.is_bedug = self.response_json.get("isDebugMode", None)
    self.name = self.response_json.get("name", None)
    self.creator = self.response_json.get("creator", None)
    self.modified_by = self.response_json.get("modifiedBy", None)
    self.priority = self.response_json.get("priority", None)
    self.description = self.response_json.get("description", None)
    self.environments = self.response_json.get("environments", None)
    self.category_name = self.response_json.get("categoryName", None)
    self.category_id = self.response_json.get("categoryId", None)
    self.original_playbook_id = self.response_json.get(
        "originalPlaybookIdentifier", None
    )
    self.creation_time = self.response_json.get(
        "creationTimeUnixTimeInMs", None
    )
    self.modification_time = self.response_json.get(
        "modificationTimeUnixTimeInMs", None
    )
    self.trigger = self.response_json.get("trigger", None)
    self.steps = self.response_json.get("steps", None)
    self.steps_relations = self.response_json.get("stepsRelations", None)
    self.template_name = self.response_json.get("templateName", None)
    self.playbook_type = self.response_json.get("playbookType", None)
    self.debug_data = self.response_json.get("debugData", None)
    self.entity_access_level = self.response_json.get("entityAccessLevel", None)
    self.default_access_level = self.response_json.get(
        "defaultAccessLevel", None
    )
    self.permissions = self.response_json.get("permissions", None)
    self.overview_templates = self.response_json.get("overviewTemplates", None)


class PlaybookFolder:
  """Class to represent playbook folder details in the response.
  """

  def __init__(self, response: dict[Response]):
    if isinstance(response, Response):
      self.status_code = response.status_code
      self.response_json = check_response_and_return_json(response=response)
    elif isinstance(response, dict):
      self.response_json = response
    self.id = self.response_json.get("id", None)
    self.name = self.response_json.get("name", None)
    self.category_state = self.response_json.get("categoryState", None)
    self.is_default = self.response_json.get("isDefaultCategory", None)


def create_trigger(
    trigger_type: str = "all",
    match_type: str = "equal",
    value: str = "",
    field_name: str = "",
) -> dict:
  """Creates a trigger data for a playbook.

  Available trigger_types:
    all, alert_type, alert_trigger_value, network_name, tag_name,
    product_name, custom_list, custom_trigger
  Available match types:
    equal, contains, starts_with

  Args:
    trigger_type: type of trigger to create
    match_type: type of matching for triggers where it exists
    value: value for alerts that require it
    field_name: name of the trigger field

  Returns:
    A dict with a trigger for a playbook
  """
  trigger_types = (
      "alert_type", "all", "alert_trigger_value", "network_name", "tag_name",
      "product_name", "custom_list", "custom_trigger"
  )
  match_types = ("equal", "contains", "starts_with")
  assert trigger_type in trigger_types, f"Wrong trigger type: {trigger_type}"
  assert match_type in match_types, f"Wrong match type: {match_type}"
  trigger_type_numbers = {
      "all": 8,
      "alert_trigger_value": 9,
      "alert_type": 2,
      "network_name": 4,
      "tag_name": 1,
      "product_name": 3,
      "custom_list": 7,
      "custom_trigger": 10,
      "block_trigger": 11,
  }
  match_type_numbers = {
      "equal": 0,
      "contains": 1,
      "starts_with": 2,
  }
  if trigger_type == "all":
    value = ""
  return {
      "id": 0,
      "identifier": siemplify.utils.generate_random_id(),
      "type": trigger_type_numbers[trigger_type],
      "logicalOperator": 0,
      "conditions": [
          {
              "value": value,
              "matchType": match_type_numbers[match_type],
              "fieldName": field_name
          }
      ]
  }


def create_block_trigger(
) -> dict:
  """Creates a trigger data for a playbook.

  Available trigger_types:
    all, alert_type, alert_trigger_value, network_name, tag_name,
    product_name, custom_list, custom_trigger
  Available match types:
    equal, contains, starts_with

  Args:
    trigger_type: type of trigger to create
    match_type: type of matching for triggers where it exists
    value: value for alerts that require it
    field_name: name of the trigger field

  Returns:
    A dict with a trigger for a playbook
  """
  return {
      "id": 0,
      "identifier": siemplify.utils.generate_random_id(),
      "type": 11,
      "logicalOperator": 0,
      "conditions": []
  }


def create_block_output(
    name: str = "Output",
    description: str = "",
    value: str = "Test",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
) -> dict:
  """Creates an output for the block.

  Args:
    name: name of the output
    description: description of the output
    value: the return value of the output
    integration_name: name of the integration the action belongs to
    is_automatic: is the output automatic (Defaults to True)
    is_skippable: is the output skippable (Defaults to True)
    skip_on_fail: should the output be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in block's "steps"
  """
  instance_name = f"{name}_1"
  action_id = siemplify.utils.generate_random_id()
  return {
      "id": 0,
      "identifier": action_id,
      "originalStepIdentifier": action_id,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "isAutomatic": is_automatic,
      "isSkippable": is_skippable,
      "autoSkipOnFailure": skip_on_fail,
      "instanceName": instance_name,
      "dynamicResultsMetadata": [],
      "name": name,
      "description": description,
      "integration": "Flow",
      "actionProvider": "Scripts",
      "type": 0,
      "actionName": "OutputAction",
      "workflowIdentifier": "will change after adding to playbook",
      "parameters": [
          {
              "name": "NestedWorkflowOutput",
              "value": value,
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          }
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": "will change after adding to playbook",
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
  }


def create_action(
    action_name: str,
    description: str,
    integration_name: str,
    script_value: dict,
    number: int = 1,
    selected_scope: str = "All entities",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
    assigned_users: Optional[str] = None,
    pending_timeout: Optional[str] = None,
) -> dict:
  """Creates an action for the playbook.

  Available scopes:
    All entities, Internal entities, External entities,
    Source entities, Destination entities, All enriched entities,
    All entities marked suspicious, All enriched entities,
    Internal users, External users, Source users, Destination users,
    Suspicious users, Non suspicious users, All hostnames,
    Internal hostnames, External hostnames, Non suspicious hostnames,
    All IP addresses, Internal IP addresses, External IP addresses,
    Source IP addresses, Destination IP addresses,
    Suspicious IP addresses, Non suspicious IP addresses, All URLs,
    Suspicious URLs, Non suspicious URLs, All file hashes,
    Suspicious file hashes, Non suspicious file hashes,
    All file names entities, Suspicious file names,
    Non suspicious file names, All processes entities,
    Suspicious processes, Non suspicious processes,
    All generic entities, All Mac addresses, All Credit cards,
    All Phone numbers, All CVE, All Threat actors,
    All Threat campaigns, All email subject entities, All usb entities,
    All deployment entities, All threat signatures entities,
    All domains, External domains, Internal domains,
    Suspicious domains, All pods, All containers, All services

  Args:
    action_name: name of the action
    description: description of the action
    integration_name: name of the integration the action belongs to
    script_value: a dict with script parameters
    number: number of the action within actions with the same name
      (e.g. if this is supposed to be the second time this action is in
      a playbook the number should be 2)
    selected_scope: scope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in playbook's "steps"
  """
  full_name = f"{integration_name}_{action_name}"
  instance_name = f"{integration_name}_{action_name}_{number}"
  action_id = siemplify.utils.generate_random_id()
  if integration_id is None and integration_name in shared_integrations:
    instances = siemplify.integrations.get_optional_integration_instances(
        environments=["*"],
        integration_name=integration_name
    ).json()
    integration_id = instances[0]["identifier"]
  if integration_id is None and integration_name not in shared_integrations:
    integration_id = siemplify.integrations.get_integration_id(
        name=integration_name)
  stringified_script = siemplify.utils.stringify_dict(input_dict=script_value)
  scope_options = (
      "All entities", "Internal entities", "External entities",
      "Source entities", "Destination entities", "All enriched entities",
      "All entities marked suspicious", "All enriched entities",
      "Internal users", "External users", "Source users", "Destination users",
      "Suspicious users", "Non suspicious users", "All hostnames",
      "Internal hostnames", "External hostnames", "Non suspicious hostnames",
      "All IP addresses", "Internal IP addresses", "External IP addresses",
      "Source IP addresses", "Destination IP addresses",
      "Suspicious IP addresses", "Non suspicious IP addresses", "All URLs",
      "Suspicious URLs", "Non suspicious URLs", "All file hashes",
      "Suspicious file hashes", "Non suspicious file hashes",
      "All file names entities", "Suspicious file names",
      "Non suspicious file names", "All processes entities",
      "Suspicious processes", "Non suspicious processes",
      "All generic entities", "All Mac addresses", "All Credit cards",
      "All Phone numbers", "All CVE", "All Threat actors",
      "All Threat campaigns", "All email subject entities", "All usb entities",
      "All deployment entities", "All threat signatures entities",
      "All domains", "External domains", "Internal domains",
      "Suspicious domains", "All pods", "All containers", "All services",
      "Entity Selection_1.SelectedEntities",
  )
  assert selected_scope in scope_options, f"Wrong scope: {selected_scope}"
  return {
      "id": 0,
      "identifier": action_id,
      "originalStepIdentifier": action_id,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "isAutomatic": is_automatic,
      "isSkippable": is_skippable,
      "autoSkipOnFailure": skip_on_fail,
      "instanceName": instance_name,
      "dynamicResultsMetadata": [],
      "name": full_name,
      "description": description,
      "integration": integration_name,
      "actionProvider": "Scripts",
      "type": 0,
      "actionName": full_name,
      "workflowIdentifier": "will change after adding to playbook",
      "parameters": [
          {
              "id": 0,
              "name": "ScriptName",
              "value": full_name,
              "type": None
          },
          {
              "id": 0,
              "name": "ScriptParametersEntityFields",
              "value": stringified_script,
              "type": None
          },
          {
              "id": 0,
              "name": "SelectedScopeName",
              "value": selected_scope,
              "type": None
          },
          {
              "id": 0,
              "name": "IntegrationInstance",
              "value": integration_id,
              "type": None
          },
          {
              "id": 0,
              "name": "FallbackIntegrationInstance",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "AssignedUsers",
              "value": assigned_users,
              "type": None
          },
          {
              "id": 0,
              "name": "MessageToAssignee",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "PendingActionTimeout",
              "value": pending_timeout,
              "type": None
          },
          {
              "id": 0,
              "name": "HasApprovalLink",
              "value": None,
              "type": None
          }
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": "will change after adding to playbook",
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
  }


def create_entity_selection_flow(
    selected_scope: str = "All entities",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
) -> dict:
  """Creates an action for the playbook.

  Available scopes:
    All entities, Internal entities, External entities,
    Source entities, Destination entities, All enriched entities,
    All entities marked suspicious, All enriched entities,
    Internal users, External users, Source users, Destination users,
    Suspicious users, Non suspicious users, All hostnames,
    Internal hostnames, External hostnames, Non suspicious hostnames,
    All IP addresses, Internal IP addresses, External IP addresses,
    Source IP addresses, Destination IP addresses,
    Suspicious IP addresses, Non suspicious IP addresses, All URLs,
    Suspicious URLs, Non suspicious URLs, All file hashes,
    Suspicious file hashes, Non suspicious file hashes,
    All file names entities, Suspicious file names,
    Non suspicious file names, All processes entities,
    Suspicious processes, Non suspicious processes,
    All generic entities, All Mac addresses, All Credit cards,
    All Phone numbers, All CVE, All Threat actors,
    All Threat campaigns, All email subject entities, All usb entities,
    All deployment entities, All threat signatures entities,
    All domains, External domains, Internal domains,
    Suspicious domains, All pods, All containers, All services

  Args:
    action_name: name of the action
    description: description of the action
    integration_name: name of the integration the action belongs to
    script_value: a dict with script parameters
    number: number of the action within actions with the same name
      (e.g. if this is supposed to be the second time this action is in
      a playbook the number should be 2)
    selected_scope: scope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in playbook's "steps"
  """

  action_id = siemplify.utils.generate_random_id()
  scope_options = (
      "All entities", "Internal entities", "External entities",
      "Source entities", "Destination entities", "All enriched entities",
      "All entities marked suspicious", "All enriched entities",
      "Internal users", "External users", "Source users", "Destination users",
      "Suspicious users", "Non suspicious users", "All hostnames",
      "Internal hostnames", "External hostnames", "Non suspicious hostnames",
      "All IP addresses", "Internal IP addresses", "External IP addresses",
      "Source IP addresses", "Destination IP addresses",
      "Suspicious IP addresses", "Non suspicious IP addresses", "All URLs",
      "Suspicious URLs", "Non suspicious URLs", "All file hashes",
      "Suspicious file hashes", "Non suspicious file hashes",
      "All file names entities", "Suspicious file names",
      "Non suspicious file names", "All processes entities",
      "Suspicious processes", "Non suspicious processes",
      "All generic entities", "All Mac addresses", "All Credit cards",
      "All Phone numbers", "All CVE", "All Threat actors",
      "All Threat campaigns", "All email subject entities", "All usb entities",
      "All deployment entities", "All threat signatures entities",
      "All domains", "External domains", "Internal domains",
      "Suspicious domains", "All pods", "All containers", "All services",
  )
  assert selected_scope in scope_options, f"Wrong scope: {selected_scope}"
  return {
      "id": 0,
      "identifier": action_id,
      "originalStepIdentifier": action_id,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "isAutomatic": is_automatic,
      "isSkippable": is_skippable,
      "autoSkipOnFailure": skip_on_fail,
      "instanceName": "Entity Selection_1",
      "dynamicResultsMetadata": [],
      "name": "Entity Selection",
      "description": "Entity Selection flow",
      "integration": "Flow",
      "actionProvider": "Flow",
      "type": 0,
      "actionName": "EntitySelection",
      "workflowIdentifier": "will change after adding to playbook",
      "parameters": [
          {
              "id": 0,
              "name": "ConditionOperator",
              "value": "0",
              "type": None
          },
          {
              "id": 0,
              "name": "Conditions",
              "value": "[{\"FieldName\":\"Entity.Type\",\"Operator\":1,\"Type\":2,\"Value\":\"URL\"}]",
              "type": None
          },
          {
              "id": 0,
              "name": "SelectedScopeName",
              "value": "All entities",
              "type": None
          },
          {
              "id": 0,
              "name": "AssignedUsers",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "MessageToAssignee",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "PendingActionTimeout",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "HasApprovalLink",
              "value": None,
              "type": None
          }
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": action_id,
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
  }


def create_nested_block(
    action_name: str,
    integration_name: str,
    number: int = 1,
    selected_scope: str = "All entities",
    is_automatic: bool = True,
    is_skippable: bool = False,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
) -> dict:
  """Creates an action for the playbook.

  Available scopes:
    All entities, Internal entities, External entities,
    Source entities, Destination entities, All enriched entities,
    All entities marked suspicious, All enriched entities,
    Internal users, External users, Source users, Destination users,
    Suspicious users, Non suspicious users, All hostnames,
    Internal hostnames, External hostnames, Non suspicious hostnames,
    All IP addresses, Internal IP addresses, External IP addresses,
    Source IP addresses, Destination IP addresses,
    Suspicious IP addresses, Non suspicious IP addresses, All URLs,
    Suspicious URLs, Non suspicious URLs, All file hashes,
    Suspicious file hashes, Non suspicious file hashes,
    All file names entities, Suspicious file names,
    Non suspicious file names, All processes entities,
    Suspicious processes, Non suspicious processes,
    All generic entities, All Mac addresses, All Credit cards,
    All Phone numbers, All CVE, All Threat actors,
    All Threat campaigns, All email subject entities, All usb entities,
    All deployment entities, All threat signatures entities,
    All domains, External domains, Internal domains,
    Suspicious domains, All pods, All containers, All services

  Args:
    action_name: name of the action
    description: description of the action
    integration_name: name of the integration the action belongs to
    script_value: a dict with script parameters
    number: number of the action within actions with the same name
      (e.g. if this is supposed to be the second time this action is in
      a playbook the number should be 2)
    selected_scope: scope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in playbook's "steps"
  """
  full_name = f"{integration_name}_{action_name}"
  instance_name = f"{integration_name}_{action_name}_{number}"
  action_id = siemplify.utils.generate_random_id()
  if integration_id is None and integration_name == "Siemplify":
    instances = siemplify.integrations.get_optional_integration_instances(
        environments=["*"],
        integration_name=integration_name
    ).json()
    integration_id = instances[0]["identifier"]
  if integration_id is None and integration_name != "Siemplify":
    integration_id = siemplify.integrations.get_integration_id(
        name=integration_name)
  #stringified_script = siemplify.utils.stringify_dict(input_dict=script_value)
  scope_options = (
      "All entities", "Internal entities", "External entities",
      "Source entities", "Destination entities", "All enriched entities",
      "All entities marked suspicious", "All enriched entities",
      "Internal users", "External users", "Source users", "Destination users",
      "Suspicious users", "Non suspicious users", "All hostnames",
      "Internal hostnames", "External hostnames", "Non suspicious hostnames",
      "All IP addresses", "Internal IP addresses", "External IP addresses",
      "Source IP addresses", "Destination IP addresses",
      "Suspicious IP addresses", "Non suspicious IP addresses", "All URLs",
      "Suspicious URLs", "Non suspicious URLs", "All file hashes",
      "Suspicious file hashes", "Non suspicious file hashes",
      "All file names entities", "Suspicious file names",
      "Non suspicious file names", "All processes entities",
      "Suspicious processes", "Non suspicious processes",
      "All generic entities", "All Mac addresses", "All Credit cards",
      "All Phone numbers", "All CVE", "All Threat actors",
      "All Threat campaigns", "All email subject entities", "All usb entities",
      "All deployment entities", "All threat signatures entities",
      "All domains", "External domains", "Internal domains",
      "Suspicious domains", "All pods", "All containers", "All services",
  )
  assert selected_scope in scope_options, f"Wrong scope: {selected_scope}"
  return {
      "id": 0,
      "identifier": action_id,
      "originalStepIdentifier": action_id,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "isAutomatic": is_automatic,
      "isSkippable": is_skippable,
      "autoSkipOnFailure": skip_on_fail,
      "instanceName": "Output_1",
      "dynamicResultsMetadata": [],
      "name": "Output",
      "description": "Nested Block Action",
      "integration": integration_name,
      "actionProvider": integration_name,
      "type": 6,
      "actionName": action_name,
      "workflowIdentifier": "",
      "parameters": [
          {
              "id": 0,
              "name": "NestedWorkflowOutput",
              "value": "Automation Test",
              "type": None
          },
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": "will change after adding to playbook",
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
  }


def add_nested_block_into_playbook(
    nested_name: str,
    nested_workflow_id: str,
    number: int = 1,
    selected_scope: str = "All entities",
) -> dict:
  """Creates an action for the playbook.

  Available scopes:
    All entities, Internal entities, External entities,
    Source entities, Destination entities, All enriched entities,
    All entities marked suspicious, All enriched entities,
    Internal users, External users, Source users, Destination users,
    Suspicious users, Non suspicious users, All hostnames,
    Internal hostnames, External hostnames, Non suspicious hostnames,
    All IP addresses, Internal IP addresses, External IP addresses,
    Source IP addresses, Destination IP addresses,
    Suspicious IP addresses, Non suspicious IP addresses, All URLs,
    Suspicious URLs, Non suspicious URLs, All file hashes,
    Suspicious file hashes, Non suspicious file hashes,
    All file names entities, Suspicious file names,
    Non suspicious file names, All processes entities,
    Suspicious processes, Non suspicious processes,
    All generic entities, All Mac addresses, All Credit cards,
    All Phone numbers, All CVE, All Threat actors,
    All Threat campaigns, All email subject entities, All usb entities,
    All deployment entities, All threat signatures entities,
    All domains, External domains, Internal domains,
    Suspicious domains, All pods, All containers, All services

  Args:
    action_name: name of the action
    description: description of the action
    integration_name: name of the integration the action belongs to
    script_value: a dict with script parameters
    number: number of the action within actions with the same name
      (e.g. if this is supposed to be the second time this action is in
      a playbook the number should be 2)
    selected_scope: scope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in playbook's "steps"
  """
  instance_name = f"{nested_name}_{number}"
  action_id = siemplify.utils.generate_random_id()
  scope_options = (
      "All entities", "Internal entities", "External entities",
      "Source entities", "Destination entities", "All enriched entities",
      "All entities marked suspicious", "All enriched entities",
      "Internal users", "External users", "Source users", "Destination users",
      "Suspicious users", "Non suspicious users", "All hostnames",
      "Internal hostnames", "External hostnames", "Non suspicious hostnames",
      "All IP addresses", "Internal IP addresses", "External IP addresses",
      "Source IP addresses", "Destination IP addresses",
      "Suspicious IP addresses", "Non suspicious IP addresses", "All URLs",
      "Suspicious URLs", "Non suspicious URLs", "All file hashes",
      "Suspicious file hashes", "Non suspicious file hashes",
      "All file names entities", "Suspicious file names",
      "Non suspicious file names", "All processes entities",
      "Suspicious processes", "Non suspicious processes",
      "All generic entities", "All Mac addresses", "All Credit cards",
      "All Phone numbers", "All CVE", "All Threat actors",
      "All Threat campaigns", "All email subject entities", "All usb entities",
      "All deployment entities", "All threat signatures entities",
      "All domains", "External domains", "Internal domains",
      "Suspicious domains", "All pods", "All containers", "All services",
  )
  assert selected_scope in scope_options, f"Wrong scope: {selected_scope}"
  return {
      "identifier": action_id,
      "originalStepIdentifier": "",
      "isAutomatic": True,
      "isSkippable": False,
      "instanceName": instance_name,
      "name": nested_name,
      "description": "Test Description",
      "integration": "Siemplify",
      "actionProvider": "Flow",
      "actionName": "NestedAction",
      "type": 5,
      "parameters": [
        {
          "name": "NestedWorkflowIdentifier",
          "value": nested_workflow_id,
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "name": "NestedWorkflowOutput",
          "value": "new output",
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "name": "NestedWorkflowInputs",
          "value": "[{\"FieldName\":\"Automation\",\"Value\":\"Testt\"}]",
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "name": "NestedWorkflowSteps",
          "value": "[{\"actionName\":\"Siemplify_Case Comment\",\"instanceName\":\"Siemplify_Case Comment_1\",\"stepType\":0}]",
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "id": 0,
          "name": "AssignedUsers",
          "value": None,
          "type": None
        },
        {
          "id": 0,
          "name": "MessageToAssignee",
          "value": None,
          "type": None
        },
        {
          "id": 0,
          "name": "PendingActionTimeout",
          "value": None,
          "type": None
        },
        {
          "id": 0,
          "name": "HasApprovalLink",
          "value": None,
          "type": None
        }
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": "will change after adding to playbook",
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
    }


def create_previous_flow(
    action_name: str,
    integration_name: str,
    number: int = 1,
    selected_scope: str = "All entities",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
    assigned_users: Optional[str] = None,
) -> dict:
  """Creates an action for the playbook.

  Available scopes:
    All entities, Internal entities, External entities,
    Source entities, Destination entities, All enriched entities,
    All entities marked suspicious, All enriched entities,
    Internal users, External users, Source users, Destination users,
    Suspicious users, Non suspicious users, All hostnames,
    Internal hostnames, External hostnames, Non suspicious hostnames,
    All IP addresses, Internal IP addresses, External IP addresses,
    Source IP addresses, Destination IP addresses,
    Suspicious IP addresses, Non suspicious IP addresses, All URLs,
    Suspicious URLs, Non suspicious URLs, All file hashes,
    Suspicious file hashes, Non suspicious file hashes,
    All file names entities, Suspicious file names,
    Non suspicious file names, All processes entities,
    Suspicious processes, Non suspicious processes,
    All generic entities, All Mac addresses, All Credit cards,
    All Phone numbers, All CVE, All Threat actors,
    All Threat campaigns, All email subject entities, All usb entities,
    All deployment entities, All threat signatures entities,
    All domains, External domains, Internal domains,
    Suspicious domains, All pods, All containers, All services

  Args:
    action_name: name of the action
    description: description of the action
    integration_name: name of the integration the action belongs to
    script_value: a dict with script parameters
    number: number of the action within actions with the same name
      (e.g. if this is supposed to be the second time this action is in
      a playbook the number should be 2)
    selected_scope: scope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in playbook's "steps"
  """
  action_id = siemplify.utils.generate_random_id()
  if integration_id is None and integration_name in shared_integrations:
    instances = siemplify.integrations.get_optional_integration_instances(
        environments=["*"],
        integration_name=integration_name
    ).json()
    integration_id = instances[0]["identifier"]
  if integration_id is None and integration_name not in shared_integrations:
    integration_id = siemplify.integrations.get_integration_id(
        name=integration_name)
  scope_options = (
      "All entities", "Internal entities", "External entities",
      "Source entities", "Destination entities", "All enriched entities",
      "All entities marked suspicious", "All enriched entities",
      "Internal users", "External users", "Source users", "Destination users",
      "Suspicious users", "Non suspicious users", "All hostnames",
      "Internal hostnames", "External hostnames", "Non suspicious hostnames",
      "All IP addresses", "Internal IP addresses", "External IP addresses",
      "Source IP addresses", "Destination IP addresses",
      "Suspicious IP addresses", "Non suspicious IP addresses", "All URLs",
      "Suspicious URLs", "Non suspicious URLs", "All file hashes",
      "Suspicious file hashes", "Non suspicious file hashes",
      "All file names entities", "Suspicious file names",
      "Non suspicious file names", "All processes entities",
      "Suspicious processes", "Non suspicious processes",
      "All generic entities", "All Mac addresses", "All Credit cards",
      "All Phone numbers", "All CVE", "All Threat actors",
      "All Threat campaigns", "All email subject entities", "All usb entities",
      "All deployment entities", "All threat signatures entities",
      "All domains", "External domains", "Internal domains",
      "Suspicious domains", "All pods", "All containers", "All services",
  )
  assert selected_scope in scope_options, f"Wrong scope: {selected_scope}"
  return {
      "id": 0,
      "identifier": action_id,
      "status": -1,
      "workflowInstanceIdentifier": 0,
      "originalStepIdentifier": action_id,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "isAutomatic": is_automatic,
      "isSkippable": is_skippable,
      "autoSkipOnFailure": skip_on_fail,
      "instanceName": "Previous Actions Conditions_1",
      "dynamicResultsMetadata": [],
      "name": "Previous Actions Conditions",
      "description": "Flow Action",
      "integration": integration_name,
      "actionProvider": "Flow",
      "type": 2,
      "actionName": "IfElse",
      "workflowIdentifier": "90ec3267-d7fe-421a-b64d-63b0ea8feac9",
      "parameters": [
          {
              "id": 0,
              "name": "Branches",
              "value": "[{\"Order\":1,\"IsDefaultBranch\":false,\"Conditions\":[{\"FieldName\":\"Siemplify_Case Comment_1.SuccessStatus\",\"Operator\":0,\"Type\":2,\"Value\":\"true\"}],\"LogicalOperator\":0,\"Name\":\"Branch\"},{\"Order\":2,\"IsDefaultBranch\":true,\"Conditions\":[],\"LogicalOperator\":0,\"Name\":\"Branch\"}]",
              "type": None
          },
          {
              "id": 0,
              "name": "ErrorFallbackBranch",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "AssignedUsers",
              "value": assigned_users,
              "type": None
          },
          {
              "id": 0,
              "name": "MessageToAssignee",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "PendingActionTimeout",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "HasApprovalLink",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "SelectedScopeName",
              "value": selected_scope,
              "type": None
          }
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": "",
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
  }


def create_condition_flow(
    integration_name: str,
    selected_scope: str = "All entities",
    branch_conditions_json = "[{\"LogicalOperator\":0,\"Conditions\":[{\"Operator\":0,\"FieldName\":\"1\",\"Type\":2,\"Value\":\"1\"}],\"Order\":1,\"IsDefaultBranch\":false,\"Name\":\"Branch\"},{\"LogicalOperator\":0,\"Conditions\":[],\"Order\":2,\"IsDefaultBranch\":true,\"Name\":\"Branch\"}]",
    integration_id: Optional[str] = None,
) -> dict:
  """Creates an action for the playbook.

  Available scopes:
    All entities, Internal entities, External entities,
    Source entities, Destination entities, All enriched entities,
    All entities marked suspicious, All enriched entities,
    Internal users, External users, Source users, Destination users,
    Suspicious users, Non suspicious users, All hostnames,
    Internal hostnames, External hostnames, Non suspicious hostnames,
    All IP addresses, Internal IP addresses, External IP addresses,
    Source IP addresses, Destination IP addresses,
    Suspicious IP addresses, Non suspicious IP addresses, All URLs,
    Suspicious URLs, Non suspicious URLs, All file hashes,
    Suspicious file hashes, Non suspicious file hashes,
    All file names entities, Suspicious file names,
    Non suspicious file names, All processes entities,
    Suspicious processes, Non suspicious processes,
    All generic entities, All Mac addresses, All Credit cards,
    All Phone numbers, All CVE, All Threat actors,
    All Threat campaigns, All email subject entities, All usb entities,
    All deployment entities, All threat signatures entities,
    All domains, External domains, Internal domains,
    Suspicious domains, All pods, All containers, All services

  Args:
    action_name: name of the action
    description: description of the action
    integration_name: name of the integration the action belongs to
    script_value: a dict with script parameters
    number: number of the action within actions with the same name
      (e.g. if this is supposed to be the second time this action is in
      a playbook the number should be 2)
    selected_scope: scope of the action (Defaults to "All entities")
    branch_conditions_json: Json of the conditions of each branch in  the flow
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in playbook's "steps"
  """
  action_id = siemplify.utils.generate_random_id()
  if integration_id is None and integration_name in shared_integrations:
    instances = siemplify.integrations.get_optional_integration_instances(
        environments=["*"],
        integration_name=integration_name
    ).json()
    integration_id = instances[0]["identifier"]
  if integration_id is None and integration_name not in shared_integrations:
    integration_id = siemplify.integrations.get_integration_id(
        name=integration_name)
  #stringified_script = siemplify.utils.stringify_dict(input_dict=script_value)
  scope_options = (
      "All entities", "Internal entities", "External entities",
      "Source entities", "Destination entities", "All enriched entities",
      "All entities marked suspicious", "All enriched entities",
      "Internal users", "External users", "Source users", "Destination users",
      "Suspicious users", "Non suspicious users", "All hostnames",
      "Internal hostnames", "External hostnames", "Non suspicious hostnames",
      "All IP addresses", "Internal IP addresses", "External IP addresses",
      "Source IP addresses", "Destination IP addresses",
      "Suspicious IP addresses", "Non suspicious IP addresses", "All URLs",
      "Suspicious URLs", "Non suspicious URLs", "All file hashes",
      "Suspicious file hashes", "Non suspicious file hashes",
      "All file names entities", "Suspicious file names",
      "Non suspicious file names", "All processes entities",
      "Suspicious processes", "Non suspicious processes",
      "All generic entities", "All Mac addresses", "All Credit cards",
      "All Phone numbers", "All CVE", "All Threat actors",
      "All Threat campaigns", "All email subject entities", "All usb entities",
      "All deployment entities", "All threat signatures entities",
      "All domains", "External domains", "Internal domains",
      "Suspicious domains", "All pods", "All containers", "All services",
  )
  assert selected_scope in scope_options, f"Wrong scope: {selected_scope}"
  return {
      "id": 0,
      "identifier": action_id,
      "workflowInstanceIdentifier": 0,
      "originalStepIdentifier": "",
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "isAutomatic": True,
      "isSkippable": True,
      "autoSkipOnFailure": False,
      "instanceName": "Condition_1",
      "name": "Condition",
      "description": "Flow Action",
      "integration": "Flow",
      "actionProvider": "Flow",
      "type": 4,
      "actionName": "IfFlowCondition",
      "parameters": [
          {
              "id": 0,
              "name": "Branches",
              "value": branch_conditions_json if isinstance(branch_conditions_json, str) else json.dumps(branch_conditions_json),
              "type": None
          },
          {
              "id": 0,
              "name": "ErrorFallbackBranch",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "AssignedUsers",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "MessageToAssignee",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "PendingActionTimeout",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "HasApprovalLink",
              "value": None,
              "type": None
          },
          {
              "id": 0,
              "name": "SelectedScopeName",
              "value": selected_scope,
              "type": None
          }
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": "",
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
  }


def create_multichoise_flow(
) -> dict:
  """Creates an action for the playbook.

  Available scopes:
    All entities, Internal entities, External entities,
    Source entities, Destination entities, All enriched entities,
    All entities marked suspicious, All enriched entities,
    Internal users, External users, Source users, Destination users,
    Suspicious users, Non suspicious users, All hostnames,
    Internal hostnames, External hostnames, Non suspicious hostnames,
    All IP addresses, Internal IP addresses, External IP addresses,
    Source IP addresses, Destination IP addresses,
    Suspicious IP addresses, Non suspicious IP addresses, All URLs,
    Suspicious URLs, Non suspicious URLs, All file hashes,
    Suspicious file hashes, Non suspicious file hashes,
    All file names entities, Suspicious file names,
    Non suspicious file names, All processes entities,
    Suspicious processes, Non suspicious processes,
    All generic entities, All Mac addresses, All Credit cards,
    All Phone numbers, All CVE, All Threat actors,
    All Threat campaigns, All email subject entities, All usb entities,
    All deployment entities, All threat signatures entities,
    All domains, External domains, Internal domains,
    Suspicious domains, All pods, All containers, All services

  Args:
    action_name: name of the action
    description: description of the action
    integration_name: name of the integration the action belongs to
    script_value: a dict with script parameters
    number: number of the action within actions with the same name
      (e.g. if this is supposed to be the second time this action is in
      a playbook the number should be 2)
    selected_scope: scope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dictionary to use in playbook's "steps"
  """
  action_id = siemplify.utils.generate_random_id()
  scope_options = (
      "All entities", "Internal entities", "External entities",
      "Source entities", "Destination entities", "All enriched entities",
      "All entities marked suspicious", "All enriched entities",
      "Internal users", "External users", "Source users", "Destination users",
      "Suspicious users", "Non suspicious users", "All hostnames",
      "Internal hostnames", "External hostnames", "Non suspicious hostnames",
      "All IP addresses", "Internal IP addresses", "External IP addresses",
      "Source IP addresses", "Destination IP addresses",
      "Suspicious IP addresses", "Non suspicious IP addresses", "All URLs",
      "Suspicious URLs", "Non suspicious URLs", "All file hashes",
      "Suspicious file hashes", "Non suspicious file hashes",
      "All file names entities", "Suspicious file names",
      "Non suspicious file names", "All processes entities",
      "Suspicious processes", "Non suspicious processes",
      "All generic entities", "All Mac addresses", "All Credit cards",
      "All Phone numbers", "All CVE", "All Threat actors",
      "All Threat campaigns", "All email subject entities", "All usb entities",
      "All deployment entities", "All threat signatures entities",
      "All domains", "External domains", "Internal domains",
      "Suspicious domains", "All pods", "All containers", "All services",
  )
  return {
      "id": 0,
      "identifier": action_id,
      "workflowInstanceIdentifier": 0,
      "originalStepIdentifier": action_id,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "isAutomatic": False,
      "isSkippable": False,
      "autoSkipOnFailure": False,
      "instanceName": "MultiChoiceQuestion_1",
      "integrationInstanceIdentifier": "00000000-0000-0000-0000-000000000000",
      "name": "MultiChoiceQuestion",
      "description": "Multi Choise Flow Action",
      "integration": "Flow",
      "actionProvider": "Flow",
      "type": 1,
      "actionName": "MultiChoiceQuestion",
      "parameters": [
          {
              "name": "Answers",
              "value": "{\"1\":\"Yes\",\"2\":\"No\"}",
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          },
          {
              "name": "AssignedUsers",
              "value": None,
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          },
          {
              "name": "HasApprovalLink",
              "value": None,
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          },
          {
              "name": "MessageToAssignee",
              "value": "",
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          },
          {
              "name": "PendingActionTimeout",
              "value": None,
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          },
          {
              "name": "Question",
              "value": "Automation Test",
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          },
          {
              "name": "SelectedScopeName",
              "value": None,
              "type": None,
              "isMandatory": False,
              "defaultValue": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "additionalProperties": {}
          }
      ],
      "properties": {},
      "isDebugMockData": False,
      "debugData": {
          "id": 0,
          "originalWorkflowIdentifier": "",
          "originalStepIdentifier": action_id,
          "resultValue": "",
          "resultJson": "",
          "scopeEntitiesEnrichmentData": []
      }
  }


def convert_block_to_action(block_json: dict) -> dict:
  """Function takes the json from create_block to use in create_playbook.

  Args:
    block_json: response_json from create_block or get_playbook_data

  Returns:
    A dict to use as an action in create_playbook
  """
  random_id = siemplify.utils.generate_random_id()
  block_name = block_json.get("name")
  instance_name = f"{block_name}_1"
  description = block_json.get("description")
  workflow_identifier = block_json.get("identifier")
  steps = block_json.get("steps")
  non_output_steps = steps[:-1]
  workflow_input_params = block_json.get("trigger")
  workflow_input_list = workflow_input_params.get("conditions")
  workflow_input_value = f"{workflow_input_list}"
  workflow_output_params = steps[-1].get("parameters")
  workflow_output_list = [workflow_output_params[0].get("value")]
  workflow_output_value = f"{workflow_output_list}"
  # Generate dict with nested steps
  nested_steps_list = []
  for step in non_output_steps:
    step_data = {
      "identifier": step.get("identifier"),
      "integration": step.get("integration"),
      "actionName": step.get("actionName"),
      "instanceName": step.get("instanceName"),
      "stepType": step.get("type"),
    }
    nested_steps_list.append(step_data)
  stringified_step_list = siemplify.utils.stringify_dict(nested_steps_list)
  final_template = {
      "parallelActions": [],
      "identifier": random_id,
      "originalStepIdentifier": "",
      "isAutomatic": True,
      "isSkippable": False,
      "instanceName": instance_name,
      "name": block_name,
      "integration": "Siemplify",
      "description": description,
      "actionProvider": "Flow",
      "actionName": "NestedAction",
      "type": 5,
      "parameters": [
        {
          "name": "NestedWorkflowIdentifier",
          "value": workflow_identifier,
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "name": "NestedWorkflowOutput",
          "value": workflow_output_value,
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "name": "NestedWorkflowInputs",
          "value": workflow_input_value,
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "name": "NestedWorkflowSteps",
          "value": stringified_step_list,
          "type": None,
          "isMandatory": False,
          "defaultValue": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "additionalProperties": {}
        },
        {
          "id": 0,
          "name": "AssignedUsers",
          "value": None,
          "type": None
        },
        {
          "id": 0,
          "name": "MessageToAssignee",
          "value": None,
          "type": None
        },
        {
          "id": 0,
          "name": "PendingActionTimeout",
          "value": None,
          "type": None
        },
        {
          "id": 0,
          "name": "HasApprovalLink",
          "value": None,
          "type": None
        }
      ],
      "autoSkipOnFailure": False,
      "isDebugMockData": False,
      "debugData": None,
      "parentStepContainerId": None,
      "workflowIdentifier": None,
      "id": 0,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": 0,
      "additionalProperties": {}
    }

  return final_template


def create_block_for_test(
    trigger: Optional[dict] = None,
    actions: Optional[list[dict]] = None,
    is_enabled: bool = True,
    is_debug: bool = False,
    block_description: str = "Test Description",
    priority: int = 2,
    category_id: int = 1,
    category_name: str = "Default",
    use_previous_flow_action: Optional[bool] = False,
    use_condition: Optional[bool] = False,
    block_type: Optional[int] = 1,
    view_template: Optional[list] = None,
    change_ids: bool = False,
    test_name: Optional[str] = None,
) -> PlaybookResponse:
  """Creates a block for a test.

  Args:
    trigger: trigger that starts the playbook (Made with create_trigger)
    actions: a list of actions
    is_enabled: is playbook enabled (defaults to True)
    is_debug: is playbook in debug mode (defaults to False)
    playbook_name: name of the new playbook. Generates a random
      name if None (defaults to None)
    playbook_description: description of the new playbook
      (defaults to "Test Description")
    environments: names of the environments. Set to "Default Environment"
      if None (defaults to None)
    priority: playbook priority (defaults to 2)
    category_id: id of the folder for the playbook (defaults to 1)
    category_name: name of the folder for the playbook (defaults to "Default")
    use_previous_flow_action: to use previous condition action flow, set true
    use_condition: to use condition action flow, set true
    view_template: for adding a view to a playbook, use the view template
    change_ids: if this is True the function will randomize all action IDs
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookResponse object (same as for playbooks, but contains Block data)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  username = siemplify.users.get_admin_user_data().username
  block_id = siemplify.utils.generate_random_id()
  block_name = siemplify.utils.generate_random_name(start="Block_")
  environments = [test_name]
  if not trigger:
    trigger = create_block_trigger()
  if not actions:
    action_1 = siemplify.payloads.playbook_actions.add_entity_insight()
    actions = [action_1]
  steps = []
  steps_ids = []
  if change_ids:
    number = 1
    for action in actions:
      random_id = siemplify.utils.generate_random_id()
      changed_action = copy.deepcopy(action)
      changed_action["identifier"] = random_id
      changed_action["originalStepIdentifier"] = random_id
      changed_action["workflowIdentifier"] = block_id
      changed_action["debugData"]["originalStepIdentifier"] = random_id
      changed_action["debugData"]["originalWorkflowIdentifier"] = block_id
      changed_action["instanceName"] = (
          action["instanceName"][:-2] + f"_{number}"
      )
      steps.append(changed_action)
      steps_ids.append(changed_action["identifier"])
      number += 1
  else:
    for action in actions:
      action["workflowIdentifier"] = block_id
      action["debugData"]["originalWorkflowIdentifier"] = block_id
      steps.append(action)
      steps_ids.append(action["identifier"])
  step_relations = []
  if len(steps) > 1:
    for step_id in range(len(steps)-1):
      relation = {
          "fromStep": steps[step_id]["identifier"],
          "toStep": steps[step_id+1]["identifier"],
          "condition": ""
      }
      step_relations.append(relation)
  if use_previous_flow_action:
    step_relations[1]["condition"] = "1"
  if use_condition:
    step_relations[0]["condition"] = "1"
  payload = {
      "id": 0,
      "categoryId": category_id,
      "categoryName": category_name,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "modifiedBy": username,
      "playbookType": block_type,
      "identifier": block_id,
      "environments": environments,
      "version": 1,
      "isEnabled": is_enabled,
      "isDebugMode": is_debug,
      "debugData": None,
      "name": block_name,
      "description": block_description,
      "creator": username,
      "priority": priority,
      "trigger": trigger,
      "steps": steps,
      "originalPlaybookIdentifier": block_id,
      "stepsRelations": step_relations,
      "templateName": "",
      "defaultAccessLevel": 2,
      "entityAccessLevel": 2,
      "permissions": [],
      "hasRestrictedEnvironments": False,
      "overviewTemplates": view_template if view_template else [],
  }
  response = post_with_admin_credentials(
      url=API_PLAYBOOK_CREATE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  final_response = PlaybookResponse(response=response)
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="block",
        item_name=final_response.identifier,
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created block '{block_name}' for {test_name}"
        ),
        failure_message=(
            f"Failed to create a block '{block_name} for {test_name}"
        ),
    )
  return final_response


def create_playbook_for_test(
    trigger: Optional[dict] = None,
    actions: Optional[list[dict]] = None,
    is_enabled: bool = True,
    is_debug: bool = False,
    playbook_description: str = "Test Description",
    priority: int = 2,
    category_id: int = 1,
    category_name: str = "Default",
    use_previous_flow_action: Optional[bool] = False,
    use_condition: Optional[bool] = False,
    playbook_type: Optional[int] = 0,
    view_template: Optional[list] = None,
    change_ids: bool = False,
    test_name: Optional[str] = None,
    ignore_500: Optional[bool] = False,
) -> PlaybookResponse:
  """Creates a playbook.

  Args:
    trigger: trigger that starts the playbook (Made with create_trigger)
    actions: a list of actions
    is_enabled: is playbook enabled (defaults to True)
    is_debug: is playbook in debug mode (defaults to False)
    playbook_description: description of the new playbook
      (defaults to "Test Description")
    priority: playbook priority (defaults to 2)
    category_id: id of the folder for the playbook (defaults to 1)
    category_name: name of the folder for the playbook (defaults to "Default")
    use_previous_flow_action: to use previous condition action flow, set true
    use_condition: to use condition action flow, set true
    view_template: for adding a view to a playbook, use the view template
    change_ids: if this is True the function will randomize all action IDs
    test_name: name of the test (Defaults to None)
    ignore_500: if true, 500 response code will be considered a success

  Returns:
    A PlaybookResponse object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  username = siemplify.users.get_admin_user_data().username
  playbook_id = siemplify.utils.generate_random_id()
  playbook_name = siemplify.utils.generate_random_name(start="Playbook_")
  environments = [test_name]
  action_id = siemplify.utils.generate_random_id()
  if view_template:
    view_template = [
        {
            "id": 0,
            "identifier": action_id,
            "name": "Automation_View",
            "creator": None,
            "playbookIdentifier": playbook_id,
            "type": 0,
            "widgets": [
                {
                    "metadata": {
                        "id": 0,
                        "identifier": action_id,
                        "title": "Automation Test",
                        "width": 2,
                        "order": 1,
                        "description": "Automation Test",
                        "type": 8,
                        "templateIdentifier": action_id,
                        "predefinedWidgetTemplateIdentifier": None,
                        "actionIdentifier": None,
                        "stepIdentifier": None,
                        "stepIntegration": None,
                        "presentIfEmpty": False,
                        "conditionsGroup": {
                            "conditions": [],
                            "logicalOperator": 0
                        }
                    },
                    "config": {
                        "text": "Automation Test"
                    }
                }
            ],
            "roles": [
                1
            ],
            "creationTimeUnixTimeInMs": 0
        }
    ]
  if not trigger:
    trigger = create_trigger()
  if not actions:
    action_1 = siemplify.payloads.playbook_actions.add_entity_insight()
    actions = [action_1]
  steps = []
  steps_ids = []
  if change_ids:
    number = 1
    for action in actions:
      random_id = siemplify.utils.generate_random_id()
      changed_action = copy.deepcopy(action)
      changed_action["identifier"] = random_id
      if changed_action["originalStepIdentifier"]:
        changed_action["originalStepIdentifier"] = random_id
      if changed_action["workflowIdentifier"]:
        changed_action["workflowIdentifier"] = playbook_id
      if changed_action["debugData"]:
        changed_action["debugData"]["originalStepIdentifier"] = random_id
        changed_action["debugData"]["originalWorkflowIdentifier"] = playbook_id
      changed_action["instanceName"] = (
          action["instanceName"][:-2] + f"_{number}"
      )
      steps.append(changed_action)
      steps_ids.append(changed_action["identifier"])
      number += 1
  else:
    for action in actions:
      action["workflowIdentifier"] = playbook_id
      action["debugData"]["originalWorkflowIdentifier"] = playbook_id
      steps.append(action)
      steps_ids.append(action["identifier"])
  step_relations = []
  if len(steps) > 1:
    for step_id in range(len(steps)-1):
      relation = {
          "fromStep": steps[step_id]["identifier"],
          "toStep": steps[step_id+1]["identifier"],
          "condition": ""
      }
      step_relations.append(relation)
  if use_previous_flow_action:
    step_relations[1]["condition"] = "1"
  if use_condition:
    step_relations[0]["condition"] = "1"
  payload = {
      "id": 0,
      "categoryId": category_id,
      "categoryName": category_name,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "modifiedBy": username,
      "playbookType": playbook_type,
      "identifier": playbook_id,
      "environments": environments,
      "version": 1,
      "isEnabled": is_enabled,
      "isDebugMode": is_debug,
      "debugData": None,
      "name": playbook_name,
      "description": playbook_description,
      "creator": username,
      "priority": priority,
      "trigger": trigger,
      "steps": steps,
      "originalPlaybookIdentifier": playbook_id,
      "stepsRelations": step_relations,
      "templateName": "",
      "defaultAccessLevel": 2,
      "entityAccessLevel": 2,
      "permissions": [],
      "hasRestrictedEnvironments": False,
      "overviewTemplates": view_template if view_template else [],
  }
  response = post_with_admin_credentials(
      url=API_PLAYBOOK_CREATE_ENDPOINT,
      payload=payload,
      test_name=test_name,
      ignore_404=True,
      ignore_500=ignore_500
  )
  if response.status_code == 404:
    final_response = get_playbook_data(identifier=playbook_id)
  else:
    final_response = PlaybookResponse(response=response)
  log_and_assert(
      ignore_404=True,
      ignore_500=ignore_500,
      response=response,
      test_name=test_name,
      success_message=f"Created playbook '{playbook_name}' for {test_name}",
      failure_message=(
          f"Failed to create a playbook '{playbook_name} for {test_name}"
      ),
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="playbook",
        item_name=final_response.identifier,
    )
  return final_response


def create_playbook_in_environments(
    environments: list[str],
    trigger: Optional[dict] = None,
    actions: Optional[list[dict]] = None,
    is_enabled: bool = True,
    is_debug: bool = False,
    playbook_description: str = "Test Description",
    priority: int = 2,
    category_id: int = 1,
    category_name: str = "Default",
    use_previous_flow_action: Optional[bool] = False,
    use_condition: Optional[bool] = False,
    playbook_type: Optional[int] = 0,
    view_template: Optional[list] = None,
    change_ids: bool = False,
    test_name: Optional[str] = None,
) -> PlaybookResponse:
  """Creates a playbook.

  Args:
    environments: a list of environments for the playbook
    trigger: trigger that starts the playbook (Made with create_trigger)
    actions: a list of actions
    is_enabled: is playbook enabled (defaults to True)
    is_debug: is playbook in debug mode (defaults to False)
    playbook_description: description of the new playbook
      (defaults to "Test Description")
    priority: playbook priority (defaults to 2)
    category_id: id of the folder for the playbook (defaults to 1)
    category_name: name of the folder for the playbook (defaults to "Default")
    use_previous_flow_action: to use previous condition action flow, set true
    use_condition: to use condition action flow, set true
    view_template: for adding a view to a playbook, use the view template
    change_ids: if this is True the function will randomize all action IDs
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  username = siemplify.users.get_admin_user_data().username
  playbook_id = siemplify.utils.generate_random_id()
  playbook_name = siemplify.utils.generate_random_name(start="Playbook_")
  action_id = siemplify.utils.generate_random_id()
  if view_template:
    view_template = [
        {
            "id": 0,
            "identifier": action_id,
            "name": "Automation_View",
            "creator": None,
            "playbookIdentifier": playbook_id,
            "type": 0,
            "widgets": [
                {
                    "metadata": {
                        "id": 0,
                        "identifier": action_id,
                        "title": "Automation Test",
                        "width": 2,
                        "order": 1,
                        "description": "Automation Test",
                        "type": 8,
                        "templateIdentifier": action_id,
                        "predefinedWidgetTemplateIdentifier": None,
                        "actionIdentifier": None,
                        "stepIdentifier": None,
                        "stepIntegration": None,
                        "presentIfEmpty": False,
                        "conditionsGroup": {
                            "conditions": [],
                            "logicalOperator": 0
                        }
                    },
                    "config": {
                        "text": "Automation Test"
                    }
                }
            ],
            "roles": [
                1
            ],
            "creationTimeUnixTimeInMs": 0
        }
    ]
  if not trigger:
    trigger = create_trigger()
  if not actions:
    action_1 = siemplify.payloads.playbook_actions.add_entity_insight()
    actions = [action_1]
  steps = []
  steps_ids = []
  if change_ids:
    number = 1
    for action in actions:
      random_id = siemplify.utils.generate_random_id()
      changed_action = copy.deepcopy(action)
      changed_action["identifier"] = random_id
      if changed_action["originalStepIdentifier"]:
        changed_action["originalStepIdentifier"] = random_id
      if changed_action["workflowIdentifier"]:
        changed_action["workflowIdentifier"] = playbook_id
      if changed_action["debugData"]:
        changed_action["debugData"]["originalStepIdentifier"] = random_id
        changed_action["debugData"]["originalWorkflowIdentifier"] = playbook_id
      changed_action["instanceName"] = (
          action["instanceName"][:-2] + f"_{number}"
      )
      steps.append(changed_action)
      steps_ids.append(changed_action["identifier"])
      number += 1
  else:
    for action in actions:
      action["workflowIdentifier"] = playbook_id
      action["debugData"]["originalWorkflowIdentifier"] = playbook_id
      steps.append(action)
      steps_ids.append(action["identifier"])
  step_relations = []
  if len(steps) > 1:
    for step_id in range(len(steps)-1):
      relation = {
          "fromStep": steps[step_id]["identifier"],
          "toStep": steps[step_id+1]["identifier"],
          "condition": ""
      }
      step_relations.append(relation)
  if use_previous_flow_action:
    step_relations[1]["condition"] = "1"
  if use_condition:
    step_relations[0]["condition"] = "1"
  payload = {
      "id": 0,
      "categoryId": category_id,
      "categoryName": category_name,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "modifiedBy": username,
      "playbookType": playbook_type,
      "identifier": playbook_id,
      "environments": environments,
      "version": 1,
      "isEnabled": is_enabled,
      "isDebugMode": is_debug,
      "debugData": None,
      "name": playbook_name,
      "description": playbook_description,
      "creator": username,
      "priority": priority,
      "trigger": trigger,
      "steps": steps,
      "originalPlaybookIdentifier": playbook_id,
      "stepsRelations": step_relations,
      "templateName": "",
      "defaultAccessLevel": 2,
      "entityAccessLevel": 2,
      "permissions": [],
      "hasRestrictedEnvironments": False,
      "overviewTemplates": view_template if view_template else [],
  }
  response = post_with_admin_credentials(
      url=API_PLAYBOOK_CREATE_ENDPOINT,
      payload=payload,
      test_name=test_name,
      ignore_404=True,
  )
  if response.status_code == 404:
    final_response = get_playbook_data(identifier=playbook_id)
  else:
    final_response = PlaybookResponse(response=response)
  log_and_assert(
      ignore_404=True,
      response=response,
      test_name=test_name,
      success_message=(
          f"Created playbook '{playbook_name}' in environments {environments}"
          f" for {test_name}"
      ),
      failure_message=(
          f"Failed to create a playbook '{playbook_name} for {test_name}"
      ),
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="playbook",
        item_name=final_response.identifier,
    )
  return final_response


def delete_playbook(
    playbook: str,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a playbook with the specified ID.

  Args:
    playbook: identifier of playbook to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  result = siemplify.playbooks.get_all_playbooks()
  check = siemplify.utils.find_key_value_in_json(
      json_data=result,
      key="identifier",
      value=playbook,
  )
  if not check:
    return True
  response = post_with_admin_credentials(
      url=API_PLAYBOOK_DELETE_ENDPOINT,
      payload={"identifiers": [playbook]},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Deleted playbook #{playbook}' for {test_name}"
        ),
        failure_message=(
            f"Failed to delete a playbook #{playbook} for {test_name}"
        ),
    )
    delete_created_item_from_test(
        test_name=test_name,
        item_type="playbook",
        item_name=playbook,
    )
  return response


def save_playbook_log_version(
    playbook_identifier: str,
    comment: str = "Default comment",
    test_name: Optional[str] = None
) -> PlaybookResponse:
  """Save new log version of a specific playbook.

  Args:
    playbook_identifier: id of the playbook to save new version log
    comment: comment to be saved, (Defaults is "Default comment")
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookResponse object with updated playbook data
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "identifier": playbook_identifier,
      "comment": comment,
  }
  response = post_with_admin_credentials(
      url=API_PLAYBOOK_SAVE_LOG_VERSION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )

  final_response = PlaybookResponse(response=response)

  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Created playbook #{playbook_identifier}' log version for {test_name}"
        ),
        failure_message=(
            f"Failed to create a log version of the playbook #{playbook_identifier}' for {test_name}"
        ),
    )

  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="playbook",
        item_name=final_response.identifier,
    )
  return final_response

def get_playbook_log_versions(
    playbook_identifier: str,
    test_name: Optional[str] = None
) -> PlaybookResponse:
  """Get playbook's log versions.

  Args:
    playbook_identifier: id of the playbook to get the logs version
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "workflowIdentifier": playbook_identifier,
  }
  return post_with_admin_credentials(
      url=API_GET_PLAYBOOK_LOG_VERSION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )


def get_all_playbooks_for_test(test_name: Optional[str] = None) -> Response:
  """Fetches all playbooks from current environment.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (Contains JSON data with all playbooks)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  response = post_with_test_credentials(
      url=API_GET_PLAYBOOKS_ENDPOINT,
      payload=[1, 0],
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched all playbooks for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch all playbooks for {test_name}"
        ),
    )
  return response


def get_all_playbooks(test_name: Optional[str] = None) -> Response:
  """Fetches all playbooks from current environment.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (Contains JSON data with all playbooks)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_GET_PLAYBOOKS_ENDPOINT,
      payload=[1, 0],
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched all playbooks for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch all playbooks for {test_name}"
        ),
    )
  return response


def delete_all_playbooks():
  """Deletes all playbooks.
  """
  all_playbooks = get_all_playbooks()
  playbooks_json = all_playbooks.json()
  for pb in playbooks_json:
    pb_id = pb["identifier"]
    delete_playbook(playbook=pb_id)
  delete_all_custom_folders()


def get_playbook_summary(
    case_id: str,
    alert_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Get playbook data summary attached to alert.

  Playbook status list:
    None = 0
    InProgress = 1
    Completed = 2
    Failed = 3
    Terminated = 4
    PendingInQueue = 5
    PendingForUser = 6

  Args:
    case_id: id of the case to check the playbook summary
    alert_id: id of the alert playbook is attached to
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_GET_PLAYBOOK_SUMMARY_RESULT_ENDPOINT,
      payload={"caseId": case_id, "alertIdentifier": alert_id},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched playbook summary for case #{case_id} & alert #{alert_id}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch playbook summary for case #{case_id} &"
            f"alert #{alert_id} for {test_name}"
        ),
    )
  return response


def get_playbook_data(
    identifier: str,
    test_name: Optional[str] = None,
) -> PlaybookResponse:
  """Fetches playbook data by it's identifier.

  Args:
    identifier: identifier of the playbook
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookResponse object with all data of the playbook
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_PLAYBOOK_DATA_ENDPOINT.format(identifier),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched playbook #{identifier} data for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch playbook #{identifier} data for {test_name}"
        ),
    )
  return PlaybookResponse(response=response)


def update_playbook(
    playbook_identifier: str,
    trigger: Optional[dict] = None,
    actions: Optional[list[dict]] = None,
    is_enabled: Optional[bool] = None,
    is_debug: Optional[bool] = None,
    playbook_name: Optional[str] = None,
    playbook_description: Optional[str] = None,
    priority: Optional[int] = None,
    category_id: Optional[int] = None,
    category_name: Optional[str] = None,
    test_name: Optional[str] = None,
) -> PlaybookResponse:
  """Creates a playbook.

  Args:
    playbook_identifier: identifier of playbook to update
    trigger: trigger that starts the playbook (Made with create_trigger)
    actions: a list of actions
    is_enabled: is playbook enabled
    is_debug: is playbook in debug mode
    playbook_name: name of the new playbook
    playbook_description: description of the new playbook
    priority: playbook priority
    category_id: id of the folder for the playbook
    category_name: name of the folder for the playbook
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  old_playbook = get_playbook_data(identifier=playbook_identifier)
  playbook_json = old_playbook.response_json
  if playbook_name:
    playbook_json["name"] = playbook_name
  if playbook_description:
    playbook_json["description"] = playbook_description
  if trigger:
    playbook_json["trigger"] = trigger
  if is_enabled is not None:
    playbook_json["isEnabled"] = is_enabled
  if is_debug is not None:
    playbook_json["isDebugMode"] = is_debug
  if priority:
    playbook_json["priority"] = priority
  if category_id:
    playbook_json["categoryId"] = category_id
  if category_name:
    playbook_json["categoryName"] = category_name
  if actions:
    steps = []
    steps_ids = []
    pb_id = old_playbook.identifier
    for action in actions:
      action["workflowIdentifier"] = pb_id
      steps.append(action)
      steps_ids.append(action["identifier"])
    step_relations = []
    if len(steps) > 1:
      for step_id in range(len(steps)-1):
        relation = {
            "fromStep": steps[step_id]["identifier"],
            "toStep": steps[step_id+1]["identifier"],
            "condition": ""
        }
        step_relations.append(relation)
    playbook_json["steps"] = steps
    playbook_json["stepsRelations"] = step_relations
  response = post_with_admin_credentials(
      url=API_PLAYBOOK_CREATE_ENDPOINT,
      payload=playbook_json,
      test_name=test_name,
      ignore_404=True,
  )
  if response.status_code == 404:
    final_response = get_playbook_data(identifier=playbook_identifier)
  else:
    final_response = PlaybookResponse(response=response)
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Updated playbook # {playbook_identifier} for {test_name}"
        ),
        failure_message=
            f"Failed to update playbook #{playbook_identifier} for {test_name}",
            ignore_404=True
    )
  return final_response


def insert_action_into_playbook(
    playbook_identifier: str,
    action: dict,
    action_index: int,
    test_name: Optional[str] = None,
) -> PlaybookResponse:
  """Inserts an action into a playbook at a given index.

  Args:
    playbook_identifier: id of the playbook to insert action into
    action: dictionary with action parameters
    action_index: index at which the action should be inserted
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookResponse object with updated playbook data
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  case_data = get_playbook_data(
      identifier=playbook_identifier,
      test_name=test_name,
  )
  old_steps = case_data.steps
  old_steps.insert(action_index, action)
  return update_playbook(
      playbook_identifier=playbook_identifier,
      actions=old_steps,
      test_name=test_name,
  )


def delete_action_from_playbook(
    playbook_identifier: str,
    action_name: str,
    test_name: Optional[str] = None,
) -> PlaybookResponse:
  """Deletes ALL actions with the specified name from a playbook.

  Args:
    playbook_identifier: id of the playbook to delete action from
    action_name: name of the action to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookResponse object with updated playbook data
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  case_data = get_playbook_data(
      identifier=playbook_identifier,
      test_name=test_name,
  )
  old_steps = case_data.steps
  new_steps = old_steps.copy()
  for value in old_steps:
    if value.get("instanceName", None) == action_name:
      new_steps.remove(value)
  return update_playbook(
      playbook_identifier=playbook_identifier,
      actions=new_steps,
      test_name=test_name,
  )


def duplicate_playbooks(
    playbook_identifiers: list[str],
    environments: Optional[list[str]] = None,
    priority: int = 0,
    category_id: int = 0,
    test_name: Optional[str] = None,
) -> PlaybookResponse:
  """Duplicates the specified playbooks.

  Args:
    playbook_identifiers: list of playbook identifiers to copy
    environments: list of environments. Set to "Default Enviornment" if None
      (defaults to None).
    priority: the new priority for the copies. Copies the original if set to 0
      (defaults to 0)
    category_id: folder for the copies. Default folder is 0 (defaults to 0)
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookResponse object if one playbook was copied, a list of
      PlaybookResponse objects if multiple were copied
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "categoryId": category_id,
      "environments": environments,
      "identifiers": playbook_identifiers,
      "priority": priority,
  }
  responses = post_with_admin_credentials(
      url=API_DUPLICATE_PLAYBOOK_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  all_responses = [
      PlaybookResponse(response=response) for response in responses.json()
  ]
  return all_responses if len(all_responses) > 2 else all_responses[0]


def add_playbook_folder(
    is_default: bool = False,
    test_name: Optional[str] = None,
) -> PlaybookFolder:
  """Creates a new playbook folder.

  Args:
    is_default: is the folder default (defaults to False)
    test_name: name of the test (Defaults to None)

  Returns:
    A PlaybookFolder object with playbook folder data
  """
  name = siemplify.utils.generate_random_name(start="Folder_")
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "id": 0,
      "name": name,
      "categoryState": 0,
      "isDefaultCategory": is_default,
  }
  response = post_with_admin_credentials(
      url=API_CREATE_PLAYBOOK_FOLDER,
      payload=payload,
      test_name=test_name,
  )
  final_response = PlaybookFolder(response=response)
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_name=final_response.id,
        item_type="playbook_folder",
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Created playbook folder '{name}'"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to create playbook folder '{name}'"
            f" for {test_name}"
        ),
    )
  return final_response


def delete_playbook_folders(
    folder_ids: list[int],
    test_name: Optional[str] = None,
) -> Response:
  """Deletes playbook folders in the list.

  Args:
    folder_ids: list of ids of the folders to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_PLAYBOOK_FOLDERS,
      payload={"ids": folder_ids},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Deleted playbook folders with IDs {folder_ids} for {test_name}"
        ),
        failure_message=(
            f"Failed to delete playbook folders with IDs {folder_ids}"
            f" for {test_name}"
        ),
    )
  return response


def _fetch_playbook_folders(
    test_name: Optional[str] = None,
) -> Response:
  """Helper function for the get_all_playbook_folders.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_PLAYBOOK_FOLDERS,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched playbook folders for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch playbook folders for {test_name}"
        ),
    )
  return response


def get_all_playbook_folders() -> list[PlaybookFolder]:
  """Fetches all playbook folders.

  Returns:
    A list of PlaybookFolder objects or one object if there is one folder
  """
  responses = _fetch_playbook_folders()
  all_responses = [
      PlaybookFolder(response=response) for response in responses.json()
  ]
  return all_responses if len(all_responses) > 2 else all_responses[0]


def delete_all_custom_folders():
  """Deletes all custom playbook folders.
  """
  all_folders = get_all_playbook_folders()
  to_delete = []
  if isinstance(all_folders, list):
    for folder in all_folders:
      if folder.id != 1 and not folder.is_default:
        to_delete.append(folder.id)
    delete_playbook_folders(folder_ids=to_delete)


def export_playbook(
    playbook_identifiers: list[str],
    test_name: Optional[str] = None,
) -> Response:
  """Deletes playbook folders in the list.

  Args:
    playbook_identifiers: identifier of the exported playbook
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_EXPORT_PLAYBOOK_ENDPOINT,
      payload={"identifiers": playbook_identifiers},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Exported playbooks with IDs: {playbook_identifiers}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to export playbooks with IDs: {playbook_identifiers}"
            f" for {test_name}"
        ),
    )
  return response


def import_playbook(
    blob: str,
    file_name: str,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes playbook folders in the list.

  Args:
    blob: the encrypted file string
    file_name: file name of the imported pb
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_IMPORT_PLAYBOOK_ENDPOINT,
      payload={"blob": blob, "fileName": file_name},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Imported playbook from file {file_name}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to import playbook from file {file_name}"
            f" for {test_name}"
        ),
    )
  return response


def get_playbook_instance_summmary(
    case_id: int,
    alert_identifier: str,
    definition_id: str,
    workflow_instance_id: Optional[int] = 0,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches playbook instance summary data.

  Args:
    case_id: case id number
    alert_identifier: alert identifier number
    definition_id: playbook identifier
    workflow_instance_id: workflow instance id (Defaults to 0)
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "caseId": case_id,
      "alertIdentifier": alert_identifier,
      "shouldFetchSteps": True,
      "definitionIdentifier": definition_id,
      "parentWorkflowInstanceId": workflow_instance_id,
      "nestedStepIdentifier": None
  }
  response = post_with_admin_credentials(
      url=API_GET_WORKFLOW_INSTANCE_SUMMARY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched playbook instance summary for case {case_id}"
            f" & alert {alert_identifier} for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch playbook instance summary for case {case_id}"
            f" & alert {alert_identifier} for {test_name}"
        ),
    )
  return response


def create_merged_actions_playbook(
    trigger: Optional[dict] = None,
    actions: Optional[list[dict]] = None,
    is_enabled: bool = True,
    is_debug: bool = False,
    playbook_name: Optional[str] = None,
    playbook_description: str = "Test Description",
    environments: Optional[list[str]] = None,
    priority: int = 2,
    category_id: int = 1,
    category_name: str = "Default",
    use_previous_flow_action: Optional[bool] = False,
    use_condition: Optional[bool] = False,
    playbook_type: Optional[int] = 0,
    view_template: Optional[bool] = None,
    test_name: Optional[str] = None,
    #use_merge: Optional[bool] = False,
) -> PlaybookResponse:
  """Creates a playbook.

  Args:
    trigger: trigger that starts the playbook (Made with create_trigger)
    actions: a list of actions
    is_enabled: is playbook enabled (defaults to True)
    is_debug: is playbook in debug mode (defaults to False)
    playbook_name: name of the new playbook. Generates a random
      name if None (defaults to None)
    playbook_description: description of the new playbook
      (defaults to "Test Description")
    environments: names of the environments. Set to "Default Environment"
      if None (defaults to None)
    priority: playbook priority (defaults to 2)
    category_id: id of the folder for the playbook (defaults to 1)
    category_name: name of the folder for the playbook (defaults to "Default")
    use_previous_flow_action: to use previous condition action flow, set true
    use_condition: to use condition action flow, set true
    view_template: for adding a view to a playbook, use the view template
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  playbook_id = siemplify.utils.generate_random_id()
  action_id = siemplify.utils.generate_random_id()
  if view_template:
    view_template = [
          {
        "id": 0,
        "identifier": action_id,
        "name": "Automation_View",
        "creator": None,
        "playbookIdentifier": playbook_id,
        "type": 0,
        "widgets": [
        {
          "metadata": {
            "id": 0,
            "identifier": action_id,
            "title": "Automation Test",
            "width": 2,
            "order": 1,
            "description": "Automation Test",
            "type": 8,
            "templateIdentifier": action_id,
            "predefinedWidgetTemplateIdentifier": None,
            "actionIdentifier": None,
            "stepIdentifier": None,
            "stepIntegration": None,
            "presentIfEmpty": False,
            "conditionsGroup": {
              "conditions": [],
              "logicalOperator": 0
            }
          },
          "config": {
            "text": "Automation Test"
          }
        }
      ],
      "roles": [
        1
      ],
      "creationTimeUnixTimeInMs": 0
    }
  ]
  user = siemplify.users.get_admin_user_data().username
  if not playbook_name:
    playbook_name = siemplify.utils.generate_random_name(start="Playbook_")
  if not environments:
    environments = ["Default Environment"]
  if not trigger:
    trigger = create_trigger()
  if not actions:
    action_flow = siemplify.payloads.playbook_actions.add_condition_flow()
    action_1 = siemplify.payloads.playbook_actions.add_entity_insight()
    action_2 = siemplify.payloads.playbook_actions.add_entity_insight()
    action_3 = siemplify.payloads.playbook_actions.add_entity_insight()
    actions = [action_flow, action_1, action_2, action_3]
  steps = []
  steps_ids = []
  for action in actions:
    action["workflowIdentifier"] = playbook_id
    action["debugData"]["originalWorkflowIdentifier"] = playbook_id
    steps.append(action)
    steps_ids.append(action["identifier"])
  step_relations = []
  if use_previous_flow_action:
    step_relations[1]["condition"] = "1"
  if use_condition:
    step_relations[0]["condition"] = "1"
  payload = {
      "id": 0,
      "categoryId": category_id,
      "categoryName": category_name,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": int(time.time()) * 1000,
      "modifiedBy": user,
      "playbookType": playbook_type,
      "identifier": playbook_id,
      "environments": environments,
      "version": 1,
      "isEnabled": is_enabled,
      "isDebugMode": is_debug,
      "debugData": None,
      "name": playbook_name,
      "description": playbook_description,
      "creator": user,
      "priority": priority,
      "trigger": trigger,
      "steps": steps,
      "originalPlaybookIdentifier": playbook_id,
      "stepsRelations": [{
      "fromStep": action_flow["identifier"],
      "toStep": action_1["identifier"],
      "condition": "1"
    },
    {
      "fromStep": action_flow["identifier"],
      "toStep": action_2["identifier"],
      "condition": "2"
    },
    {
      "fromStep": action_1["identifier"],
      "toStep": action_3["identifier"],
      "condition": ""
    },
    {
      "fromStep": action_2["identifier"],
      "toStep": action_3["identifier"],
      "condition": ""
    }],
      "templateName": "",
      "defaultAccessLevel": 2,
      "entityAccessLevel": 2,
      "permissions": [],
      "hasRestrictedEnvironments": False,
      "overviewTemplates": view_template,
  }
  response = post_with_admin_credentials(
      url=API_PLAYBOOK_CREATE_ENDPOINT,
      payload=payload,
      test_name=test_name,
      ignore_404=True,
  )
  if response.status_code == 404:
    final_response = get_playbook_data(identifier=playbook_id)
  else:
    final_response = PlaybookResponse(response=response)
  if test_name:
    log_and_assert(
        ignore_404=True,
        response=response,
        test_name=test_name,
        success_message=(
            f"Created merged actions playbook '{playbook_name}'"
            f" or {test_name}"
        ),
        failure_message=(
            f"Failed to create merged actions playbook '{playbook_name}'"
            f" for {test_name}"
        ),
    )
  return final_response


def wait_for_playbook_status(
    case_id: str,
    alert_id: str,
    playbook_name: str,
    status: int,
    retries: int = 10,
    cadence: int = 5,
) -> int:
  """_summary_

  Args:
    case_id: _description_
    alert_id: _description_
    playbook_name: _description_
    status: _description_
    retries: _description_. Defaults to 10.
    cadence: _description_. Defaults to 5.

  Returns:
    A playbook status
  """
  received_status = 0
  attempts = 0
  while attempts < retries:
    pb_summary = get_playbook_summary(
        case_id=case_id,
        alert_id=alert_id,
    )
    playbook_find = siemplify.utils.find_key_value_in_json(
        json_data=pb_summary,
        key="name",
        value=playbook_name,
    )
    if playbook_find and isinstance(playbook_find, list):
      received_status = playbook_find[0].get("status")
    elif isinstance(playbook_find, dict):
      received_status = playbook_find.get("status")
    if received_status == status:
      attempts += retries
      return received_status
    else:
      attempts += 1
      if attempts >= retries:
        return received_status
      time.sleep(cadence)


def wait_for_playbook_status_in_case(
    case_id: str,
    playbook_name: str,
    status: int,
    retries: int = 10,
    cadence: int = 5,
) -> int:
  """Checks if playbook was attached to a case a specified amount of times.

  Args:
    case_id: id of the case with the playbook
    playbook_name: name of the playbook
    status: status of the playbook
    retries: number of retries. Defaults to 10.
    cadence: time to sleep between retries. Defaults to 5.

  Returns:
    A playbook status
  """
  attempts = 0
  while attempts < retries:
    case_details = siemplify.cases.get_case_full_details(case_id=case_id)
    wall_data = case_details.wall_data
    check_name = siemplify.utils.find_key_value_in_json(
        json_data=wall_data,
        key="playbookName",
        value=playbook_name
    )
    status_code = check_name.get("status")
    if status == status_code:
      attempts += retries
      return status_code
    else:
      attempts += 1
      if attempts >= retries:
        return status_code
      time.sleep(cadence)


def wait_for_playbook_in_case(
    case_id: str,
    playbook_name: str,
    retries: int = 10,
    cadence: int = 5,
) -> int:
  """Checks if playbook was attached to a case a specified amount of times.

  Args:
    case_id: id of the case with the playbook
    playbook_name: name of the playbook
    retries: number of retries. Defaults to 10.
    cadence: time to sleep between retries. Defaults to 5.

  Returns:
    A playbook status
  """
  attempts = 0
  while attempts < retries:
    case_details = siemplify.cases.get_case_full_details(case_id=case_id)
    wall_data = case_details.wall_data
    check_name = siemplify.utils.find_key_value_in_json(
        json_data=wall_data,
        key="playbookName",
        value=playbook_name
    )
    if check_name:
      attempts += retries
      return check_name
    else:
      attempts += 1
      if attempts >= retries:
        return check_name
      time.sleep(cadence)
