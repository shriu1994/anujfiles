"""Module containing utility functions for siemplify client.
"""
import csv
import json
import os
import random
import base64
from typing import Optional, Union
from deepdiff import DeepDiff
from google.cloud import secretmanager
from google.oauth2 import service_account
from logger.html_logger import log_event
from requests import Response
from source.config import CUSTOMER
from source.config import PROJECT_ID
from source.config import SERVICE_ACCOUNT_JSON
from source.utils import check_test_name_can_not_be_none


CHECK_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CLEANUP_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cleanup.json"
)
LOGS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
)


def generate_random_id() -> str:
  """Generates a random id in xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx format.

  Returns:
    A generated ID
  """
  characters = "abcdef0123456789"
  length_pattern = (8, 4, 4, 4, 12)
  end_result = []
  for part in length_pattern:
    result = "".join(random.choice(characters) for i in range(part))
    end_result.append(result)
  return "-".join(end_result)


def generate_random_name(start: str = "Test_") -> str:
  """Generates a random name starting with set string + random letters/numbers.

  Args:
    start: The fixed starting string (Defaults to "Test")

  Returns:
    A string with random name
  """
  characters = "abcdefgh0123456789"
  return start + "".join(random.choice(characters) for i in range(10))


def enable_all_cleanup():
  """Sets all cleanup functions in JSON to true.
  """
  with open(CLEANUP_PATH, "r") as f:
    data = json.load(f)
    for key, value in data.items():
      data[key] = 1
    json_data = json.dumps(data)
  with open(CLEANUP_PATH, "w") as f:
    f.write(json_data)


def check_case_wall(
    case_data: Response,
    requirements: dict,
) -> bool:
  """Checks if the case wall has needed actions.

  Args:
    case_data: response object from simulate_cases
    requirements: dict with needed data to check
  Returns:
    Status of the check
  """
  check_data = {
      "comment": False,
      "task": False,
      "assigned": False,
      "tag": False,
      "stage": False,
      "priority": False,
  }
  case_json = case_data["wallData"]
  for data in case_json:
    if "activityKind" in data.keys():
      kind = data["activityKind"]
      if kind == 10 and "Triage" not in data["description"]:
        check_data["stage"] = True
      elif kind == 15:
        check_data["tag"] = True
      elif kind == 12:
        check_data["priority"] = True
      elif kind == 8:
        check_data["assigned"] = True
    elif "content" in data.keys():
      check_data["task"] = True
    elif "comment" in data.keys():
      check_data["comment"] = True

  return requirements == check_data


def compare_csv(input_csv: list, compare_to: str) -> bool:
  """Checks if string containing csv is equal to csv file.

  Args:
    input_csv: csv represented by a list of strings
    compare_to: name of the .csv file in /AutomationBE folder
      (with or without .csv)
  Returns:
    A list of tuples with differences between the expected csv and received csv
      with expected value in index #0 and received value in index #1
  """
  if not compare_to.endswith(".csv"):
    file_name = f"{compare_to}.csv"
  else:
    file_name = compare_to
  file_path = os.path.join(CHECK_PATH, file_name)
  original = []
  with open(file_path, "r", encoding="utf-8-sig") as read_obj:
    csv_reader = csv.reader(read_obj)
    for line in csv_reader:
      original.append(line)
  check = []
  differences = []
  for line in input_csv:
    check.append(line.split(","))
  if len(original) != len(check):
    log_event(
        message="Compared CSV's have different lengths!",
        details=f"File length: {len(original)}, Received length: {len(check)}",
        success=False,
    )
    raise ValueError("Compared CSV's have different lengths!!")
  for i, value in enumerate(original):
    if set(value) != set(check[i]):
      differences.append((value, check[i]))
  return differences


def _compare_json(
    input_json: Union[list, dict],
    compare_to: str,
) -> bool:
  """Checks if json is equal to json file.

  Args:
    input_json: json represented by list OR dict
    compare_to: name of the .json file in /checks folder
      (with or without .json)
  Returns:
    True if json is equal, False if not
  """
  if not compare_to.endswith(".json"):
    file_name = f"{compare_to}.json"
  else:
    file_name = compare_to
  file_path = os.path.join(CHECK_PATH, file_name)
  with open(file_path, "r", encoding="utf-8-sig") as read_obj:
    data = json.load(read_obj)
    if isinstance(data, dict) and isinstance(input_json, dict):
      return data == input_json
    elif isinstance(data, list) and isinstance(input_json, list):
      for i in range(len(data)):
        if data[i] != input_json[i]:
          return False
    else:
      raise ValueError("JSON file or Input is wrong type")
  return True


def find_key_in_json(
    json_data: Union[list, dict, Response],
    key: str,
) -> Union[list, dict]:
  """Finds all values with the chosen key.

  Args:
    json_data: input JSON data
    key: a key to find
  Returns:
    A list of dicts with values OR a dict if only 1 found
  """
  result = []
  if isinstance(json_data, Response):
    input_json = json_data.json()
    json_data = input_json
  if isinstance(json_data, dict):
    if key in json_data:
      result.append(json_data[key])
  if isinstance(json_data, list):
    for item in json_data:
      if key in item:
        result.append(item[key])

  return result[0] if len(result) == 1 else result


def find_key_value_in_json(
    json_data: Union[list, dict, Response],
    key: str,
    value,
) -> list:
  """Finds all key:value pairs with the chosen key and value.

  Args:
    json_data: input JSON data
    key: a key to find
    value: a value to find
  Returns:
    A list of dicts with key:value pairs OR a dict if only 1 found
  """
  result = []
  if isinstance(json_data, Response):
    input_json = json_data.json()
    json_data = input_json
  if isinstance(json_data, dict):
    if key in json_data and json_data[key] == value:
      result.append({key: value})
  if isinstance(json_data, list):
    for item in json_data:
      if key in item and item[key] == value:
        result.append(item)

  return result[0] if len(result) == 1 else result


def find_dict_by_key_in_dicts_list(
    dicts_list: list[dict],
    key: str,
    value: str
):
  """Filters list of dicts by key and value inside dict.

  Args:
    dicts_list: list of dictionaries to be filtered
    key: key in dict to be used for filter
    value: key's value to be used for filter

  Returns:
    A specific dictionary
  """
  result = list(filter(lambda d: d[key] == value, dicts_list))
  if not result:
    return []
  return result[0]


def remove_keys_from_json(
    json_data: Union[dict, Response],
    remove_keys: list[str],
) -> dict:
  """Removes all keys in the list from json.

  Args:
    json_data: a response object or a dictionary
    remove_keys: a list of keys to remove

  Returns:
    A dictionary without listed keys
  """
  for key in remove_keys:
    remove_keys_from_json_helper(obj=json_data, bad_key=key)


def remove_keys_from_json_helper(obj, bad_key: str) -> None:
  """delete <bad_key>-value from Dictionary <ojb> object.

  Args:
      obj: Dictionary object to delete keys from
      bad_key: the key to delete from 'obj'
  """
  if isinstance(obj, dict):

    for key in list(obj.keys()):
      if bad_key in key:
        del obj[key]
      else:
        remove_keys_from_json_helper(obj[key], bad_key)
  elif isinstance(obj, list):
    for i in reversed(range(len(obj))):
      if not isinstance(obj[i], int) and bad_key in obj[i]:
        del obj[i]
      else:
        remove_keys_from_json_helper(obj[i], bad_key)
  else:
    # neither a dict nor a list, do nothing
    pass


def leave_keys_in_json(
    json_data: Union[dict, Response],
    leave_keys: list[str],
) -> dict:
  """Removes all keys from json except the ones in the list.

  Args:
    json_data: a response object or a dictionary
    leave_keys: a list of keys to leave in the dictionary

  Returns:
    A dictionary without listed keys
  """
  if isinstance(json_data, Response):
    json_resp = json.json()
    json_data = json_resp
  keys_to_delete = []
  for key in json_data.keys():
    if key not in leave_keys:
      keys_to_delete.append(key)
  for key in keys_to_delete:
    json_data.pop(key, None)

  return json_data


def get_dicts_diff(
    actual: dict,
    expected: dict,
    **kwargs
):
  """Gets the difference between 2 dicts.

  Uses deepdiff module, documentation: https://zepworks.com/deepdiff/6.2.1/

  Args:
    actual: actual item to compare
    expected: expected item to compare with
    **kwargs: additional arguments to pass to DeepDiff()

  Returns:
    DeepDiff in a form of a dictionary
  """
  return DeepDiff(expected, actual, **kwargs)


def stringify_dict(input_dict: dict) -> str:
  """Converts dictionary into a string.

  Args:
    input_dict: initial dictionary

  Returns:
    A stringified dictionary
  """
  return json.dumps(input_dict)


def update_list_of_dicts(
    to_update: list[dict],
    update_with: list[dict],
) -> list[dict]:
  """Updates list of dictionaries with list of dictionaries provided.

  Changes / adds only dict fields that were provided

  Args:
    to_update: list of dictionaries to be updated
    update_with: list of dictionaries with fields for update

  Returns:
    New updated list of dictionaries
  """
  return [
      {**d, **update_item} for d in to_update for update_item in update_with
  ]


def next_request_should_fail(
    test_name: Optional[str] = None,
):
  """Indicates that the next request in the test should fail.

  If the flow of the test indicates that the next request should fail for
    some reason, like testing if a user can access certain endpoints, use this
    function and if the next request fails it will not fail the test and in
    the log it will display the failure message with a success icon.

  Args:
    test_name: name of the test (Defaults to None)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  data["next_request_should_fail"] = True
  json_data = json.dumps(data)
  with open(path, "w") as file:
    file.write(json_data)


def get_secret(
    secret_id: str,
    version_id: Optional[str] = "latest",
) -> str:
  """Gets a secret from Secret Manager.

  Args:
    secret_id: secret name to get
    version_id: secret version

  Returns:
    The value of the secret
  """
  credentials = service_account.Credentials.from_service_account_info(
      json.loads(SERVICE_ACCOUNT_JSON),
      scopes=["https://www.googleapis.com/auth/cloud-platform"],)

  client = secretmanager.SecretManagerServiceClient(credentials=credentials)
  secret_id = CUSTOMER + "_" + secret_id
  name = f"projects/{PROJECT_ID}/secrets/{secret_id}/versions/{version_id}"
  response = client.access_secret_version(request={"name": name})

  return response.payload.data.decode("UTF-8")

def get_base64_from_image(file_path, file_name) -> str:
  """Generates base64 string from image

   Args:
     file_path: relative path to folder inside parallel-automation-be
     file_name: file name

   Returns:
     The base64 string value of given image
  """
  path = f"{os.getcwd()}/{file_path}/{file_name}"
  with open(path, "rb") as image_file:
    encoded_string = base64.b64encode(image_file.read())
  return encoded_string.decode("utf-8")
