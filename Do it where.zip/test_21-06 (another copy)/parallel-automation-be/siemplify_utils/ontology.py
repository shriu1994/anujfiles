"""Module containing actions to manipulate settings in siemplify client.
"""
from typing import Optional
# API endpoints
from endpoints.ontology import API_DELETE_VISUAL_FAMILY_ENDPOINT
from endpoints.ontology import API_GET_ONTOLOGY_MAPPING_RULES_ENDPOINT
from endpoints.ontology import API_GET_ONTOLOGY_STATUS_RECORDS_ENDPOINT
from endpoints.ontology import API_GET_VISUAL_FAMILY_ENDPOINT
from endpoints.ontology import API_POST_CREATE_UPDATE_VISUAL_FAMILY_ENDPOINT
from endpoints.ontology import API_POST_IMPORT_ONTOLOGY_ENDPOINT
from endpoints.ontology import API_POST_IMPORT_VISUAL_FAMILY_ENDPOINT
from endpoints.ontology import API_SET_MAPPING_RULE

# Requests
from requests import Response
# Source
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import add_restore_requirement_to_test
from source.utils import log_and_assert
from source.utils import get_with_admin_credentials
from source.utils import post_with_admin_credentials
from source.enums import MappingExtractionFunctionType
from source.enums import MappingTransormationFunctionType
from source.enums import MappingFieldType
from source.enums import MappingComparisonType
from source.enums import OntologyConfigurationLevel


class OntologyMappingRulesResponse:
  """Class to represent ontology mapping rules in the response.
  """

  def __init__(self, response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.family_fiels = self.response_json.get("familyFields", {})
    self.system_fields = self.response_json.get("systemFields", {})


class PermissionGroup:
  """Class to represent ontology mapping rules in the response.
  """

  def __init__(self, response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.family_fiels = self.response_json.get("familyFields", {})
    self.system_fields = self.response_json.get("systemFields", {})


def get_ontology_mapping_rules(
    source: str,
    product: Optional[str] = None,
    event_name: Optional[str] = None,
    test_name: Optional[str] = None,
) -> OntologyMappingRulesResponse:
  """Gets ontology mapping rules for source, product or event.

  Args:
    source: source name. Must always be sent.
    product: product name if None - will fetch the next higher level.
    event_name: event name, if None - will fetch the next higher level.
    test_name: name of the calling test (Defaults to None)

  Returns:
    An OntologyMappingRulesResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "eventName": event_name,
      "product": product,
      "source": source,
  }
  response = post_with_admin_credentials(
      url=API_GET_ONTOLOGY_MAPPING_RULES_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Fetched ontology mapping rules for {test_name}"
      ),
      failure_message=(
          f"Failed to fetch ontology mapping rules for {test_name}"
      ),
  )
  return OntologyMappingRulesResponse(response=response)


def get_ontology_status_records(
    search_term: Optional[str] = "",
    requested_page: Optional[int] = 0,
    page_size: Optional[int] = 50,
    test_name: Optional[str] = None,
) -> Response:
  """Get ontology status records.

  Args:
    search_term: generic search term
    requested_page: number of pages in the result
    page_size: size of each page in the result
    test_name: name of the test (Defaults to None)

  Returns:
    Ontology status records.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "searchTerm": search_term,
      "requestedPage": requested_page,
      "pageSize": page_size,
  }
  response = post_with_admin_credentials(
      url=API_GET_ONTOLOGY_STATUS_RECORDS_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Fetched ontology status records for {test_name}"
      ),
      failure_message=(
          f"Failed to fetch ontology status records for {test_name}"
      ),
  )
  return response


def upload_visual_family(
    blob: str = "",
    file_name: str = "",
    test_name: Optional[str] = None,
) -> Response:
  """upload visual family.

  Args:
    blob: base64 of the file
    file_name: file name to upload
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "blob": blob,
      "fileName": file_name,
  }
  response = post_with_admin_credentials(
      url=API_POST_IMPORT_VISUAL_FAMILY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Uploaded visual family file for {test_name}"
      ),
      failure_message=(
          f"Failed to upload visual family file for {test_name}"
      ),
  )
  return response


def upload_ontology_file(
    blob: str = "",
    file_name: str = "",
    exisiting_visual_family: bool = True,
    test_name: Optional[str] = None,
) -> Response:
  """Upload ontology family file.

  Args:
    blob: base64 of the file
    file_name: file name to upload
    exisiting_visual_family: check if family already exists
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "blob": blob,
      "fileName": file_name,
      "replaceExistingVisualFamily": exisiting_visual_family
  }
  response = post_with_admin_credentials(
      url=API_POST_IMPORT_ONTOLOGY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Uploaded ontology file for {test_name}"
      ),
      failure_message=(
          f"Failed to upload ontology file for {test_name}"
      ),
  )
  return response


def set_field_mapping(
    field_name: Optional[str] = None,
    source: Optional[str] = None,
    field_type: MappingFieldType = MappingFieldType.FAMILY,
    product: Optional[str] = None,
    event: Optional[str] = None,
    primary_field_match_term: Optional[str] = None,
    primary_field_compare_type: MappingComparisonType = 
        MappingComparisonType.EQUAL,
    secondary_field_match_term: Optional[str] = None,
    secondary_field_compare_type: MappingComparisonType = 
        MappingComparisonType.EQUAL,
    third_field_match_term: Optional[str] = None,
    third_field_compare_type: MappingComparisonType = 
        MappingComparisonType.EQUAL,
    extract_func: MappingExtractionFunctionType = 
        MappingExtractionFunctionType.DELIMITER,
    extract_param: str = ",",
    transform_func: MappingTransormationFunctionType =
        MappingTransormationFunctionType.TO_STRING,
    transform_param: Optional[str] = None,
    full_payload: Optional[list[dict]] = None,
    test_name = None
) -> Response:
  """
  Sets the given field mapping for event, product, or source, 
  with the given mapping.

  Args:
    field_name: name of field to map
    source: name of source to map field of/under. Must be given.
    field_type: MappingFieldType. Defaults to FAMILY
    product: name of product to map field of/under. If none, sets upper level - source 
    event: name of event to map field of. If none, sets upper level - product
    primary_field_match_term: first string to compare to
    primary_field_compare_type: first MappingComparisonType to compare by
    secondary_field_match_term: second string to compare to
    secondary_field_compare_type: second MappingComparisonType to compare by
    third_field_match_term: third string to compare to
    third_field_compare_type: third MappingComparisonType to compare by
    extract_func: MappingExtractionFunctionType
    extract_param: parameter for the extraction function
    transform_func: MappingTransormationFunctionType
    transform_param: parameter for transformation function
    full_payload: if available, the full payload for the request.
      Can be sent alone
    test_name: name of the calling test
  """
  if not test_name:
    test_name = check_test_name_can_be_none()

  if test_name:
    add_restore_requirement_to_test(
      test_name=test_name,
      item_type="fields_mapping",
      fetch_payload={
        "source": source,
	    	"product": product,
	    	"eventName": event
      },
      item_metadata={
        "securityEventFieldName": field_name,
        "targetFieldType": field_type.value
      }
    )

  if full_payload:
    payload = full_payload
  else:
    config_level = OntologyConfigurationLevel.EVENT if event \
        else OntologyConfigurationLevel.PRODUCT if product \
        else OntologyConfigurationLevel.SOURCE

    payload = [{
	    "mappingRule": {
	    	"source": source,
	    	"product": product,
	    	"eventName": event,
	    	"securityEventFieldName": field_name,
	    	"transformationFunction": transform_func.value,
	    	"transformationFunctionParam": transform_param,
	    	"rawDataPrimaryFieldMatchTerm": primary_field_match_term,
	    	"rawDataPrimaryFieldComparisonType": primary_field_compare_type.value,
	    	"rawDataSecondaryFieldMatchTerm": secondary_field_match_term,
	    	"rawDataSecondaryFieldComparisonType": secondary_field_compare_type.value,
	    	"rawDataThirdFieldMatchTerm": third_field_match_term,
	    	"rawDataThirdFieldComparisonType": third_field_compare_type.value,
	    	"enrichmentFields": None,
	    	"isArtifact": True,
	    	"extractionFunctionParam": extract_param,
	    	"extractionFunction": extract_func.value,
	    	"id": 0,
	    	"creationTimeUnixTimeInMs": 1689757395430,
	    	"modificationTimeUnixTimeInMs": 1689757395430
	    },
	    "ontologyConfigurationLevel": config_level.value,
	    "targetFieldType": field_type.value
    }]

  response = post_with_admin_credentials(
    url=API_SET_MAPPING_RULE,
    payload=payload,
    test_name=test_name
  )
  
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Changed field mapping for {test_name}"
      ),
      failure_message=(
          f"Failed to change field mapping for {test_name}"
      )
  )

  return response

def create_visual_family(
    family_name: str = "example",
    test_name: Optional[str] = None,
) -> Response:
  """Create a new Visual Family

  Args:
    family_name: visual family name (Defaults to "example")
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "visualFamilyDataModel": {
      "id": 0,
      "imageBase64": None,
      "description": "for testing",
      "family": family_name,
      "isCustom": True,
      "rules": [
        {
          "primarySource": "SourceHostName",
          "secondarySource": "SourceAddress",
          "thirdSource": "SourceUserName",
          "fourthSource": "SourceProcessName",
          "relationType": "Type",
          "primaryDestination": "DestinationHostName",
          "secondaryDestination": "DestinationAddress",
          "thirdDestination": "DestinationUserName",
          "fourthDestination": "DestinationProcessName",
          "id": 0,
          "visualFamily": family_name
        }
      ]
    }
  }
  response = post_with_admin_credentials(
      url=API_POST_CREATE_UPDATE_VISUAL_FAMILY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Visual Family created for {test_name}"
      ),
      failure_message=(
          f"Failed to create Visaul Family file for {test_name}"
      ),
  )
  result = get_with_admin_credentials(
      url=API_GET_VISUAL_FAMILY_ENDPOINT,
      test_name=test_name,
  )
  return response

def update_visual_family(
    family_name: str = "example",
    description: str = "testing",
    id: int = 0,

    test_name: Optional[str] = None,
) -> Response:
  """Updates a existing Visual Family. Ignore 404, 400 error code
  for cases of editing system families.

  Args:
    family_name: visual family name (Defaults to "example")
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "visualFamilyDataModel": {
      "id": id,
      "imageBase64": None,
      "description": description,
      "family": family_name,
      "isCustom": True,
      "rules": [
        {
          "primarySource": "SourceHostName",
          "secondarySource": "SourceAddress",
          "thirdSource": "SourceUserName",
          "fourthSource": "SourceProcessName",
          "relationType": "Type",
          "primaryDestination": "DestinationHostName",
          "secondaryDestination": "DestinationAddress",
          "thirdDestination": "DestinationUserName",
          "fourthDestination": "DestinationProcessName",
          "id": id,
          "visualFamily": family_name
        }
      ]
    }
  }
  response = post_with_admin_credentials(
      url=API_POST_CREATE_UPDATE_VISUAL_FAMILY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Visual Family updated for {test_name}"
      ),
      failure_message=(
          f"Failed to update Visaul Family file for {test_name}"
      ),
      ignore_404=True,
      ignore_400=True
  )
  return response

def fetch_visual_families(
    test_name: Optional[str] = None,
) -> Response:
  """Fetches the list of Visual Families

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_VISUAL_FAMILY_ENDPOINT,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Visual Families fetched for {test_name}"
      ),
      failure_message=(
          f"Failed to fetch Visaul Family for {test_name}"
      )
  )
  return response

def delete_visual_families(
    family_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes Visual Family with specific ID.
  Ignores cases of deleting system visual families.

  Args:
    family_id: visual family id (Mandatory Parameter)
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_DELETE_VISUAL_FAMILY_ENDPOINT.format(family_id),
      test_name=test_name,
  )
  if response.status_code == 500:
    return response
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Visual Families deleted for {test_name}"
      ),
      failure_message=(
          f"Failed to delete Visaul Family for {test_name}"
      )
  )
  return response