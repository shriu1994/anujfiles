"""Module containing actions and DTOs for external authentication settings.
"""
from typing import Optional
from endpoints.external_auth_settings import (
    API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT_BASE
)
from endpoints.external_auth_settings import (
    API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT
)
from requests import Response
from source import enums
# Source
from source.utils import add_created_item_to_test
from source.utils import check_test_name_can_be_none
from source.utils import delete_with_admin_credentials
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import log_event
from source.utils import post_with_admin_credentials
from source.utils import put_with_admin_credentials


class Base64SettingWrapper:
  """Class to represent base64 file settings.

  used in the external authentication settings request.
  """

  def __init__(
      self,
      saml_settings_file_type: enums.SamlSettingsFileType,
      name: str,
      content_base64: str
  ):
    self.saml_settings_file_type = saml_settings_file_type
    self.name = name
    self.content_base64 = content_base64

  def to_json(self):
    return {
        "type": self.saml_settings_file_type.value,
        "name": self.name,
        "contentBase64": self.content_base64
    }

  @classmethod
  def from_json(cls, item: dict[str, str]):
    saml_settings_file_type = enums.SamlSettingsFileType(item.get("type"))
    name = item.get("name")
    content_base64 = item.get("contentBase64")
    return cls(saml_settings_file_type, name, content_base64)


class AddExternalProviderRequest:
  """Class to represent add external authentication settings request.
  """

  def __init__(
      self,
      provider_name: str,
      identity_provider_type: enums.IdentityProviderType,
      remote_entity_id_url: str,
      local_entity_id_url: str,
      metadata: Base64SettingWrapper,
      public_certificate: Base64SettingWrapper,
      first_name_attribute: str = "",
      last_name_attribute: str = "",
      username_attribute: str = "",
      email_attribute: str = "",
      auto_add_user: bool = False,
      auto_redirect: bool = False,
      are_saml_settings_in_use: bool = True,
      allow_unsolicited_response: bool = False,
      default_license_type: str = "",
      default_soc_role_id: str = "",
      default_permission_group: str = "",
      default_environments: Optional[list[str]] = None,
  ):
    self.provider_name = provider_name
    self.identity_provider_type = identity_provider_type
    self.remote_entity_id_url = remote_entity_id_url
    self.local_entity_id_url = local_entity_id_url
    self.metadata = metadata
    self.public_certificate = public_certificate
    self.first_name_attribute = first_name_attribute
    self.last_name_attribute = last_name_attribute
    self.username_attribute = username_attribute
    self.email_attribute = email_attribute
    self.auto_add_user = auto_add_user
    self.auto_redirect = auto_redirect
    self.are_saml_settings_in_use = are_saml_settings_in_use
    self.allow_unsolicited_response = allow_unsolicited_response
    self.default_license_type = default_license_type
    self.default_soc_role_id = default_soc_role_id
    self.default_permission_group = default_permission_group
    self.default_environments = default_environments

  def to_json(self):
    return {
        "providerName": self.provider_name,
        "identityProviderType": self.identity_provider_type.value,
        "remoteEntityIdUrl": self.remote_entity_id_url,
        "localEntityIdUrl": self.local_entity_id_url,
        "autoRedirect": self.auto_redirect,
        "autoAddUser": self.auto_add_user,
        "areSamlSettingsInUse": self.are_saml_settings_in_use,
        "metadata": self.metadata.to_json(),
        "publicCertificate": self.public_certificate.to_json(),
        "allowUnsolicitedResponse": self.allow_unsolicited_response,
        "firstNameAttribute": self.first_name_attribute,
        "lastNameAttribute": self.last_name_attribute,
        "usernameAttribute": self.username_attribute,
        "emailAttribute": self.email_attribute,
        "defaultLicenseType": self.default_license_type,
        "defaultSocRoleId": self.default_soc_role_id,
        "defaultPermissionGroup": self.default_permission_group,
        "defaultEnvironments": self.default_environments
    }


class UpdateExternalProviderRequest(AddExternalProviderRequest):
  """Class to represent update external authentication settings request.
  """

  def __init__(
      self,
      provider_id: str,
      provider_name: str,
      identity_provider_type: enums.IdentityProviderType,
      remote_entity_id_url: str,
      local_entity_id_url: str,
      metadata: Base64SettingWrapper,
      public_certificate: Base64SettingWrapper,
      first_name_attribute: str = "",
      last_name_attribute: str = "",
      username_attribute: str = "",
      email_attribute: str = "",
      auto_add_user: bool = False,
      auto_redirect: bool = False,
      are_saml_settings_in_use: bool = True,
      allow_unsolicited_response: bool = False,
      default_license_type: str = "",
      default_soc_role_id: str = "",
      default_permission_group: str = "",
      default_environments: Optional[list[str]] = None,
  ):
    super().__init__(
        provider_name=provider_name,
        identity_provider_type=identity_provider_type,
        remote_entity_id_url=remote_entity_id_url,
        local_entity_id_url=local_entity_id_url,
        metadata=metadata,
        public_certificate=public_certificate,
        first_name_attribute=first_name_attribute,
        last_name_attribute=last_name_attribute,
        username_attribute=username_attribute,
        email_attribute=email_attribute,
        auto_add_user=auto_add_user,
        auto_redirect=auto_redirect,
        are_saml_settings_in_use=are_saml_settings_in_use,
        allow_unsolicited_response=allow_unsolicited_response,
        default_license_type=default_license_type,
        default_soc_role_id=default_soc_role_id,
        default_permission_group=default_permission_group,
        default_environments=default_environments
    )
    self.provider_id = provider_id

  def to_json(self):
    json = super().to_json()
    json["id"] = self.provider_id
    return json


class ExternalProvider:
  """Class to represent external authentication settings.
  """

  def __init__(
      self,
      provider_id: str,
      provider_name: str,
      identity_provider_type: enums.IdentityProviderType,
      remote_entity_id_url: str,
      local_entity_id_url: str,
      metadata: Base64SettingWrapper,
      public_certificate: Base64SettingWrapper,
      first_name_attribute: str = "",
      last_name_attribute: str = "",
      username_attribute: str = "",
      email_attribute: str = "",
      auto_add_user: bool = False,
      auto_redirect: bool = False,
      are_saml_settings_in_use: bool = True,
      allow_unsolicited_response: bool = False,
      default_license_type: str = "",
      default_soc_role_id: str = "",
      default_permission_group: str = "",
      default_environments: Optional[list[str]] = None,
  ):
    self.provider_id = provider_id
    self.provider_name = provider_name
    self.identity_provider_type = identity_provider_type
    self.remote_entity_id_url = remote_entity_id_url
    self.local_entity_id_url = local_entity_id_url
    self.metadata = metadata
    self.public_certificate = public_certificate
    self.first_name_attribute = first_name_attribute
    self.last_name_attribute = last_name_attribute
    self.username_attribute = username_attribute
    self.email_attribute = email_attribute
    self.auto_add_user = auto_add_user
    self.auto_redirect = auto_redirect
    self.are_saml_settings_in_use = are_saml_settings_in_use
    self.allow_unsolicited_response = allow_unsolicited_response
    self.default_license_type = default_license_type
    self.default_soc_role_id = default_soc_role_id
    self.default_permission_group = default_permission_group
    self.default_environments = default_environments

  @classmethod
  def from_dictionary(cls, item: dict[str, str]):
    """Creates a class instance when getting a dictionary.

    Args:
      item: dictionary containing all fields.
    Returns:
      instance of external provider.
    """
    provider_id = item.get("id")
    provider_name = item.get("providerName")
    identity_provider_type = enums.IdentityProviderType(
        item.get("identityProviderType"))
    remote_entity_id_url = item.get("remoteEntityIdUrl")
    local_entity_id_url = item.get("localEntityIdUrl")
    auto_redirect = item.get("autoRedirect")
    auto_add_user = item.get("autoAddUser")
    are_saml_settings_in_use = item.get("areSamlSettingsInUse")
    metadata = Base64SettingWrapper.from_json(item.get("metadata"))
    public_certificate = Base64SettingWrapper.from_json(
        item.get("publicCertificate"))
    allow_unsolicited_response = item.get("allowUnsolicitedResponse")
    first_name_attribute = item.get("firstNameAttribute")
    last_name_attribute = item.get("lastNameAttribute")
    username_attribute = item.get("usernameAttribute")
    email_attribute = item.get("emailAttribute")
    default_license_type = item.get("defaultLicenseType")
    default_soc_role_id = item.get("defaultSocRoleId")
    default_permission_group = item.get("defaultPermissionGroup")
    default_environments = item.get("defaultEnvironments")
    return cls(
        provider_id=provider_id,
        provider_name=provider_name,
        identity_provider_type=identity_provider_type,
        remote_entity_id_url=remote_entity_id_url,
        local_entity_id_url=local_entity_id_url,
        auto_redirect=auto_redirect,
        auto_add_user=auto_add_user,
        are_saml_settings_in_use=are_saml_settings_in_use,
        metadata=metadata,
        public_certificate=public_certificate,
        allow_unsolicited_response=allow_unsolicited_response,
        first_name_attribute=first_name_attribute,
        last_name_attribute=last_name_attribute,
        username_attribute=username_attribute,
        email_attribute=email_attribute,
        default_license_type=default_license_type,
        default_soc_role_id=default_soc_role_id,
        default_permission_group=default_permission_group,
        default_environments=default_environments)

  def to_json(self):
    return {
        "id": self.provider_id,
        "providerName": self.provider_name,
        "identityProviderType": self.identity_provider_type.value,
        "remoteEntityIdUrl": self.remote_entity_id_url,
        "localEntityIdUrl": self.local_entity_id_url,
        "autoRedirect": self.auto_redirect,
        "autoAddUser": self.auto_add_user,
        "areSamlSettingsInUse": self.are_saml_settings_in_use,
        "metadata": self.metadata.to_json(),
        "publicCertificate": self.public_certificate.to_json(),
        "allowUnsolicitedResponse": self.allow_unsolicited_response,
        "firstNameAttribute": self.first_name_attribute,
        "lastNameAttribute": self.last_name_attribute,
        "usernameAttribute": self.username_attribute,
        "emailAttribute": self.email_attribute,
        "defaultLicenseType": self.default_license_type,
        "defaultSocRoleId": self.default_soc_role_id,
        "defaultPermissionGroup": self.default_permission_group,
        "defaultEnvironments": self.default_environments
    }


# Classes for Response DTOs
class ExternalAuthenticationSettingsResponse:
  """Class to represent external authentication settings response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    if(self.status_code > 201):
      self.external_providers = None
      self.response_json = None
    else:
      self.response_json = response.json()
      if isinstance(self.response_json, list):
        self.external_providers = [
            ExternalProvider.from_dictionary(item=x) for x in self.response_json
        ]
      else:
        self.external_providers = [
            ExternalProvider.from_dictionary(self.response_json)
        ]


def get_all_external_authentication_settings(
    provider_name: str = "",
    identity_provider_type: enums.IdentityProviderType =
    enums.IdentityProviderType.NONE,
    test_name: Optional[str] = None,
) -> ExternalAuthenticationSettingsResponse:
  """Retrieves external authentication settings from the server.

  When no provider_name or identity_provider_type are specified
  all external authentication settings will be returned.

  Args:
    provider_name: the name of the provider we want to get.
    identity_provider_type: the type of providers we want to filter on.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  query_params = {
      "providerName": provider_name,
      "identityProviderType": identity_provider_type,
  }
  response = get_with_admin_credentials(
      url=API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT_BASE,
      test_name=test_name,
      params=query_params,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Fetched external authentication settings for {test_name}"
      ),
      failure_message=(
          f"Failed to fetch external authentication settings for {test_name}"
      ),
    )
  return ExternalAuthenticationSettingsResponse(response=response)


def get_external_authentication_settings_by_id(
    provider_id: str,
    test_name: Optional[str] = None,
) -> ExternalAuthenticationSettingsResponse:
  """Retrieves external authentication settings from the server.

  Args:
    provider_id: unique id of the external authentication provider.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  query_params = {
      "id": provider_id
  }
  response = get_with_admin_credentials(
      url=API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT_BASE,
      test_name=test_name,
      params=query_params,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Fetched external authentication settings by id #{provider_id}"
          f" for {test_name}"
      ),
      failure_message=(
          f"Failed to fetch external authentication settings for {test_name}"
      ),
    )
  return ExternalAuthenticationSettingsResponse(response=response)


def delete_external_authentication_settings(
    provider_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes external authentication settings from the server.

  Args:
    provider_id: The Id of the settings we want to delete.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = delete_with_admin_credentials(
      url=f"{API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT_BASE}/{provider_id}",
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Deleted external authentication settings by id #{provider_id}"
          f" for {test_name}"
      ),
      failure_message=(
          f"Failed to delete external authentication settings for {test_name}"
      ),
  )


def create_external_authentication_settings(
    provider_name: str,
    identity_provider_type: enums.IdentityProviderType,
    remote_entity_id_url: str,
    local_entity_id_url: str,
    metadata: Base64SettingWrapper,
    public_certificate: Base64SettingWrapper,
    first_name_attribute: str = "",
    last_name_attribute: str = "",
    username_attribute: str = "",
    email_attribute: str = "",
    auto_add_user: bool = False,
    auto_redirect: bool = False,
    are_saml_settings_in_use: bool = True,
    allow_unsolicited_response: bool = False,
    default_license_type: str = "",
    default_soc_role_id: str = "",
    default_permission_group: str = "",
    default_environments: Optional[list[str]] = None,
    test_name: Optional[str] = None,
) -> ExternalAuthenticationSettingsResponse:
  """Creates a new external authentication settings.

  Args:
    provider_name: Name of the provider, this field is unique.
    identity_provider_type: The provider type, it is an enum value.
    remote_entity_id_url: The identifier of the IDP.
    local_entity_id_url: The ACS URL.
    metadata: IDP metadata file.
    public_certificate: IDP public certificate.
    first_name_attribute: Name of the field from which first name is extracted.
    last_name_attribute: Name of the field from which last name is extracted.
    username_attribute: Name of the field from which login id is extracted.
    email_attribute: Name of the field from which user email is extracted.
    auto_add_user: Creates user dynamically when the log in
                    based on the attributes configured.
    auto_redirect: Decides if user can be automatically authenticated.
    are_saml_settings_in_use: Are the settings enabled.
    allow_unsolicited_response: User will automatically be logged in into the
                                system from external provider application.
    default_license_type: Enum of the type of license the new user will have.
    default_soc_role_id: The role of the new user.
    default_permission_group: The permission group of the new user.
    default_environments: The environments the new user will be exposed to.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.

  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  add_request_payload = AddExternalProviderRequest(
      provider_name=provider_name,
      identity_provider_type=identity_provider_type,
      remote_entity_id_url=remote_entity_id_url,
      local_entity_id_url=local_entity_id_url,
      metadata=metadata,
      public_certificate=public_certificate,
      first_name_attribute=first_name_attribute,
      last_name_attribute=last_name_attribute,
      username_attribute=username_attribute,
      email_attribute=email_attribute,
      auto_add_user=auto_add_user,
      auto_redirect=auto_redirect,
      are_saml_settings_in_use=are_saml_settings_in_use,
      allow_unsolicited_response=allow_unsolicited_response,
      default_license_type=default_license_type,
      default_soc_role_id=default_soc_role_id,
      default_permission_group=default_permission_group,
      default_environments=default_environments
  )
  response = post_with_admin_credentials(
      url=API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT_BASE,
      payload=add_request_payload.to_json(),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Created external authentication settings for {test_name}"
      ),
      failure_message=(
          f"Failed to create external authentication settings for {test_name}"
      ),
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="external_auth_settings",
        item_name="we",
    )
  return ExternalAuthenticationSettingsResponse(response=response)


def update_external_authentication_settings(
    external_provider: ExternalProvider,
    test_name: Optional[str] = None,
) -> ExternalAuthenticationSettingsResponse:
  """Updates an external authentication settings.

  Args:
    external_provider: the updated provider instance
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  update_request_payload = UpdateExternalProviderRequest(
      provider_id=external_provider.provider_id,
      provider_name=external_provider.provider_name,
      identity_provider_type=external_provider.identity_provider_type,
      remote_entity_id_url=external_provider.remote_entity_id_url,
      local_entity_id_url=external_provider.local_entity_id_url,
      metadata=external_provider.metadata,
      public_certificate=external_provider.public_certificate,
      first_name_attribute=external_provider.first_name_attribute,
      last_name_attribute=external_provider.last_name_attribute,
      username_attribute=external_provider.username_attribute,
      email_attribute=external_provider.email_attribute,
      auto_add_user=external_provider.auto_add_user,
      auto_redirect=external_provider.auto_redirect,
      are_saml_settings_in_use=external_provider.are_saml_settings_in_use,
      allow_unsolicited_response=external_provider.allow_unsolicited_response,
      default_license_type=external_provider.default_license_type,
      default_soc_role_id=external_provider.default_soc_role_id,
      default_permission_group=external_provider.default_permission_group,
      default_environments=external_provider.default_environments
  )

  response = put_with_admin_credentials(
      url=API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT.format(
          external_provider.provider_id
      ),
      payload=update_request_payload.to_json(),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Updated external authentication settings for {test_name}"
      ),
      failure_message=(
          f"Failed to update external authentication settings for {test_name}"
      ),
  )
  return ExternalAuthenticationSettingsResponse(response=response)


def delete_all_external_auth_settings(
    test_name: Optional[str] = None,
) -> None:
  """Deletes all external provider settings.
  
  Args:
    test_name: name of the test (Defaults to None)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  all_settings = get_all_external_authentication_settings()
  for external_provider in all_settings.external_providers:
    delete_external_authentication_settings(
        provider_id=external_provider.provider_id)
  if test_name:
    log_event(
        test_name=test_name,
        message="All external authentication settings were deleted",
        success=True,
        details="No extra details"
    )
