"""Module containing actions to manipulate environments in siemplify client.
"""
from typing import Optional
# Endpoints
from endpoints.environments import API_ADD_UPDATE_ENVIRONMENT_ENDPOINT
from endpoints.environments import API_DELETE_ENVIRONMENT_ENDPOINT
from endpoints.environments import API_GET_ENVIRONMENTS_ENDPOINT
from endpoints.environments import API_ADD_UPDATE_ENV_DYNAMIC_PARAMETERS
from endpoints.environments import API_REMOVE_ENV_DYNAMIC_PARAMETER
# Requests
from requests import Response
# Other siemplify modules
from siemplify_utils import siemplify
# Utils
from source.utils import add_created_item_to_test
from source.utils import delete_created_item_from_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import log_and_assert
from source.utils import log_event
from source.utils import post_with_admin_credentials


# Classes for Response DTOs
class EnvironmentResponse:
  """Class to represent a single environment in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.id = self.response_json.get("id")
    self.name = self.response_json.get("name")
    self.description = self.response_json.get("description")
    self.contact_name = self.response_json.get("contactName")
    self.contact_emails = self.response_json.get("contactEmails")
    self.contact_emails_list = self.response_json.get("contactEmailsList")
    self.contact_phone = self.response_json.get("contactPhone")
    self.allowed_actions = self.response_json.get("allowedActions")
    self.remediation_duration_in_days = (
        self.response_json.get("remediationDurationInDays")
    )
    self.should_allow_remediation_actions = (
        self.response_json.get("shouldAllowRemediationActions")
    )
    self.should_notify_on_remediation_actions = (
        self.response_json.get("shouldNotifyOnRemediationActions")
    )
    self.retention_duration_in_months = (
        self.response_json.get("retentionDurationInMonths")
    )
    self.retention_duration_in_months_internal = (
        self.response_json.get("retentionDurationInMonthsInternal")
    )
    self.base64_image = self.response_json.get("base64Image")
    self.for_db_migration = self.response_json.get("forDBMigration")
    self.environment_allowed_for_all_users = (
        self.response_json.get("environmentAllowedForAllUsers")
    )
    self.dynamic_parameters = self.response_json.get("dynamicParameters")
    self.properties = self.response_json.get("properties")
    self.is_system = self.response_json.get("isSystem")
    self.aliases = self.response_json.get("aliases")
    self.instance_url = self.response_json.get("instanceUrl")


class EnvironmentsResponse:
  """Class to represent fetched environments in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.objects_list = self.response_json.get("objectsList", [])
    self.metadata = self.response_json.get("metadata", {})
    self.total_pages = self.metadata.get("totalNumberOfPages", 0)
    self.total_count = self.metadata.get("totalRecordsCount", 0)
    self.page_size = self.metadata.get("pageSize", 0)


class EnvironmentDetails:
  """Class to represent a single environment in the response.
  """

  def __init__(self, env: dict):
    self.response_json = env
    self.id = self.response_json.get("id")
    self.name = self.response_json.get("name")
    self.description = self.response_json.get("description")
    self.contact_name = self.response_json.get("contactName")
    self.contact_emails = self.response_json.get("contactEmails")
    self.contact_emails_list = self.response_json.get("contactEmailsList")
    self.contact_phone = self.response_json.get("contactPhone")
    self.allowed_actions = self.response_json.get("allowedActions")
    self.remediation_duration_in_days = (
        self.response_json.get("remediationDurationInDays")
    )
    self.should_allow_remediation_actions = (
        self.response_json.get("shouldAllowRemediationActions")
    )
    self.should_notify_on_remediation_actions = (
        self.response_json.get("shouldNotifyOnRemediationActions")
    )
    self.retention_duration_in_months = (
        self.response_json.get("retentionDurationInMonths")
    )
    self.retention_duration_in_months_internal = (
        self.response_json.get("retentionDurationInMonthsInternal")
    )
    self.base64_image = self.response_json.get("base64Image")
    self.for_db_migration = self.response_json.get("forDBMigration")
    self.environment_allowed_for_all_users = (
        self.response_json.get("environmentAllowedForAllUsers")
    )
    self.dynamic_parameters = self.response_json.get("dynamicParameters")
    self.properties = self.response_json.get("properties")
    self.is_system = self.response_json.get("isSystem")
    self.aliases = self.response_json.get("aliases")
    self.instance_url = self.response_json.get("instanceUrl")


def create_custom_environment(
    name: str,
    description: str = "Test description",
    contact_name: str = "Test",
    contact_email: str = "test@test.com",
    contact_phone: str = "+9999999999",
    allow_for_all_users: bool = False,
    alias_env: Optional[list] = []
) -> EnvironmentResponse:
  """Creates a new environment.

  !!! This function is not designed to be used inside a test! Please use
    create_environment_for_test instead!

  Args:
    name: a name of new environment (defaults to "Test environment")
    description: a description of new environment
    (defaults to "Test description")
    contact_name: contact name for new environment (defaults to "Test")
    contact_email: email for new environment
    (defaults to "test@test.com")
    contact_phone: phone for new environment
    (defaults to "+9999999999")
    allow_for_all_users: setting to allow all users into this environment

  Returns:
    A Response objects (contains JSON with environment data)
  """
  payload = {
      "name": name,
      "description": description,
      "contactName": contact_name,
      "contactEmails": contact_email,
      "environmentAllowedForAllUsers": allow_for_all_users,
      "contactPhone": contact_phone,
      "retentionDurationInMonths": 3,
      "dynamicParameters": [],
      "aliases": alias_env
  }
  response = post_with_admin_credentials(
      url=API_ADD_UPDATE_ENVIRONMENT_ENDPOINT,
      payload=payload,
  )
  return EnvironmentResponse(response=response)


def create_environment_for_test(
    description: str = "Test description",
    contact_name: str = "Test",
    contact_email: str = "test@test.com",
    contact_phone: str = "+9999999999",
    allow_for_all_users: bool = False,
    env_aliases: Optional[list] = [],
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> EnvironmentResponse:
  """Creates a new environment.

  Args:
    description: a description of new environment
    (defaults to "Test description")
    contact_name: contact name for new environment (defaults to "Test")
    contact_email: email for new environment
    (defaults to "test@test.com")
    contact_phone: phone for new environment
    (defaults to "+9999999999")
    allow_for_all_users: setting to allow all users into this environment
    test_name: name of the test (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A EnvironmentResponse objects
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  name = siemplify.utils.generate_random_name(start="Environment_")
  payload = {
      "name": name,
      "description": description,
      "contactName": contact_name,
      "contactEmails": contact_email,
      "environmentAllowedForAllUsers": allow_for_all_users,
      "contactPhone": contact_phone,
      "retentionDurationInMonths": 3,
      "dynamicParameters": [],
      "aliases": env_aliases
  }
  response = post_with_admin_credentials(
      url=API_ADD_UPDATE_ENVIRONMENT_ENDPOINT,
      payload=payload,
      test_name=test_name,
      ignore_404=True,
  )
  if response.status_code == 404:
    final_response = get_environment_data(environment_name=name)
  else:
    final_response = EnvironmentResponse(response=response)
  if log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Created environment with name '{name}' for {test_name}"
        ),
        failure_message=f"Failed to create environment for {test_name}",
        ignore_404=True,
    )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="environment",
        item_name=name,
    )
  return final_response

def update_existing_environment(
    env_details: EnvironmentResponse,
    test_name: Optional[str] = None,
    log_response: bool = True
) -> EnvironmentResponse:
  """Updates an existing environment.

  Args:
    env_details: EnvironmentResponse object which will represent
    previously created environment, to update any field just modify
    EnvironmentResponse object before ex. EnvironmentResponse.aliases = [1,2]
    test_name: name of the test (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A EnvironmentResponse objects
  """

  payload ={
    "aliases": env_details.aliases,
    "allowedActions": env_details.allowed_actions,
    "base64Image": env_details.base64_image,
    "contactEmails": env_details.contact_emails,
    "contactEmailsList": env_details.contact_emails_list,
    "contactName": env_details.contact_name,
    "contactPhone": env_details.contact_phone,
    "description": env_details.description,
    "dynamicParameters": env_details.dynamic_parameters,
    "environmentAllowedForAllUsers": env_details.environment_allowed_for_all_users,
    "forDBMigration": env_details.for_db_migration,
    "id": env_details.id,
    "instanceUrl": env_details.instance_url,
    "isSystem": env_details.is_system,
    "name": env_details.name,
    "properties": env_details.properties,
    "remediationDurationInDays": env_details.remediation_duration_in_days,
    "retentionDurationInMonths": env_details.retention_duration_in_months,
    "retentionDurationInMonthsInternal": env_details.retention_duration_in_months_internal,
    "shouldAllowRemediationActions": env_details.should_allow_remediation_actions,
    "shouldNotifyOnRemediationActions": env_details.should_notify_on_remediation_actions
  }
  response = post_with_admin_credentials(
    url=API_ADD_UPDATE_ENVIRONMENT_ENDPOINT,
    payload=payload,
    test_name=test_name,
    ignore_404=True,
  )
  if response.status_code == 404:
    final_response = get_environment_data(environment_name=env_details.name)
  else:
    final_response = EnvironmentResponse(response=response)
  if log_response:
    log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
        f"Created environment with name '{env_details.name}' for {test_name}"
      ),
      failure_message=f"Failed to create environment for {test_name}",
      ignore_404=True,
    )
  if test_name:
    add_created_item_to_test(
      test_name=test_name,
      item_type="environment",
      item_name=env_details.name,
    )
  return final_response

def get_environment_data(
    environment_name: str,
    test_name: Optional[str] = None,
) -> EnvironmentDetails:
  """Fetches full details of the environment.

  Args:
    environment_name: name of the environment to fetch
    test_name: name of the test (Defaults to None)

  Raises:
    AssertionError if the environment with that name was not found

  Returns:
    A EnvironmentResponse objects
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  all_environments = get_environments().objects_list
  for environment in all_environments:
    name = environment.get("name")
    if name == environment_name:
      log_event(
          test_name=test_name,
          message=f"Fetched environment details for {environment_name}",
          details=environment,
          success=True,
      )
      return EnvironmentDetails(env=environment)
  raise AssertionError(f"Environment {environment_name} not found!")


def get_environments() -> EnvironmentsResponse:
  """Fetches all environments.

  Returns:
    A list of dicts with data for all environments
  """
  payload = {"searchTerm": "", "requestedPage": 0, "pageSize": 20}
  response = post_with_admin_credentials(
      url=API_GET_ENVIRONMENTS_ENDPOINT,
      payload=payload,
  )
  return EnvironmentsResponse(response=response)


def delete_environment(
    name: str,
    test_name: Optional[str] = None
) -> Response:
  """Deletes an environment with a specified name.

  Args:
    name: the name of environment to delete (names are unique)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A Response objects
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = None
  all_environments = get_environments().objects_list
  for env in all_environments:
    if env["name"] == name:
      payload = {
          "id": env["id"],
          "name": name,
          "description": env["description"],
          "contactName": env["contactName"],
          "contactEmails": env["contactEmails"],
          "contactEmailsList": None,
          "contactPhone": env["contactPhone"],
          "allowedActions": None,
          "remediationDurationInDays": 0,
          "shouldAllowRemediationActions": False,
          "shouldNotifyOnRemediationActions": False,
          "retentionDurationInMonths": 3,
          "retentionDurationInMonthsInternal": None,
          "base64Image": None,
          "forDBMigration": False,
          "environmentAllowedForAllUsers": False,
          "dynamicParameters": env['dynamicParameters'],
          "properties": {},
          "isSystem": False,
          "aliases": []
      }
  response = post_with_admin_credentials(
      url=API_DELETE_ENVIRONMENT_ENDPOINT,
      payload=payload,
  )
  if test_name:
    logged_response = log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted environment with name '{name}'"
            f" for {test_name}"
        ),
        failure_message=f"Failed to delete environment for {test_name}",
    )
    delete_created_item_from_test(
      test_name=test_name,
      item_type='environment',
      item_name=name
    )
    return logged_response

  return response


def delete_all_custom_environments():
  """Deletes all environments except "Default Environment" with id #1.
  """
  all_environments = get_environments().objects_list
  for environment in all_environments:
    if environment["id"] != 1:
      delete_environment(environment["name"])

def add_update_env_dynamic_param(
    name: str,
    default_value: str,
    param_id: Optional[int] = 0,
    param_type: Optional[int] = 0,
    optional_values: Optional[list] = [],
    test_name: Optional[str] = None
) -> Response:
  """Creates or updates environment dynamic param.

 Args:
   name: name of dynamic param
   default_value: default value of param
   param_id: 0 as default, if you need to modify existing param
   YOU NEED TO PASS CORRECT ID
   param_type: 0 or 1, 0 for STRING type, 1 for a LIST type
   optional_values: optional values,
   option only available for LIST type param_type

 Returns:
   A Response objects
 """
  if not test_name:
    test_name = check_test_name_can_be_none()

  payload = {
    "defaultValue": default_value,
    "id":param_id,
    "name":name,
    "optionalValues":optional_values,
    "type":param_type
  }
  response = post_with_admin_credentials(
    url=API_ADD_UPDATE_ENV_DYNAMIC_PARAMETERS,
    payload=payload
  )
  if test_name:
    add_created_item_to_test(
      test_name=test_name,
      item_type=response.json(),
      item_name='dynamic_param_' + name
    )

  return response.json()

def delete_all_dynamic_params(
    created_dynamic_params: list[dict],
    test_name: Optional[str] = None
):
  if not test_name:
    test_name = check_test_name_can_be_none()
  for dynamic_param in created_dynamic_params:
    payload = {
      'defaultValue': dynamic_param.get('defaultValue'),
      'id': dynamic_param.get('id'),
      'name': dynamic_param.get('name'),
      'optionalValues': dynamic_param.get('optionalValues'),
      'type': dynamic_param.get('type'),
      'typeLabel': "STRING" if dynamic_param.get('type') == 0 else "LIST"
    }
    response = post_with_admin_credentials(
      url=API_REMOVE_ENV_DYNAMIC_PARAMETER,
      payload=payload
    )
    logged_response = log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
        f"Successfully deleted dynamic param "
        f"with name '{dynamic_param.get('name')}'"
        f" for {test_name}"
      ),
      failure_message=f"Failed to delete dynamic param for {test_name}",
    )