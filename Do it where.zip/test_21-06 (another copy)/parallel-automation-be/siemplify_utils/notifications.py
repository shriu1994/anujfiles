"""Module with user and system notifications.
"""
import time
from typing import Optional
# Endpoints
from endpoints.notifications import API_GET_SYSTEM_NOTIFICATIONS
# Requests
from requests import Response
# Source
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert


def get_system_notifications(test_name: Optional[str] = None) -> Response:
  """Fetches all system notifications.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (Contains JSON with tasks data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_SYSTEM_NOTIFICATIONS,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched all system notifications for {test_name}",
      failure_message=(
          f"Failed to fetch all system notifications for {test_name}"
      ),
  )


def system_notification_waiter():
  """Waits for notification records.
  """
  result = []
  timeout = 100
  start_time = time.time()
  records = get_system_notifications()
  records_queue = records.json()
  while not records_queue:
    response = get_system_notifications
    if response.status_code != 200:
      raise AssertionError(
          f"Error, non-zero status code: {response.status_code}"
      )
    result = response.json()
    if not result:
      if time.time() - start_time > timeout:
        raise AssertionError(
            f"Timeout reached, records are empty, check the logs/UI, "
            f"retunred data: {result}"
        )
      time.sleep(5)
    else:
      break
  return result
