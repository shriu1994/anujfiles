"""Module containing actions to manipulate Webhooks in Siemplify client.
"""
from typing import Optional

# Endpoints
from endpoints.webhooks import API_GET_WEBHOOKS_ENDPOINT
from endpoints.webhooks import API_WEBHOOKS_ENDPOINT_BASE

# Requests
from payloads.webhooks import sample_alert
from payloads.webhooks import webhooks_payload
from requests import Response

# Source
from source.config import API_MAIN
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import delete_with_admin_credentials
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials
from source.utils import put_with_admin_credentials


# Classes for Response DTOs
class WebhookResponse:
  """Class to represent Webhook details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)


def create_webhook(
    webhook_name: str,
    description: Optional[str] = "Test",
    environment: str = "Default Environment",
    test_name: Optional[str] = None,
) -> WebhookResponse:

  """Creates Webhook.

  Args:
    webhook_name: name of the webhook
    description: description of the test (Defaults to 'Test')
    environment: name of the environment for the webhook
    (Defaults to 'Default Environment')
    test_name: name of the test (Defaults to None)

  Returns:
    A Webhook object with all the default webhook configurations
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "name": webhook_name,
      "description": description,
      "defaultEnvironment": environment
  }
  response = post_with_admin_credentials(
      url=API_WEBHOOKS_ENDPOINT_BASE,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Webhook created for {test_name}",
      failure_message=f"Failed to create Webhook for {test_name}",
  )
  return response


def update_webhook_mapping_test(
    webhook_name: str,
    description: str,
    environment: str,
    identifier: str,
    test_name: Optional[str] = None,
) -> WebhookResponse:

  """Updates Webhook mapping.

  Args:
    webhook_name: name of the webhook
    description: description of the test
    environment: name of the environment for the webhook
    identifier: identifier of the webhook
    test_name: name of the test (Defaults to None)

  Returns:
    A Webhook object with the updated configurations
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = webhooks_payload(
      name=webhook_name,
      description=description,
      env=environment,
      identifier=identifier)

  response = put_with_admin_credentials(
      url=API_WEBHOOKS_ENDPOINT_BASE,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Webhook updated for {test_name}",
      failure_message=f"Failed to update Webhook for {test_name}",
  )
  return response


def send_webhook_request_test(
    postfix: str,
    test_name: Optional[str] = None,
) -> WebhookResponse:

  """Sends request to test webhook.

  Args:
    postfix: postfix param of the webhook
    test_name: name of the test (Defaults to None)

  Returns:
    A Webhook object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  data = sample_alert()
  response = post_with_admin_credentials(
      url=API_MAIN + "/" + postfix,
      payload=data,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Webhook tested for {test_name}",
      failure_message=f"Failed to test Webhook for {test_name}",
  )
  return response


def get_all_webhooks(
    test_name: Optional[str] = None,
    ) -> WebhookResponse:

  """Fetches the Webhook list.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A Webhook object with all the available webhooks.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_WEBHOOKS_ENDPOINT,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Webhook get for {test_name}",
      failure_message=f"Failed to get Webhook for {test_name}",
  )
  return response


def delete_webhook(
    identifier: str,
    test_name: Optional[str] = None,
) -> WebhookResponse:

  """Deletes Webhook by Identifier.

  Args:
    identifier: identifier of the webhook
    test_name: name of the test (Defaults to None)

  Returns:
    A Webhook object with all the default webhook configurations
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = delete_with_admin_credentials(
      url=API_WEBHOOKS_ENDPOINT_BASE + identifier,
      test_name=test_name,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Deleted webhook by id #{identifier}"
          f" for {test_name}"
      ),
      failure_message=(
          f"Failed to delete webhook for {identifier}"
      ),
  )


def delete_all_webhooks(
        test_name: Optional[str] = None,
) -> None:
  """Deletes all Webhooks.

  Args:
    test_name: name of the test (Defaults to None)
  """
  if not test_name:
    check_test_name_can_be_none()
  all_webhooks = get_all_webhooks()
  for wb in all_webhooks.json():
    delete_webhook(wb["identifier"])