"""Module containing actions to manipulate blocklists in siemplify client.
"""
import time
from typing import Optional
# API endpoints
from endpoints.blocklists import API_ADD_BLOCKLIST_ENTITY_ENDPOINT
from endpoints.blocklists import API_DELETE_BLOCKLIST_ENTITY_ENDPOINT
from endpoints.blocklists import API_GET_ALL_BLOCKLIST_ENTITIES_ENDPOINT
# Requests
from requests import Response
# Siemplify
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_test_name_can_be_none
from source.utils import delete_created_item_from_test
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


def get_all_blocklist_entities(
    page: int = 0,
    search: str = "",
    page_size: int = 100,
    test_name: Optional[str] = None,
) -> Response:
  """Get all blocklist entities.

  Args:
    page: pagination page
    search: domain search template
    page_size: count of domains returned per page
    test_name: name of the test (Defaults to None)

  Returns:
    A Request object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "requestedPage": page,
      "searchTerm": search,
      "pageSize": page_size
  }
  response = post_with_admin_credentials(
      url=API_GET_ALL_BLOCKLIST_ENTITIES_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched blocklist entities for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch blocklist entities for {test_name}"
        ),
    )
  return response


def delete_blocklist_entity(
    payload: dict,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a blocklist entity.

  Args:
    payload: dict object with fields to delete domain
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_BLOCKLIST_ENTITY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted blocklist entity for {test_name}"
        ),
        failure_message=(
            f"Failed to delete blocklist entity for {test_name}"
        ),
    )
  return response


def delete_all_blocklist_entities() -> None:
  """Deletes all blocklist entities.
  """
  response = get_all_blocklist_entities()
  items = siemplify.utils.find_key_in_json(
      json_data=response,
      key="objectsList",
  )
  for item in items:
    delete_blocklist_entity(payload=item)


def add_blocklist_entity(
    identifier: str,
    entity_type: str,
    action: str,
    environments: Optional[list[str]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Adds a blocklist entity.

  Args:
    identifier: entity identifier
    entity_type: entity type
    action: action to perform on add entity to blocklist
    environments: environments to be used
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  actions = {
      "Do not group alerts": 2,
      "Do not create entity": 3,
  }
  payload = {
      "entityIdentifier": identifier,
      "entityType": entity_type,
      "environments": environments,
      "scope": actions[action]
  }
  response = post_with_admin_credentials(
      url=API_ADD_BLOCKLIST_ENTITY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="blocklist_entity",
        item_name=identifier,
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully created blocklist entity for {test_name}"
        ),
        failure_message=(
            f"Failed to create blocklist entity for {test_name}"
        ),
    )
  time.sleep(5)
  return response
