"""Module containing actions to manipulate homepage in siemplify client.
"""
from typing import Optional
# Endpoints
from endpoints.homepage import API_GET_PENDING_ACTIONS_ENDPOINT
from endpoints.homepage import API_CREATE_ANNOUNCEMENTS_ENDPOINT
from endpoints.homepage import API_DELETE_ANNOUNCEMENTS_ENDPOINT
from endpoints.homepage import API_GET_ANNOUNCEMENTS_COUNT_ENDPOINT
from endpoints.homepage import API_GET_CONTACTS_ENDPOINT
from endpoints.homepage import API_CREATE_CONTACT_ENDPOINT
from endpoints.homepage import API_DELETE_CONTACT_ENDPOINT

# Requests
from requests import Response
# Source
from source.utils import log_and_assert
from source.utils import get_with_test_credentials
from source.utils import get_with_admin_credentials
from source.utils import check_test_name_can_be_none
from source.utils import check_response_and_return_json
from source.utils import post_with_test_credentials
from source.utils import delete_with_admin_credentials
from source.utils import put_with_appkey
from source.utils import post_with_appkey, get_with_appkey,  delete_with_appkey


class ContactsResponses:
  """Class to represent ContactsResponses details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.json_response = check_response_and_return_json(response=response)
    self.object_list = self.json_response.get("objectsList")
    self.metadata = self.json_response.get("metadata", {})
    self.page_size = self.metadata.get("pageSize")
    self.total_record_count = self.metadata.get("totalRecordsCount")
    self.totale_number_pages = self.metadata.get("totalNumberOfPages")


class CreateContactResponse:
  """Class to represent CreateContactResponse details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.json_response = check_response_and_return_json(response=response)
    self.contact_name = self.json_response.get("contactName")
    self.phone_number = self.json_response.get("phoneNumber")
    self.email = self.json_response.get("email")
    self.description = self.json_response.get("description")
    self.creator_userid = self.json_response.get("creatorUserId")
    self.id = self.json_response.get("id")
    self.creation_time = self.json_response.get("creationTimeUnixTimeInMs")
    self.modification_time = self.json_response.get(
      "modificationTimeUnixTimeInMs"
    )



class CreateAnnouncementResponse:
  """Class to represent CreateAnnouncementResponse details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.json_response = check_response_and_return_json(response=response)
    self.modify_userid = self.json_response.get("modifierUserId")
    self.title = self.json_response.get("title")
    self.content_feed = self.json_response.get("feed")
    self.expiration_time = self.json_response.get("expirationTimeUnixTimeInMs")
    self.creator_userid = self.json_response.get("creatorUserId")
    self.id = self.json_response.get("id")
    self.creation_time = self.json_response.get("creationTimeUnixTimeInMs")
    self.modification_time = self.json_response.get("modificationTimeUnixTimeInMs")


class PendingStepsForUser:
  """Class to represent all pending steps for user
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.json_response = check_response_and_return_json(response=response)
    self.pending_steps = \
      [PendingStepForUser(step) for step in self.json_response]
    self.pending_steps_count = len(self.pending_steps)

class PendingStepForUser:
  """Class to represent pending step for user
  """

  def __init__(self, response: dict):
    self.workflow_identifier = response.get("workflowIdentifier")
    self.parent_workflow_identifier = response.get("parentWorkflowIdentifier")
    self.workflow_instance_identifier = \
      response.get("workflowInstanceIdentifier")
    self.case_id = response.get("caseId")
    self.indicator_identifier = response.get("indicatorIdentifier")
    self.alert_group_identifier = response.get("alertGroupIdentifier")
    self.status = response.get("status")
    self.executing_user = response.get("executingUser")
    self.allowed_to_execute = response.get("allowedToExecute")
    self.result_code = response.get("resultCode")
    self.message = response.get("message")
    self.result_value = response.get("resultValue")
    self.results = response.get("results")
    self.target_entities = response.get("targetEntities")
    self.result_entities = response.get("resultEntities")
    self.properties = response.get("properties")
    self.action_def = response.get("actionDef")
    self.block_step_id = response.get("blockStepId")
    self.json_result_object = response.get("jsonResultObject")
    self.integration_instance_identifier = \
      response.get("integrationInstanceIdentifier")
    self.integration_instance_name = response.get("integrationInstanceName")
    self.integration_instance_environment = \
      response.get("integrationInstanceEnvironment")
    self.description = response.get("description")
    self.pending_step_properties = response.get("pendingStepProperties")
    self.step_instance_identifier = response.get("stepInstanceIdentifier")
    self.identifier = response.get("identifier")
    self.original_step_identifier = response.get("originalStepIdentifier")
    self.is_automatic = response.get("isAutomatic")
    self.is_skippable = response.get("isSkippable")
    self.creation_time_unix_time_in_ms =\
      response.get("creationTimeUnixTimeInMs")
    self.modification_time_unix_time_in_ms = \
      response.get("modificationTimeUnixTimeInMs")
    self.instance_name = response.get("instanceName")
    self.name = response.get("name")
    self.integration = response.get("integration")
    self.action_provider = response.get("actionProvider")
    self.action_name = response.get("actionName")
    self.type = response.get("type")
    self.parameters = response.get("parameters")
    self.auto_skip_on_failure = response.get("autoSkipOnFailure")
    self.is_debug_mock_data = response.get("isDebugMockData")


def get_all_pending_actions_for_user(
    user_type: str = 'test',
    sort_by: Optional[int] = 3,
    test_name: Optional[str] = None
) -> PendingStepsForUser:
  """Gets all pending actions for given user

  Args:
    user_type: either "test" or "admin" to fetch all pending actions for
    appropriate user
    sort_by: Available values : 0, 1, 2, 3, 4, 5, 6, 7
    test_name: name of the test (Defaults to None)

  Returns:
    PendingStepsForUser object which represents
    all pending actions for given user
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if user_type == 'test':
    response = get_with_test_credentials(
      url=API_GET_PENDING_ACTIONS_ENDPOINT + f"?sortBy={sort_by}",
      test_name=test_name
    )
  elif user_type == 'admin':
    response = get_with_admin_credentials(
      url=API_GET_PENDING_ACTIONS_ENDPOINT + f"?sortBy={sort_by}",
      test_name=test_name
    )
  log_and_assert(
    response=response,
    success_message=f"Successfully got all pending actions "
                    f"for {user_type} user for test {test_name}",
    failure_message=f"Failed to get all pending action for {user_type} user"
                    f"for test {test_name}"
  )

  return PendingStepsForUser(response)


def create_announcement(
    test_name: Optional[str] = None,
    title: [str] = "Test",
    feed: [str] = "Test",
    expiration_date: Optional[str] = None,
    expiration_time: Optional[str] = None,
) -> CreateAnnouncementResponse:
  """Create Announcement.

  Args:
    test_name: name of the test (Defaults to None)
    title: title of the Announcement.
    feed: content of the Announcement
    expiration_date: Expiration date of the Announcement.
    expiration_time: Expiration date of the Announcement.

  Returns:
    A Response object of CreateAnnouncementResponse.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
    "title": title,
    "feed": feed,
    "expirationDate": expiration_date,
    "expirationTimeUnixTimeInMs": expiration_time}

  response = post_with_test_credentials(
      url=API_CREATE_ANNOUNCEMENTS_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Create Annoucnement Success for {test_name}",
      failure_message=f"Failed to Create Announcement for {test_name}",
  )
  return CreateAnnouncementResponse(response=response)


def delete_announcement(
    id: [int],
) -> Response:
  """Delete the Announcement.

  Args:
    id: id of the announcement to be deleted

  Returns:
    A Response object.
  """
  response = delete_with_admin_credentials(
      url=API_DELETE_ANNOUNCEMENTS_ENDPOINT.format(id),
  )

  return response


def get_announcement_count(
    test_name: Optional[str] = None,
) -> Response:
  """Get the Announcement Count.

  Args:
    test_name: name of the test (Defaults to None).

  Returns:
    A Response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()

  response = get_with_test_credentials(
      url=API_GET_ANNOUNCEMENTS_COUNT_ENDPOINT,
      test_name=test_name,
  )

  return response


def get_contact_details(
    test_name: Optional[str] = None,
) -> ContactsResponses:
  """Get the contact details.

  Args:
    test_name: name of the test (Defaults to None).

  Returns:
    A ContactsResponses Response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
       "requestedPage": 0,
       "pageSize":20,
       "SearchTerm": None
  }
  response = get_with_appkey(
      url=API_GET_CONTACTS_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  return ContactsResponses(response=response)


def create_contact(
    test_name: Optional[str] = None,
    contact_name: [str] = "Test",
    phone_number: [int] = 123456,
    email: [str] = "abc@gmail.com",
    description: [str] = "Test",
) -> CreateContactResponse:
  """Create Contact.

  Args:
    test_name: name of the test (Defaults to None)
    contact_name: name of the contact.
    phone_number: phone number of the contact
    email: email of the contact.
    description: descrption details of the contact.

  Returns:
    A Response object of CreateContactResponse.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
       "contactName": contact_name,
       "phoneNumber": phone_number,
       "email": email,
       "description": description
  }
  response = post_with_appkey(
      url=API_CREATE_CONTACT_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Create Contact Success for {test_name}",
      failure_message=f"Failed to Create Contact for {test_name}",
  )
  return CreateContactResponse(response=response)


def update_contact(
    test_name: Optional[str] = None,
    contact_name: [str] = "Test",
    phone_number: [int] = 123456,
    email: [str] = "abc@gmail.com",
    description: [str] = "Test",
    id: [int] = 0,
) -> CreateContactResponse:
  """Update Contact.

  Args:
    test_name: name of the test (Defaults to None)
    contact_name: name of the contact.
    phone_number: phone number of the contact
    email: email of the contact.
    description: descrption details of the contact.
    id: id of the contact to be update.

  Returns:
    A Response object of CreateContactResponse.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "contactName": contact_name,
      "phoneNumber": phone_number,
      "email": email,
      "description": description,
      "id": id
  }
  response = put_with_appkey(
      url=API_CREATE_CONTACT_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Update Contact Success for {test_name}",
      failure_message=f"Failed to Update Contact for {test_name}",
  )
  return CreateContactResponse(response=response)


def update_contact_failed(
    test_name: Optional[str] = None,
    contact_name: [str] = "Test",
    phone_number: [int] = 123456,
    email: [str] = "abc@gmail.com",
    description: [str] = "Test",
    id: [int] = 0,
) -> CreateContactResponse:
  """Update Contact.

  Args:
    test_name: name of the test (Defaults to None)
    contact_name: name of the contact.
    phone_number: phone number of the contact
    email: email of the contact.
    description: descrption details of the contact.
    id: id of the contact to be update.

  Returns:
    A Response object of CreateContactResponse.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "contactName": contact_name,
      "phoneNumber": phone_number,
      "email": email,
      "description": description,
      "id": id
  }
  response = put_with_appkey(
      url=API_CREATE_CONTACT_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Update Contact Success for {test_name}",
      failure_message=f"Failed to Update Contact for {test_name}",
      ignore_400=True,
  )
  return CreateContactResponse(response=response)



def create_contact_failed(
    test_name: Optional[str] = None,
    contact_name: [str] = "Test",
    phone_number: [int] = 123456,
    email: [str] = "abc@gmail.com",
    description: [str] = "Test",
) -> CreateContactResponse:
  """Create Contact.

  Args:
    test_name: name of the test (Defaults to None)
    contact_name: name of the contact.
    phone_number: phone number of the contact
    email: email of the contact.
    description: descrption details of the contact.

  Returns:
    A Response object of CreateContactResponse.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "contactName": contact_name,
      "phoneNumber": phone_number,
      "email": email,
      "description": description
  }
  response = post_with_appkey(
      url=API_CREATE_CONTACT_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Failed to add contact {contact_name} for {test_name}"
        ),
        failure_message=(
            f"Added contact {contact_name}  for {test_name}"
        ),
        ignore_400=True,
    )
  return CreateContactResponse(response=response)


def delete_contact(
    id: [int],
) -> Response:
  """Delete the Contact.

  Args:
    id: id of the Contact to be deleted

  Returns:
    A Response object.
  """
  response = delete_with_appkey(
      url=API_DELETE_CONTACT_ENDPOINT.format(id),
  )
  return response
