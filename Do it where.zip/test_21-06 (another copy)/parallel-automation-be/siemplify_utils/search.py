"""Module containing actions to manipulate settings in siemplify client.
"""
import datetime as dt
from typing import Optional
# API endpoints
from endpoints.search import API_SEARCH_CASES_EVERYTHING_ENDPOINT
from endpoints.search import API_SEARCH_ENTITIES_ENDPOINT
# Requests
from requests import Response
# Source
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials
from source.utils import post_with_test_credentials


def search_cases_for_test(
    tags: Optional[list[str]] = None,
    case_source: Optional[list[str]] = None,
    stage: Optional[list[str]] = None,
    environments: Optional[list[str]] = None,
    assigned_users: Optional[list[str]] = None,
    products: Optional[list[str]] = None,
    ports: Optional[list[str]] = None,
    category_outcomes: Optional[list[str]] = None,
    status: Optional[list[str]] = None,
    case_ids: Optional[list[str]] = None,
    importance: Optional[list[str]] = None,
    is_incident: Optional[list[str]] = None,
    priorities: Optional[list[str]] = None,
    title: Optional[str] = None,
    time_period: Optional[int] = None,
    is_closed: Optional[bool] = None,
    rule_generator: Optional[list[str]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Searches for cases with specified parameters.

  Args:
    tags: tags to search for
    case_source: case source to search for
    stage: stage to search for
    environments: environments to search for
    assigned_users: assigned users to search for
    products: products to search for
    ports: ports to search for
    category_outcomes: category outcomes to search for
    status: status to search for
    case_ids: case ids to search for
    importance: status of importance to search for
    is_incident: status of is incident to search for
    priorities: chosen priority levels to search for
    title: title to search for
    time_period: a time period for the search (number of days)
    is_closed: closure status of cases to search for
    rule_generator: name of the alert type
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains JSON with search result)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  # Convert booleans into strings search accepts
  if isinstance(importance, bool):
    importance = ["True"] if importance else ["False"]
  if isinstance(is_incident, bool):
    is_incident = ["True"] if is_incident else ["False"]
  # Create strings for time period
  time_now = dt.datetime.now()
  time_delta = None
  if not time_period:
    time_delta = dt.timedelta(days=1)
  else:
    time_delta = dt.timedelta(days=time_period)
  start_time = time_now - time_delta
  start_time_iso = start_time.isoformat()
  end_time_iso = time_now.isoformat()
  payload = {
      "tags": tags,
      "ruleGenerator": rule_generator,
      "caseSource": case_source,
      "stage": stage,
      "environments": environments,
      "assignedUsers": assigned_users,
      "products": products,
      "ports": ports,
      "categoryOutcomes": category_outcomes,
      "status": status,
      "caseIds": case_ids,
      "incident": is_incident,
      "importance": importance,
      "priorities": priorities,
      "pageSize": 50,
      "title": title,
      "startTime": start_time_iso,
      "endTime": end_time_iso,
      "requestedPage": 0,
      "timeRangeFilter": 1,
      "isCaseClosed": is_closed,
  }
  response = post_with_test_credentials(
      url=API_SEARCH_CASES_EVERYTHING_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully searched cases for {test_name}",
        failure_message=f"Failed to search cases for {test_name}",
    )

  return response


def search_cases_in_all_environments(
    tags: Optional[list[str]] = None,
    case_source: Optional[list[str]] = None,
    stage: Optional[list[str]] = None,
    environments: Optional[list[str]] = None,
    assigned_users: Optional[list[str]] = None,
    products: Optional[list[str]] = None,
    ports: Optional[list[str]] = None,
    category_outcomes: Optional[list[str]] = None,
    status: Optional[list[str]] = None,
    case_ids: Optional[list[str]] = None,
    importance: Optional[list[str]] = None,
    is_incident: Optional[list[str]] = None,
    priorities: Optional[list[str]] = None,
    title: Optional[str] = None,
    time_period: Optional[int] = None,
    is_closed: Optional[bool] = None,
    rule_generator: Optional[list[str]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Searches for cases with specified parameters.

  Args:
    tags: tags to search for
    case_source: case source to search for
    stage: stage to search for
    environments: environments to search for
    assigned_users: assigned users to search for
    products: products to search for
    ports: ports to search for
    category_outcomes: category outcomes to search for
    status: status to search for
    case_ids: case ids to search for
    importance: status of importance to search for
    is_incident: status of is incident to search for
    priorities: chosen priority levels to search for
    title: title to search for
    time_period: a time period for the search (number of days)
    is_closed: closure status of cases to search for
    rule_generator: name of the alert type
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains JSON with search result)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  # Convert booleans into strings search accepts
  if isinstance(importance, bool):
    importance = ["True"] if importance else ["False"]
  if isinstance(is_incident, bool):
    is_incident = ["True"] if is_incident else ["False"]
  # Create strings for time period
  time_now = dt.datetime.now()
  time_delta = None
  if not time_period:
    time_delta = dt.timedelta(days=1)
  else:
    time_delta = dt.timedelta(days=time_period)
  start_time = time_now - time_delta
  start_time_iso = start_time.isoformat()
  end_time_iso = time_now.isoformat()
  payload = {
      "tags": tags,
      "ruleGenerator": rule_generator,
      "caseSource": case_source,
      "stage": stage,
      "environments": environments,
      "assignedUsers": assigned_users,
      "products": products,
      "ports": ports,
      "categoryOutcomes": category_outcomes,
      "status": status,
      "caseIds": case_ids,
      "incident": is_incident,
      "importance": importance,
      "priorities": priorities,
      "pageSize": 50,
      "title": title,
      "startTime": start_time_iso,
      "endTime": end_time_iso,
      "requestedPage": 0,
      "timeRangeFilter": 1,
      "isCaseClosed": is_closed,
  }
  response = post_with_admin_credentials(
      url=API_SEARCH_CASES_EVERYTHING_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully searched cases for {test_name}",
        failure_message=f"Failed to search cases for {test_name}",
    )
  return response

def search_entities_for_test(
    type: Optional[list[str]] = None,
    operation_system: Optional[list[str]] = None,
    network_name: Optional[list[str]] = None,
    environments_name: Optional[list[str]] = None,
    term: Optional[str] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Searches for entities with specified parameters.

  Args:
    type: type to search for
    operation_system: operationSystem to search for
    network_name: networkName to search for
    environments_name: environments to search for
    term: term or string to search for
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains JSON with search result)
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  payload = {
      "type": type,
      "operationSystem": operation_system,
      "networkName": network_name,
      "environmentsName": environments_name,
      "pageSize": 50,
      "term": term,
      "requestedPage": 0
    }
  response = post_with_test_credentials(
      url=API_SEARCH_ENTITIES_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully searched entities for {test_name}",
        failure_message=f"Failed to search entities for {test_name}",
    )
  return response