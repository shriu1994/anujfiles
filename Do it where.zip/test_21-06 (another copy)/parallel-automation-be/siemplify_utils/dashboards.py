"""Module containing actions to manipulate widgets in siemplify client.
"""
import time
from typing import Optional
# API endpoints
from endpoints.dashboards import API_ADD_UPDATE_DASHBOARD_ENDPOINT
from endpoints.dashboards import API_ADD_WIDGET_ENDPOINT
from endpoints.dashboards import API_DELETE_DASHBOARD_ENDPOINT
from endpoints.dashboards import API_DELETE_WIDGET_ENDPOINT
from endpoints.dashboards import API_GET_WIDGET_VALUES_ENDPOINT
from endpoints.dashboards import API_GET_WIDGETS_ENDPOINT
# Requests
from requests import Response
# Other siemplify utils
from siemplify_utils import siemplify
# Source
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import get_with_test_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials
from source.utils import post_with_test_credentials


class DashboardResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.creator = self.response_json.get("creator")
    self.name = self.response_json.get("name")
    self.default_time_range = self.response_json.get("defaultTimeRange")
    self.allowed_users = self.response_json.get("allowedUsers")
    self.widgets = self.response_json.get("widgets")
    self.environments = self.response_json.get("environments")
    self.id = self.response_json.get("id")
    self.creation_time = self.response_json.get("creationTimeUnixTimeInMs")
    self.modification_time = self.response_json.get(
        "modificationTimeUnixTimeInMs"
    )


def create_dashboard_for_test(
    test_name: Optional[str] = None,
) -> DashboardResponse:
  """Fetches all widgets.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A DashboardResponse object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  creator = siemplify.users.get_test_user_data(test_name=test_name).username
  name = siemplify.utils.generate_random_name(start="Dashboard_")
  payload = {
      "id": 0,
      "creator": creator,
      "name": name,
      "defaultTimeRange": 1,
      "environments": [
          test_name
      ],
      "allowedUsersJson": "",
      "allowedUsers": [
          creator
      ],
      "widgets": []
  }
  response = post_with_test_credentials(
      url=API_ADD_UPDATE_DASHBOARD_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Created dashboard '{name}' for {test_name}",
        failure_message=f"Failed to create dashboard '{name}' for {test_name}",
    )
  return DashboardResponse(response=response)


def delete_dashboard(
    dashboard_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches all widgets.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    dashboard_id: id of the dashboard to delete
    test_name: name of the test (Defaults to None)
  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_DASHBOARD_ENDPOINT.format(dashboard_id),
      payload={},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Deleted dashboard #{dashboard_id} for {test_name}",
        failure_message=(
            f"Failed to delete dashboard #{dashboard_id} for {test_name}"
        ),
    )
  return response


def get_dashboard_widgets(
    dashboard_id: int,
    test_name: Optional[str] = None,
) -> DashboardResponse:
  """Fetches all widgets.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    dashboard_id: id of the dashboard to fetch widgets from
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_test_credentials(
      url=API_GET_WIDGETS_ENDPOINT.format(dashboard_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully fetched widgets for {test_name}",
        failure_message=f"Failed to fetch widgets for {test_name}",
    )
  return DashboardResponse(response=response)


def delete_dashboard_widget(
    widget_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a widget with specified ID.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    widget_id: id of widget to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_WIDGET_ENDPOINT.format(widget_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully deleted widget #{widget_id} for {test_name}"
        ),
        failure_message=f"Failed to delete widget #{widget_id} for {test_name}",
    )
  return response


def create_widget(
    dashboard: int = 1,
    chart_type: str = "pie chart",
    number_of: str = "cases",
    calculate: str = "count",
    group_by: str = "analyst",
    number_of_results: int = 10,
    order_by: str = "ascending",
    title: str = "TestWidget",
    width: int = 1,
    tag_filters: Optional[list[str]] = None,
    analyst_filters: Optional[list[str]] = None,
    case_status_filter: Optional[list[str]] = None,
    priority_filter: Optional[list[str]] = None,
    importance_status_filter: Optional[bool] = None,
    case_stage_filter: Optional[list[str]] = None,
    close_reasons_filter: Optional[list[str]] = None,
    root_cause_filter: Optional[list[str]] = None,
    is_incident_filter: Optional[bool] = None,
    environment_filter: Optional[list[str]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Creates a new widget.

  Available inputs for different arguments:
  chart_type: pie chart, horizontal, vertical, table, soc status, roi chart,
    editor, image
  number_of: cases, alerts, playbooks
  calculate: count, avg time
  group_by: analyst, environment, importance, priority, tag, stage, case status,
    close reason, root cause, sla status, rule name, soc analysts load,
    soc status, alerts reduction, entity
  order_by: ascending, descending
  case_status_filter: open, closed
  priority_filter: critical, high, informative, low, medium
  case_stage_filter (case sensitive!): Assessment, Improvement, Incident,
    Investigation, Research, Triage
  close_reasons_filter: inconclusive, maintenance, malicious, not malicious
  root_cause_filter (case sensitive!): Employee error, Human error, Lab test,
    Legit action

  Args:
    dashboard: id of the dashboard to add widget to (Defaults to 1)
    chart_type: type of widget to create. (Defaults to "pie chart")
    number_of: what number to represent. (Defaults to "cases")
    calculate: how to calculate the above field. (Defaults to "count")
    group_by: grouping option for the widget. (Defaults to "analyst")
    number_of_results: how many results to show. (Defaults to 10)
    order_by: ordering type. (Defaults to "ascending")
    title: title of the widget. (Defaults to "TestWidget")
    width: width of the widget. (Defaults to 1)
    tag_filters: filter for tags. (Defaults to None)
    analyst_filters: filter for analyst. (Defaults to None)
    case_status_filter: filter for case statuses. (Defaults to None)
    priority_filter: filter for case priority. (Defaults to None)
    importance_status_filter: filter for importance. (Defaults to None)
    case_stage_filter: filter for case stage. (Defaults to None)
    close_reasons_filter: filter for case close reasons. (Defaults to None)
    root_cause_filter: filter for case root causes. (Defaults to None)
    is_incident_filter: filter for incidents. (Defaults to None)
    environment_filter: widget environments. ("Default Environment" if None)
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  case_stages_options = ("Assessment", "Improvement", "Incident",
                         "Investigation", "Research", "Triage")
  case_root_cause_options = ("Employee error", "Human error", "Lab test",
                             "Legit action")
  close_reasons_options = {"inconclusive": 3, "maintenance": 2, "malicious": 0,
                           "not malicious": 1}
  chart_type_options = {"pie chart": 0, "horizontal": 1, "vertical": 2,
                        "table": 3, "soc status": 7, "roi chart": 8,
                        "editor": 9, "image": 10}
  case_priority_options = {"critical": 100, "high": 80,
                           "informative": -1, "low": 40, "medium": 60}
  case_status_options = {"open": 1, "closed": 2}
  order_by_options = {"ascending": 1, "descending": 2}
  number_of_options = {"cases": 0, "alerts": 1, "playbooks": 3}
  width_options = (1, 2, 3)
  calculate_types = {"count": 0, "avg time": 1}
  group_by_options = {
      "analyst": 0, "environment": 4, "importance": 7, "priority": 2, "tag": 1,
      "stage": 13, "case status": 8, "close reason": 9, "root cause": 10,
      "sla status": 17, "rule name": 6, "soc analysts load": 30,
      "alerts reduction": 40, "entity": 16, "soc status": 31,
  }
  # Check that entered data is valid
  assert order_by.lower() in order_by_options.keys(), (
      f"Wrong order type: {order_by}"
  )
  assert calculate.lower() in calculate_types.keys(), (
      f"Wrong calc type: {calculate}"
  )
  assert number_of.lower() in number_of_options, f"Wrong type: {number_of}"
  assert group_by.lower() in group_by_options.keys(), (
      f"Wrong grouping: {group_by}"
  )
  assert chart_type.lower() in chart_type_options, (
      f"Wrong chart type: {chart_type}"
  )
  # Prepare filters for converting strings to numeric representation
  case_priority_numbers = None
  close_reason_numbers = None
  case_status_numbers = None
  # Check filters for validity
  if priority_filter:
    for option in priority_filter:
      assert option.lower() in case_priority_options, (
          f"Wrong priority filter: {option}"
      )
    # Create a filter with numeric representations of filters
    case_priority_numbers = [
        case_priority_options[priority.lower()] for priority in priority_filter
    ]
  if case_stage_filter:
    for stage in case_stage_filter:
      assert stage in case_stages_options, (
          f"Wrong case stage: {stage}"
      )
  if close_reasons_filter:
    for reason in close_reasons_filter:
      assert reason.lower() in close_reasons_options.keys(), (
          f"Wrong close reason: {reason}"
      )
    # Create a filter with numeric representations of filters
    close_reason_numbers = [
        close_reasons_options[reason] for reason in close_reasons_filter
    ]
  if root_cause_filter:
    for cause in root_cause_filter:
      assert cause in case_root_cause_options, (
          f"Wrong root cause: {cause}"
      )
  if case_status_filter:
    for status in case_status_filter:
      assert status.lower() in case_status_options.keys(), (
          f"Wrong status type: {status}"
      )
    # Create a filter with numeric representations of filters
    case_status_numbers = [
        case_status_options[status.lower()] for status in case_status_filter
    ]
  assert width in width_options, f"Wrong width: {width}"
  if not environment_filter:
    environment_filter = [test_name]
  # Find current user
  user = siemplify.users.get_test_user_data(test_name=test_name).username
  # Create a payload
  payload = {
      "title": title,
      "widgetType": 70,
      "widthSize": width,
      "timeFilter": 1,
      "tagFilters": tag_filters or [],
      "environmentFilter": environment_filter,
      "analystFilters": analyst_filters or [],
      "priorityFilter": case_priority_numbers or [],
      "caseStatusesFilter": case_status_numbers or [],
      "importanceStatusesFilter": importance_status_filter or [],
      "incidentStatusesFilter": is_incident_filter or [],
      "exceededSlaFilter": [],
      "closeReasonsFilter": close_reason_numbers or [],
      "caseStageFilter": case_stage_filter or [],
      "caseRootCauseFilter": root_cause_filter or [],
      "slaStatusFilter": [],
      "entityTypeFilter": [],
      "productFilters": [],
      "playbooksFilter": [],
      "integrationsFilter": [],
      "playbookStatusFilter": [],
      "subject": number_of_options[number_of.lower()],
      "dimensionA": group_by_options[group_by.lower()],
      "dimensionB": 6,
      "chartType": chart_type_options[chart_type.lower()],
      "resultsAmount": number_of_results,
      "resultsOrder": 0,
      "calculateField": calculate_types[calculate.lower()],
      "dashboardId": dashboard,
      "order": order_by_options[order_by.lower()],
      "socAnalystsLoadFirstSocRoleId": 2,
      "socAnalystsLoadSecondSocRoleId": 3,
      "socAnalystsLoadManagerUsername": user,
  }

  response = post_with_test_credentials(
      url=API_ADD_WIDGET_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Created widget '{title}' in dashboard #{dashboard}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to create widget '{title}' in dashboard #{dashboard}"
            f" for {test_name}"
        ),
    )
  return response


def get_widgets_values(
    widget: Response,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches value of the created widget.

  Args:
    widget: response object from create_widget
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (contains JSON with widget values)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  widget_json = widget.json()
  response = post_with_test_credentials(
      url=API_GET_WIDGET_VALUES_ENDPOINT,
      payload=widget_json,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched widget data for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch widget for {test_name}"
        ),
    )
  return response


def wait_for_widget_cases_value(
    widget: Response,
    value: Optional[int] = None,
    more_than: Optional[int] = None,
    less_than: Optional[int] = None,
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> int:
  """Fetches widget values and looks for specific value.

  Used for widget with cases. If value is not what was specified, waits a set
    amount of seconds, retries it several times if needed.

  Args:
    widget: response object from creating a widget
    value: exact widget value to look for
    more_than: widget value to look for that is more than this value
    less_than: widget value to look for that is less than this value
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A total number of cases after the condition is met OR retires are done
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if (value and more_than or value and less_than or
      value and more_than and less_than):
    raise ValueError("Please only use 'count' OR 'less_than' OR 'more_than'")
  attempts = 0
  while attempts < retries:
    widget_data = get_widgets_values(test_name=test_name, widget=widget)
    series = siemplify.utils.find_key_in_json(
        json_data=widget_data,
        key="series",
    )
    values = siemplify.utils.find_key_in_json(
        json_data=series,
        key="values",
    )
    total_count = int(values[0])
    if value and total_count == value:
      attempts = retries
      return total_count
    elif more_than and total_count > more_than:
      attempts = retries
      return total_count
    elif less_than and total_count < less_than:
      attempts = retries
      return total_count
    else:
      attempts += 1
      if attempts >= retries:
        return total_count
      time.sleep(cadence)


def create_default_widgets():
  """Creates all 8 default widgets in SOC Status.
  """
  create_widget(
      chart_type="soc status",
      title="Soc Status",
      group_by="soc status",
      width=1,
  )
  create_widget(
      chart_type="soc status",
      title="SOC Analysts load",
      group_by="soc analysts load",
      width=1,
  )
  create_widget(
      chart_type="pie chart",
      title="Alerts Distribution",
      number_of="alerts",
      calculate="count",
      group_by="rule name",
      number_of_results=5,
      order_by="descending",
      width=1,
  )
  create_widget(
      chart_type="pie chart",
      title="Top reporting products",
      number_of="alerts",
      calculate="count",
      group_by="rule name",
      number_of_results=5,
      order_by="descending",
      width=1,
  )
  create_widget(
      chart_type="roi chart",
      title="Alert reduction percentage",
      group_by="alerts reduction",
      width=1,
  )
  create_widget(
      chart_type="pie chart",
      title="Case Distribution By Priority - Open Cases",
      number_of="cases",
      calculate="count",
      group_by="priority",
      number_of_results=5,
      order_by="descending",
      case_status_filter=["open"],
      width=1,
  )
  create_widget(
      chart_type="horizontal",
      title="Top Entities Appearing In Alerts",
      number_of="alerts",
      calculate="count",
      group_by="entity",
      number_of_results=5,
      order_by="descending",
      width=2,
  )
  create_widget(
      chart_type="pie chart",
      title="Case Tags Distribution",
      number_of="cases",
      calculate="count",
      group_by="tag",
      number_of_results=5,
      order_by="descending",
      width=1,
  )