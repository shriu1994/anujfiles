"""Module to work with cases.
"""
import datetime as dt
import json
import os
import time
import base64
from typing import Optional, TypedDict, Union
# Endpoints
from endpoints.cases import API_ADD_CASE_COMMENT_ENDPOINT
from endpoints.cases import API_GET_CASE_WALL_ACTIVITIES_ENDPOINT
from endpoints.cases import API_UPDATE_CASE_COMMENT_ENDPOINT
from endpoints.cases import API_GET_CASE_EVIDENCE_DATA
from endpoints.cases import API_MARK_COMMENT_AS_DELETED_ENDPOINT
from endpoints.cases import API_ADD_CASE_TAG_ENDPOINT
from endpoints.cases import API_ASSIGN_USER_TO_CASE_ENDPOINT
from endpoints.cases import API_CASES_CREATE_CASE
from endpoints.cases import API_CASE_RUN_MANUAL_ACTION_ENDPOINT
from endpoints.cases import API_GET_ALERT_EVENTS_ENDPOINT
# from endpoints.cases import API_ADD_UPDATE_CASE_TASK_ENDPOINT
from endpoints.cases import API_UPDATE_ALERT_PRIORITY_ENDPOINT
from endpoints.cases import API_CHANGE_CASE_DESCRIPTION_ENDPOINT
from endpoints.cases import API_CHANGE_CASE_STAGE_ENDPOINT
from endpoints.cases import API_CLOSE_CASES_ENDPOINT
from endpoints.cases import API_CREATE_MANUAL_CASE_ENDPOINT
# from endpoints.cases import API_CREATE_SIMULATED_CUSTOM_CASE_ENDPOINT
from endpoints.cases import API_EXECUTE_PENDING_ACTION
# from endpoints.cases import API_GENERATE_CASE_REPORT_ENDPOINT
from endpoints.cases import API_GET_ALERT_OVERVIEW_DATA_ENDPOINT
from endpoints.cases import API_GET_ASSIGNED_CASES_ENDPOINT
# from endpoints.cases import API_GET_CASE_ACTION_RESULT_ENDPOINT
from endpoints.cases import API_GET_CASE_DETAILS_ENDPOINT
from endpoints.cases import API_GET_CASE_FULL_DETAILS_ENDPOINT
from endpoints.cases import API_GET_CASE_OVERVIEW_DATA_ENDPOINT
# from endpoints.cases import API_GET_CASE_WALL_ACTIVITIES_ENDPOINT
from endpoints.cases import API_GET_CASES_ENDPOINT
from endpoints.cases import API_GET_CUSTOM_CASES_ENDPOINT
from endpoints.cases import API_GET_WORKFLOW_INSTANCE_ENDPOINT
from endpoints.cases import API_INGEST_ALERT_AS_TEST_ENDPOINT
from endpoints.cases import API_MERGE_CASES_ENDPOINT
from endpoints.cases import API_MOVE_CASE_TO_ENVIRONMENT_ENDPOINT
from endpoints.cases import API_RAISE_INCIDENT_ENDPOINT
from endpoints.cases import API_REMOVE_CASE_TAG_ENDPOINT
# from endpoints.cases import API_RERUN_WORKFLOW_ENDPOINT
from endpoints.cases import API_SIMULATE_CASE_ENDPOINT
# from endpoints.cases import API_SKIP_ACTION_ENDPOINT
from endpoints.cases import API_UPDATE_CASE_PRIORITY_ENDPOINT
from endpoints.cases import API_REOPEN_CASES_IN_BULK_ENDPOINT
from endpoints.cases import API_MOVE_ALERT_TO_CASE_ENDPOINT
from endpoints.cases import API_IMPORT_CUSTOM_CASE_ENDPOINT
from endpoints.cases import API_DELETE_USE_CASE_ENDPOINT
from endpoints.cases import API_CASES_QUEUE_ENDPOINT
from endpoints.cases import API_GET_INVESTIGATION_DATA
# Requests
from requests import Response
# Other siemplify modules
from siemplify_utils import siemplify
# Enums
from source import enums
# Source
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import get_with_admin_credentials
from source.utils import get_with_test_credentials
from source.utils import log_and_assert
from source.utils import log_event
from source.utils import post_with_admin_credentials
from source.utils import post_with_test_credentials
from source.utils import put_with_admin_credentials
from source.utils import patch_with_admin_credentials
from source.utils import post_with_appkey, get_with_appkey

# Payloads
from payloads.cases import data_exfiltration_case

AUTH_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auth.json"
)
TESTS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests.json"
)

TOTAL_CASES_NEEDED = 7


# Typed dicts for type hints
class QueueCard(TypedDict):
  id: str
  title: str
  environment: str
  assigned_user: str


class ActionData(TypedDict):
  id: int
  title: str


# Classes for Response DTOs
class CaseQueueResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.case_cards = self.response_json.get("caseCards", [])
    self.page_size = self.response_json.get("pageSize")
    self.requested_page = self.response_json.get("requestedPage")
    self.total_count = self.response_json.get("totalCount", 0)


class CaseFullDetailsResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.wall_data = self.response_json.get("wallData", None)
    self.alerts: Union[list[AlertItem], list] = [
        AlertItem(item=x) for x in self.response_json.get("alerts", [])
    ]
    self.tags = self.response_json.get("tags", None)
    self.insights = self.response_json.get("insights", None)
    self.entity_cards = self.response_json.get("entityCards", None)
    self.entities = self.response_json.get("entities", None)
    self.description = self.response_json.get("description", None)
    self.title = self.response_json.get("title", None)
    self.priority = self.response_json.get("priority", None)
    self.assigned_user = self.response_json.get("assignedUserName", None)
    self.id = self.response_json.get("id", None)
    self.product_families = self.response_json.get("productFamilies", None)


class CaseDetailsResponse:
  """Class to represent case details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.alert_cards: Union[list[AlertItem], list] = [
        AlertCard(item=x) for x in self.response_json.get("alertCards", [])
    ]
    self.assigned_user = self.response_json.get("assignedUser")
    self.can_open_incident = self.response_json.get("canOpenIncident")
    self.creation_time = self.response_json.get("creationTimeUnixTimeInMs")
    self.description = self.response_json.get("description")
    self.end_time = self.response_json.get("endTimeUnixTimeInMs")
    self.environment = self.response_json.get("environment")
    self.id = self.response_json.get("id")
    self.incident_id = self.response_json.get("incidentId")
    self.is_important = self.response_json.get("isImportant")
    self.is_incident = self.response_json.get("isIncident")
    self.is_manual_case = self.response_json.get("isManualCase")
    self.is_overflow_case = self.response_json.get("isOverflowCase")
    self.is_test_case = self.response_json.get("isTestCase")
    self.modification_time = self.response_json.get(
        "modificationTimeUnixTimeInMs"
    )
    self.name = self.response_json.get("name")
    self.priority = self.response_json.get("priority")
    self.sla = Sla(self.response_json.get("sla"))
    self.stage = self.response_json.get("stage")
    self.stage_sla = Sla(self.response_json.get("stageSla"))
    self.start_time = self.response_json.get("startTimeUnixTimeInMs")
    self.status = self.response_json.get("status")
    self.tags = self.response_json.get("tags", [])
    self.type = self.response_json.get("type")


class AlertItem:
  """Class to represent alert details.
  """

  def __init__(self, item: dict):
    self.ticket_id = item.get("ticketId")
    self.status = item.get("status")
    self.identifier = item.get("identifier")
    self.has_workflows = item.get("hasWorkflows")
    self.workflows_status = item.get("workflowsStatus")
    self.source_system_name = item.get("sourceSystemName")
    self.security_event_cards = item.get("securityEventCards", [])
    self.entity_cards = item.get("entityCards", [])
    self.product_families = item.get("productFamilies", [])
    self.fields = item.get("fields", [])
    self.name = item.get("name")
    self.product = item.get("product")
    self.start_time = item.get("startTimeUnixTimeInMs")
    self.api_sla_expiration = item.get("apiSlaExpiration", {})
    self.is_manual_alert = item.get("isManualAlert")
    self.priority = item.get("priority")
    self.id = item.get("id")
    self.creation_time = item.get("creationTimeUnixTimeInMs")
    self.modification_time = item.get("modificationTimeUnixTimeInMs")
    self.additional_properties = item.get("additionalProperties", {})


class Sla:
  """Class to represent Alert or Case Sla.
  """

  def __init__(self, item: dict):
    self.sla_expiration_time = item.get("slaExpirationTime")
    self.critical_expiration_time = item.get("criticalExpirationTime")
    self.expiration_status = item.get("expirationStatus")
    self.remaining_time_since_last_pause = item.get(
        "remainingTimeSinceLastPause"
    )


class AlertCard:
  """Class to represent alert card.
  """

  def __init__(self, item: dict):
    self.alert_group_identifier = item.get("alertGroupIdentifier")
    self.creation_time = item.get("creationTimeUnixTimeInMs")
    self.identifier = item.get("identifier")
    self.device_product = item.get("deviceProduct")
    self.end_time = item.get("endTime")
    self.events_count = item.get("eventsCount")
    self.fields_groups = item.get("fieldsGroups", [])
    self.id = item.get("id")
    self.identifier = item.get("identifier")
    self.is_manual_alert = item.get("isManualAlert")
    self.modification_time = item.get("modificationTimeUnixTimeInMs")
    self.name = item.get("name")
    self.playbook_attached = item.get("playbookAttached")
    self.playbook_run_count = item.get("playbookRunCount",)
    self.priority = item.get("priority")
    self.rule_generator = item.get("ruleGenerator")
    self.sla = Sla(item.get("sla"))
    self.source_rule_url = item.get("sourceRuleUrl")
    self.source_url = item.get("sourceUrl")
    self.start_time = item.get("startTime")
    self.status = item.get("status")
    self.title = item.get("title")
    self.workflows_status = item.get("workflowsStatus")


class AlertEventsResponse:
  """Class to represent alert events response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.events = [AlertEventItem(item=x) for x in self.response_json]


class AlertEventItem:
  """Class to represent alert event.
  """

  def __init__(self, item: dict):
    self.response_json = item
    self.fields = item.get("fields")
    self.case_id = item.get("caseId")
    self.alert_identifier = item.get("alertIdentifier")
    self.name = item.get("name")
    self.product = item.get("product")
    self.port = item.get("port")
    self.source_system_name = item.get("sourceSystemName")
    self.outcome = item.get("outcome")
    self.type = item.get("type")
    self.time = item.get("time")
    self.artifact_entities = item.get("artifactEntities", [])


class ManualActionResponse:
  """Class to represent manual action details in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.script_result = self.response_json.get("scriptResultEntityData", [])
    self.result_name = self.response_json.get("resultName")
    self.properties = self.response_json.get("properties", {})
    self.result_code = self.response_json.get("resultCode")
    self.message = self.response_json.get("message")
    self.status = self.response_json.get("status")
    self.result_value = self.response_json.get("resultValue")
    entities_result = self.response_json.get("resultEntitiesJsonObject")
    if not entities_result:
      entities_result = "{}"
    self.entities_result = json.loads(entities_result)
    result_json_object = self.response_json.get("resultJsonObject")
    if not result_json_object:
      result_json_object = "{}"
    self.result_json_object = json.loads(result_json_object)
    json_result = self.result_json_object.get(
        "JsonResult", {}).get("RawJson", "{}")
    if json_result.startswith("<%"):
      self.json_result = {
          "json_result_too_big": (
              "The json result was too big, "
              "and was not returned in the response"
          )
      }
    else:
      self.json_result = json.loads(json_result)

class CaseComment:
  """Class to represent a case comment.
  """
  def __init__(self, response: dict):
    self.comment = response.get("comment")
    self.last_editor_id = response.get("lastEditorId")
    self.last_editor_full_name = response.get("lastEditorFullName")
    self.field_id = response.get("fileId")
    self.file_type = response.get("fileType")
    self.file_name = response.get("fileName")
    self.file_id = response.get("fileId")
    self.is_deleted = response.get("isDeleted")
    self.creator_user_id = response.get("creatorUserId")
    self.creator_full_name = response.get("creatorFullName")
    self.id = response.get("id")
    self.type = response.get("type")
    self.case_id = response.get("caseId")
    self.is_favorite = response.get("isFavorite")
    self.modification_time_unix_in_ms = \
      response.get("modificationTimeUnixTimeInMs")
    self.creation_time_unix_time_in_ms = \
      response.get("creationTimeUnixTimeInMs")
    self.alert_identifier = response.get("alertIdentifier")

def run_manual_action(
    case_id: int,
    action_name: str,
    action_data: Union[str, dict],
    integration_instance: Optional[str] = None,
    scope: Optional[str] = "All entities",
    action_provider: str = "Scripts",
    alert_name: Optional[str] = None,
    target_entities: Optional[list[str]] = None,
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> ManualActionResponse:
  """Runs a manual action on a case.

  Args:
    case_id: id of the case
    action_name: full name of the action
    action_data: a name of json file in /AutomationBE with or without
      the .json (can add folders before the filename) OR dict with parameters
    integration_instance: id of the integration instance for this action.
      Gets the ID from the integration name before the underscore in
      action_name if None (defaults to None)
    scope: scope of the action. Defaults to "All entities". Automatically set
      to None if entities are provided in target_entities
    action_provider: action provider in siemplify (Defaults to "Scripts")
    alert_name: name of the alert. Automatically gets the alert from the case
      if None (Defaults to None)
    target_entities: a list of entity names to use action on. Scope must not
      be None if this is None (Defaults to None)
    test_name: name of the test, if None looks at the stack (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A ManualActionResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  case = get_case_full_details(case_id=case_id)
  case_json = case.response_json
  if not alert_name:
    alerts = [(case_json["alerts"][0]
               ["additionalProperties"]["alertGroupIdentifier"])]
  if isinstance(action_data, str):
    if not action_data.endswith(".json"):
      file_name = action_data.lower() + ".json"
    else:
      file_name = action_data.lower()
    path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), file_name
    )
    with open(path, "r") as file:
      action_data = json.load(file)
  if not integration_instance:
    split_action_name = action_name.split("_")
    integration_name = split_action_name[0]
    all_installed = siemplify.integrations.get_installed_by_environment(
        environment="*",
    )
    instances = (all_installed.json().get("instances"))
    found_integration = siemplify.utils.find_key_value_in_json(
        json_data=instances,
        key="integrationIdentifier",
        value=integration_name,
    )
    integration_instance = found_integration.get("identifier")
  stringified_data = siemplify.utils.stringify_dict(input_dict=action_data)
  action_properties = {
      "ScriptName": action_name,
      "ScriptParametersEntityFields": stringified_data,
      "IntegrationInstance": integration_instance,
  }
  # Fetch data for the entities
  entities = []
  if target_entities:
    scope = None
    for entity in target_entities:
      entity_data = siemplify.entities.get_existing_entity_data(
          entity_name=entity,
          case_id=case_id,
      )
      entities.append(entity_data)
  payload = {
      "alertGroupIdentifiers": alerts,
      "scope": scope,
      "targetEntities": entities or [],
      "caseId": case_id,
      "actionName": action_name,
      "actionProvider": action_provider,
      "properties": action_properties,
      "isPredefinedScope": True if scope else False,
    }
  response = post_with_admin_credentials(
      url=API_CASE_RUN_MANUAL_ACTION_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully ran manual action '{action_name}' on case #{case_id}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to run manual action '{action_name}' on case #{case_id}"
            f" for {test_name}"
        ),
    )
  return ManualActionResponse(response=response)


def get_custom_cases() -> Response:
  """Fetches details of all custom cases.

  Returns:
    A response object
  """
  return get_with_admin_credentials(
      url=API_GET_CUSTOM_CASES_ENDPOINT,
  )


def simulate_cases_in_environment(
    cases: Optional[list[str]] = None,
    environment: str = "Default Environment",
    test_name: Optional[str] = None,
    no_wait: bool = False,
) -> Response:
  """Simulates specified or default cases.

  When no cases are specified 6 default cases will be simulated:
    Access to disabled account, Data Exfiltration, Failed Login, Phishing Email,
    Malware Detected, IRC Connection

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    cases: list of cases to simulate (defaults to None)
    environment: name of the environment to simulate cases in
    test_name: name of the test (Defaults to None)
    no_wait: set to False if you don't want function to check how many
      cases are in the environment and wait for a needed amount

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not cases:
    cases_list = [
        "Access to disabled account", "Data Exfiltration", "Failed Login",
        "IRC Connections", "Malware Detected", "Phishing Email"
    ]
  else:
    cases_list = cases
  payload = {
      "environment": environment,
      "customCases": cases_list,
      "kinds": []
  }
  starting_number = get_cases_in_environments(
      environments=[environment]
  ).total_count
  required_cases = starting_number
  if cases:
    required_cases += len(cases)
    if "Failed Login" in cases:
      required_cases += 2
    elif "IRC Connections" in cases:
      required_cases += 1
  else:
    required_cases += TOTAL_CASES_NEEDED
  response = post_with_admin_credentials(
      url=API_SIMULATE_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if no_wait:
    if test_name:
      log_and_assert(
          response=response,
          test_name=test_name,
          success_message=(
              f"Simulated cases {cases_list} in environment '{environment}'"
              f" for {test_name}"
          ),
          failure_message=(
              f"Failed to simulate cases in environment '{environment}'"
              f" for {test_name}"
          ),
      )
    return response
  if not cases:
    time.sleep(2)
    cases_count = get_cases_in_environments(
        environments=[environment]
    ).total_count
    fail_counter = 0
    while cases_count != required_cases:
      time.sleep(2)
      cases_count = get_cases_in_environments(
          environments=[environment],
      ).total_count
      fail_counter += 1
      if fail_counter > 15:
        break
  else:
    time.sleep(2)
    cases_count = get_cases_in_environments(
        environments=[environment],
    ).total_count
    fail_counter = 0
    while cases_count != required_cases:
      time.sleep(2)
      cases_count = get_cases_in_environments(
          environments=[environment],
      ).total_count
      fail_counter += 1
      if fail_counter > 15:
        break
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Simulated cases {cases_list} in environment '{environment}'"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to simulate cases in environment '{environment}'"
            f" for {test_name}"
        ),
    )
  return response


def simulate_cases_for_test(
    cases: Optional[list[str]] = None,
    test_name: Optional[str] = None,
    log_response: bool = True,
    ignore_400: bool = False,
    allow_empty_cases: bool = False
) -> Response:
  """Simulates specified or default cases.

  When no cases are specified 6 default cases will be simulated:
    Access to disabled account, Data Exfiltration, Failed Login, Phishing Email,
    Malware Detected, IRC Connection

  Args:
    cases: list of cases to simulate (defaults to None)
    to get error response, otherwise all available cases will be simulated
    test_name: name of the test, if None looks at the stack (Defaults to None)
    log_response: set to False if you don't want the response to be logged
    ignore_400: set this to True if you want 400 response to be considered
      a success
    allow_empty_cases: set to True if want to pass empty list of cases

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if not cases and not(allow_empty_cases):
    cases_list = [
        "Access to disabled account", "Data Exfiltration", "Failed Login",
        "IRC Connections", "Malware Detected", "Phishing Email"
    ]
  else:
    cases_list = cases
  payload = {
      "environment": test_name,
      "customCases": cases_list,
      "kinds": [],
  }
  starting_number = get_cases_for_test(
      test_name=test_name,
      log_response=False,
  ).total_count
  required_cases = starting_number
  if cases:
    required_cases += len(cases)
    if "Failed Login" in cases:
      required_cases += 2
    elif "IRC Connections" in cases:
      required_cases += 1
  else:
    required_cases += TOTAL_CASES_NEEDED
  response = post_with_test_credentials(
      test_name=test_name,
      url=API_SIMULATE_CASE_ENDPOINT,
      payload=payload,
  )
  if not cases:
    time.sleep(2)
    cases_count = get_cases_for_test(
        test_name=test_name,
        log_response=False,
    ).total_count
    fail_counter = 0
    while cases_count != required_cases:
      time.sleep(2)
      cases_count = get_cases_for_test(
          test_name=test_name,
          log_response=False,
      ).total_count
      fail_counter += 1
      if fail_counter > 15:
        break
  else:
    time.sleep(2)
    cases_count = get_cases_for_test(
        test_name=test_name,
        log_response=False,
    ).total_count
    fail_counter = 0
    while cases_count != required_cases:
      time.sleep(2)
      cases_count = get_cases_for_test(
          test_name=test_name,
          log_response=False,
      ).total_count
      fail_counter += 1
      if fail_counter > 15:
        break
  if log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Simulated cases {cases_list} for {test_name}",
        failure_message=f"Failed to simulate cases for {test_name}",
        ignore_400=ignore_400
    )

  return response


def create_manual_case_for_test(
    title: str = "TestCase",
    alert_name: str = "TestAlert",
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> CaseFullDetailsResponse:
  """Creates a manual case.

  Args:
    title: title of new case
    alert_name: name of the alert
    test_name: name of the test, if None looks at the stack (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  user = siemplify.users.get_test_user_data(test_name=test_name).username
  # Create strings for time period
  time_now = dt.datetime.now()
  time_delta = dt.timedelta(seconds=30)
  occurence_time = time_now - time_delta
  occurence_time_iso = occurence_time.isoformat()
  payload = {
      "title": title,
      "assignedUser": user,
      "reason": "Testing",
      "priority": 60,
      "environment": test_name,
      "isImportant": False,
      "alertName": alert_name,
      "occurenceTime": occurence_time_iso,
      "slaExpirationDateTime": None,
      "entities": [],
      "playbooks": [],
      "tags": []
  }
  response = post_with_test_credentials(
      test_name=test_name,
      url=API_CREATE_MANUAL_CASE_ENDPOINT,
      payload=payload,
  )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Created manual case '{title}' for {test_name}",
        failure_message=f"Failed to create a manual case for {test_name}",
    )
  case_id = response.json()
  return get_case_full_details(case_id=case_id)


def create_manual_case_in_environment(
    environment: str,
    title: str = "TestCase",
    alert_name: str = "TestAlert",
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> CaseFullDetailsResponse:
  """Creates a manual case.

  Args:
    environment: name of the environment
    title: title of new case
    alert_name: name of the alert
    test_name: name of the test, if None looks at the stack (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  user = siemplify.users.get_admin_user_data().username
  # Create strings for time period
  time_now = dt.datetime.now()
  time_delta = dt.timedelta(seconds=30)
  occurence_time = time_now - time_delta
  occurence_time_iso = occurence_time.isoformat()
  payload = {
      "title": title,
      "assignedUser": user,
      "reason": "Testing",
      "priority": 60,
      "environment": environment,
      "isImportant": False,
      "alertName": alert_name,
      "occurenceTime": occurence_time_iso,
      "slaExpirationDateTime": None,
      "entities": [],
      "playbooks": [],
      "tags": []
  }
  response = post_with_admin_credentials(
      url=API_CREATE_MANUAL_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Created manual case {title} in environment {environment}"
            f" for {test_name}"
        ),
        failure_message=f"Failed to create a manual case for {test_name}",
    )
  case_id = response.json()
  return get_case_full_details(case_id=case_id)


def get_cases_in_all_environments(
    time_period: int = 1,
    filters: Optional[list[dict]] = None,
    filter_operator: str = "and",
    sort_type: str = "modified newest",
) -> CaseQueueResponse:
  """Fetches all cases from the siemplify_client.

  Available sorting types:
    "id high", "id low", "time newest", "time oldest",
    "modified newest", "modified oldest", "priority high", "priority low",
    "alert type longest", "alert type shortest", "case stage longest",
    "case stage shortest"

  Args:
    time_period: time period for case filter (default to 1)
    filters: filters to be applied for get cases list (default = None)
    filter_operator: logical operator for filters. Can be "and"/"or"
      (Defaults to "and")
    sort_type: the type of sorting

  Returns:
    A CaseQueueResponse object
  """
  time_options = (1, 2, 3)
  operator_options = {"and": 0, "or": 1}
  sort_options = {"id high": 6, "id low": 7, "time newest": 0, "time oldest": 1,
                  "modified newest": 2, "modified oldest": 3,
                  "priority high": 4, "priority low": 5,
                  "alert type longest": 8, "alert type shortest": 9,
                  "case stage longest": 10, "case stage shortest": 11
                  }
  assert time_period in time_options, f"Wrong time period: {time_period}"
  assert filter_operator.lower() in operator_options.keys(), (
      f"Wrong logical operator: {filter_operator}"
  )
  assert sort_type.lower() in sort_options.keys(), (
      f"Wrong sort type: {sort_type}"
  )
  payload = {
      "sortType": sort_options[sort_type.lower()],
      "requestedPage": 0,
      "pageSize": 50,
      "searchTerm": "",
      "filterOperator": operator_options[filter_operator.lower()],
      "filters": filters or [],
      "startTime": 0,
      "endTime": 0,
      "timeRangeFilter": time_period,
  }
  response = post_with_admin_credentials(
      url=API_GET_CASES_ENDPOINT,
      payload=payload,
  )
  # Check if this was called from a test
  test_name = check_test_name_can_be_none()
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched cases for {test_name}",
        failure_message=f"Failed to fetch cases for {test_name}",
    )

  return CaseQueueResponse(response=response)


def get_cases_for_test(
    time_period: int = 1,
    filters: Optional[list[dict]] = None,
    filter_operator: str = "and",
    sort_type: str = "modified newest",
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> CaseQueueResponse:
  """Fetches all cases from the siemplify_client.

  Available sorting types:
    "id high", "id low", "time newest", "time oldest",
    "modified newest", "modified oldest", "priority high", "priority low",
    "alert type longest", "alert type shortest", "case stage longest",
    "case stage shortest"

  Args:
    time_period: time period for case filter (default to 1)
    filters: filters to be applied for get cases list (default = None)
    filter_operator: logical operator for filters. Can be "and"/"or"
      (Defaults to "and")
    sort_type: the type of sorting

  Returns:
    A CaseQueueResponse object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  time_options = (1, 2, 3)
  operator_options = {"and": 0, "or": 1}
  sort_options = {"id high": 6, "id low": 7, "time newest": 0, "time oldest": 1,
                  "modified newest": 2, "modified oldest": 3,
                  "priority high": 4, "priority low": 5,
                  "alert type longest": 8, "alert type shortest": 9,
                  "case stage longest": 10, "case stage shortest": 11
                  }
  assert time_period in time_options, f"Wrong time period: {time_period}"
  assert filter_operator.lower() in operator_options.keys(), (
      f"Wrong logical operator: {filter_operator}"
  )
  assert sort_type.lower() in sort_options.keys(), (
      f"Wrong sort type: {sort_type}"
  )
  payload = {
      "sortType": sort_options[sort_type.lower()],
      "requestedPage": 0,
      "pageSize": 50,
      "searchTerm": "",
      "filterOperator": operator_options[filter_operator.lower()],
      "filters": filters or [],
      "startTime": 0,
      "endTime": 0,
      "timeRangeFilter": time_period,
  }
  response = post_with_test_credentials(
      url=API_GET_CASES_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched cases for {test_name}",
        failure_message=f"Failed to fetch cases for {test_name}",
    )

  return CaseQueueResponse(response=response)


def get_cases_in_environments(
    environments: list[str],
    test_name: Optional[str] = None,
) -> CaseQueueResponse:
  """Fetches all cases for specific test environment.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    environments: list of environments to fetch cases in
    test_name: name of the test (Defaults to None)

  Returns:
    A CaseQueueResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  # Create environment filter
  filter1 = create_case_filter_criteria(
      criteria_type="environments",
      operator=True,
      values=environments,
  )
  # Find all the cases
  return get_cases_in_all_environments(
      filters=[filter1],
  )


def create_case_filter_criteria(
    criteria_type: str,
    operator: bool,
    values: list[str],
) -> dict:
  """Creates a criteria for case filter.

  Available criteria types: "priorities", "stages", "alert names", "analysts",
    "environments", "products", "tags"
  Available priority types: "critical", "high", "medium", "low", "informative"
  Available stage options: "Incident", "Improvement", "Triage", "Assessment",
    "Investigation", "Research"
  Args:
    criteria_type: type of criteria
    operator: True for Is, False for IsNot
    values: value of criteria

  Returns:
    A dictionary to use as a filter criteria in get_casess
  """
  criteria_types = {"priorities": 2, "stages": 3, "alert names": 5,
                    "analysts": 0, "environments": 1, "products": 6, "tags": 4}
  priority_options = {"critical": 100, "high": 80,
                      "informative": -1, "low": 40, "medium": 60}
  stages_options = ("Incident", "Improvement", "Triage", "Assessment",
                    "Investigation", "Research")
  # Verify data is valid
  criteria_values = []
  assert criteria_type.lower() in criteria_types.keys(), (
      f"Wrong type: {criteria_type}"
  )
  if criteria_type.lower() == "priorities":
    for value in values:
      assert value.lower() in priority_options.keys(), (
          f"Wrong priority: {value}"
      )
      criteria_values.append(priority_options[value.lower()])
  elif criteria_type.lower() == "stages":
    for value in values:
      assert value in stages_options, f"Wrong stage: {value}"
      criteria_values.append(value)
  else:
    for value in values:
      criteria_values.append(value)
  return {
      "type": criteria_types[criteria_type.lower()],
      "operator": 0 if operator else 1,
      "values": criteria_values,
      "includeUsers": True,
  }


def get_last_case_id_for_test(
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> int:
  """Fetches ID of the first case in case queue.

  Args:
    test_name: name of the test, if None looks at the stack (Defaults to None)
    log_response: set to False if you don't want the response to be logged
  Returns:
    A case id
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  # Find all the cases
  cases = get_cases_for_test(test_name=test_name, log_response=False)
  case_ids = [case["id"] for case in cases.case_cards]
  if not case_ids:
    log_event(
        message="No cases found",
        details="Tried to fetch last case ID, but no cases were found",
        success=False,
        test_name=test_name,
    )
    raise ValueError("No cases found")
  last_case_id = case_ids[0]
  if log_response:
    log_event(
        message=f"Fetched last case ID for {test_name}",
        details=f"Case ID: {last_case_id}",
        success=True,
        test_name=test_name,
    )
  return last_case_id


def get_last_case_id_in_environments(
    environments: list[str],
    test_name: Optional[str] = None
) -> int:
  """Fetches ID of the first case in case queue.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    environments: list of environments to fetch cases in
    test_name: name of the test (Defaults to None)
  Returns:
    A case id
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  # Create environment filter
  filter1 = create_case_filter_criteria(
      criteria_type="environments",
      operator=True,
      values=environments,
  )
  # Find all the cases
  cases = get_cases_in_all_environments(
      filters=[filter1],
  )
  case_ids = [case["id"] for case in cases.case_cards]
  if not case_ids and test_name:
    log_event(
        message="No cases found",
        details="Tried to fetch last case ID, but no cases were found",
        success=False,
        test_name=test_name,
    )
    raise ValueError("No cases found")
  last_case_id = case_ids[0]
  if test_name:
    log_event(
        message=(
            f"Fetched last case ID in environments: {environments}"
            f" for {test_name}"
        ),
        details=f"Case ID: {last_case_id}",
        success=True,
        test_name=test_name,
    )
  return last_case_id


def get_case_details(
    case_id: int,
    test_name: Optional[str] = None,
) -> CaseDetailsResponse:
  """Fetches details of the case with the specified ID.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    case_id: a string with case ID number
    test_name: name of the test (Defaults to None)

  Returns:
    A CaseResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_CASE_DETAILS_ENDPOINT.format(case_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched case details of case #{case_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch case details of case #{case_id} for {test_name}"
        ),
    )
  return CaseDetailsResponse(response=response)


def get_case_full_details(
    case_id: int,
    test_name: Optional[str] = None,
) -> CaseFullDetailsResponse:
  """Fetches full details of the case with the specified ID.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    case_id: a string with case ID number
    test_name: name of the test (Defaults to None)

  Returns:
    A CaseResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_CASE_FULL_DETAILS_ENDPOINT.format(case_id),
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched full case details of case #{case_id} for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch case details of case #{case_id} for {test_name}"
        ),
    )
  return CaseFullDetailsResponse(response=response)


def get_last_case_details_for_test(
    test_name: Optional[str] = None,
) -> CaseDetailsResponse:
  """Fetches details of the last case created for a specified test.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A CaseResponse object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  case_id = get_last_case_id_for_test(test_name=test_name, log_response=False)
  return get_case_details(case_id=case_id, test_name=test_name)


def get_last_case_details_in_environments(
    environments: list[str],
    test_name: Optional[str] = None,
) -> CaseDetailsResponse:
  """Fetches details of the last created case found in specified environments.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    environments: list of environments to fetch cases in
    test_name: name of the test (Defaults to None)

  Returns:
    A CaseResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  case_id = get_last_case_id_in_environments(
      environments=environments,
      test_name=test_name,
  )
  return get_case_details(case_id=case_id, test_name=test_name)


def get_last_case_full_details_for_test(
    test_name: Optional[str] = None,
) -> CaseFullDetailsResponse:
  """Fetches details of the last case created for a specified test.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A CaseResponse object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  case_id = get_last_case_id_for_test(test_name=test_name, log_response=False)
  return get_case_full_details(case_id=case_id, test_name=test_name)


def get_last_case_full_details_in_environments(
    environments: list[str],
    test_name: Optional[str] = None,
) -> CaseFullDetailsResponse:
  """Fetches details of the last created case found in specified environments.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    environments: list of environments to fetch cases in
    test_name: name of the test (Defaults to None)

  Returns:
    A CaseResponse object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  case_id = get_last_case_id_in_environments(
      environments=environments,
      test_name=test_name,
  )
  return get_case_full_details(case_id=case_id, test_name=test_name)


def wait_for_case_for_test(
    data: str,
    data_type: str = "title",
    retries: int = 20,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> Union[list[dict], dict]:
  """Fetches cases and looks for details in the cases.

  If details are not found in cases, waits a set amount of seconds, retries
    it several times if needed. If test_name is not specified it will
    try to get it from the stack. Use test_name only if you are not calling
    the function from a test.

  Args:
    data: value to look for in the case cards
    data_type: key to look for in the case cards (Defaults to "title")
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A dict or list from find_key_value_in_json
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  attempts = 0
  while attempts < retries:
    cases = get_cases_for_test(test_name=test_name, log_response=False)
    case_check = siemplify.utils.find_key_value_in_json(
        json_data=cases.case_cards,
        key=data_type,
        value=data,
    )
    if case_check:
      attempts = retries
      return case_check
    else:
      attempts += 1
      if attempts >= retries:
        return case_check
      time.sleep(cadence)


def wait_for_case_count_for_test(
    count: Optional[int] = None,
    more_than: Optional[int] = None,
    less_than: Optional[int] = None,
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> int:
  """Fetches cases and looks for specific number of cases.

  If case count is not what was specified, waits a set amount of seconds,
    retries it several times if needed.

  Args:
    count: exact number of cases to look for
    more_than: number of cases to look for that is more than this value
    less_than: number of cases to look for that is less than this value
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A total number of cases after the condition is met OR retires are done
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if (count and more_than or count and less_than or
      count and more_than and less_than):
    raise ValueError("Please only use 'count' OR 'less_than' OR 'more_than'")
  attempts = 0
  while attempts < retries:
    cases = get_cases_for_test(test_name=test_name, log_response=True)
    total_count = cases.total_count
    if count and total_count == count:
      attempts = retries
      return total_count
    elif more_than and total_count > more_than:
      attempts = retries
      return total_count
    elif less_than and total_count < less_than:
      attempts = retries
      return total_count
    else:
      attempts += 1
      if attempts >= retries:
        return total_count
      time.sleep(cadence)


def wait_for_case_in_environments(
    environments: list[str],
    data: str,
    data_type: str = "title",
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> Union[list[dict], dict]:
  """Fetches cases and looks for details in the cases.

  If details are not found in cases, waits a set amount of seconds, retries
    it several times if needed. If test_name is not specified it will
    try to get it from the stack. Use test_name only if you are not calling
    the function from a test.

  Args:
    environments: environemnts to look for case in
    data: value to look for in the case cards
    data_type: key to look for in the case cards (Defaults to "title")
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A dict or list from find_key_value_in_json
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  attempts = 0
  while attempts < retries:
    cases = get_cases_in_environments(environments=environments)
    case_check = siemplify.utils.find_key_value_in_json(
        json_data=cases.case_cards,
        key=data_type,
        value=data,
    )
    if case_check:
      attempts = retries
      return case_check
    else:
      attempts += 1
      if attempts >= retries:
        return case_check
      time.sleep(cadence)


def wait_for_case_count_in_environments(
    environments: list[str],
    count: Optional[int] = None,
    more_than: Optional[int] = None,
    less_than: Optional[int] = None,
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> int:
  """Fetches cases and looks for specific number of cases.

  If case count is not what was specified, waits a set amount of seconds,
    retries it several times if needed.

  Args:
    environments: environemnts to look for case count in
    count: exact number of cases to look for
    more_than: number of cases to look for that is more than this value
    less_than: number of cases to look for that is less than this value
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A total number of cases after the condition is met OR retires are done
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if (count and more_than or count and less_than or
      count and more_than and less_than):
    raise ValueError("Please only use 'count' OR 'less_than' OR 'more_than'")
  attempts = 0
  while attempts < retries:
    cases = get_cases_in_environments(environments=environments)
    total_count = cases.total_count
    if count and total_count == count:
      attempts = retries
      return total_count
    elif more_than and total_count > more_than:
      attempts = retries
      return total_count
    elif less_than and total_count < less_than:
      attempts = retries
      return total_count
    else:
      attempts += 1
      if attempts >= retries:
        return total_count
      time.sleep(cadence)


def wait_for_alert_count_for_test(
    count: Optional[int] = None,
    more_than: Optional[int] = None,
    less_than: Optional[int] = None,
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> int:
  """Fetches cases and looks for specific number of alerts in cases.

  If case count is not what was specified, waits a set amount of seconds,
    retries it several times if needed.

  Args:
    count: exact number of cases to look for
    more_than: number of cases to look for that is more than this value
    less_than: number of cases to look for that is less than this value
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A total number of cases after the condition is met OR retires are done
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if (count and more_than or count and less_than or
      count and more_than and less_than):
    raise ValueError("Please only use 'count' OR 'less_than' OR 'more_than'")
  attempts = 0
  while attempts < retries:
    cases = get_cases_for_test(test_name=test_name, log_response=True)
    case_cards = cases.case_cards
    total_alerts = 0
    for case in case_cards:
      alerts = case.get("alertsCount")
      total_alerts += alerts
    total_count = total_alerts
    if count and total_count == count:
      attempts = retries
      return total_count
    elif more_than and total_count > more_than:
      attempts = retries
      return total_count
    elif less_than and total_count < less_than:
      attempts = retries
      return total_count
    else:
      attempts += 1
      if attempts >= retries:
        return total_count
      time.sleep(cadence)


def wait_for_alert_count_in_environments(
    environments: list[str],
    count: Optional[int] = None,
    more_than: Optional[int] = None,
    less_than: Optional[int] = None,
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> int:
  """Fetches cases and looks for specific number of alerts.

  If case count is not what was specified, waits a set amount of seconds,
    retries it several times if needed.

  Args:
    environments: environemnts to look for case count in
    count: exact number of cases to look for
    more_than: number of cases to look for that is more than this value
    less_than: number of cases to look for that is less than this value
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test to fetch case in (Defaults to None)

  Returns:
    A total number of cases after the condition is met OR retires are done
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if (count and more_than or count and less_than or
      count and more_than and less_than):
    raise ValueError("Please only use 'count' OR 'less_than' OR 'more_than'")
  attempts = 0
  while attempts < retries:
    cases = get_cases_in_environments(environments=environments)
    case_cards = cases.case_cards
    total_alerts = 0
    for case in case_cards:
      alerts = case.get("alertsCount")
      total_alerts += alerts
    total_count = total_alerts
    if count and total_count == count:
      attempts = retries
      return total_count
    elif more_than and total_count > more_than:
      attempts = retries
      return total_count
    elif less_than and total_count < less_than:
      attempts = retries
      return total_count
    else:
      attempts += 1
      if attempts >= retries:
        return total_count
      time.sleep(cadence)


def close_cases_in_environments(
    environments: list[str],
    cases: Optional[list[int]] = None,
    close_reason: Union[str, enums.CaseCloseReason] = (
        enums.CaseCloseReason.NOT_MALICIOUS
    ),
    root_cause: Union[str, enums.CaseCloseRootCause] = (
        enums.CaseCloseRootCause.NotMalicious.LAB_TEST
    ),
    close_comment: str = "",
    test_name: Optional[str] = None,
) -> Response:
  """Closes all cases with listed IDs in specified environments.

  If cases are None closes last 50 cases.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    environments: list of environments to clase cases in
    cases: list of case numbers (defaults to None)
    close_reason: reason for closing the case
    root_cause: cause of closing
    close_comment: comment on closing the case
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not cases:
    cases = get_cases_in_environments(environments=environments)
    case_ids = [case["id"] for case in cases.case_cards]
  else:
    case_ids = cases
  payload = {
      "casesIds": case_ids,
      "rootCause": root_cause,
      "closeReason": close_reason,
      "closeComment": close_comment,
  }
  response = post_with_admin_credentials(
      url=API_CLOSE_CASES_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  time.sleep(1)
  cases_count = get_cases_in_environments(
      environments=environments,
  ).total_count
  if cases_count == 0:
    return response
  fail_counter = 0
  while cases_count > 0:
    time.sleep(1)
    cases_count = get_cases_in_environments(
        environments=environments,
    ).total_count
    fail_counter += 1
    if fail_counter > 15:
      break
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Closed cases {case_ids} in environments: {environments}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to close cases in environments: {environments}"
            f" for {test_name}"
        ),
    )
  return response


def close_cases_for_test(
    cases: Optional[list[int]] = None,
    close_reason: Union[str, enums.CaseCloseReason] = (
        enums.CaseCloseReason.NOT_MALICIOUS
    ),
    root_cause: Union[str, enums.CaseCloseRootCause] = (
        enums.CaseCloseRootCause.NotMalicious.LAB_TEST
    ),
    close_comment: str = "",
    test_name: Optional[str] = None,
) -> Response:
  """Closes all cases with listed IDs for test environment.

  If cases are None closes last 50 cases.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    cases: list of case numbers (defaults to None)
    close_reason: reason for closing the case
    root_cause: cause of closing
    close_comment: comment on closing the case
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if not cases:
    cases = get_cases_for_test(test_name=test_name, log_response=False)
    case_ids = [case["id"] for case in cases.case_cards]
  else:
    case_ids = cases
  payload = {
      "casesIds": case_ids,
      "rootCause": root_cause,
      "closeReason": close_reason,
      "closeComment": close_comment,
  }
  response = post_with_test_credentials(
      url=API_CLOSE_CASES_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  time.sleep(1)
  cases_count = get_cases_for_test(
      test_name=test_name,
      log_response=False,
  ).total_count
  if cases_count == 0:
    return log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Closed cases {case_ids} for {test_name}",
        failure_message=f"Failed to close cases for {test_name}",
    )
  fail_counter = 0
  while cases_count > 0:
    time.sleep(1)
    cases_count = get_cases_for_test(
        test_name=test_name,
        log_response=False,
    ).total_count
    fail_counter += 1
    if fail_counter > 15:
      break
  logged_response = log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Closed cases {case_ids} for {test_name}",
      failure_message=f"Failed to close cases for {test_name}",
    )
  return logged_response


def assign_case_to_user(
    case_id: int,
    user_id: Optional[str] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Assigns a specified case to a specified user.

  If user_id is not specified will automatically use user_id for the current
    test from the json.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    case_id: id of a case to assign a user to
    user_id: id of a user to assign
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object (contains JSON with assigned cases data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not user_id:
    user_id = siemplify.users.get_test_user_data(test_name=test_name).username
  case_details = siemplify.cases.get_case_full_details(case_id=case_id)
  assigned_user = case_details.assigned_user
  if assigned_user == user_id:
    if test_name:
      log_event(
          test_name=test_name,
          message=f"Case #{case_id} was already assigned to user {user_id}",
          success=True,
          details="No additional details",
      )
    return
  payload = {"caseId": case_id, "userId": user_id}
  response = post_with_admin_credentials(
      url=API_ASSIGN_USER_TO_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="case",
        item_name=case_id,
    )
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Assigned case #{case_id} to user {user_id} for {test_name}"
        ),
        failure_message=f"Failed to assign case #{case_id} to user {user_id}",
    )
  return response


def get_assigned_cases_for_test(
    test_name: Optional[str] = None,
) -> Response:
  """Fetches all cases assigned to the current user.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    test_name: name of the test (Defaults to None)
  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_test_credentials(
      url=API_GET_ASSIGNED_CASES_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched cases assigned to current user for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch cases assigned to current user for {test_name}"
        ),
    )
  return response


def get_assigned_cases_for_admin_user(
    test_name: Optional[str] = None,
) -> Response:
  """Fetches all cases assigned to the current user.

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_ASSIGNED_CASES_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched cases assigned to admin user for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch cases assigned to admin user for {test_name}"
        ),
    )
  return response


def remove_tag(
    case_id: int,
    tag: str,
    test_name: Optional[str] = None,
) -> Response:
  """Removes tag from a case.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    case_id: id of a case to remove tag from
    tag: name of the tag to remove
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "caseId": case_id,
      "tag": tag,
  }
  response = post_with_admin_credentials(
      url=API_REMOVE_CASE_TAG_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Removed tag {tag} from case #{case_id}"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to remove tag {tag} from case #{case_id} for {test_name}"
        ),
    )
  return response


def add_tag(
    tag: str,
    case_id: int,
    alert_name: Optional[str] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Removes tag from a case.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    tag: name of the tag to add
    case_id: id of a case to add tag to
    alert_name: name of the alert to add tag to. If None automatically chooses
      the first alert in the case (Defaults to None)
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not alert_name:
    case = get_case_full_details(case_id=case_id, test_name=test_name)
    case_json = case.response_json
    alert_name = (case_json["alerts"][0]
                  ["additionalProperties"]["alertGroupIdentifier"])
  payload = {
      "caseId": case_id,
      "alertIdentifier": alert_name,
      "tag": tag,
  }
  response = post_with_admin_credentials(
      url=API_ADD_CASE_TAG_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Added tag {tag} to case #{case_id} for test {test_name}"
        ),
        failure_message=(
            f"Failed to add tag {tag} to case #{case_id} for {test_name}"
        )
    )
  return response


def add_tag_to_fail(
    tag: str,
    case_id: int,
    alert_name: str = "example_alert",
    test_name: Optional[str] = None,
) -> Response:
  """Checks that Tag cannot be added.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    tag: name of the tag to add
    case_id: id of a case to add tag to
    alert_name: name of the alert to add tag to.(Defaults to example_alert)
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "caseId": case_id,
      "alertIdentifier": alert_name,
      "tag": tag,
  }
  response = post_with_admin_credentials(
      url=API_ADD_CASE_TAG_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Failed to add tag {tag} to case #{case_id} for {test_name}"
        ),
        failure_message=(
            f"Added tag {tag} to case #{case_id} for {test_name}"
        ),
        ignore_404=True
    )
  return response


def add_case_wall_comment(
    case_id: int,
    alert_identifier: str,
    comment: str = "Test comment",
    base_64_blob: Optional[str] = None,
    file_name: Optional[str] = None,
    file_type: Optional[str] = None,
    test_name: Optional[str] = None,
    log_response: bool = True,
    ignore_403: bool = False
) -> CaseComment:
  """Adds a comment to a case.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    case_id: id of the case to add case comment to
    comment: text of the comment
    alert_identifier: id of alert to add case comment to
    is_important: True or False
    base_64_blob: base64 representation of attachment
    file_name: name of attachment
    file_type: type of attachment, ex. ".png"
    test_name: name of test (Defaults to None)
    log_response: True/False to log response
    ignore_403: if set to True, 403 response code will be considered success

  Returns:
    A CaseComment class that represents the case comment
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
    "base64Blob": base_64_blob,
    "caseId": case_id,
    "alertIdentifier": alert_identifier,
    "comment": comment,
    "fileName": file_name,
    "fileType": file_type
  }
  response = post_with_test_credentials(
      url=API_ADD_CASE_COMMENT_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if log_response:
    log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Added comment '{comment}' to case #{case_id} for test {test_name}"
      ),
      failure_message=(
          f"Failed to add comment '{comment}' to case #{case_id}"
          f" for {test_name}"
      ),
      ignore_403=ignore_403
    )
    if response.status_code == 403:
      return CaseComment(response={})

  return CaseComment(response=response.json())

# API_UPDATE_CASE_COMMENT_ENDPOINT doesn't work
def update_case_wall_comment(
    attachment_id: int,
    comment_id: int,
    base_64_blob: Optional[str] = None,
    file_name: Optional[str] = None,
    file_type: Optional[str] = None,
    updated_comment: Optional[str]= "Updated comment",
    log_response: bool = True,
    test_name: Optional[str]= None,
) -> CaseComment:
  """Updates a comment from a case.

    If test_name is None function will try to get test name from the stack
      to check if it was called from a test. If you don't call it from the test
      but know which test log this call belongs to you can specify
      test_name manually.

    Args:
      attachment_id: id of attachment to update
      updated_comment: updated text of comment
      comment_id: id of comment to update
      base_64_blob: base64 representation of attachment
      file_name: name of attachment
      file_type: type of attachment, ex. ".png"
      test_name: name of test (Defaults to None)
      log_response: True/False to log response

    Returns:
      A CaseComment class that represents the case comment
    """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
    "attachmentId": attachment_id,
    "base64Blob": base_64_blob,
    "comment": updated_comment,
    "fileName": file_name,
    "fileType": file_type
  }
  response = put_with_admin_credentials(
    url=API_UPDATE_CASE_COMMENT_ENDPOINT.format(comment_id),
    payload=payload,
    test_name=test_name,
  )
  if log_response:
    log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
        f"Updated comment '{updated_comment}' for test {test_name}"
      ),
      failure_message=(
        f"Failed to update comment '{updated_comment}' for {test_name}"
      )
    )

  return CaseComment(response=response.json())

def get_all_case_wall_activities(
    case_id: int,
    alert_identifier: Optional[str] = None,
    user_owner_id: Optional[str] = None,
    test_name: Optional[str] = None
) -> list[CaseComment]:
  """Gets all case wall activities from a case.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    case_id: id of the case
    alert_identifier: optional, (Defaults to None)
    user_owner_id: optional, (Defaults to None)
    test_name: name of the test (Defaults to None)

  Returns:
    A list of CaseComment objects
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  final_endpoint = API_GET_CASE_WALL_ACTIVITIES_ENDPOINT.format(case_id)
  if alert_identifier is not None:
    final_endpoint += \
      final_endpoint + f"&AlertIdentifier={alert_identifier}"
  elif user_owner_id is not None:
    final_endpoint += \
      final_endpoint + f"&UserOwnerId={user_owner_id}"
  elif alert_identifier is not None and user_owner_id is not None:
    final_endpoint += \
      final_endpoint + \
      f"&AlertIdentifier={alert_identifier}&UserOwnerId={user_owner_id}"
  resp = get_with_admin_credentials(
    url=final_endpoint,
    log_request_enabled=True
  )
  final_response = log_and_assert(
    response=resp,
    test_name=test_name,
    success_message=f'All case wall activities were fetched for #{case_id}',
    failure_message=f'Failed to fetch all case wall activities from #{case_id}'
  )

  return [CaseComment(response=comment) for comment in final_response.json()]

def get_case_evidence_data(
    attachment_id: int,
    case_id: int,
    test_name: Optional[str]= None
):
  """Gets case evidence data (which is attachment from case wall comment).

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    attachment_id: id of attachment to download
    case_id: id of the case where case comment was added
    test_name: name of the test (Defaults to None)

  Returns:
    decoded string of attachment
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  resp = get_with_admin_credentials(
    url=API_GET_CASE_EVIDENCE_DATA.format(attachment_id)
  )
  log_and_assert(
    response=resp,
    test_name=test_name,
    success_message=f'Case comment attachment was downloaded'
                    f'from case with #{case_id} id',
    failure_message=f'Failed to download attachment from case wall comment'
                    f'from case with #{case_id} id'
  )

  return base64.b64encode(resp.content).decode('utf-8')

def mark_case_wall_comment_as_deleted(
    comment_id: int,
    case_id: int,
    test_name: Optional[str]= None
) -> Response:
  """Marks case wall comment as deleted or simply deletes case wall comment

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If you don't call it from the test
    but know which test log this call belongs to you can specify
    test_name manually.

  Args:
    comment_id: id of case wall comment
    case_id: id of the case where case comment was added
    test_name: name of the test (Defaults to None)

  Returns:
    Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  resp = patch_with_admin_credentials(
    url=API_MARK_COMMENT_AS_DELETED_ENDPOINT.format(comment_id)
  )
  log_and_assert(
    response=resp,
    test_name=test_name,
    success_message=f'Case comment was successfully deleted'
                    f'in case with #{case_id} id',
    failure_message=f'Failed to delete case wall comment'
                    f'from case with #{case_id} id'
  )

  return resp

def change_priority(
    case_id: int,
    priority: int = 100,
    test_name: Optional[str] = None,
) -> Response:
  """Changes priority of the case.

  Args:
    case_id: id of the case to change priority of
    priority: new priority
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "caseId": case_id,
      "priority": priority,
  }
  response = post_with_admin_credentials(
      url=API_UPDATE_CASE_PRIORITY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Changed priority of the case #{case_id}"
            f" to '{priority}' for test {test_name}"
        ),
        failure_message=(
            f"Failed to change priority of the case #{case_id}"
            f" to '{priority}' for {test_name}"
        ),
    )
  return response


def raise_incident(
    case_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches all events in the alert.

  Args:
    case_id: id of the case
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "caseId": case_id
  }
  response = post_with_admin_credentials(
      url=API_RAISE_INCIDENT_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Raised incident in the case #{case_id} for test {test_name}"
        ),
        failure_message=(
            f"Failed to raise incident in the case #{case_id}"
            f" for {test_name}"
        ),
    )
  return response


def change_stage(
    case_id: int,
    stage: enums.CaseStages = enums.CaseStages.INVESTIGATION,
    test_name: Optional[str] = None,
) -> Response:
  """Changes stage of the specified case.

  Args:
    stage: name of a new stage
    case_id: id of the case to change stage of
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "caseId": case_id,
      "stage": stage,
  }
  response = post_with_admin_credentials(
      url=API_CHANGE_CASE_STAGE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Changed stage of the case #{case_id} to {stage}"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to change stage of the case #{case_id} to {stage}"
            f" for {test_name}"
        ),
    )
  return response


def merge_cases_for_test(
    cases_ids: list[int],
    merge_to: int,
    test_name: Optional[str] = None,
):
  """Merges cases into one.

  This function uses test credentials! All cases must be assigned to test user!

  Args:
    cases_ids: list of cases ids to merge
    merge_to: id of case to merge into
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  response = post_with_test_credentials(
      url=API_MERGE_CASES_ENDPOINT,
      payload={"casesIds": cases_ids, "caseToMergeWith": merge_to},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Merged cases {cases_ids} into {merge_to}"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to merge cases {cases_ids} into {merge_to}"
            f" for {test_name}"
        ),
    )
  return response


def merge_cases_as_admin(
    cases_ids: list[int],
    merge_to: int,
    test_name: Optional[str] = None,
):
  """Merges cases into one.

  This function uses admin credentials specified in the .env! All cases must
    be assigned to admin user!

  Args:
    cases_ids: list of cases ids to merge
    merge_to: id of case to merge into
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_MERGE_CASES_ENDPOINT,
      payload={"casesIds": cases_ids, "caseToMergeWith": merge_to},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Merged cases {cases_ids} into {merge_to}"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to merge cases {cases_ids} into {merge_to}"
            f" for {test_name}"
        ),
    )
  return response


def move_case_to_different_environment(
    case_id: int,
    move_to: str,
    close_old_case: bool = False,
    test_name: Optional[str] = None,
) -> Response:
  """Move case to different environment.

  Args:
    case_id: list of cases ids to merge
    move_to: name of the environment to move the case to
    close_old_case: bool - close old case
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "environment": move_to,
      "caseId": case_id,
      "shouldCloseOldCase": close_old_case
  }
  response = post_with_admin_credentials(
      url=API_MOVE_CASE_TO_ENVIRONMENT_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Moved case #{case_id} into environment '{move_to}'"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to move case #{case_id} into environment '{move_to}'"
            f" for {test_name}"
        ),
    )
  time.sleep(3)
  return response


def reopen_cases(
    cases_id: list[int],
    test_name: Optional[str] = None,
) -> Response:
  """Reopens all selected cases in bulk or a single case.

  Args:
    cases_id: the list of case id's to reopen
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "reopenComment": "Automation Reopen Cases",
      "casesIds": cases_id
  }
  response = post_with_admin_credentials(
      url=API_REOPEN_CASES_IN_BULK_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Reopened cases {cases_id}"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to reopen cases {cases_id}"
            f" for {test_name}"
        ),
    )
  return response


def get_alert_events(
    case: int,
    alert_name: Optional[str] = None,
    test_name: Optional[str] = None,
) -> list[AlertEventItem]:
  """Gets list of AlertEventItem from alert events response.

  Args:
    case: case id
    alert_name: alert name (optional)
    test_name: name of the test (Defaults to None)

  Returns:
    List of AlertEventItem objects
  """
  def __get_alert_events(case, alert_name, test_name) -> AlertEventsResponse:
    """Fetches all events in the alert.

    Args:
      case: case id OR response object from get_case_full_details
        OR None to get last case
      alert_name: alert name (optional)
      test_name: name of the test (Defaults to None)

    Returns:
      AlertEventsResponse object
    """
    case_data = get_case_full_details(case_id=case)
    alert_name = alert_name or case_data.alerts[0].identifier
    payload = {
        "caseId": case,
        "alertIdentifier": alert_name,
    }
    response = post_with_admin_credentials(
        url=API_GET_ALERT_EVENTS_ENDPOINT,
        payload=payload,
        test_name=test_name,
    )
    return AlertEventsResponse(response=response)

  response = __get_alert_events(
      case=case,
      alert_name=alert_name,
      test_name=test_name
  )
  return response.events


def move_alert_to_case(
    alert_identifier: str,
    destination_case_id: int,
    source_case_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Moves alert from one case to another.

  Args:
    alert_identifier: identifier of an alert to be moved
    destination_case_id: id of case to move into
    source_case_id: id of the case to move from
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "alertIdentifier": alert_identifier,
      "destinationCaseId": destination_case_id,
      "sourceCaseId": source_case_id
  }
  response = post_with_admin_credentials(
      url=API_MOVE_ALERT_TO_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Moved alert '{alert_identifier}' "
            f"from case #{source_case_id} to case #{destination_case_id}"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to move alert '{alert_identifier}' "
            f"from case #{source_case_id} to case #{destination_case_id}"
            f" for {test_name}"
        ),
    )
  return response


def move_alert_to_new_case(
    alert_identifier: str,
    source_case_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Moves alert from one case to a new case.

  Args:
    alert_identifier: identifier of an alert to be moved
    source_case_id: id of the case to move from
    test_name: name of the test (Defaults to None)

  Returns:
    A response object.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "alertIdentifier": alert_identifier,
      "sourceCaseId": source_case_id
  }
  response = post_with_admin_credentials(
      url=API_MOVE_ALERT_TO_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Moved alert '{alert_identifier}' "
            f"from case #{source_case_id} to a new case"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to move alert '{alert_identifier}' "
            f"from case #{source_case_id} to a new case"
            f" for {test_name}"
        ),
    )
  return response


def change_alert_priority(
    alert_identifier: str,
    alert_name: str,
    case_id: int,
    previous_priority: int,
    priority: int,
    test_name: Optional[str] = None,
) -> Response:
  """Changes priority of the alert.

  Args:
    alert_identifier: alert identifier to change priority of,
    alert_name: str = None,
    case_id: id of the case the alert belongs to
    previous_priority: previous priority of the alert
    priority: new priority of the alert
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "alertIdentifier": alert_identifier,
      "alertName": alert_name,
      "caseId": case_id,
      "previousPriority": previous_priority,
      "priority": priority,
  }
  response = post_with_admin_credentials(
      url=API_UPDATE_ALERT_PRIORITY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Changed alert '{alert_identifier}' priority"
            f"from {previous_priority} to {priority}"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to change alert '{alert_identifier}' priority"
            f"from {previous_priority} to {priority}"
            f" for {test_name}"
        ),
    )
  return response


def get_alert_overview_data(
    case_id: Optional[int] = None,
    alert_identifier: Optional[str] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches alert overview data for the specified case.

  If no case is specified defaults to the last case in case queue

  Args:
    case_id: id of the chosen case (defaults to None)
    alert_identifier: id of the chosen alert (defaults to None)
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_GET_ALERT_OVERVIEW_DATA_ENDPOINT,
      payload={"caseId": case_id, "alertIdentifier": alert_identifier},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched alert overview data for '{alert_identifier}'"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to fetch alert overview data for '{alert_identifier}'"
            f" for {test_name}"
        ),
    )
  return response


def get_workflow_step_instance(
    case_id: int,
    alert_identifier: str,
    step_identifier: str,
    workflow_identifier: str,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches a workflow step instance data.

  Args:
    case_id: case id
    alert_identifier: alert id
    step_identifier: step action id
    workflow_identifier: playbook id
    test_name: name of the test (Defaults to None)
      status list:
        NoStatus = -1,
        Faulted = 0,
        InProgress = 1,
        Completed = 2,
        PendingUserInput = 3,
        PendingPreviousSteps = 4,
        Started = 5,
        FaultedAndSkipped = 6,
        HandledTimedout = 7,
        UnhandledTimedout = 8,
        Terminated = 9,
        NotRunAndSkipped = 10,
        PendingActionTimeout = 11,
        PendingActionTimeoutAndSkipped = 12

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "caseId": case_id,
      "alertIdentifier": alert_identifier,
      "stepIdentifier": step_identifier,
      "workflowIdentifier": workflow_identifier
  }
  response = post_with_admin_credentials(
      url=API_GET_WORKFLOW_INSTANCE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched workflow step instance of '{workflow_identifier}'"
            f" for test {test_name}"
        ),
        failure_message=(
            f"Failed to fetch workflow step instance of '{workflow_identifier}'"
            f" for {test_name}"
        ),
    )
  return response


def execute_pending_action(
    json_params: dict,
    test_name: Optional[str] = None,
) -> Response:
  """Executes a pending action in a workflow.

  Args:
    json_params: json params from GetWorkflowStepInstance api call
    test_name: name of the test (Defaults to None)
  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_EXECUTE_PENDING_ACTION,
      payload=json_params,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Executed pending action for test {test_name}"
        ),
        failure_message=(
            f"Failed to execute pending action for test {test_name}"
        ),
    )
  time.sleep(3)
  return response


def get_case_overview_data(
    case_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches case overview data for the specified case.

  If no case is specified defaults to the last case in case queue
  Args:
    case_id: id of the chosen case (defaults to None)
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_GET_CASE_OVERVIEW_DATA_ENDPOINT,
      payload={"caseId": case_id},
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched case #{case_id} overview data for test {test_name}"
        ),
        failure_message=(
            f"Failed to fetch case #{case_id} overview data"
            f" for test {test_name}"
        ),
    )
  return response


def ingest_alert_as_a_case_test(
    case_id: str,
    alert_id: str,
    environment: str = "Default Environment",
    test_name: Optional[str] = None,
) -> Response:
  """Ingests alert as a test in order to run actions on it from IDE.

  Args:
    case_id: id of the chosen case
    alert_id: id of the alert to ingest
    environment: name of the environment (defaults to "Default Environment")
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "alertIdentifier": alert_id,
      "caseId": case_id,
      "environment": environment
  }
  response = post_with_admin_credentials(
      url=API_INGEST_ALERT_AS_TEST_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Executed pending action for test {test_name}",
      failure_message=f"Failed to execute pending action for test {test_name}",
    )
  time.sleep(3)
  return response


def import_custom_case(
    cases,
    test_name: Optional[str] = None,
) -> Response:
  """Import a custom case.

  Args:
    cases: json case file data raw
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_IMPORT_CUSTOM_CASE_ENDPOINT,
      payload=cases,
      test_name=test_name,
  )
  if test_name:
    cases_list = cases.get("cases")
    name = cases_list[0].get("name")
    add_created_item_to_test(
        test_name=test_name,
        item_name=name,
        item_type="custom_case",
    )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Imported a case for test {test_name}",
      failure_message=f"Failed to import a case for test {test_name}",
    )
  return response


def delete_custom_simulated_case(
    case: str,
    test_name: Optional[str] = None,
) -> Response:
  """Delete a custom case.

  Args:
    case: name of the custom case to delete
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "customCases": [case],
      "kinds": []
  }
  response = post_with_admin_credentials(
      url=API_DELETE_USE_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Deleted a custom case '{case}' test {test_name}",
      failure_message=(
          f"Failed to delete a custom case '{case}' for test {test_name}"
      ),
  )
  return response


def get_cases_queue_error(
    test_name: Optional[str] = None,
) -> Response:
  """Get data records from cases queue error.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_CASES_QUEUE_ENDPOINT.format("errors"),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched case queue errors test {test_name}",
      failure_message=f"Failed to fetch case queue errors for test {test_name}",
  )
  return response


def get_cases_pending_queue_error(
    test_name: Optional[str] = None,
) -> Response:
  """Get data records for cases pending errors.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_CASES_QUEUE_ENDPOINT.format("errors?status=pending"),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched case queue pending errors test {test_name}",
      failure_message=(
          f"Failed to fetch case queue pending errors for test {test_name}"
      ),
  )
  return response


def get_cases_done_queue_error(
    test_name: Optional[str] = None,
) -> Response:
  """Get data records for cases done errors.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_CASES_QUEUE_ENDPOINT.format("errors?status=done"),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched case queue done errors test {test_name}",
      failure_message=(
          f"Failed to fetch case queue done errors for test {test_name}"
      ),
  )
  return response


def get_cases_inprogress_queue_error(
    test_name: Optional[str] = None,
) -> Response:
  """Get data records for cases in progress errors.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_CASES_QUEUE_ENDPOINT.format("errors?status=in-progress"),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched case queue in progress errors test {test_name}",
      failure_message=(
          f"Failed to fetch case queue in progress errors for test {test_name}"
      ),
  )
  return response


def get_cases_pending_queue(
    test_name: Optional[str] = None,
) -> Response:
  """Get data records for cases pending queue.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_CASES_QUEUE_ENDPOINT.format("items?status=pending"),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched cases pending queue test {test_name}",
      failure_message=(
          f"Failed to fetch cases pending queue for test {test_name}"
      ),
  )
  return response


def get_cases_in_progress_queue(
    test_name: Optional[str] = None,
) -> Response:
  """Get data records for cases in progress queue.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_CASES_QUEUE_ENDPOINT.format("items?status=in-progress"),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched cases in progress queue test {test_name}",
      failure_message=(
          f"Failed to fetch cases in progress queue for test {test_name}"
      ),
  )
  return response


def get_cases_done_queue(
    test_name: Optional[str] = None,
) -> Response:
  """Get data records for cases done queue.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_CASES_QUEUE_ENDPOINT.format("items?status=done"),
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched cases done queue test {test_name}",
      failure_message=(
          f"Failed to fetch cases done queue for test {test_name}"
      ),
  )
  return response


def records_waiter():
  """Waits for queue records.
  """
  result = []
  timeout = 60
  start_time = time.time()
  records = get_cases_queue_error()
  records_queue = records.json().get("records")
  while not records_queue:
    response = get_cases_queue_error()
    if response.status_code != 200:
      raise AssertionError(
          f"Error, non-zero status code: {response.status_code}"
      )
    result = response.json()["records"]
    if not result:
      if time.time() - start_time > timeout:
        raise AssertionError(
            "Timeout reached, records are empty, check the logs/UI, "
            f"returned data: {result}"
        )
      time.sleep(5)
    else:
      break
  return result


def _close_cases_in_bulk(
    case_ids: Optional[list[int]] = None,
    close_reason: Union[str, enums.CaseCloseReason] = (
        enums.CaseCloseReason.NOT_MALICIOUS
    ),
    root_cause: Union[str, enums.CaseCloseRootCause] = (
        enums.CaseCloseRootCause.NotMalicious.LAB_TEST
    ),
    close_comment: str = "",
) -> Response:
  """Closes all cases with listed IDs.

  Args:
    case_ids: list of case numbers (defaults to None)
    close_reason: reason for closing the case
    root_cause: cause of closing
    close_comment: comment on closing the case

  Returns:
    A response object
  """
  payload = {
      "casesIds": case_ids,
      "rootCause": root_cause,
      "closeReason": close_reason,
      "closeComment": close_comment,
  }
  response = post_with_admin_credentials(
      url=API_CLOSE_CASES_ENDPOINT,
      payload=payload,
  )
  return response


def close_all_cases():
  """Closes all cases that exist in all environments.
  """
  all_cases = get_cases_in_all_environments().case_cards
  case_ids = [case.get("id") for case in all_cases]
  while case_ids:
    _close_cases_in_bulk(case_ids=case_ids)
    all_cases = get_cases_in_all_environments().case_cards
    case_ids = [case.get("id") for case in all_cases]
    if case_ids:
      time.sleep(2)


def create_data_exfiltration_case(environment: str) -> Response:
  """Create case of data exflitration.

  Args:
    environment: environment to ingest the created case

  Returns:
    A response object
  """

  json = data_exfiltration_case(environment=environment)
  response = post_with_admin_credentials(
      url=API_CASES_CREATE_CASE,
      payload=json,
  )
  return response


def get_case_card_request_test(
    test_name: Optional[str] = None,
    log_response: bool = True,
    page_size: Optional[int] = 50,
    validate_admincreds: bool = True,
) -> CaseQueueResponse:
  """Fetches all case card request data from the siemplify_client.
  Args:
    test_name: name of the test, if None looks at the stack (Defaults to None)
    log_response: set to False if you don't want the response to be logged
    page_size: page size for the get case card request.
    validate_admincreds: set to false if need to verify it through App Key.

  Returns:
    A CaseQueueResponse object
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()

  payload = {
      "pageSize": page_size,
  }
  if (validate_admincreds):
    response = post_with_admin_credentials(
        url=API_GET_CASES_ENDPOINT,
        payload=payload,
        test_name=test_name,
    )
  else:
    response = post_with_appkey(
        url=API_GET_CASES_ENDPOINT,
        payload=payload,
        test_name=test_name,
    )

  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched case card request for {test_name}",
        failure_message=f"Failed to fetch case card request for {test_name}",
    )

  return CaseQueueResponse(response=response)

def get_case_investigation_data(
    case_id: int,
    test_name = None
) -> Response:
  """
  Gets full investigator data regarding given case,
  Representing general info, nested alerts, events, entities, and relations.

  Args:
    case_id: id of the case to fetch information about
    test_name: name of calling test

  Returns:
    Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  
  response = get_with_admin_credentials(
    url = API_GET_INVESTIGATION_DATA.format(case_id),
    test_name=test_name,
    log_request_enabled=True
  )
  
  log_and_assert(
    response=response,
    success_message="successfully fetched case investigation data",
    failure_message="failed to fetch case investigation data",
    test_name=test_name)
  
  return response

def change_case_description(
    case_id: int,
    description: str,
    test_name: Optional[str] = None
) -> Response:
  """
  Changes case description

  Args:
    case_id: id of the case to change case description
    description: new description
    test_name: name of calling test

  Returns:
    Response object
  """
  payload = {
    "caseId": case_id,
    "description": description
  }
  response = post_with_admin_credentials(
    url=API_CHANGE_CASE_DESCRIPTION_ENDPOINT,
    payload=payload,
  )
  log_and_assert(
    response=response,
    test_name=test_name,
    success_message=f"Case description changed to {description}",
    failure_message=(
      f"Failed to change case description for test {test_name}")
  )
  return response
