"""Module which is responsible to run functions of an agent.
"""
from typing import Optional
# Endpoints
from endpoints.agents import API_DEL_AGENT_ENDPOINT
from endpoints.agents import API_GET_AGENT_LIST_ENDPOINT
from endpoints.agents import API_GET_AGENTS_BY_ENV_ENDPOINT
from endpoints.agents import API_GET_AGENTS_INFO_BY_ID_ENDPOINT
from endpoints.agents import API_UPDATE_AGENT_ENDPOINT
# Requests
from requests import Response
# Source
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


def get_agent_list(test_name: Optional[str] = None) -> Response:
  """Fetches a list of all agents (activated, disabled and deleted).

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (list of all agents)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_AGENT_LIST_ENDPOINT,
      test_name=test_name,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched agents list for {test_name}",
        failure_message=f"Failed to fetch agents list for {test_name}",
    )
  return response


def get_agent_list_by_env(
    environment: str = "Default Environment",
    test_name: Optional[str] = None,
) -> Response:
  """Fetches a list of all agents (activated, disabled and deleted).

  Args:
    environment: name of the environment to check
      (Defaults to "Default Environment")
    test_name: name of the test (Defaults to None)

  Returns:
    A response object (list of all agents)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_GET_AGENTS_BY_ENV_ENDPOINT,
      test_name=test_name,
      payload={"environment": environment},
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched agent list in environment '{environment}' for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch agent list in environment '{environment}'"
            f" for {test_name}"
        ),
    )
  return response


def filterd_only_activate_agent() -> dict:
  """Fetches active remote agents.

  Returns:
    A dictionary with active agents (or empty dict if none found)
  """
  agent_data = dict()
  for agent in get_agent_list().json():
    if agent["status"] == 0:  # 0 active, 2 disabled, 1 deleted
      agent_data = agent
      return agent_data


def update_agent(
    agent_id: int,
    name: str,
    agent_name: str,
    publisher_id: int,
    publisher_name: str,
    access_link: str,
    certificate: str,
    agent_identifier: str,
    agent_version: str,
    agent_ip: str,
    hostname: str,
    required_version: str,
    log_level: int,
    is_deleted: bool,
    is_disabled: bool,
    agent_status: int,
    environments: Optional[list[str]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Updates remote agent.

  Args:
    agent_id: id of the agent
    name: name
    agent_name: name of the agent
    publisher_id: id of the publisher
    publisher_name: name of the publisher
    access_link: access link
    certificate: publisher certificate
    agent_identifier: agent identifier
    agent_version: agent version
    agent_ip: agent IP adress
    hostname: host name
    required_version: required Siemplify version
    log_level: logging level
    is_deleted: is agent deleted
    is_disabled: is agent disabled
    agent_status: status if the agent
    environments: environments for this agent (Defaults to None)
      set to "Default Environment" if None
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not environments:
    environments = ["Default Environment"]
  payload = {
      "isSlavePublisher": False,
      "id": agent_id,
      "identifier": agent_identifier,
      "name": name,
      "environments": environments,
      "publisherId": publisher_id,
      "publisherName": publisher_name,
      "publisherSlaveName": None,
      "accessLink": access_link,
      "status": agent_status,
      "certificate": certificate,
      "loggingLevel": log_level,
      "agentIdentifier": agent_identifier,
      "agentName": agent_name,
      "lastCommunicationUnixTime": 0,
      "lastActionExecutionUnixTime": None,
      "agentVersion": agent_version,
      "requiredSiemplifyVersion": required_version,
      "agentIP": agent_ip,
      "agentHostname": hostname,
      "communicationStatus": 0,
      "usages": [],
      "connectivityFlag": 0,
      "deploymentType": "Docker",
      "remoteLoggingLevel": None,
      "availableForLoggingLevel": True,
      "isUpgradeAvailable": False,
      "isDeleted": is_deleted,
      "isDisabled": is_disabled,
  }
  response = post_with_admin_credentials(
      url=API_UPDATE_AGENT_ENDPOINT,
      test_name=test_name,
      payload=payload,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Updated agent #{agent_id} for {test_name}",
        failure_message=f"Failed to update agent #{agent_id} for {test_name}",
    )
  return response


def get_agents_info_by_ids(
    agent_ids: list[str],
    test_name: Optional[str] = None,
) -> Response:
  """Get agent infomation by ids.

  Args:
    agent_ids: agent identifiers
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_GET_AGENTS_INFO_BY_ID_ENDPOINT,
      test_name=test_name,
      payload={"agentIdentifiers": agent_ids},
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Fetched agents with IDs {agent_ids} for {test_name}",
        failure_message=(
            f"Failed to fetch agents with IDs {agent_ids} for {test_name}"
        ),
    )
  return response


def delete_agent(
    agent_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Deletes agent infomation by id.

  Args:
    agent_id: agent identifier
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DEL_AGENT_ENDPOINT,
      test_name=test_name,
      payload={"agentIdentifier": agent_id},
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Agent #{agent_id} deleted for {test_name}",
        failure_message=f"Failed to delete agent #{agent_id} for {test_name}",
    )
  return response
