"""Module containing actions to manipulate jobs in siemplify client.
"""
import time
from typing import Optional, Union
# Endpoints
from endpoints.jobs import API_DELETE_INSTALLED_JOB_ENDPOINT
from endpoints.jobs import API_GET_INSTALLED_JOBS_ENDPOINT
from endpoints.jobs import API_GET_JOB_HISTORY_ENDPOINT
from endpoints.jobs import API_RUN_JOB_ENDPOINT
from endpoints.jobs import API_SAVE_OR_UPDATE_JOB_ENDPOINT
# Requests
from requests import Response
# Resources
from resources.strings.strings import DEFAULT_CUSTOM_JOB_SCRIPT
from resources.strings.strings import DEFAULT_RUNNING_JOB_SCRIPT
# Other siemplify modules
from siemplify_utils import siemplify
# Source
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials


# Classes for Response DTOs
class RunningJobResponse:
  """Class to represent job log in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.identifier = self.response_json.get("uniqueIdentifier")
    self.id = self.response_json.get("id")
    self.job_definition_id = self.response_json.get("jobDefinitionId")
    self.name = self.response_json.get("name")
    self.integration = self.response_json.get("integration")
    self.script = self.response_json.get("script")
    self.creator = self.response_json.get("creator")
    self.description = self.response_json.get("description")
    self.is_enabled = self.response_json.get("isEnabled")
    self.is_custom = self.response_json.get("isCustom")
    self.version = self.response_json.get("version")
    self.parameters = self.response_json.get("parameters")
    self.run_interval = self.response_json.get("runIntervalInSeconds")
    self.creation_time = self.response_json.get("creationTime")
    self.last_modification = self.response_json.get("lastModificationTime")
    self.is_system_job = self.response_json.get("isSystemJob")


class JobLog:
  """Class to represent job log in the response.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.log_items = [JobLogItem(item=item) for item in self.response_json]


class JobLogItem:
  """Class to represent job log item in the response.
  """

  def __init__(self, item: dict):
    self.job_id = item.get("jobId")
    self.message = item.get("message")
    self.utc_start_time = item.get("utcStartTime")
    self.utc_end_time = item.get("utcEndTime")
    self.result_status = item.get("resultStatus")
    self.id = item.get("id")
    self.creation_time = item.get("creationTimeUnixTimeInMs")
    self.modification_time = item.get("modificationTimeUnixTimeInMs")


def add_running_job(
    item_id: int,
    integration_name: str,
    creator: Optional[str] = None,
    payload: Optional[Union[dict, list]] = None,
    test_name: Optional[str] = None,
) -> RunningJobResponse:
  """Adds and enables a running job in Jobs page.

  If test_name is None function will try to get test name from the stack
    to check if it was called from a test. If it was not called from a test
    it will not be logged. If you don't call it from the test but know which
    test log this call belongs to you can specify test_name manually.

  Args:
    item_id: id of the job
    integration_name: name of the integration
    creator: id of who created the item
    payload: If given, overrides all other params and sends this to the
      API directly
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects (contains JSON with playbook data)
  """
  name = siemplify.utils.generate_random_name(start="Job_")
  if not test_name:
    test_name = check_test_name_can_be_none()
  final_payload = {
      "uniqueIdentifier": "00000000-0000-0000-0000-000000000000",
      "id": 0,
      "jobDefinitionId": item_id,
      "name": name,
      "integration": integration_name,
      "script": DEFAULT_CUSTOM_JOB_SCRIPT,
      "creator": creator,
      "description": "Test description",
      "isEnabled": True,
      "isCustom": True,
      "version": 2,
      "parameters": [
          {
              "id": 0,
              "isMandatory": True,
              "name": "Output Name",
              "type": 2,
              "value": "Test!"
          },
          {
              "id": 0,
              "isMandatory": True,
              "name": "Polling Timeout",
              "type": 2,
              "value": "10"
          },
          {
              "id": 0,
              "isMandatory": False,
              "name": "Default Return Value",
              "type": 2,
              "value": ""
          },
          {
              "id": 0,
              "isMandatory": False,
              "name": "Include JSON Result",
              "type": 0,
              "value": "false"
              }
          ],
      "runIntervalInSeconds": 60,
      "creationTime": "2022-11-29T08:40:15.013Z",
      "lastModificationTime": "2022-11-28T20:46:12.462Z",
      "isSystemJob": False,
  }
  if payload:
    final_payload = payload
  response = post_with_admin_credentials(
      url=API_SAVE_OR_UPDATE_JOB_ENDPOINT,
      payload=final_payload,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully created a job '{name} for {test_name}",
        failure_message=f"Failed to create a job for {test_name}",
    )

  return RunningJobResponse(response=response)


def run_job(
    item_id: int,
    integration_name: str,
    job_name: str,
    uniq_id: str,
    payload: Optional[Union[dict, list]] = None,
    test_name: Optional[str] = None,
) -> Response:
  """Runs job in Jobs page.

  Args:
    item_id: id of the job
    integration_name: name of the integration
    job_name: name of the job
    uniq_id: id of who created the item
    payload: If given, overrides all other params and sends this to the
      API directly
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  final_payload = {
      "uniqueIdentifier": uniq_id,
      "id": item_id,
      "jobDefinitionId": 0,
      "name": job_name,
      "integration": integration_name,
      "script": DEFAULT_RUNNING_JOB_SCRIPT,
      "creator": None,
      "description": "Test description",
      "isEnabled": True,
      "isCustom": True,
      "version": 2,
      "parameters": [
          {
              "id": 61,
              "isMandatory": True,
              "name": "Output Name",
              "type": 2,
              "value": "Test!"
          },
          {
              "id": 62,
              "isMandatory": True,
              "name": "Polling Timeout",
              "type": 2,
              "value": "10"
          },
          {
              "id": 63,
              "isMandatory": False,
              "name": "Default Return Value",
              "type": 2,
              "value": ""
          },
          {
              "id": 64,
              "isMandatory": False,
              "name": "Include JSON Result",
              "type": 0,
              "value": "false"
          }
      ],
      "runIntervalInSeconds": 60,
      "creationTime": "2022-11-29T14:16:04.133Z",
      "lastModificationTime": "2022-11-29T14:16:04.133Z",
      "isSystemJob": False,
  }
  if payload:
    final_payload = payload
  response = post_with_admin_credentials(
      url=API_RUN_JOB_ENDPOINT,
      payload=final_payload,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully ran a job {job_name} for {test_name}",
        failure_message=f"Failed to run a job {job_name} for {test_name}",
    )

  return response


def get_installed_jobs(test_name: Optional[str] = None) -> Response:
  """Fetches a list of installed jobs in Jobs page.

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A Response objects
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_INSTALLED_JOBS_ENDPOINT,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Successfully fetched jobs for {test_name}",
        failure_message=f"Failed to fetch jobs for {test_name}", 
    )

  return response


def delete_installed_job(
    job_list: list[int],
    test_name: Optional[str] = None,
) -> Response:
  """Deletes a list of installed custom jobs in Jobs page.

  Args:
    job_list: parameters for deletion
    test_name: name of the test (Defaults to None)
  Returns:
    A Response objects (contains JSON with playbook data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = post_with_admin_credentials(
      url=API_DELETE_INSTALLED_JOB_ENDPOINT,
      payload=job_list,
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=f"Deleted installed jobs successfully for {test_name}",
        failure_message=f"Failed to delete installed jobs for {test_name}",
    )

  return response


def delete_all_custom_jobs():
  jobs = get_installed_jobs()
  deletion_list = []
  for deleted_list in jobs.json():
    for item in deleted_list:
      if item == "isCustom":
        if deleted_list[item] is True:
          deletion_list.append(deleted_list)
  for delete_list in deletion_list:
    delete_installed_job(job_list=delete_list)


def get_job_history_logs(
    job_id: int,
    test_name: Optional[str] = None,
) -> JobLog:
  """Fetches history logs for a job with specified ID.

  Args:
    job_id: id of the job
    test_name: name of the test (Defaults to None)

  Returns:
    A Response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_JOB_HISTORY_ENDPOINT.format(job_id),
  )
  if test_name:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Fetched job history logs for job #{job_id} successfully"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch job history logs for job #{job_id}"
            f" for {test_name}"
        )
    )

  return JobLog(response=response)


def wait_for_new_history_log_item(
    job_id: int,
    retries: int = 10,
    cadence: int = 5,
    test_name: Optional[str] = None,
) -> JobLog:
  """Waits and Fetches job run history.

  Gets current state of the history and wait for
  a new log to be written, which means the
  executer got to run the job again

  Args:
    job_id: Id of the job instance to wait for
    retries: amount of retries (Defaults to 5)
    cadence: wait time per retry (Defaults to 5)
    test_name: name of the test (Defaults to None)

  Returns:
    A JobLog object with history run of the job.
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  attempts = 0
  initial_log_count = -1
  while attempts < retries:
    history = siemplify.jobs.get_job_history_logs(
        job_id=job_id,
        test_name=test_name,
    )
    if initial_log_count == -1:
      initial_log_count = len(history.log_items)

    if initial_log_count != len(history.log_items):
      return history
    else:
      attempts += 1
      if attempts >= retries:
        return history
      time.sleep(cadence)
