"""A module for action manipulating entities in siemplify.
"""
import random
from typing import Optional
# Endpoints
from endpoints.entities import API_ADD_ENTITY_TO_CASE_ENDPOINT
from endpoints.entities import API_GET_ALERT_ENTITIES_ENDPOINT
from endpoints.entities import API_GET_ENTITIES_ENDPOINT
from endpoints.entities import API_UPDATE_ENTITY_ENDPOINT
# Requests
from requests import Response
# Other module functions
from siemplify_utils import siemplify
# Source
from source import enums
from source.utils import check_test_name_can_be_none
from source.utils import check_test_name_can_not_be_none
from source.utils import get_with_admin_credentials
from source.utils import log_and_assert
from source.utils import post_with_admin_credentials
from source.utils import post_with_test_credentials


def get_case_entities(
    case_id: int,
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> Response:
  """Fetches all entities in the case.

  Args:
    case_id: id of the case
    test_name: name of the test (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A response object (contains JSON with entities data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_admin_credentials(
      url=API_GET_ENTITIES_ENDPOINT.format(case_id),
      test_name=test_name,
  )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched case entities for case #{case_id}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch case entities for case #{case_id} for {test_name}"
        ),
    )
  return response


def get_alert_entities(
    case_id: int,
    alert_ids: Optional[list[str]] = None,
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> Response:
  """Fetches all entities in the alert.

  Args:
    case_id: id of the case
    alert_ids: list of alert ID's. If not specified will get the first alert
      from the specified case (Defaults to None)
    test_name: name of the test (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A response object (contains JSON with entities data)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not alert_ids:
    case_data = siemplify.cases.get_case_full_details(case_id=case_id)
    alert_name = case_data.alerts[0].identifier
  payload = {
      "caseId": case_id,
      "alertGroupIdentifiers": [
          alert_name
      ]
  }
  response = post_with_admin_credentials(
      url=API_GET_ALERT_ENTITIES_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully fetched alert entities for case #{case_id}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to fetch alert entities for case #{case_id}"
            f" for {test_name}"
        ),
    )
  return response


def get_existing_entity_data(
    entity_name: str,
    case_id: int,
) -> dict:
  """Fetches data of the existing entity.

  Args:
    entity_name: name of the entity to fetch
    case_id: id of the case

  Returns:
    A dictionary with entity data
  """
  entities = get_case_entities(case_id=case_id)
  entities_json = entities.json()
  for entity in entities_json:
    if entity["identifier"] and entity["identifier"] == entity_name:
      return entity

  return dict()


def update_entity_property(
    entity_id: str,
    entity_type: str,
    property_name: str,
    property_value: str,
    test_name: Optional[str] = None,
    log_response: bool = True,
) -> Response:
  """Updates existing entity data.

  Args:
    entity_id: identifier of the updated entity,
    entity_type: type of updated entity,
    property_name: name of the updated property,
    property_value: value for the updated property,
    test_name: name of the test (Defaults to None)
    log_response: set to False if you don't want the response to be logged

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "identifier": entity_id,
      "caseId": 0,
      "type": entity_type,
      "property": {
          "key": property_name,
          "value": property_value
      }
  }
  response = post_with_admin_credentials(
      url=API_UPDATE_ENTITY_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  if test_name and log_response:
    log_and_assert(
        response=response,
        test_name=test_name,
        success_message=(
            f"Successfully updated properties for entity #{entity_id}"
            f" for {test_name}"
        ),
        failure_message=(
            f"Failed to update properties for entity #{entity_id}"
            f" for {test_name}"
        ),
    )
  return response


def add_entity_to_case_for_test(
    case_id: int,
    entity_type: enums.EntityType,
    alert_id: Optional[int] = None,
    entity_id: Optional[str] = None,
    suspicious: bool = False,
    internal: bool = False,
    artifact: bool = False,
    enriched: bool = False,
    vulnerable: bool = False,
    pivot: bool = False,
    manual: bool = True,
    test_name: Optional[str] = None,
) -> tuple[Response, str]:
  """Adds a new entity to a specified case.

  If no entity_id is specified will generate a random unique entity_id and
  return a tuple with response object and entity_id.
  If entity_id is specified will return a response object.

  Args:
    case_id: id of the case
    entity_type: type of the entity
    alert_id: id of the alert to add entity to. If None takes the first alert
      of the case automatically (Default to None)
    entity_id: name of the entity
    suspicious: status of isSuspicious
    internal: status of isInternal
    artifact: status of isArtifact
    enriched: status of isEnriched
    vulnerable: status of isVulnerable
    pivot: status of isPivot
    manual: status of isManuallyCreated
    test_name: name of the test (Defaults to None)

  Returns:
    A tuple of response object and entity_id
  """
  if not test_name:
    test_name = check_test_name_can_not_be_none()
  if not alert_id:
    case_data = siemplify.cases.get_case_full_details(case_id=case_id)
    alert_id = case_data.alerts[0].identifier
  # If entity was not specified
  if not entity_id:
    entity_id = random.randint(100000, 999999)
    # Find all entity names so random name doesn't overlap
    all_entities = get_case_entities(case_id=case_id)
    entity_ids = siemplify.utils.find_key_in_json(
        json_data=all_entities,
        key="identifier"
    )
    while entity_id in entity_ids:
      entity_id = random.randint(100000, 999999)
  # Add entity to the case
  payload = {
      "caseId": case_id,
      "alertIdentifier": alert_id,
      "entities": [
          {
              "caseId": case_id,
              "identifier": entity_id,
              "entityType": entity_type,
              "isInternal": internal,
              "isSuspicious": suspicious,
              "isArtifact": artifact,
              "isEnriched": enriched,
              "isVulnerable": vulnerable,
              "isPivot": pivot,
              "environment": test_name,
              "isManuallyCreated": manual
          }
      ]
  }
  response = post_with_test_credentials(
      url=API_ADD_ENTITY_TO_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Added entity #{entity_id} to case #{case_id} for {test_name}"
      ),
      failure_message=(
          f"Failed to add entity #{entity_id} to case #{case_id}"
          f" for {test_name}"
      ),
  )
  return (response, entity_id)


def add_entity_to_case_in_environment(
    environment: str,
    case_id: int,
    entity_type: enums.EntityType,
    alert_id: Optional[int] = None,
    entity_id: Optional[str] = None,
    suspicious: bool = False,
    internal: bool = False,
    artifact: bool = False,
    enriched: bool = False,
    vulnerable: bool = False,
    pivot: bool = False,
    manual: bool = True,
    test_name: Optional[str] = None,
) -> tuple[Response, str]:
  """Adds a new entity to a specified case.

  If no entity_id is specified will generate a random unique entity_id and
  return a tuple with response object and entity_id.
  If entity_id is specified will return a response object.

  Args:
    environment: name of the environment
    case_id: id of the case
    entity_type: type of the entity
    alert_id: id of the alert to add entity to. If None takes the first alert
      of the case automatically (Default to None)
    entity_id: name of the entity
    suspicious: status of isSuspicious
    internal: status of isInternal
    artifact: status of isArtifact
    enriched: status of isEnriched
    vulnerable: status of isVulnerable
    pivot: status of isPivot
    manual: status of isManuallyCreated
    test_name: name of the test (Defaults to None)

  Returns:
    A tuple of response object and entity_id
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  if not alert_id:
    case_data = siemplify.cases.get_case_full_details(case_id=case_id)
    alert_id = case_data.alerts[0].identifier
  # If entity was not specified
  if not entity_id:
    entity_id = random.randint(100000, 999999)
    # Find all entity names so random name doesn't overlap
    all_entities = get_case_entities(case_id=case_id)
    entity_ids = siemplify.utils.find_key_in_json(
        json_data=all_entities,
        key="identifier"
    )
    while entity_id in entity_ids:
      entity_id = random.randint(100000, 999999)
  # Add entity to the case
  payload = {
      "caseId": case_id,
      "alertIdentifier": alert_id,
      "entities": [
          {
              "caseId": case_id,
              "identifier": entity_id,
              "entityType": entity_type,
              "isInternal": internal,
              "isSuspicious": suspicious,
              "isArtifact": artifact,
              "isEnriched": enriched,
              "isVulnerable": vulnerable,
              "isPivot": pivot,
              "environment": environment,
              "isManuallyCreated": manual
          }
      ]
  }
  response = post_with_admin_credentials(
      url=API_ADD_ENTITY_TO_CASE_ENDPOINT,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Added entity '{entity_id}' to case #{case_id} for {test_name}"
      ),
      failure_message=(
          f"Failed to add entity '{entity_id}' to case #{case_id}"
          f" for {test_name}"
      ),
  )
  return (response, entity_id)
