"""A module for action working with SDK endpoints in siemplify."""
from typing import Optional
import uuid
# Endpoints
from endpoints.sdk import API_GET_ATTACHMENT_DATA_ENDPOINT
from endpoints.sdk import API_GET_ATTACHMENTS_ENDPOINT
from endpoints.sdk import API_GET_CASE_COMMENTS_ENDPOINT
from endpoints.sdk import API_GET_CURRENT_SIEMPLIFY_VERSION_ENDPOINT
from endpoints.sdk import API_GET_SYNC_NEW_ALERTS_ENDPOINT
from endpoints.sdk import API_GET_SYSTEM_INFO_ENDPOINT
from endpoints.sdk import API_GET_USER_FULL_NAME_ENDPOINT
from endpoints.sdk import API_POST_SYNC_NEW_ALERTS_RESULTS_ENDPOINT
# Requests
from requests import Response
# Source
from source.utils import add_created_item_to_test
from source.utils import check_response_and_return_json
from source.utils import check_test_name_can_be_none
from source.utils import get_with_appkey
from source.utils import log_and_assert
from source.utils import post_with_appkey


class ApiSyncFetchNewAlertsResponse:
  """Represents a response of a request to obtain SOAR alerts.

  which are not synced with Chronicle SIEM.
  """

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.alerts_to_sync = [ApiSyncNewAlert(item=x) for x in self.response_json]
    self.total_count = len(self.alerts_to_sync)


class ApiSyncNewAlert:
  """Represent a new alert sync with Chronicle SIEM."""

  def __init__(self, item: dict[str, str]):
    self.alert_identifier = item.get("alertIdentifier")
    self.alert_group_identifier = item.get("alertGroupIdentifier")
    self.creation_time = item.get("creationTime")
    self.name = item.get("name")
    self.start_time = item.get("startTime")
    self.end_time = item.get("endTime")
    self.detection_time = item.get("detectionTime")
    self.vendor = item.get("vendor")
    self.source_system_name = item.get("sourceSystemName")
    self.product = item.get("product")
    self.ticket_id = item.get("ticketId")
    self.environment = item.get("environment")
    self.siem_alert_id = item.get("siemAlertId")
    self.events = [ApiSyncSecurityEvent(item=x) for x in item.get("events")]


class ApiSyncSecurityEvent:
  """Represent a security event which is part of an alert to sync."""

  def __init__(self, item: dict[str, str]):
    self.event_time_epoch_time_in_ms = item.get("eventTimeEpochTimeInMs")
    self.name = item.get("name")
    self.severity = item.get("severity")
    self.description = item.get("description")
    self.event_id = item.get("eventId")
    self.receipt_time = item.get("receiptTime")
    self.manager_receipt_time = item.get("managerReceiptTime")
    self.start_time = item.get("startTime")
    self.source_host_name = item.get("sourceHostName")
    self.source_address = item.get("sourceAddress")
    self.destination_user_name = item.get("destinationUserName")
    self.destination_dns_domain = item.get("destinationDnsDomain")
    self.destination_nt_domain = item.get("destinationNtDomain")
    self.source_dns_domain = item.get("sourceDnsDomain")
    self.source_user_name = item.get("sourceUserName")
    self.source_user_id = item.get("sourceUserId")
    self.source_nt_domain = item.get("sourceNtDomain")
    self.destination_url = item.get("destinationUrl")
    self.file_name = item.get("fileName")
    self.file_hash = item.get("fileHash")
    self.deployment = item.get("deployment")
    self.file_type = item.get("fileType")
    self.transport_protocol = item.get("transportProtocol")
    self.application_protocol = item.get("applicationProtocol")
    self.destination_port = item.get("destinationPort")
    self.category_outcome = item.get("categoryOutcome")
    self.device_vendor = item.get("deviceVendor")
    self.device_product = item.get("deviceProduct")
    self.source_process_name = item.get("sourceProcessName")
    self.destination_process_name = item.get("destinationProcessName")
    self.email_subject = item.get("emailSubject")
    self.threat_signature = item.get("threatSignature")
    self.generic_entity = item.get("genericEntity")
    self.source_mac_address = item.get("sourceMacAddress")
    self.destination_mac_address = item.get("destinationMacAddress")
    self.phone_number = item.get("phoneNumber")
    self.cve = item.get("cve")
    self.threat_actor = item.get("threatActor")
    self.threat_campaign = item.get("threatCampaign")
    self.process = item.get("process")
    self.parent_process = item.get("parentProcess")
    self.source_domain = item.get("sourceDomain")
    self.destination_domain = item.get("destinationDomain")
    self.end_time = item.get("endTime")
    self.rule_generator = item.get("ruleGenerator")
    self.message = item.get("message")
    self.usb = item.get("usb")


class ApiSyncNewAlertResultsResponse:
  """Represents a response of a request to obtain new SOAR alerts to sync."""

  def __init__(self, response: Response):
    self.status_code = response.status_code
    self.response_json = check_response_and_return_json(response=response)
    self.alert_sync_results = [
        ApiSyncNewAlertResult(item=x) for x in self.response_json
    ]
    self.total_count = len(self.alert_sync_results)


class ApiSyncNewAlertResult:
  """Represents a response to obtain SOAR alerts which are not synced with SIEM."""

  def __init__(self, item: dict[str, str]):
    self.alert_group_identifier = item.get("alertGroupIdentifier")
    self.environment = item.get("environment")
    self.creation_time = item.get("creationTime")
    self.created_in_siem = item.get("createdInSiem")
    self.siem_alert_id = item.get("siemAlertId")
    self.message = item.get("message")
    self.updated_in_soar = item.get("updatedInSoar")


def get_user_full_name(
    user_id: str,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches full user name.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    user_id: the id of the user
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_USER_FULL_NAME_ENDPOINT.format(user_id),
      sdk_key=True,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched full user name for {test_name}",
      failure_message=f"Failed to fetch full user name for {test_name}",
  )


def get_current_siemplify_version(test_name: Optional[str] = None) -> Response:
  """Fetches current siemplify version.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_CURRENT_SIEMPLIFY_VERSION_ENDPOINT,
      sdk_key=True,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched current siemplify version for {test_name}",
      failure_message=(
          f"Failed to fetch current siemplify version for {test_name}"
      ),
  )


def get_system_info(
    system_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches system info version.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    system_id: the id of the system
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_SYSTEM_INFO_ENDPOINT.format(system_id),
      sdk_key=True,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched system info for {test_name}",
      failure_message=f"Failed to fetch system info for {test_name}",
  )


def get_attachments(
    identifier: int,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches system info version.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    identifier: the id
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_ATTACHMENTS_ENDPOINT.format(identifier),
      sdk_key=True,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched attachments for {test_name}",
      failure_message=f"Failed to fetch attachments for {test_name}",
  )


def get_attachment_data(
    identifier: int,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches system info version.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    identifier: the id
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_ATTACHMENT_DATA_ENDPOINT.format(identifier),
      sdk_key=True,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched attachment data for {test_name}",
      failure_message=f"Failed to fetch attachment data for {test_name}",
  )


def get_case_comments(
    case_id: int,
    test_name: Optional[str] = None,
) -> Response:
  """Fetches system info version.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    case_id: the id of the case
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  response = get_with_appkey(
      url=API_GET_CASE_COMMENTS_ENDPOINT.format(case_id),
      sdk_key=True,
  )
  return log_and_assert(
      response=response,
      test_name=test_name,
      success_message=f"Fetched case comments for {test_name}",
      failure_message=f"Failed to fetch case comments for {test_name}",
  )


def fetch_new_alerts_to_sync_for_test(
    items_count: int = 100,
    test_name: Optional[str] = None,
) -> ApiSyncFetchNewAlertsResponse:
  """Fetches newly ingested alerts which are not synced with Chronicle SIEM.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    items_count: Maximum number of results
    environments: Environments to search for new alerts. If equals to null or an
      empty list, all environments will be used.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "batchSize": items_count,
      "environments": [test_name],
  }
  response = get_with_appkey(
      url=API_GET_SYNC_NEW_ALERTS_ENDPOINT,
      sdk_key=True,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Fetched new SOAR alerts to sync with Chronicle SIEM for {test_name}"
      ),
      failure_message=(
          "Failed to fetch new SOAR alerts to sync with Chronicle SIEM "
          f"for {test_name}"
      ),
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="alert_sync",
        item_name=test_name,
    )
  return ApiSyncFetchNewAlertsResponse(response=response)


def fetch_new_alerts_to_sync_in_environments(
    items_count: int = 100,
    environments: list[str] = None,
    test_name: Optional[str] = None,
) -> ApiSyncFetchNewAlertsResponse:
  """Fetches newly ingested alerts which are not synced with Chronicle SIEM.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    items_count: Maximum number of results
    environments: Environments to search for new alerts. If equals to null or an
      empty list, all environments will be used.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  payload = {
      "batchSize": items_count,
      "environments": environments,
  }
  response = get_with_appkey(
      url=API_GET_SYNC_NEW_ALERTS_ENDPOINT,
      sdk_key=True,
      payload=payload,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Fetched new SOAR alerts to sync with Chronicle SIEM for {test_name}"
      ),
      failure_message=(
          "Failed to fetch new SOAR alerts to sync with Chronicle SIEM "
          f"for {test_name}"
      ),
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="alert_sync",
        item_name="all",
    )
  return ApiSyncFetchNewAlertsResponse(response=response)


def update_new_alerts_sync_status(
    alert_sync_results: list[ApiSyncNewAlertResult],
    environments: list[str] = None,
    test_name: Optional[str] = None,
) -> ApiSyncNewAlertResultsResponse:
  """Updates SOAR with the status of attempts of alerts creation in SIEM.

  This function uses SDK Appkey, please specify SDK_APPKEY="key" in the .env

  Args:
    alert_sync_results: Alert sync results between SOAR and the SIEM
    environments: Environments that were used to fetch the alerts for
      synchronization. If None, it will be considered as all environments.
    test_name: name of the test (Defaults to None)

  Returns:
    A response object
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  results = []
  for result in alert_sync_results:
    results.append({
        "alertGroupIdentifier": result.alert_group_identifier,
        "environment": result.environment,
        "creationTime": result.creation_time,
        "createdInSiem": result.created_in_siem,
        "siemAlertId": result.siem_alert_id,
        "message": result.message,
    })
  payload = {"results": results, "environments": environments}
  response = post_with_appkey(
      url=API_POST_SYNC_NEW_ALERTS_RESULTS_ENDPOINT,
      payload=payload,
      sdk_key=True,
      test_name=test_name,
  )
  log_and_assert(
      response=response,
      test_name=test_name,
      success_message=(
          f"Updated SOAR alerts as synced with Chronicle SIEM for {test_name}"
      ),
      failure_message=(
          "Failed to update new SOAR alerts to sync with Chronicle SIEM "
          f"for {test_name}"
      ),
  )
  if test_name:
    add_created_item_to_test(
        test_name=test_name,
        item_type="alert_sync",
        item_name="1",
    )
  return ApiSyncNewAlertResultsResponse(response=response)


def mark_all_alerts_as_synced_for_test(
    test_name: Optional[str] = None,
):
  """Marks all alerts as synced, so it won't affect the tests.

  Args:
    test_name: name of the test (Defaults to None)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  # We define a hard limit, to ensure this procedure won't run endlessly.
  max_iterations = 100
  batch_size = 100
  for _ in range(max_iterations):
    response = fetch_new_alerts_to_sync_for_test(
        items_count=batch_size,
        test_name=test_name,
    )
    if not response.alerts_to_sync:
      break
    sync_results = []
    for alert in response.alerts_to_sync:
      sync_results.append(
          ApiSyncNewAlertResult({
              "alertGroupIdentifier": alert.alert_group_identifier,
              "environment": alert.environment,
              "creationTime": alert.creation_time,
              "createdInSiem": True,
              "siemAlertId": "sa_" + str(uuid.uuid4()),
          })
      )
    update_new_alerts_sync_status(
        alert_sync_results=sync_results, environments=[test_name]
    )


def mark_all_alerts_as_synced_in_environments(
    environments: list[str] = None,
    test_name: Optional[str] = None,
):
  """Marks all alerts as synced, so it won't affect the tests.

  Args:
    environments: Environments to search for new alerts. If equals to null or an
      empty list, all environments will be used.
    test_name: name of the test (Defaults to None)
  """
  if not test_name:
    test_name = check_test_name_can_be_none()
  # We define a hard limit, to ensure this procedure won't run endlessly.
  max_iterations = 100
  batch_size = 100
  for _ in range(max_iterations):
    response = fetch_new_alerts_to_sync_in_environments(
        items_count=batch_size,
        environments=environments,
        test_name=test_name,
    )
    if not response.alerts_to_sync:
      break
    sync_results = []
    for alert in response.alerts_to_sync:
      sync_results.append(
          ApiSyncNewAlertResult({
              "alertGroupIdentifier": alert.alert_group_identifier,
              "environment": alert.environment,
              "creationTime": alert.creation_time,
              "createdInSiem": True,
              "siemAlertId": "sa_" + str(uuid.uuid4()),
          })
      )
    update_new_alerts_sync_status(
        alert_sync_results=sync_results, environments=environments
    )
