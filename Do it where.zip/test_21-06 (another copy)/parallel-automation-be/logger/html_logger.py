"""Module for logging all tests to HTML logs.
"""
import datetime
import json
import os
import time
from typing import Union

HTML_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logger"
)
REPORT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "test_report"
)
JSON_LOG_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOGS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
)


def delete_logs():
  """Deletes all logs from /logs folder.
  """
  for filename in os.listdir(LOGS_PATH):
    if filename.endswith(".json"):
      file_path = os.path.join(LOGS_PATH, filename)
      os.remove(file_path)
  return True


def create_log_from_json():
  """Creates a full html log from log.json file.
  """
  file_path = os.path.join(JSON_LOG_PATH, "log.json")
  template_path = os.path.join(HTML_PATH, "new_template.html")
  output_path = os.path.join(REPORT_PATH, "test-report.html")
  tests_data = ""
  success_icon = (
      '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" '
      'fill="green" class="bi bi-check-circle" viewBox="0 0 16 16">'
      '<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0'
      ' 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>'
      '<path d="M10.97 4.97a.235.235 0 0 0-.02.022L7.477 9.417 5.384'
      ' 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-'
      '.02l3.992-4.99a.75.75 0 0 0-1.071-1.05z"/></svg>'
  )
  failure_icon = (
      '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" '
      'fill="red" class="bi bi-x-circle" viewBox="0 0 16 16">'
      '<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1'
      ' 0 8 0a8 8 0 0 0 0 16z"/>'
      '<path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1'
      ' .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a'
      '.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"/></svg>'
  )
  technical_icon = (
      '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" '
      'fill="blue" class="bi bi-info-circle" viewBox="0 0 16 16">'
      '<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 '
      '0 0 0 0 16z"/> <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.'
      '352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 '
      '1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 '
      '0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>'
      '</svg>'
  )
  report_name = ""
  total_number = 0
  success_number = 0
  failed_number = 0
  skipped_number = 0
  success_percentage = 0
  fail_percentage = 0
  skip_percentage = 0
  start = None
  end = None
  with open(file_path) as file:
    file_data = file.read()
    data = json.loads(file_data)
    tags_list = ""
    if data["tags"]:
      tags_list = "Selected tags: " + ", ".join(data["tags"])
    report_name = f'{data["start"]}. ' + tags_list
    start = data["start"]
    end = data["end"]
  start_time = datetime.datetime.strptime(start, "%d/%m/%Y, %H:%M:%S")
  end_time = datetime.datetime.strptime(end, "%d/%m/%Y, %H:%M:%S")
  time_difference = end_time - start_time
  # Look at all json files in "logs"
  files = []
  for file in os.listdir(LOGS_PATH):
    if file.endswith(".json"):
      files.append(os.path.join(LOGS_PATH, file))
  for file in files:
    with open(file) as f:
      file_data = f.read()
      data = json.loads(file_data)
    name = data["environment"]
    uuid = data["test_id"]
    total_number += 1
    if data["test_status"]:
      success_number += 1
    else:
      failed_number += 1
    icon = success_icon if data["test_status"] else failure_icon
    test_data = (
        '<div class="accordion-item">'
        f'<h2 class="accordion-header" id="header_{name}">'
        '<button class="accordion-button collapsed" type="button"'
        f'data-bs-toggle="collapse" data-bs-target="#{name}" '
        f'aria-expanded="false" aria-controls="{name}">'
        f'<div class="me-2"><strong>{name}</strong></div> {icon}'
        f'<span class="ms-2">({uuid})</span>'
        '</button> </h2>'
        f'<div id="{name}" class="accordion-collapse collapse"'
        f'aria-labelledby="heading_{name}" '
        'data-bs-parent="#accordionWithTests">'
        '<div class="accordion-body">'
        f'<div class="accordion accordion-flush" id="inner_{name}">'
    )
    steps_data = ""
    step_id = 0
    for step in data["test_steps"]:
      icon = success_icon if step["success"] else failure_icon
      if step["success"] == "info":
        icon = technical_icon
      step_data = (
          '<div class="accordion-item">'
          f'<h2 class="accordion-header" id="header_{step_id}">'
          '<button class="accordion-button collapsed" type="button"'
          f'data-bs-toggle="collapse" data-bs-target="#step_{step_id}" '
          f'aria-expanded="false" aria-controls="step_{step_id}">'
          f'<div class="me-2">{step["message"]}</div> {icon}'
          '</button> </h2>'
          f'<div id="step_{step_id}" class="accordion-collapse collapse"'
          f'aria-labelledby="heading_{step_id}" data-bs-parent="#inner_{name}">'
          '<div class="accordion-body">'
          '<div class="text-start">'
          f'<pre>{step["details"]}</pre></div></div></div></div>\n'
      )
      steps_data += step_data
      step_id += 1
    test_data += steps_data
    test_data += "</div></div></div></div>\n"
    tests_data += test_data
  # Update the numbers
  if total_number != 0:
    success_percentage = round((success_number / total_number * 100), 2)
    fail_percentage = round((failed_number / total_number * 100), 2)
    skip_percentage = round((skipped_number / total_number * 100), 2)
  if success_number > 3:
    success_bar_test = f"{success_number} ({success_percentage}%)"
  else:
    success_bar_test = f"{success_number}"
  if failed_number > 3:
    failed_bar_test = f"{failed_number} ({fail_percentage}%)"
  else:
    failed_bar_test = f"{failed_number}"
  if skipped_number > 3:
    skipped_bar_test = f"{skipped_number} ({skip_percentage}%)"
  else:
    skipped_bar_test = f"{skipped_number}"
  with (
      open(template_path, "r") as temp,
      open(output_path, "w") as out,
    ):
    input_html = temp.read()
    new_html = input_html.replace(
        "$start$", report_name
    ).replace(
        "$tests$", tests_data
    ).replace(
        "$total$", str(total_number)
    ).replace(
        "$succeeded$", str(success_number)
    ).replace(
        "$failed$", str(failed_number)
    ).replace(
        "$skipped$", str(skipped_number)
    ).replace(
        "$succeeded_percent$", str(success_percentage)
    ).replace(
        "$failed_percent$", str(fail_percentage)
    ).replace(
        "$skipped_percent$", str(skip_percentage)
    ).replace(
        "$runtime$", str(time_difference)
    ).replace(
        "$success_bar_test$", str(success_bar_test)
    ).replace(
        "$failed_bar_test$", str(failed_bar_test)
    ).replace(
        "$skipped_bar_test$", str(skipped_bar_test)
    )
    print("WRITING LOG")
    out.write(new_html)
  return True


def log_event(
    test_name: str,
    message: str,
    details: str,
    success: Union[bool, str],
):
  """Adds a log event into a test log.

  Args:
    test_name: name of the test to log data into
    message: a message to log
    details: log item details
    success: False if error, True if success
  """
  if not test_name:
    return True
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  time_now = datetime.datetime.now()
  log_data = {
      "message": message,
      "details": details,
      "success": success,
      "timestamp": time_now.strftime("%d/%m/%Y, %H:%M:%S"),
  }
  json_data = None
  with open(path, "r") as file:
    data = json.load(file)
    data["test_steps"].append(log_data)
    json_data = json.dumps(data)
  with open(path, "w") as file:
    file.write(json_data)
