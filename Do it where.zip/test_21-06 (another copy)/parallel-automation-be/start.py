"""This is a file to launch parallel and sequence testing with one command.
"""
import os


os.system("pytest --tags PARALLEL -n auto")
os.system("pytest --tags SEQUENCE --options NOLOGDELETE")
