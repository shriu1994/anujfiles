"""Configuration for different testing modules.
"""
import os
from dotenv import load_dotenv
from requests import Session

SESSION = Session()

_ENV_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), ".env"
)

if os.path.exists(_ENV_PATH):
  load_dotenv(_ENV_PATH)

OPTIONS = {
    "NO_PRE_CLEANUP": False,
    "NO_INTEGRATION_CLEANUP": False,
}
# Authentication credentials
AUTH_LOGIN = os.getenv("AUTH_LOGIN", "")
AUTH_PASSWORD = os.getenv("AUTH_PASSWORD", "")

# Main api
API_MAIN = os.getenv("API_MAIN", "")

# Secret Manager project and creds
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "")
CUSTOMER = os.getenv("CUSTOMER", "")
PROJECT_ID = os.getenv("PROJECT_ID", "")

# SSL verifications status
VERIFY = True
NO_INTEGRATION_CLEANUP = False

# Appkey
APPKEY = os.getenv("APPKEY", "")
SDK_APPKEY = os.getenv("SDK_APPKEY", "")

# Default integration name
DEFAULT_INTEGRATION_NAME = "Siemplify"
DEFAULT_INTEGRATION_VERSION = 65

# Check for the localhost
localhost = os.getenv("LOCALHOST", "")
if localhost.lower() == "true":
  VERIFY = False

# Check for no cleanup
NO_CLEANUP = False
NO_POST_CLEANUP = False
NO_PRE_CLEANUP = False
no_cleanup_settings = os.getenv("NO_CLEANUP", "")
no_post_cleanup_settings = os.getenv("NO_POST_CLEANUP", "")
no_pre_cleanup_settings = os.getenv("NO_PRE_CLEANUP", "")
if no_cleanup_settings.lower() == "true":
  NO_CLEANUP = True
if no_post_cleanup_settings.lower() == "true":
  NO_POST_CLEANUP = True
if no_pre_cleanup_settings.lower() == "true":
  NO_PRE_CLEANUP = True
