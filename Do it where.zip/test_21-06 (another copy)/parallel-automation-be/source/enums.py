"""Module for working with enum classes for different modules.
"""
from enum import Enum

class DefaultCases:
  """Class to represent default case names.
  """
  DATA_EXFILTRATION = "Data Exfiltration"
  ACCESS_TO_DISABLED_ACCOUNT = "Access to disabled account"
  FAILED_LOGIN = "Failed Login"
  IRC_CONNECTIONS = "IRC Connections"
  MALWARE_DETECTED = "Malware Detected"
  PHISHING_EMAIL = "Phishing Email"


class CasePriority:
  """Class to represent default case priorities.
  """
  CRITICAL = 100
  HIGH = 80
  MEDIUM = 60
  LOW = 40
  INFORMATIVE = -1


class CaseStages:
  """Class to represent default case stages.
  """
  INCIDENT = "Incident"
  IMPROVEMENT = "Improvement"
  TRIAGE = "Triage"
  ASSESSMENT = "Assessment"
  INVESTIGATION = "Investigation"
  RESEARCH = "Research"


class CaseFilterCritera:
  """Class to represent default case filter criterias.
  """
  PRIORITIES = 2
  STAGES = 3
  ALERT_NAMES = 5
  ANALYSTS = 0
  ENVIRONMENTS = 1
  PRODUCTS = 6
  TAGS = 4


class CaseSortType:
  """Class to represent default case sort types.
  """
  ID_HIGH = "id high"
  ID_LOW = "id low"
  TIME_NEWEST = "time newest"
  TIME_OLDEST = "time oldest"
  MODIFIED_NEWEST = "modified newest"
  MODIFIED_OLDEST = "modified oldest"
  PRIORITY_HIGH = "priority high"
  PRIORITY_LOW = "priority low"
  ALERT_TYPE_LONGEST = "alert type longest"
  ALERT_TYPE_SHORTEST = "alert type shortest"
  CASE_STAGE_LONGEST = "case stage longest"
  CASE_STAGE_SHORTEST = "case stage shortest"


class CaseCloseReason:
  """Class to represent default case close reasons.
  """
  MALICIOUS = 0
  NOT_MALICIOUS = 1
  MAINTENANCE = 2
  INCONCLUSIVE = 3


class CaseCloseRootCause:
  """Class to represent default case close root causes.
  """

  class Malicious:
    """Root causes for "Malicious" close reason.
    """
    EXTERNAL_ATTACK = "External attack"
    INFRASTRUCTURE_ISSUE = "Infrastructure issue"
    IRRELEVANT_PORT = "Irrelevant TCP/UDP port"
    MISCONFIGURED_SYSTEM = "Misconfigured system"
    OTHER = "Other"
    SIMILAR_CASE_UNDER_INVESTIGATION = (
        "Similar case is already under investigation"
    )
    SYSTEM_BLOCKED_THE_ATTACK = "System blocked the attack"
    UNKNOWN = "Unknown"
    SYSTEM_MALFUNCTION = "System/application malfunction"
    UNFORESEEN_EFFECTS_OF_CHANGE = "Unforeseen effects of change"

  class NotMalicious:
    """Root causes for "Not Malicious" close reason.
    """
    EMPLOYEE_ERROR = "Employee error"
    HUMAN_ERROR = "Human error"
    LAB_TEST = "Lab test"
    NONE = "None"
    LEGIT_ACTION = "Legit action"
    MISCONFIGURED_SYSTEM = "Misconfigured system"
    OTHER = "Other"
    NORMAL_BEHAVIOR = "Normal behavior"
    PENETRATION_TEST = "Penetration test"
    RULE_UNDER_CONSTRUCTION = "Rule under construction"
    UNKNOWN = "Unknown"
    USER_MISTAKE = "User mistake"
    SIMILAR_CASE_UNDER_INVESTIGATION = (
        "Similar case is already under investigation"
    )

  class Maintenance:
    """Root causes for "Maintenance" close reason.
    """
    LAB_TEST = "Lab test"
    OTHER = "Other"
    RULE_UNDER_CONSTRUCTION = "Rule under construction"

  class Inconclusive:
    """Root causes for "Inconclusive" close reason.
    """
    NO_CLEAR_CONCLUSION = "No clear conclusion"


class SlaExpiration:
  PASSED_DUE = 0
  OPEN_SLA = 1
  NO_SLA = 2
  CRITICAL_EXPIRED = 3
  PAUSED = 4


class ApiSlaProviderType:
  ALERT_RULE = 2
  CASE_STAGE = 3
  CASE_PRIORITY = 4
  ALERT_PRIORITY = 5


class ApiPeriodType:
  MINUTES = 0
  HOURS = 1
  DAYS = 2
  SECONDS = 3


class ApiSlaAlertType:
  ALL_ALERTS = 0
  SPECIFIC_ALERTS = 1


class SocRoleId:
  """Class to represent SOC role Ids.
  """
  ADMIN = 1
  TIER1 = 2
  TIER2 = 3
  TIER3 = 4
  SOC_MANAGER = 5
  CISO = 6


class SocRoleNames:
  """Class to represent SOC role names.
  """
  ADMIN = "@Administrator"
  TIER1 = "@Tier1"
  TIER2 = "@Tier2"
  TIER3 = "@Tier3"
  SOC_MANAGER = "@SocManager"
  CISO = "@CISO"


class PermissionGroups:
  """Class to represent permission group.
  """
  ADMIN = "Admins"
  READERS = "Readers"
  BASIC = "Basic"


class EntityType:
  """Class to represent entity types.
  """
  ADRESS = "ADDRESS"
  APPLICATION = "APPLICATION"
  CLUSTER = "CLUSTER"
  CONTAINER = "CONTAINER"
  CREDIT_CARD = "CREDITCARD"
  CVE = "CVE"
  DATABASE = "DATABASE"
  DEPLOYMENT = "DEPLOYMENT"
  DESTINATION_URL = "DestinationURL"
  DOMAIN = "DOMAIN"
  EMAIL_SUBJECT = "EMAILSUBJECT"
  FILE_HASH = "FILEHASH"
  FILE_NAME = "FILENAME"
  GENERIC_ENTITY = "GENERICENTITY"
  HOSTNAME = "HOSTNAME"
  IP_SET = "IPSET"
  MAC_ADRESS = "MACADDRESS"
  PHONE_NUMBER = "PHONENUMBER"
  POD = "POD"
  PROCESS = "PROCESS"
  SERVICE = "SERVICE"
  THREAT_ACTOR = "THREATACTOR"
  THREAT_CAMPAIGN = "THREATCAMPAIGN"
  THREAT_SIGNATURE = "THREATSIGNATURE"
  USB = "USB"
  USER_UNIQUE_NAME = "USERUNIQNAME"


class IdeItemType:
  CONNECTOR = 0
  ACTION = 1
  JOB = 2
  MANAGER = 4


class AuditSettingsRequestType:
  """Class to represent different Audit settings request types.
  """
  GROUP = 0,
  COUNT = 1


class AuditOperations:
  SIMULATE_CASES = "Simulate cases"


class IdentityProviderType(Enum):
  """"Class to represent different identity provider types we support.
  """
  NONE = -1
  OKTA = 0
  G_SUITE = 1
  CUSTOM_SAML2 = 2
  LDAP = 3


class SamlSettingsFileType(Enum):
  """"Class to represent different file types in external auth settings.
  """
  METADATA = 0
  PUBLIC_CERTIFICATE = 1


class TaskStatusType(Enum):
  """Class to represent task status types to filter by when fetching homepage tasks.
  """
  OPEN = 3
  CLOSED = 4

# Ontology:

class MappingExtractionFunctionType(Enum):
  """Class to represent field mapping different extration function types.
  """
  NONE = 0
  REGEX_PATTERN = 1
  DELIMITER = 2


class MappingTransormationFunctionType(Enum):
  """Class to represent field mapping different extration function types.
  """
  TO_STRING = 0
  FROM_UNIX_STRING_OR_LONG = 3
  FROM_CUSTOM_DATETIME = 4
  EXTRACT_BY_REGEX = 7
  TO_IP_ADDRESS = 101


class MappingFieldType(Enum):
  """Class to represent field types in ontology mapping.
  """
  FAMILY = 0
  SYSTEM = 1


class OntologyConfigurationLevel(Enum):
  """Class to represent ontology configuration level types.
  """
  SOURCE = 0
  PRODUCT = 1
  EVENT = 2


class MappingComparisonType(Enum):
  """Class to represent field mapping comparison types.
  """
  EQUAL = 0
  CONTAINS = 1
  STARTS_WITH = 2
  ENDS_WITH = 3
