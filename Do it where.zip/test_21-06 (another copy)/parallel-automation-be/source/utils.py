"""Module for utility functions.
"""
import datetime
import inspect
import json
import os
import random
import string
import time
import types
from typing import cast
from typing import Optional
from typing import Union
# Loggin
from logger.html_logger import log_event
# Requests
from requests import exceptions as exc
from requests import JSONDecodeError
from requests import Response
# Siemplify modules
from siemplify_utils import siemplify
# Source
from source.config import APPKEY
from source.config import SDK_APPKEY
from source.config import SESSION
from source.config import VERIFY


LOG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "log.json"
)
AUTH_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auth.json"
)
TESTS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tests.json"
)
LOGS_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"
)
# Constants for retries
RETRIES = 3
SUCCESS_CODES = (200, 201, 202, 203, 204)
AUTH_CODES = (401, 403)


def _check_admin_auth():
  """Function to check for authentication with admin credentials.

  Checks if auth.json exists, checks the timestamp and authenticates if needed.
  """
  if not os.path.isfile(AUTH_PATH):
    siemplify.authentication.authenticate()
  auth_retries = 15
  auth_attempts = 0
  while auth_attempts < auth_retries:
    try:
      with open(AUTH_PATH, "r") as file:
        data = json.load(file)
        auth_attempts += auth_retries
    except JSONDecodeError:
      time.sleep(2)
      auth_attempts += 1
  timestamp = data["timestamp"]
  timestamp_timedate = datetime.datetime.strptime(
      timestamp, "%m-%d-%Y-%H-%M-%S"
  )
  current_timedate = datetime.datetime.now()
  time_difference = current_timedate - timestamp_timedate
  seconds_difference = time_difference.total_seconds()
  if seconds_difference > 200:
    siemplify.authentication.authenticate()


def _check_test_auth(test_name: str):
  """Function to check for authentication with test credentials.

  Args:
    test_name: name if the test to check auth for
  Checks tests.json, checks the timestamp and logs in again if needed.
  """
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  timestamp = data.get("timestamp")
  timestamp_timedate = datetime.datetime.strptime(
      timestamp, "%d/%m/%Y, %H:%M:%S"
  )
  current_timedate = datetime.datetime.now()
  time_difference = current_timedate - timestamp_timedate
  seconds_difference = time_difference.total_seconds()
  if seconds_difference > 200:
    siemplify.authentication.relog_for_test(
        test_name=test_name,
    )


def post_with_admin_credentials(
    url: str,
    payload: Optional[dict] = None,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
    ignore_404: bool = False,
    ignore_500: bool = False
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    payload: dict with payload (Defaults to None)
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged
    ignore_404: set this to True if you want 404 response to be considered
      a success
    ignore_500: if true, 500 response code will be considered a success

  Returns:
    A Response object
  """
  _check_admin_auth()
  updated_codes = list(SUCCESS_CODES)
  if ignore_404:
    updated_codes.append(404)
  if ignore_500:
    updated_codes.append(500)
  if test_name:
    test_path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(test_path, "r") as file:
      test_data = json.load(file)
  auth_retries = 3
  auth_attempts = 0
  while auth_attempts < auth_retries:
    try:
      with open(AUTH_PATH, "r") as file:
        data = json.load(file)
        auth_attempts += auth_retries
    except JSONDecodeError:
      time.sleep(1)
      auth_attempts += 1
  if test_name and test_data["custom_login"]:
    headers = test_data["custom_credentials"]["headers"]
  else:
    headers = data.get("headers")
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.post(
          url=url,
          json=payload,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in updated_codes:
        if response.status_code in AUTH_CODES and not data["custom_login"]:
          siemplify.authentication.authenticate()
          time.sleep(2)
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="POST",
        payload=payload,
    )
  return response


def put_with_admin_credentials(
    url: str,
    payload: Optional[dict] = None,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    payload: dict with payload (Defaults to None)
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged

  Returns:
    A Response object
  """
  _check_admin_auth()
  if test_name:
    test_path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(test_path, "r") as file:
      test_data = json.load(file)
  with open(AUTH_PATH, "r") as file:
    data = json.load(file)
  if test_name and test_data["custom_login"]:
    headers = test_data["custom_credentials"]["headers"]
  else:
    headers = data.get("headers")
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.put(
          url=url,
          json=payload,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        if response.status_code in AUTH_CODES and not data["custom_login"]:
          siemplify.authentication.authenticate()
          time.sleep(2)
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="PUT",
        payload=payload,
    )
  return response

def patch_with_admin_credentials(
    url: str,
    payload: Optional[dict] = None,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
) -> Response:
  """Sends a patch request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    payload: dict with payload (Defaults to None)
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged

  Returns:
    A Response object
  """
  _check_admin_auth()
  if test_name:
    test_path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(test_path, "r") as file:
      test_data = json.load(file)
  with open(AUTH_PATH, "r") as file:
    data = json.load(file)
  if test_name and test_data["custom_login"]:
    headers = test_data["custom_credentials"]["headers"]
  else:
    headers = data.get("headers")
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.patch(
        url=url,
        json=payload,
        headers=headers,
        verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        if response.status_code in AUTH_CODES and not data["custom_login"]:
          siemplify.authentication.authenticate()
          time.sleep(2)
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
      test_name=test_name,
      url=url,
      request_type="PATCH",
      payload=payload,
    )
  return response

def get_with_admin_credentials(
    url: str,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
    params: Optional[dict] = None,
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged
    params: a dict with query parameters (Default to None)

  Returns:
    A Response object
  """
  _check_admin_auth()
  if test_name:
    test_path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(test_path, "r") as file:
      test_data = json.load(file)
  with open(AUTH_PATH, "r") as file:
    data = json.load(file)
  if test_name and test_data["custom_login"]:
    headers = test_data["custom_credentials"]["headers"]
  else:
    headers = data.get("headers")
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.get(
          url=url,
          headers=headers,
          verify=VERIFY,
          params=params,
      )
      if response.status_code not in SUCCESS_CODES:
        if response.status_code in AUTH_CODES and not data["custom_login"]:
          siemplify.authentication.authenticate()
          time.sleep(2)
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="GET",
    )
  return response


def delete_with_admin_credentials(
    url: str,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged
  Returns:
    A Response object
  """
  _check_admin_auth()
  if test_name:
    test_path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(test_path, "r") as file:
      test_data = json.load(file)
  with open(AUTH_PATH, "r") as file:
    data = json.load(file)
  if test_name and test_data["custom_login"]:
    headers = test_data["custom_credentials"]["headers"]
  else:
    headers = data.get("headers")
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.delete(
          url=url,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        if response.status_code in AUTH_CODES and not data["custom_login"]:
          siemplify.authentication.authenticate()
          time.sleep(2)
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="DELETE",
    )
  return response


def post_with_test_credentials(
    test_name: str,
    url: str,
    payload: Optional[dict] = None,
    log_request_enabled: bool = False,
) -> Response:
  """Sends a post request using test-specific credentials from tests.json.

  Args:
    test_name: name of the test to log in for
    url: destination URL
    payload: dict with payload (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged

  Returns:
    A Response object
  """
  _check_test_auth(test_name=test_name)
  if log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="POST",
        payload=payload,
    )
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  if data["custom_login"]:
    headers = data["custom_credentials"]["headers"]
  else:
    headers = data.get("headers")
  if data["test_id"]:
    headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.post(
          url=url,
          json=payload,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        if response.status_code in AUTH_CODES and not data["custom_login"]:
          siemplify.authentication.relog_for_test(test_name=test_name)
          time.sleep(2)
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError as connection_error:
      attempts += 1
      if attempts >= RETRIES:
        log_event(
            test_name=test_name,
            message="Connection error!",
            details=connection_error,
            success=False,
        )
      time.sleep(2)
    except exc.ConnectionError as req_connection_error:
      attempts += 1
      if attempts >= RETRIES:
        log_event(
            test_name=test_name,
            message="Connection error!",
            details=req_connection_error,
            success=False,
        )
      time.sleep(2)
    except Exception as exception:
      log_event(
          test_name=test_name,
          message="Something went wrong!",
          details=exception,
          success=False,
      )
      attempts += RETRIES
  return response


def get_with_test_credentials(
    test_name: str,
    url: str,
    log_request_enabled: bool = False,
) -> Response:
  """Sends a post request using test-specific credentials from tests.json.

  Args:
    test_name: name of the test to log in for
    url: destination URL
    log_request_enabled: set to True if you want request data to be logged

  Returns:
    A Response object
  """
  _check_test_auth(test_name=test_name)
  if log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="GET",
    )
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  if data["custom_login"]:
    headers = data["custom_credentials"]["headers"]
  else:
    headers = data.get("headers")
  if data["test_id"]:
    headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.get(
          url=url,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        if response.status_code in AUTH_CODES and not data["custom_login"]:
          siemplify.authentication.relog_for_test(test_name=test_name)
          time.sleep(2)
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError as connection_error:
      attempts += 1
      if attempts >= RETRIES:
        log_event(
            test_name=test_name,
            message="Connection error!",
            details=connection_error,
            success=False,
        )
      time.sleep(2)
    except exc.ConnectionError as req_connection_error:
      attempts += 1
      if attempts >= RETRIES:
        log_event(
            test_name=test_name,
            message="Connection error!",
            details=req_connection_error,
            success=False,
        )
      time.sleep(2)
    except Exception as exception:
      log_event(
          test_name=test_name,
          message="Something went wrong!",
          details=exception,
          success=False,
      )
      attempts += 3
  return response


def put_with_appkey(
    url: str,
    payload: Optional[dict] = None,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
    sdk_key: Optional[bool] = False,
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    payload: dict with payload (Defaults to None)
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged
    sdk_key: set to True if you use SDK AppKey for this request

  Returns:
    A Response object
  """
  if sdk_key and not SDK_APPKEY:
    raise ValueError("Please provide the SDK_APPKEY in .env")
  if not sdk_key and not APPKEY:
    raise ValueError("Please provide the APPKEY in .env")
  if sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": SDK_APPKEY,
    }
  elif not sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": APPKEY,
    }
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  retries = 3
  attempts = 0
  response = None
  while attempts < retries:
    try:
      response = SESSION.put(
          url=url,
          json=payload,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="PUT",
        payload=payload,
    )
  return response


def post_with_appkey(
    url: str,
    payload: Optional[dict] = None,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
    sdk_key: Optional[bool] = False,
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    payload: dict with payload (Defaults to None)
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged
    sdk_key: set to True if you use SDK AppKey for this request

  Returns:
    A Response object
  """
  if sdk_key and not SDK_APPKEY:
    raise ValueError("Please provide the SDK_APPKEY in .env")
  if not sdk_key and not APPKEY:
    raise ValueError("Please provide the APPKEY in .env")
  if sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": SDK_APPKEY,
    }
  elif not sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": APPKEY,
    }
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  retries = 3
  attempts = 0
  response = None
  while attempts < retries:
    try:
      response = SESSION.post(
          url=url,
          json=payload,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="POST",
        payload=payload,
    )
  return response


def delete_with_appkey(
    url: str,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
    sdk_key: Optional[bool] = False,
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged
    sdk_key: set to True if you use SDK AppKey for this request

  Returns:
    A Response object
  """
  if sdk_key and not SDK_APPKEY:
    raise ValueError("Please provide the SDK_APPKEY in .env")
  if not sdk_key and not APPKEY:
    raise ValueError("Please provide the APPKEY in .env")
  if sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": SDK_APPKEY,
    }
  elif not sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": APPKEY,
    }
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.delete(
          url=url,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="DELETE",
    )
  return response


def get_with_appkey(
    url: str,
    test_name: Optional[str] = None,
    log_request_enabled: bool = False,
    sdk_key: Optional[bool] = False,
    payload: Optional[dict] = None,
) -> Response:
  """Sends a post request using admin credentials from auth.json.

  If the test_name is specified and log_request_enabled is True the request
    will be logged in the corresponding test in the log. Mostly for debugging
    purposes (By default is turned off)

  Args:
    url: destination URL
    test_name: name of the test if request is used inside it (Defaults to None)
    log_request_enabled: set to True if you want request data to be logged
    sdk_key: set to True if you use SDK AppKey for this request
    payload: payload for the request

  Returns:
    A Response object
  """
  if sdk_key and not SDK_APPKEY:
    raise ValueError("Please provide the SDK_APPKEY in .env")
  if not sdk_key and not APPKEY:
    raise ValueError("Please provide the APPKEY in .env")
  if sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": SDK_APPKEY,
    }
  elif not sdk_key:
    headers = {
        "Content-Type": "application/json",
        "AppKey": APPKEY,
    }
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    if data["test_id"]:
      headers["correlation-id"] = data["test_id"]
  attempts = 0
  response = None
  while attempts < RETRIES:
    try:
      response = SESSION.get(
          url=url,
          json=payload,
          headers=headers,
          verify=VERIFY,
      )
      if response.status_code not in SUCCESS_CODES:
        attempts += 1
        time.sleep(2)
      else:
        attempts += RETRIES
    except ConnectionError:
      attempts += 1
      time.sleep(2)
    except exc.ConnectionError:
      attempts += 1
      time.sleep(2)
    except Exception:
      attempts += RETRIES
  if test_name and log_request_enabled:
    log_request(
        test_name=test_name,
        url=url,
        request_type="GET",
    )
  return response


def check_response_and_return_json(
    response: Response,
) -> dict:
  """Checks status code of the response and returns json.

  Args:
    response: a response object
  Returns:
    A dict with json or empty dict if no json received
  """
  try:
    response_json = response.json()
  except JSONDecodeError:
    response_json = {}
  return response_json


def strong_assert(
    success_message: Optional[str] = None,
    failure_message: Optional[str] = None,
    compare: Optional[Union[str, int, list, dict, tuple, bool]] =
    "DefaultCompareValue",
    to: Optional[Union[str, int, list, dict, tuple, bool]] =
    "DefaultToValue",
    is_true: Optional[Union[str, int, list, dict, tuple, bool]] = None,
    is_false: Optional[Union[str, int, list, dict, tuple, bool]] = None,
    extra_info: str = "No extra info",
):
  """Asserts any value and adds an event to the log.

  This stops the test if it fails!

  Please either use "compare" and "to" together OR "is_true" OR "is_false"

  Args:
    success_message: message when assertion succeeded
    failure_message: message when assertion failed
    compare: used with "to" parameter to compare two values
    to: used with "compare" parameter to compare two values
    is_true: used to verify something is True
    is_false: used to verify something is False
    extra_info: info in the dropdown section in the log
  """
  log_data = {
      "message": "",
      "details": "",
      "success": None,
      "timestamp": "",
  }
  test_name = cast(
      types.FrameType, cast(types.FrameType, inspect.currentframe()).f_back
  ).f_code.co_name
  time_now = datetime.datetime.now()
  log_data["timestamp"] = time_now.strftime("%d/%m/%Y, %H:%M:%S")
  # Make default messages
  if not success_message and not failure_message:
    success_message = "Assertion successful"
    failure_message = "Assertion failed"
    if compare and to:
      extra_info = f"Expected: {compare} \n Received: {to}"
    elif is_true is not None and not is_true:
      extra_info = f"{is_true} should be True, but is False"
    elif is_true is not None and is_true:
      extra_info = f"{is_true} is True"
    elif is_false is not None and is_false:
      extra_info = f"{is_false} should be False, but is True"
    elif is_false is not None and not is_false:
      extra_info = f"{is_false} is False"
  elif success_message and not failure_message:
    failure_message = f"Assertion failed: {success_message}"
  # Verification
  if compare != "DefaultCompareValue" and is_true is not None:
    raise ValueError(
        "Please don't use 'compare' and 'is_true' in the same assertion"
    )
  elif compare != "DefaultCompareValue" and is_false is not None:
    raise ValueError(
        "Please don't use 'compare' and 'is_false' in the same assertion"
    )
  elif is_true is not None and is_false is not None:
    raise ValueError(
        "Please don't use 'is_true' and 'is_false' in the same assertion"
    )
  # Check if extra info is json
  if isinstance(extra_info, dict):
    details = json.dumps(extra_info, indent=4)
    extra_info = details
  # Assertion
  if (
      compare != "DefaultCompareValue" and to != "DefaultToValue" and
      compare == to
      or is_true and is_true is not None
      or not is_false and is_false is not None
    ):
    log_data["message"] = success_message
    log_data["success"] = True
  else:
    log_data["message"] = failure_message
    log_data["success"] = False
  log_data["details"] = extra_info
  # Add data to the log
  json_data = None
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
    data["test_steps"].append(log_data)
    if log_data["success"] is False:
      data["test_status"] = False
    json_data = json.dumps(data, indent=4)
  with open(path, "w") as file:
    file.write(json_data)
  if is_true is not None:
    assert is_true, failure_message
  elif is_false is not None:
    assert not is_false, failure_message
  elif compare != "DefaultCompareValue" and to != "DefaultToValue":
    assert compare == to, failure_message


def soft_assert(
    success_message: Optional[str] = None,
    failure_message: Optional[str] = None,
    compare: Optional[Union[str, int, list, dict, tuple, bool]] =
    "DefaultCompareValue",
    to: Optional[Union[str, int, list, dict, tuple, bool]] =
    "DefaultToValue",
    is_true: Optional[Union[str, int, list, dict, tuple, bool]] = None,
    is_false: Optional[Union[str, int, list, dict, tuple, bool]] = None,
    extra_info: str = "No extra info",
):
  """Asserts any value and adds an event to the log.

  This does not stop the test if it fails!

  Please either use "compare" and "to" together OR "is_true" OR "is_false"

  Args:
    success_message: message when assertion succeeded
    failure_message: message when assertion failed
    compare: used with "to" parameter to compare two values
    to: used with "compare" parameter to compare two values
    is_true: used to verify something is True
    is_false: used to verify something is False
    extra_info: info in the dropdown section in the log
  """
  test_name = cast(
      types.FrameType, cast(types.FrameType, inspect.currentframe()).f_back
  ).f_code.co_name
  log_data = {
      "message": "",
      "details": "",
      "success": None,
      "timestamp": "",
  }
  time_now = datetime.datetime.now()
  log_data["timestamp"] = time_now.strftime("%d/%m/%Y, %H:%M:%S")
  # Make default messages
  if not success_message and not failure_message:
    success_message = "Assertion successful"
    failure_message = "Assertion failed"
    if compare and to:
      extra_info = f"Expected: {compare} \n Received: {to}"
    elif is_true is not None and not is_true:
      extra_info = f"{is_true} should be True, but is False"
    elif is_true is not None and is_true:
      extra_info = f"{is_true} is True"
    elif is_false is not None and is_false:
      extra_info = f"{is_false} should be False, but is True"
    elif is_false is not None and not is_false:
      extra_info = f"{is_false} is False"
  elif success_message and not failure_message:
    failure_message = f"Assertion failed: {success_message}"
  # Verification
  if compare != "DefaultCompareValue" and is_true is not None:
    raise ValueError(
        "Please don't use 'compare' and 'is_true' in the same assertion"
    )
  elif compare != "DefaultCompareValue" and is_false is not None:
    raise ValueError(
        "Please don't use 'compare' and 'is_false' in the same assertion"
    )
  elif is_true is not None and is_false is not None:
    raise ValueError(
        "Please don't use 'is_true' and 'is_false' in the same assertion"
    )
  # Assertion
  if (
      compare != "DefaultCompareValue" and to != "DefaultToValue" and
      compare == to
      or is_true and is_true is not None
      or not is_false and is_false is not None
    ):
    log_data["message"] = success_message
    log_data["success"] = True
  else:
    log_data["message"] = failure_message
    log_data["success"] = False
  if isinstance(extra_info, dict):
    extra_info = json.dumps(extra_info, indent=4)
  if isinstance(extra_info, list):
    extra_info = json.dumps(extra_info, indent=4)
  log_data["details"] = extra_info
  # Add data to the log
  json_data = None
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
    data["test_steps"].append(log_data)
    if log_data["success"] is False:
      data["test_status"] = False
    json_data = json.dumps(data, indent=4)
  with open(path, "w") as file:
    file.write(json_data)


def get_random_string(length: int) -> str:
  """Creates a random string of a specified length.

  Args:
    length: length of a string

  Returns:
    A random string
  """
  # With combination of lower and upper case
  return "".join(random.choice(string.ascii_letters) for i in range(length))


def log_and_assert(
    response: Response,
    success_message: str,
    failure_message: str,
    test_name: Optional[str] = None,
    ignore_404: bool = False,
    ignore_400: bool = False,
    ignore_403: bool = False,
    ignore_500: bool = False
) -> Response:
  """Asserts the response, logs it and returns it back.

  Args:
    response: a response object
    success_message: message shown if assertion is successful
    failure_message: message shown if assertion has failed
    test_name: name of the test
    ignore_404: set this to True if you want 404 response to be considered
      a success
    ignore_400: set this to True if you want 400 response to be considered
      a success
    ignore_403: set this to True if you want 403 response to be considered
    a success
    ignore_500: if true, 500 response code will be considered a success

  Raises:
    AssertionError: if no response was received

  Returns:
    The original response object
  """
  should_fail = False
  updated_codes = list(SUCCESS_CODES)
  if ignore_404:
    updated_codes.append(404)
  if ignore_400:
    updated_codes.append(400)
  if ignore_403:
    updated_codes.append(403)
  if ignore_500:
    updated_codes.append(500)
  if test_name:
    path = os.path.join(LOGS_PATH, f"{test_name}.json")
    with open(path, "r") as file:
      data = json.load(file)
    time_now = datetime.datetime.now()
    timestamp = time_now.strftime("%d/%m/%Y, %H:%M:%S")
    log_data = {
        "message": "",
        "details": "",
        "success": None,
        "timestamp": timestamp,
    }
    code = response.status_code
    if code in updated_codes:
      log_data["success"] = True
      log_data["message"] = success_message
    elif code not in updated_codes and data["next_request_should_fail"]:
      log_data["success"] = True
      log_data["message"] = failure_message
      data["next_request_should_fail"] = False
      should_fail = True
    else:
      log_data["success"] = False
      log_data["message"] = failure_message + f" (Code: {code})"
    try:
      details = response.json()
      log_data["details"] = json.dumps(details, indent=4)
    except JSONDecodeError:
      log_data["details"] = "No JSON was received!"
    data["test_steps"].append(log_data)
    if log_data["success"] == False:
      data["test_status"] = False
    json_data = json.dumps(data)
    with open(path, "w") as file:
      file.write(json_data)
    if not should_fail:
      assert code in updated_codes, (
          failure_message + f" Code: {response.status_code}"
      )
  return response


def log_request(
    test_name: str,
    url: str,
    request_type: str = "post",
    payload: Optional[dict] = None,
):
  """Logs technical details of the request to the test log.

  Args:
    test_name: name of the test to log into
    url: url for the request
    request_type: type of request: POST or GET or DELETE or UPDATE
    payload: request payload
  """
  request_types = ("POST", "GET", "DELETE", "UPDATE", "PUT")
  request_upper = request_type.upper()
  assert request_upper in request_types, f"Wrong request type: {request_type}"
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  headers = data.get("headers")
  email = data.get("email")
  password = data.get("password")
  tech_log = {
      "URL": url,
      "Email": email,
      "Password": password,
      "Payload": payload,
      "Headers": headers,
  }
  log_event(
      test_name=test_name,
      message=f"Sending {request_upper} request!",
      details=json.dumps(tech_log, indent=4),
      success="info",
  )

def add_restore_requirement_to_test(
    test_name: str,
    item_type: str,
    fetch_payload: list | dict | None = None,
    item_data: list | dict | None = None,
    item_metadata: list | dict | None = None
):
  """Adds info about items that the test changes and should be restored
    to the attached data. All is saved to the corresponding json file.
    Stores the info as: 
    <stringified item_data>: <strigified dict with item type and metadata/s>
    
  Args:
    test_name: name of the test that created the item
    item_type: type of the item that needs to be restores in cleanup
    fetch_payload: payload to fetch to required data with, if item_data is not given
    item_data: data of the item to restore, if available
    item_metadata: if the data needs to be fetched, this will hold info about
      which of the fetched data is to be sent for restoring
  """
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  
  data_stored = False
  item_data_str = None
  updated_metadata = None

  if item_type == "fields_mapping":
    source = fetch_payload["source"]
    product = fetch_payload["product"]
    event = fetch_payload["eventName"]
    if data.get("to_restore"): # -> there's something saved already
      store = data.get("to_restore")
      mappings = [(stored_data, stored_md) 
                  for stored_data, stored_md in store.items() 
                  if json.loads(stored_md).get("item_type") == "fields_mapping"]
      for mapping in mappings:
        mapping_data, metadata = mapping
        mapping_json = json.loads(mapping_data)
        metadata_json = json.loads(metadata)
        first_rule = mapping_json.get("familyFields")[0].get("mappingRule")
        if first_rule.get("source") == source and \
          first_rule.get("product") == product and \
            first_rule.get("eventName") == event:
          # found matching source, product, event in restore data
          item_data_str = mapping_data
          data_stored = True
          if not item_metadata in metadata_json["fields"]:
            metadata_json["fields"].append(item_metadata)
            updated_metadata = metadata_json
          else:
            log_event(
              test_name=test_name, 
              message="this mapping's data;metadata was already saved",
              details=json.dumps(fetch_payload),
              success=True
            )
            return
    if not item_data and not data_stored:
      item_data = siemplify.ontology.get_ontology_mapping_rules(
        source, product, event).response_json     
  # add elif here to store other types of data required...
  else:
    log_event(test_name=test_name, 
              message="No data to save for restoring later",
              details=item_type,
              success=False)
    return

  if not item_data_str:
    if 'list' in str(type(item_data)):
      item_data_str = str(list)
    else:
      item_data_str = json.dumps(item_data)
  if not updated_metadata:
    updated_metadata = {"item_type": item_type,
                   "fields": [
                     item_metadata
                   ]} 
  item_metadata_str = json.dumps(updated_metadata)

  data["to_restore"][item_data_str] = item_metadata_str
  json_data = json.dumps(data)
  with open(path, "w") as file:
    file.write(json_data)

def add_created_item_to_test(
    test_name: str,
    item_type: str,
    item_name: str,
):
  """Adds info that item was created by a test to the corresponding json file.

  Args:
    test_name: name of the test that created the item
    item_type: type of the item that was created
    item_name: name of the item that was created
  """
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
    data["created"][item_name] = item_type
    json_data = json.dumps(data)
  with open(path, "w") as file:
    file.write(json_data)


def delete_created_item_from_test(
    test_name: str,
    item_type: str,
    item_name: str,
):
  """Adds info that a created item was deleted by a test,
  to the corresponding json file.

  Args:
    test_name: name of the test that deleted the item
    item_type: type of the item that was deleted
    item_name: name of the item that was deleted
  """
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
  created = data["created"]
  found_item = created.get(item_name)
  if found_item and found_item == item_type:
    data["created"].pop(item_name)
  json_data = json.dumps(data)
  with open(path, "w") as file:
    file.write(json_data)


def check_created_items_for_test(test_name: str) -> dict:
  """Fetches all items created by a test from json file.

  Args:
    test_name: name of the test to check

  Returns:
    A list with all created items in form of dicts
  """
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
    created = data.get("created")
  return created

def check_items_to_restore(test_name: str) -> dict:
  """Fetches all data to be restored after a test from json file
  
  Args:
    test_name: name of the test to check

  Returns:
    A dictionary with all data to be restored
  """
  path = os.path.join(LOGS_PATH, f"{test_name}.json")
  with open(path, "r") as file:
    data = json.load(file)
    to_restore = data.get("to_restore")
  return to_restore

def restore_required_items_for_test(test_name: str):
  """Restores all items kept as to_restore for a test.

  Args:
    test_name: name of the test to check
  """
  items = check_items_to_restore(test_name=test_name)
  if not items:
    return
  # Return mappings to original state
  mappings = [(key, value) for key, value in items.items() 
              if json.loads(value).get("item_type") == "fields_mapping"]
  for mapping in mappings:
    data = json.loads(mapping[0])
    metadata = json.loads(mapping[1])
    for field_md in metadata.get("fields"):
      field_group_name = "familyFields" \
        if field_md.get("targetFieldType") == 0 \
          else "systemFields"
      field_group = data.get(field_group_name)
      field_data = [field for field in field_group if 
                    field.get("mappingRule").get("securityEventFieldName")
                      == field_md["securityEventFieldName"]]
      for field in field_data:
        field["mappingRule"]["id"] = 0
      res = siemplify.ontology.set_field_mapping(full_payload=field_data)

def delete_created_items_for_test(test_name: str):
  """Deletes all items created for a test.

  Args:
    test_name: name of the test to check
  """
  items = check_created_items_for_test(test_name=test_name)
  if not items:
    return
  # Return views to default state
  views = [key for key, value in items.items() if value == "view_template"]
  if views:
    siemplify.views.set_all_views_to_default()
  # Delete external auth settings
  ext_auth = [
      key for key, value in items.items() if value == "external_auth_settings"]
  if ext_auth:
    siemplify.external_auth_settings.delete_all_external_auth_settings()
  # Delete custom cases
  custom_cases = [key for key, value in items.items() if value == "custom_case"]
  for case in custom_cases:
    siemplify.cases.delete_custom_simulated_case(case=case)
  # Delete all tasks
  tasks = [key for key, value in items.items() if value == "task"]
  for task in tasks:
    siemplify.tasks.delete_task(task_id=task, test_name=test_name)
  # Delete all custom ide items
  ide_items = [value for key, value in items.items() if "ide_item" in key]
  for item in ide_items:
    item_name = item.get("item_name")
    integration_name = item.get("integration")
    data = siemplify.ide.get_ide_item_data_by_name(
        item_name=item_name,
        integration_name=integration_name,
    ).response_json
    siemplify.ide.delete_custom_ide_item(action_data=data, test_name=test_name)
  # Delete all sla definitions entities
  sla = [
      key for key, value in items.items() if value == "sla_definition"
  ]
  if sla:
    siemplify.sla.delete_all_sla_definitions_for_test(test_name=test_name)
  # Delete all blocklist entities
  blocklist = [
      key for key, value in items.items() if value == "blocklist_entity"
  ]
  if blocklist:
    siemplify.blocklist.delete_all_blocklist_entities()
  # Delete all custom lists:
  custom_lists = [
      key for key, value in items.items() if value == "custom_list"
  ]
  for lst in custom_lists:
    lst_json = json.loads(lst)
    siemplify.custom_lists.remove_custom_list(
      full_payload=lst_json,
      test_name=test_name
    )
  # Fetch all cases that are left
  remaining_cases = siemplify.cases.get_cases_in_all_environments().case_cards
  remaining_ids = [case["id"] for case in remaining_cases]
  # Delete all custom cases
  case_ids = [
      key for key, value in items.items() if value == "case"
      and key in remaining_ids
  ]
  siemplify.cases.close_cases_for_test(cases=case_ids, test_name=test_name)
  # Delete all custom playbooks
  playbook_ids = [key for key, value in items.items() if value == "playbook"]
  for playbook_id in playbook_ids:
    siemplify.playbooks.delete_playbook(
        playbook=playbook_id,
        test_name=test_name
    )
  # Delete all custom users
  user_names = [key for key, value in items.items() if value == "user"]
  for user in user_names:
    siemplify.users.delete_user(username=user, test_name=test_name)
  # Delete all custom roles
  role_names = [key for key, value in items.items() if value == "role"]
  for role in role_names:
    siemplify.users.delete_role(role_id=role, test_name=test_name)
  # Delete all custom connector instances
  instance_names = [
      key for key, value in items.items() if value == "connector_instance"
  ]
  for instance in instance_names:
    siemplify.connectors.delete_connector_instance(
        identifier=instance, test_name=test_name
    )
  # Delete all custom connectors
  con_names = [key for key, value in items.items() if value == "connector"]
  for connector in con_names:
    item_data = siemplify.ide.get_ide_item_data_by_id(
        item_type=0,
        item_id=connector,
    )
    siemplify.ide.delete_custom_ide_item(
        action_data=item_data,
        test_name=test_name,
    )
  # Delete all custom integrations
  integration_names = [
      key for key, value in items.items() if value == "custom_integration"
  ]
  for integration in integration_names:
    siemplify.integrations.delete_custom_integration(
        integration_name=integration,
    )
  # Delete all custom environments
  env_names = [key for key, value in items.items() if value == "environment"]
  for env in env_names:
    siemplify.environments.delete_environment(name=env, test_name=test_name)
  dynamic_params = \
    [value for key, value in items.items() if "dynamic_param_" in key]
  if dynamic_params:
    siemplify.environments.delete_all_dynamic_params(
      created_dynamic_params=dynamic_params,
      test_name=test_name
    )
  # Mark all alerts as synced
  views = [key for key, value in items.items() if value == "alert_sync"]
  for view in views:
    if view == "all":
      siemplify.sdk.mark_all_alerts_as_synced_in_environments()
    else:
      siemplify.sdk.mark_all_alerts_as_synced_for_test(test_name=test_name)


def check_test_name_can_be_none() -> Optional[str]:
  """Looks at the stack to check test name.

  This function checks the stack to find the name of the function calling
    the function that called this. If it starts with test_ the name of the 
    test is returned, otherwise returns None.

  Returns:
    Name of the test or None
  """
  test_name = cast(
      types.FrameType,
      cast(types.FrameType, inspect.currentframe()).f_back.f_back
  ).f_code.co_name
  if not test_name.startswith("test_"):
    test_name = None
  return test_name


def check_test_name_can_not_be_none() -> str:
  """Looks at the stack to check test name.

  This function checks the stack to find the name of the function calling
    the function that called this. If it starts with test_ the name of the
    test is returned, otherwise raises an error.

  Raises:
    ValueError if function on the stack doesn't start with test_

  Returns:
    Name of the test
  """
  name = cast(
      types.FrameType,
      cast(types.FrameType, inspect.currentframe()).f_back.f_back
  ).f_code.co_name
  if not name.startswith("test_"):
    raise ValueError(f"The function was not called by a test! Caller: {name}")
  return name


def generate_test_id() -> str:
  """Generates a random ID for the test.

  Returns:
    A string with random name
  """
  characters = "abcdefgh0123456789"
  return "".join(random.choice(characters) for i in range(36))