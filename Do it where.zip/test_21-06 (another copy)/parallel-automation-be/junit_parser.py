from junitparser import JUnitXml

parallel_report = JUnitXml.fromfile('parallel-test-results.xml')
report = JUnitXml.fromfile('test-results.xml')

# Merge in place and write back to same file
parallel_report += report
parallel_report.write('combined_report.xml')