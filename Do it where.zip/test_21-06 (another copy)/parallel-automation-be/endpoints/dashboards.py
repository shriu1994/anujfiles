"""Configuration for widget-related API endpoints.
"""
from source.config import API_MAIN

API_GET_WIDGETS_ENDPOINT = API_MAIN + (
    "/api/external/v1/dashboards/GetDashboard/{}"
)
API_ADD_WIDGET_ENDPOINT = API_MAIN + (
    "/api/external/v1/dashboards/AddOrUpdateDashboardWidget"
)
API_DELETE_WIDGET_ENDPOINT = API_MAIN + (
    "/api/external/v1/dashboards/DeleteDashboardWidget?dashboardWidgetId={}"
)
API_GET_WIDGET_VALUES_ENDPOINT = API_MAIN + (
    "/api/external/v1/dashboards/GetDashboardWidgetValues"
)
API_CREATE_WIDGET_ENDPOINT = API_MAIN + (
    "/api/external/v1/dashboards/AddOrUpdateDashboardWidget"
)
API_ADD_UPDATE_DASHBOARD_ENDPOINT = API_MAIN + (
    "/api/external/v1/dashboards/AddOrUpdateDashboard"
)
API_DELETE_DASHBOARD_ENDPOINT = API_MAIN + (
    "/api/external/v1/dashboards/DeleteDashboard?format=camel&dashboardtId={}"
)
