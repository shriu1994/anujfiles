"""Configuration for environment-related API endpoints.
"""
from source.config import API_MAIN

API_ADD_UPDATE_ENVIRONMENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateEnvironmentRecords"
)
API_GET_ENVIRONMENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetEnvironments"
)
API_DELETE_ENVIRONMENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/RemoveEnvironmentRecords"
)
API_GET_ENVIRONMENT_ACTIONS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetEnvironmentActionDefinitions"
)
API_GET_ALERT_EVENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/GetAlertEvents"
)
API_ADD_UPDATE_ENV_DYNAMIC_PARAMETERS = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateDynamicParameters"
)
API_REMOVE_ENV_DYNAMIC_PARAMETER = API_MAIN + (
    "/api/external/v1/settings/RemoveDynamicParameter"
)