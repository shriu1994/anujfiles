"""Configuration for integrations-related API endpoints.
"""
from source.config import API_MAIN

API_INSTALL_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/store/DownloadAndInstallIntegrationFromLocalStore"
)
API_DELETE_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/store/UnInstallNewIntegration/{}"
)
API_GET_INSTALLED_INTEGRATIONS_ENDPOINT = API_MAIN + (
    "/api/external/v1/integrations/GetInstalledIntegrations"
)
API_GET_INSTALLED_INTEGRATIONS_BY_ENV_ENDPOINT = API_MAIN + (
    "/api/external/v1/integrations/GetEnvironmentInstalledIntegrations"
)
API_CONFIGURE_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/store/SaveIntegrationConfigurationProperties"
)
API_GET_INTEGRATION_ID_ENDPOINT = API_MAIN + (
    "/api/external/v1/integrations/GetIntegrationDefaultInstance/{}"
)
API_GET_INTEGRATION_FULL_DETAILS_ENDPOINT = API_MAIN + (
    "/api/external/v1/store/GetIntegrationFullDetails"
)
API_GET_INTEGRATIONS_STORE_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/store/GetIntegrationsStoreData"
)
API_CREATE_INTEGRATION_INSTANCE_ENDPOINT = API_MAIN + (
    "/api/external/v1/integrations/CreateIntegrationInstance"
)
API_TEST_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/store/TestIntegration/{}"
)
API_DELETE_INTEGRATION_INSTANCE_ENDPOINT = API_MAIN + (
    "/api/external/v1/integrations/DeleteIntegrationInstance"
)
API_GET_INTEGRATIONS_INSTANCE_SETTINGS = API_MAIN + (
    "/api/external/v1/integrations/GetIntegrationInstanceSettings/{}"
)
API_GET_OPTIONAL_INSTANCES_ENDPOINT = API_MAIN + (
    "/api/external/v1/integrations/GetOptionalIntegrationInstances"
)
API_CREATE_CUSTOM_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/CreateCustomIntegration"
)
API_DELETE_CUSTOM_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/DeleteCustomIntegration/{}"
)
