"""Configuration for jobs-related API endpoints.
"""
from source.config import API_MAIN

API_SAVE_OR_UPDATE_JOB_ENDPOINT = API_MAIN + (
    "/api/external/v1/jobs/SaveOrUpdateJobData"
)
API_RUN_JOB_ENDPOINT = API_MAIN + (
    "/api/external/v1/jobs/RunJob"
)
API_GET_INSTALLED_JOBS_ENDPOINT = API_MAIN + (
    "/api/external/v1/jobs/GetInstalledJobs"
)
API_DELETE_INSTALLED_JOB_ENDPOINT = API_MAIN + (
    "/api/external/v1/jobs/DeleteJobData"
)
API_GET_JOB_HISTORY_ENDPOINT = API_MAIN + (
    "/api/external/v1/jobs/GetJobHistoryLogs/jobIdStr?jobIdStr={}"
)
