"""Configuration for SLA-related API endpoints.
"""
from source.config import API_MAIN


API_GET_USER_FULL_NAME_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/GetUserFullName/{}"
)
API_GET_CURRENT_SIEMPLIFY_VERSION_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/GetCurrentSiemplifyVersion"
)
API_GET_SYSTEM_INFO_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/SystemInfo/{}"
)
API_GET_ATTACHMENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/Attachments/{}"
)
API_GET_ATTACHMENT_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/AttachmentData/{}"
)
API_GET_CASE_COMMENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/GetCaseComments/{}"
)
API_GET_SYNC_NEW_ALERTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/sync/new-alerts"
)
API_POST_SYNC_NEW_ALERTS_MATCHES_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/sync/new-alerts/matches"
)
API_POST_SYNC_NEW_ALERTS_SYNC_FAILURES_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/sync/new-alerts/failures"
)
API_POST_SYNC_NEW_ALERTS_RESULTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/sdk/sync/new-alerts/results"
)
