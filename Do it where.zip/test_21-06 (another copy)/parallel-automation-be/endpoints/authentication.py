"""Configuration for jobs-related API endpoints.
"""
from source.config import API_MAIN

# ---------- Login endpoints ----------
API_LOGIN_ENDPOINT = API_MAIN + "/api/external/v1.0/auth/login"
API_AUTHZ_METADATA_ENDPOINT = API_MAIN + "/api/external/v1.0/authz-metadata"
API_GET_INTEGRATION_ENDPOINT = API_MAIN +(
    "/api/external/v1/integrations/GetIntegrationDefaultInstance/{}"
)
