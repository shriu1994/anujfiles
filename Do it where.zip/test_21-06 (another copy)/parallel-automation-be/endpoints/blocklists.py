"""Configuration for blocklist-related API endpoints.
"""
from source.config import API_MAIN

API_ADD_BLOCKLIST_ENTITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateModelBlockRecords"
)
API_DELETE_BLOCKLIST_ENTITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/RemoveModelBlockRecords"
)
API_GET_ALL_BLOCKLIST_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetBlockListDetails"
)
