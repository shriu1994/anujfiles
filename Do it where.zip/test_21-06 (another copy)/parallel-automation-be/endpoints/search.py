"""Configuration for search-related API endpoints.
"""
from source.config import API_MAIN

API_SEARCH_CASES_EVERYTHING_ENDPOINT = API_MAIN + (
    "/api/external/v1/search/CaseSearchEverything"
)
API_SEARCH_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/search/EntitySearchEverything"
)