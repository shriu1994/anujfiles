"""Configuration for publisher-related API endpoints.
"""
from source.config import API_MAIN

API_GET_PUBLISHER_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/GetPublishers"
)
API_TEST_PUBLISHER_PING_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/TestPublisherConnectivity/{}"
)
API_UPDATE_PUBLISHER_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/AddOrUpdatePublisher"
)
API_DELETE_PUBLISHER_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/DeletePublishers"
)