"""Configuration for entity-related API endpoints.
"""
from source.config import API_MAIN

API_ADD_ENTITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/entities/InitEmptyEntity"
)
API_ADD_ENTITY_TO_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/CreateCaseEntity"
)
API_SEARCH_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/search/EntitySearchEverything"
)
API_GET_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetCaseEntities/{}"
)
API_GET_ALERT_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetAlertsEntities"
)
API_UPDATE_ENTITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/AddOrUpdateEntityProperty"
)
