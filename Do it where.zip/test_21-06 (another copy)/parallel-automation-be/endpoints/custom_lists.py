"""Configuration for custom-lists API endpoints.
"""
from source.config import API_MAIN

API_ADD_OR_UPDATE_CUSTOM_LIST = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateTrackingListRecords"
)
API_REMOVE_CUSTOM_LIST = API_MAIN + (
    "/api/external/v1/settings/RemoveTrackingListRecords"
)
API_GET_CUSTOM_LISTS = API_MAIN + (
    "/api/external/v1/settings/GetTrackingListRecords"
)