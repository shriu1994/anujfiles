"""Configuration for connectors-related API endpoints.
"""
from source.config import API_MAIN

API_ADD_OR_UPDATE_CONNECTOR_INSTANCE_ENDPOINT = API_MAIN + (
    "/api/external/v1/connectors"
)
API_DELETE_CONNECTOR_INSTANCE_ENDPOINT = API_MAIN + (
    "/api/external/v1/connectors/{}"
)
API_GET_CONNECTOR_INSTANCES_ENDPOINT = API_MAIN + (
    "/api/external/v1/connectors/cards"
)
API_ADD_TEMPLATE_ENDPOINT = API_MAIN + (
    "/api/external/v1/connectors/template"
)
API_RUN_CONNECTOR_ONCE_ENDPOINT = API_MAIN + (
    "/api/external/v1/connectors/fetch-sample-data"
)
API_ENABLE_CONNECTOR_LOGS_COLLECTION_ENDPOINT = API_MAIN + (
    "/api/external/v1/connectors/{}/AppLogs"
)
API_GET_CONNECTOR_LOGS_ENDPONT = API_MAIN + (
    "/api/external/v1/connectors/{}/GetAppLogs"
)