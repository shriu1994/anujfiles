"""Configuration for IDE-related API endpoints.
"""
from source.config import API_MAIN

API_ADD_OR_UPDATE_IDE_ITEM_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/AddOrUpdateItem"
)
API_CREATE_CUSTOM_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/CreateCustomIntegration"
)
API_CREATE_CUSTOM_ACTION_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/GetIdeTemplate"
)
API_DELETE_CUSTOM_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/DeleteCustomIntegration/{}"
)
API_RUN_TEST_ITEM_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/TestItem"
)
API_EXPORT_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/ExportPackage/{}"
)
API_IMPORT_INTEGRATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/ImportPackage"
)
API_GET_ITEMS_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/GetIdeItemCards"
)
API_DELETE_ITEM_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/DeleteItem"
)
API_GET_ITEM_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/GetIdeItem"
)
API_ADD_UPDATE_ITEM_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/AddOrUpdateItem"
)
API_IMPORT_ITEM_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/ImportItems"
)
