"""Configuration for case-related API endpoints.
"""
from source.config import API_MAIN

API_SIMULATE_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/attackssimulator/GenerateUseCases"
)
API_GET_CASES_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases-queue/GetCaseCardsByRequest"
)
API_CLOSE_CASES_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases-queue/bulk-operations/ExecuteBulkCloseCase"
)
API_GET_CASE_DETAILS_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/GetCaseDetails/{}"
)
API_GET_CASE_FULL_DETAILS_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/GetCaseFullDetails/{}"
)
API_CREATE_MANUAL_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/CreateManualCase"
)
API_ASSIGN_USER_TO_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/AssignUserToCase"
)
API_GET_ASSIGNED_CASES_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/homepagecases/GetByRequest"
)
API_SEARCH_CASES_EVERYTHING_ENDPOINT = API_MAIN + (
    "/api/external/v1/search/CaseSearchEverything"
)
API_CASE_RUN_MANUAL_ACTION_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/ExecuteManualAction"
)
API_ADD_UPDATE_CASE_TASK_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/AddOrUpdateCaseTask"
)
API_RENAME_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/RenameCase"
)
API_ADD_CASE_TAG_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/AddCaseTag"
)
API_REMOVE_CASE_TAG_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/RemoveCaseTag"
)
API_ADD_CASE_COMMENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/comments"
)
API_UPDATE_CASE_COMMENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/comments/id:long?id={}"
)
API_GET_CASE_EVIDENCE_DATA = API_MAIN + (
    "/api/external/v1/dynamic-cases/getEvidenceData/{}"
)
API_GET_CASE_WALL_ACTIVITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/comments?CaseId={}"
)
API_MARK_COMMENT_AS_DELETED_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/comments/mark-as-deleted/{}"
)
API_UPDATE_CASE_PRIORITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/UpdateCasePriority"
)
API_GENERATE_CASE_REPORT_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/GenerateCaseReport"
)
API_CHANGE_CASE_STAGE_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/ChangeCaseStage"
)
API_CHANGE_CASE_DESCRIPTION_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/ChangeCaseDescription"
)
API_ADD_ENTITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/entities/InitEmptyEntity"
)
API_GET_CASE_ACTION_RESULT_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/GetActionResultById/{}"
)
API_GET_CASE_WALL_ACTIVITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/GetWallActivities/{}"
)
API_ADD_ENTITY_TO_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/CreateCaseEntity"
)
API_SEARCH_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/search/EntitySearchEverything"
)
API_GET_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetCaseEntities/{}"
)
API_GET_ALERT_ENTITIES_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetAlertsEntities"
)
API_UPDATE_ENTITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/AddOrUpdateEntityProperty"
)
API_GET_ALERT_OVERVIEW_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetAlertOverviewData"
)
API_GET_CASE_OVERVIEW_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetCaseOverviewData"
)
API_GET_CUSTOM_CASES_ENDPOINT = API_MAIN + (
    "/api/external/v1/attackssimulator/GetCustomCases"
)
API_CREATE_SIMULATED_CUSTOM_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/attackssimulator/CreateSimulatedCustomCase"
)
API_MERGE_CASES_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases-queue/bulk-operations/MergeCases"
)
API_MOVE_CASE_TO_ENVIRONMENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/IngestCaseInOtherEnvironment"
)
API_INGEST_ALERT_AS_TEST_ENDPOINT = API_MAIN + (
    "/api/external/v1/attackssimulator/SimulateAlert"
)
API_RAISE_INCIDENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/RaiseIncident"
)
API_SKIP_ACTION_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/Skip"
)
API_GET_WORKFLOW_INSTANCE_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/GetWorkflowStepInstance"
)
API_RERUN_WORKFLOW_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/RerunPlaybook"
)
API_EXECUTE_PENDING_ACTION = API_MAIN + (
    "/api/external/v1/cases/ExecuteStep"
)
API_REOPEN_CASES_IN_BULK_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/ExecuteBulkReopenCase"
)
API_GET_ALERT_EVENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/GetAlertEvents"
)
API_MOVE_ALERT_TO_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/MoveAlertToNewCase"
)
API_UPDATE_ALERT_PRIORITY_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/UpdateAlertPriority"
)
API_IMPORT_CUSTOM_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/attackssimulator/ImportCustomCase"
)
API_DELETE_USE_CASE_ENDPOINT = API_MAIN + (
    "/api/external/v1/attackssimulator/DeleteUseCase"
)
API_CASES_QUEUE_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/cases/{}"
)
API_CASES_CREATE_CASE = API_MAIN + (
    "/api/external/v1/cases/CreateCase"
)
API_GET_INVESTIGATION_DATA = API_MAIN + (
    "/api/external/v1/investigator/GetInvestigatorData/{}"
)