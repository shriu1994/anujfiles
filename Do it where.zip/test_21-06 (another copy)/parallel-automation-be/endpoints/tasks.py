"""Configuration for tasks-related API endpoints.
"""
from source.config import API_MAIN

API_GET_TASKS_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/tasks/GetByRequest"
)
API_DELETE_TASK_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/tasks/{}"
)
API_ADD_UPDATE_CASE_TASK_ENDPOINT = API_MAIN + (
    "/api/external/v1/dynamic-cases/AddOrUpdateCaseTask"
)
API_ADD_TASK_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/tasks"
)
