"""Configuration for settings-related API endpoints.
"""
from source.config import API_MAIN


API_CHANGE_EMAIL_VERIFICATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/UpdateUserRegistrationSettings"
)
API_SAVE_ALERT_GROUPING_SETTINGS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/SaveAlertGroupingSettings"
)
API_UPDATE_MOVE_CASES_BETWEEN_ENVS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/"
    "AddOrUpdateMoveCaseBetweenEnvironmentsPolicySettings"
)
API_UPDATE_CASE_ASSIGNMENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateCaseAssignmentPolicySettings"
)
API_ADD_ITEM_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/AddOrUpdateItem"
)
API_ADD_UPDATE_LOCALIZATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateLocalizationSettingForAllUsers"
)
API_TEST_EMAIL_SETTINGS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/TestEmailSettings"
)
API_SAVE_EMAIL_SETTINGS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateEmailSettings"
)
API_GET_EMAIL_SETTINGS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetEmailSettings"
)