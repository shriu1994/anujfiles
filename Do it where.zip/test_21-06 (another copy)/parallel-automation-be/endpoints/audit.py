"""Configuration for audit-related API endpoints.
"""
from source.config import API_MAIN

API_GET_AUDIT_DATA_V2_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetAuditDataV2"
)