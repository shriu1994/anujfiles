"""Configuration for SLA-related API endpoints.
"""
from source.config import API_MAIN

API_GET_SYSTEM_NOTIFICATIONS = API_MAIN + (
    "/api/external/v1/notifications/GetSystemNotifications"
)
