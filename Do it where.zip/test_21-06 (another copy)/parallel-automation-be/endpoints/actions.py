"""Configuration for action-related API endpoints.
"""
from source.config import API_MAIN

API_GET_ITEMS_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/GetIdeItemCards"
)
API_DELETE_ITEM_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/DeleteItem"
)
API_GET_ITEM_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/ide/GetIdeItem"
)
