"""Configuration for retention-related API endpoints.
"""
from source.config import API_MAIN

API_GET_RETENTION_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetDataRetentionSettings"
)
API_TRIGGER_RETENTION_ENDPOINT = API_MAIN + (
    "/api/external/v1/retention/Execute"
)