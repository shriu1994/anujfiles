"""Configuration for homepage-related API endpoints."""
from source.config import API_MAIN

API_GET_PENDING_ACTIONS_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/GetPendingStepsUserRelated"
)
API_GET_REQUESTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/requests/GetByRequest"
)
API_GET_LINKS_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/links/GetByRequest"
)
API_GET_FILES_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/attachments/GetByRequest"
)
API_GET_CONTACTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/contacts/GetByRequest"
)
API_GET_NOTES_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/notes/GetByRequest"
)
API_GET_ANNOUNCEMENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/rss/GetByRequest"
)
API_CREATE_ANNOUNCEMENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/rss"
)
API_DELETE_ANNOUNCEMENTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/rss/{}"
)
API_GET_ANNOUNCEMENTS_COUNT_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/rss/GetRssCount"
)
API_GET_CONTACT_DETAILS_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/contacts/{}"
)
API_CREATE_CONTACT_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/contacts"
)
API_DELETE_CONTACT_ENDPOINT = API_MAIN + (
    "/api/external/v1/homepage/contacts/{}"
)