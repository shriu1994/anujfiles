"""Configuration for agent-related API endpoints.
"""
from source.config import API_MAIN

API_GET_AGENT_LIST_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/GetAgents"
)
API_GET_AGENTS_BY_ENV_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/GetAgentsByEnvironment"
)
API_UPDATE_AGENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/UpdateAgent"
)
API_GET_AGENTS_INFO_BY_ID_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/GetAgentsInformationByIdentifiers"
)
API_DEL_AGENT_ENDPOINT = API_MAIN + (
    "/api/external/v1/agents/DeleteAgent"
)