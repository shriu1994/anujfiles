"""Configuration for services related API endpoints.
"""
from source.config import API_MAIN

API_CHECK_SERVICES_ENDPOINT = API_MAIN + (
    "/api/external/v1/stoptheworld"
)

API_WEBHOOKS_KEEPALIVE_ENDPOINT = API_MAIN + (
    "/api/external/v1/webhooks-management/KeepAlive"
)
