"""Configuration for Webhooks-related API endpoints.
"""
from source.config import API_MAIN

# ----- Webhooks Endpoints -----
API_WEBHOOKS_ENDPOINT_BASE = API_MAIN + (
    "/api/external/v1/webhooks-management/"
)
API_GET_WEBHOOKS_ENDPOINT = API_MAIN + (
    "/api/external/v1/webhooks-management/Cards"
)