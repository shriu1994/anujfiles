"""Configuration for domain-related API endpoints.
"""
from source.config import API_MAIN

API_ADD_DOMAIN_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateDomainAliasesRecords"
)
API_DELETE_DOMAIN_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/RemoveDomainAliasesRecords"
)
API_GET_ALL_DOMAINS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetDomainAliases"
)