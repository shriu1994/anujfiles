"""Configuration for playbook-related API endpoints.
"""
from source.config import API_MAIN

API_PLAYBOOK_CREATE_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/SaveWorkflowDefinitions"
)
API_PLAYBOOK_DELETE_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/DeleteWorkflows"
)
API_GET_PLAYBOOKS_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/GetWorkflowMenuCardsWithEnvFilter"
)
API_GET_PLAYBOOK_SUMMARY_RESULT_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/GetWorkflowInstancesCards"
)
API_GET_PLAYBOOK_DATA_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/GetWorkflowFullInfoByIdentifier/{}"
)
API_DUPLICATE_PLAYBOOK_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/DuplicateWorkflows"
)
API_CREATE_PLAYBOOK_FOLDER = API_MAIN + (
    "/api/external/v1/playbooks/AddOrUpdatePlaybookCategory"
)
API_DELETE_PLAYBOOK_FOLDERS = API_MAIN + (
    "/api/external/v1/playbooks/RemoveCategories"
)
API_GET_PLAYBOOK_FOLDERS = API_MAIN + (
    "/api/external/v1/playbooks/GetWorkflowCategories"
)
API_EXPORT_PLAYBOOK_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/ExportDefinitions"
)
API_IMPORT_PLAYBOOK_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/ImportDefinitions"
)
API_GET_WORKFLOW_INSTANCE_SUMMARY_ENDPOINT = API_MAIN + (
    "/api/external/v1/cases/GetWorkflowInstanceSummary"
)
API_PLAYBOOK_SAVE_LOG_VERSION_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/SaveLogVersionOfWorkflowDefinitions"
)
API_GET_PLAYBOOK_LOG_VERSION_ENDPOINT = API_MAIN + (
    "/api/external/v1/playbooks/GetWorkFlowVersionLogs"
)
