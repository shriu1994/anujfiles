"""Configuration for case-related API endpoints.
"""
from source.config import API_MAIN

API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT_BASE = API_MAIN + (
    "/api/external/v1/external-authentication-settings"
)
API_EXTERNAL_AUTHENTICATION_SETTINGS_ENDPOINT = API_MAIN + (
    "/api/external/v1/external-authentication-settings/{}"
)
