"""Configuration for users-related API endpoints.
"""
from source.config import API_MAIN

API_ADD_ROLE_ENDPOINT = API_MAIN + (
    "/api/external/v1/socroles/AddOrUpdateSocRole"
)
API_DELETE_ROLE_ENDPOINT = API_MAIN + (
    "/api/external/v1/socroles/DeleteSocRole"
)
API_ADD_USER_ENDPOINT = API_MAIN + (
    "/api/external/v1/accounts/Register"
)
API_DELETE_USER_ENDPOINT = API_MAIN + (
    "/api/external/v1/accounts/DeleteUserProfile"
)
API_GET_USERS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetUserProfiles"
)
API_GET_ROLES_ENDPOINT = API_MAIN + (
    "/api/external/v1/socroles/getSocRoles"
)
API_GET_ROLE_BY_ID_ENDPOINT = API_MAIN + (
    "/api/external/v1/socroles/GetSocRole/{}"
)
API_CREATE_PERMISSION_GROUP_ENDPOINT = API_MAIN + (
    "/api/external/v1/permissions"
)
API_DELETE_PERMISSION_GROUP_ENDPOINT = API_MAIN + (
    "/api/external/v1/permissions/{}"
)
API_GET_PERMISSION_GROUPS_ENDPOINT = API_MAIN + (
    "/api/external/v1/permissions/GetPermissionsGroupCards"
)
API_ADD_OR_UPDATE_USER_PROFILE = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateUserProfile"
)
