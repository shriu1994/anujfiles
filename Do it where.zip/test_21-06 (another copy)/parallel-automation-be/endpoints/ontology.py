"""Configuration for ontologies-related API endpoints.
"""
from source.config import API_MAIN

API_GET_ONTOLOGY_MAPPING_RULES_ENDPOINT = API_MAIN + (
    "/api/external/v1/ontology/GetMappingRulesForSettings"
)
API_GET_ONTOLOGY_STATUS_RECORDS_ENDPOINT = API_MAIN + (
    "/api/external/v1/ontology/GetOntologyStatusRecords"
)
API_POST_IMPORT_ONTOLOGY_ENDPOINT = API_MAIN + (
    "/api/external/v1/ontology/ImportOntology"
)
API_POST_IMPORT_VISUAL_FAMILY_ENDPOINT = API_MAIN + (
    "/api/external/v1/ontology/ImportVisualFamily"
)
API_SET_MAPPING_RULE = API_MAIN + (
    "/api/external/v1/ontology/AddOrUpdateMappingRules"
)
API_POST_CREATE_UPDATE_VISUAL_FAMILY_ENDPOINT = API_MAIN + (
    "/api/external/v1/ontology/AddOrUpdateVisualFamily"
)
API_GET_VISUAL_FAMILY_ENDPOINT = API_MAIN + (
    "/api/external/v1/ontology/GetVisualFamilies"
)
API_DELETE_VISUAL_FAMILY_ENDPOINT = API_MAIN + (
    "/api/external/v1/ontology/DeleteFamilyData/{}"
)