"""Configuration for SLA-related API endpoints.
"""
from source.config import API_MAIN


API_GET_TENANTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/tenants?PageSize=501"
)
API_ADD_TENANT_ENDPOINT = API_MAIN + (
    "/api/external/v1/tenants"
)
API_REGISTER_TENANT_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/tenants/{}"
)
API_CHANGE_TENANT_PYTHON_POD_ENDPOINT = API_MAIN + (
    "/api/external/v1/tenants/private-python-pod"
)
API_DELETE_TENANT_ENDPOINT = API_MAIN + (
    "/api/external/v1/tenants/{}"
)
API_SEND_INVITATION_ENDPOINT = API_MAIN + (
    "/api/external/v1/accounts/SendInvitationEmail"
)
API_GET_SUMMARY_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/0"
)
API_GET_CASES_QUEUE_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/cases/items"
)
API_GET_INDEXER_QUEUE_ITEMS_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/indexer/items"
)
API_GET_WORKFLOW_QUEUE_ITEMS_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/workflow/items"
)
API_GET_CASES_QUEUE_ERRORS_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/cases/errors"
)
API_GET_INDEXER_QUEUE_ERRORS_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/indexer/errors"
)
API_GET_WORKFLOW_QUEUE_ERRORS_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/workflow/errors"
)
API_GET_QUEUE_WEIGHTS_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/queues/tenant-weights"
)
API_GET_TENANT_BY_EMAIL_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/tenants/get-tenant-details-by-email/{}"
)
API_GET_TENANT_BY_ID_ENDPOINT = API_MAIN + (
    "/api/external/v1/management/tenants/{}"
)
