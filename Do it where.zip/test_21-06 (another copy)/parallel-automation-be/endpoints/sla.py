"""Configuration for SLA-related API endpoints.
"""
from source.config import API_MAIN


API_PAUSE_ALERT_SLA = API_MAIN + (
    "/api/external/v1/cases/PauseAlertSla"
)
API_RESUME_ALERT_SLA = API_MAIN + (
    "/api/external/v1/cases/ResumeAlertSla"
)
API_DELETE_SLA_DEFINITION_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/RemoveSlaDefinitionRecords"
)
API_GET_SLA_DEFINITIONS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetSlaDefinitions"
)
API_ADD_SLA_DEFINITION_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddSlaDefinitionsRecord?format=camel"
)
