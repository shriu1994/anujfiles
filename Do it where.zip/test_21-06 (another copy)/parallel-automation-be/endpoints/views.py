"""Configuration for views-related API endpoints.
"""
from source.config import API_MAIN

API_SAVE_VIEW_TEMPLATE_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/SaveOverviewTemplate"
)
API_DELETE_VIEW_TEMPLATE_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/DeleteOverviewTemplate"
)
API_GET_VIEW_TEMPLATES_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetOverviewTemplateCards"
)
API_GET_VIEW_TEMPLATE_DETAILS_ENDPOINT = API_MAIN + (
    "/api/external/v1/case-overview/GetFullOverviewTemplateDetails/{}"
)