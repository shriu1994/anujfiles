"""Configuration for reports-related API endpoints.
"""
from source.config import API_MAIN

API_GENERATE_REPORT_ENDPOINT = API_MAIN + (
    "/api/external/v1/reports/GenerateReportTemplate"
)
API_GET_REPORT_TEMPLATES_ENDPOINT = API_MAIN + (
    "/api/external/v1/reports/GetReportTemplates"
)
API_CREATE_UPDATE_REPORT_TEMPLATE_ENDPOINT = API_MAIN + (
    "/api/external/v1/reports/AddOrUpdateReportTemplate"
)
API_CREATE_UPDATE_REPORT_WIDGET_ENDPOINT = API_MAIN + (
    "/api/external/v1/reports/AddOrUpdateReportWidget"
)