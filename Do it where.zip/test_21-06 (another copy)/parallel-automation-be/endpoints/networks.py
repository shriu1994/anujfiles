"""Configuration for network-related API endpoints.
"""
from source.config import API_MAIN


API_ADD_NETWORK_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/AddOrUpdateNetworkDetailsRecords"
)
API_DELETE_ALL_NETWORKS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/networks/permitted"
)
API_DELETE_NETWORK_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/networks/{}"
)
API_GET_NETWORKS_ENDPOINT = API_MAIN + (
    "/api/external/v1/settings/GetNetworkDetails"
)