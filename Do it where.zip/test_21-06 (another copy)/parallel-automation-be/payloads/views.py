"""Functions that generate JSON for payloads for API calls.
"""
import json
import random
import time
from typing import Optional

from resources.strings.strings import TABLE

BASE_ID = "3ef59927-4ac6-4539-98de-"


def save_view_payload(
    user_id: str,
    template_type: str,
    widgets: list[str],
    identifier: Optional[str],
    playbook_id: Optional[str]
) -> json:
  """Creates a JSON based on a template.

  Args:
    user_id: ID of user creating a playbook
    template_type: type of template: can be "Alert" or "Case"
    widgets: list of widgets to add to a view
    identifier: ID of the view

  Returns:
    A JSON with data to create a playbook
  """
  if not identifier:
    random_id = random.randint(100000000000, 999999999999)
    identifier = f"{BASE_ID}{random_id}"
  template_lower = template_type.lower()
  if template_lower == "alert":
    template_id = 1
    type_id = 2
    name = "Default Alert View"
  elif template_lower == "case":
    template_id = 2
    type_id = 3
    name = "Default Case View"
  else:
    raise ValueError("template type has to be 'Alert' or 'Case'")
  template = {
      "id": template_id,
      "identifier": identifier,
      "name": name,
      "creator": user_id,
      "playbookIdentifier": playbook_id,
      "type": type_id,
      "widgets": [],
      "roles": [],
      "creationTimeUnixTimeInMs": int(time.time()) * 1000
  }
  order = 1
  for widget in widgets:
    # Entities highlights - available in alert and case
    widget_lower = widget.lower()
    if widget_lower == "entities highlights":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append(
          {
              "metadata": {
                  "id": 0,
                  "identifier": widget_id,
                  "title": "Entities Highlights",
                  "width": 2,
                  "order": order,
                  "description": (
                      "This widget displays the highlighted fields"
                      " for each entity"
                  ),
                  "type": 10,
                  "templateIdentifier": identifier,
                  "predefinedWidgetTemplateIdentifier": None,
                  "actionIdentifier": None,
                  "stepIdentifier": None,
                  "presentIfEmpty": False,
                  "conditionsGroup": {
                      "conditions": [],
                      "logicalOperator": 0
                  }
              },
              "config": {}
          },)
      order += 1
    # Entities graph - available in alert and case
    elif widget_lower == "entities graph":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append({
          "metadata": {
              "identifier": widget_id,
              "title": "Entities Graph",
              "width": 2,
              "order": order,
              "description":
                  ("This widget includes a visual graph and other details "
                   "of the Case Entities"),
              "type": 7,
              "templateIdentifier": identifier,
              "predefinedWidgetTemplateIdentifier": None,
              "actionIdentifier": None,
              "stepIdentifier": "",
              "presentIfEmpty": False,
              "conditionsGroup": {
                  "conditions": [],
                  "logicalOperator": 0
              }
          },
          "config": {}
      })
      order += 1
    # Insights - available in alert and case
    elif widget_lower == "insights":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append({
          "metadata": {
              "type": 15,
              "order": order,
              "identifier": widget_id,
              "description":
                  ("This widget contains all the Insights from the Playbook "
                   "Insights actions, general Insights and any other Insights "
                   "you have added. They will be presented in HTML format"),
              "title": "Insights",
              "width": 2,
              "presentIfEmpty": False,
              "stepIdentifier": "",
              "actionIdentifier": None,
              "predefinedWidgetTemplateIdentifier": None,
              "templateIdentifier": identifier,
              "conditionsGroup": {
                  "conditions": [],
                  "logicalOperator": 0
              }
          },
          "config": {}
      })
      order += 1
    # Free text - available in alert and case
    elif widget_lower == "free text":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append({
          "metadata": {
              "type": 8,
              "order": order,
              "identifier": widget_id,
              "description": "",
              "title": "Free Text",
              "width": 2,
              "presentIfEmpty": False,
              "stepIdentifier": "",
              "actionIdentifier": None,
              "predefinedWidgetTemplateIdentifier": None,
              "templateIdentifier": identifier,
              "conditionsGroup": {
                  "conditions": [],
                  "logicalOperator": 0
              }
          },
          "config": {
              "text": "Test"
          }
      })
      order += 1
    # Insights - available in alert and case
    elif widget_lower == "html":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append({
          "metadata": {
              "type": 3,
              "order": order,
              "identifier": widget_id,
              "description": "",
              "title": "HTML",
              "width": 2,
              "presentIfEmpty": False,
              "stepIdentifier": "",
              "actionIdentifier": None,
              "predefinedWidgetTemplateIdentifier": None,
              "templateIdentifier": identifier,
              "conditionsGroup": {
                  "conditions": [],
                  "logicalOperator": 0
              }
          },
          "config": {
              "htmlContent": TABLE,
              "safeRendering": False,
              "htmlHeight": 425
          }
      })
      order += 1
    # Pending actions - available in alert and case
    elif widget_lower == "pending actions":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append({
          "metadata": {
              "type": 11,
              "order": order,
              "identifier": widget_id,
              "description": (
                  "This Widget lists all playbook actions"
                  " waiting for user input."
              ),
              "title": "Pending Actions",
              "width": 2,
              "presentIfEmpty": False,
              "stepIdentifier": "",
              "actionIdentifier": None,
              "predefinedWidgetTemplateIdentifier": None,
              "templateIdentifier": identifier,
              "conditionsGroup": {
                  "conditions": [],
                  "logicalOperator": 0
              }
          },
          "config": {}
      })
      order += 1
    # Case description - available in case
    elif widget_lower == "case description" and template_lower == "case":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append({
          "metadata": {
              "type": 14,
              "order": order,
              "identifier": widget_id,
              "description":
                  ("This widget enables you to write a unique description "
                   "for each case."),
              "title": "Case Description",
              "width": 2,
              "presentIfEmpty": False,
              "stepIdentifier": "",
              "actionIdentifier": None,
              "predefinedWidgetTemplateIdentifier": None,
              "templateIdentifier": identifier,
              "conditionsGroup": {
                  "conditions": [],
                  "logicalOperator": 0
              },
          },
          "config": {
              "pendingSteps": None,
              "type": 11,
              "widgetDefinitionScope": 0
          }
      })
      order += 1
    # Alerts - available in case
    elif widget_lower == "alerts" and template_lower == "case":
      random_id = random.randint(100000000000, 999999999999)
      widget_id = f"{BASE_ID}{random_id}"
      template["widgets"].append({
          "metadata": {
              "type": 5,
              "order": order,
              "identifier": widget_id,
              "description": (
                  "This widget displays information on all the alerts that are "
                  "grouped into this case - including name, number of events, "
                  "and priority."),
              "title": "Alerts",
              "width": 2,
              "presentIfEmpty": False,
              "stepIdentifier": "",
              "actionIdentifier": None,
              "predefinedWidgetTemplateIdentifier": None,
              "templateIdentifier": identifier,
              "conditionsGroup": {
                  "conditions": [],
                  "logicalOperator": 0
              }
          },
          "config": {}
      })
      order += 1
    else:
      raise ValueError(f"Widget not available: {widget_lower}")

  return template


def default_case_view_payload(identifier: str, creator: str):
  """Creates a JSON based on a template.

  Args:
    creator: ID of user creating a view
    identifier: ID of the view

  Returns:
    A JSON with data to create a playbook
  """
  template = {
      "id": 2,
      "identifier": identifier,
      "name": "Default Case View",
      "creator": creator,
      "playbookIdentifier": "",
      "type": 3,
      "widgets": [
          {
      "metadata": {
        "type": 14,
        "order": 1,
        "identifier": "5342127d-c4a9-4115-a2e1-da067b500949",
        "description": "This widget enables you to write a unique description for each case.",
        "title": "Case Description",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 11,
        "order": 2,
        "identifier": "35f21731-e32a-49b1-a5c2-217d448f96ef",
        "description": "This Widget lists all playbook actions waiting for user input.",
        "title": "Pending Actions",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 5,
        "order": 3,
        "identifier": "5c615f21-30f7-443e-88bb-492601e3755f",
        "description": "This widget displays information on all the alerts that are grouped into this case - including name, number of events, and priority.",
        "title": "Alerts",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 7,
        "order": 4,
        "identifier": "9453cf45-d55f-430e-a3a1-990fba3ca042",
        "description": "This widget includes a visual graph and other details of the Case Entities.",
        "title": "Entities Graph",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 15,
        "order": 5,
        "identifier": "ca4e524e-a746-4312-95a5-8b37d8c0ccf6",
        "description": "This widget contains all the Insights from the Playbook Insights actions, general Insights and any other Insights you have added. They will be presented in HTML format",
        "title": "Insights",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 10,
        "order": 6,
        "identifier": "7a73df83-2ea0-4210-9406-1350b030e25e",
        "description": "This widget displays the highlighted fields for each entity.",
        "title": "Entities Highlights",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 4,
        "order": 7,
        "identifier": "ad2390a7-1176-4a24-98ca-518095d653cd",
        "description": "This widget displays the selected case wall activities over a selected period of time.",
        "title": "Latest Case Wall Activity",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {
        "timeRangeFilter": 1,
        "types": [
          0,
          2
        ]
      }
    },
    {
      "metadata": {
        "type": 12,
        "order": 8,
        "identifier": "058b5203-c47c-4b24-a8c0-a1c8817716f1",
        "description": "This widget displays similar cases and the recommended analysts and tags to assign to it.",
        "title": "Recommendations",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 13,
        "order": 9,
        "identifier": "c4669001-7bec-44c4-a4bb-c2129a4efead",
        "description": "This widget displays the distribution of selected Entity fields.",
        "title": "Statistics",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "73e642df-d52d-4291-9a9a-66162f08f289",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {
        "dataDistributionSettingList": [
          {
            "rawFieldName": "Entity.Type",
            "maxResults": 5
          },
          {
            "rawFieldName": "Entity.IsSuspicious",
            "maxResults": 5
          },
          {
            "rawFieldName": "Entity.IsInternalAsset",
            "maxResults": 5
          }
        ]
      }
    }
  ],
  "roles": [],
  "creationTimeUnixTimeInMs": 1671540654906
  }
  return template


def default_alert_view_payload(identifier: str, creator: str):
  """Creates a JSON based on a template.

  Args:
    creator: ID of user creating a view
    identifier: ID of the view

  Returns:
    A JSON with data to create a playbook
  """
  template = {
  "id": 1,
  "identifier": identifier,
  "name": "Default Alert View",
  "creator": creator,
  "playbookIdentifier": "",
  "type": 2,
  "widgets": [
    {
      "metadata": {
        "type": 10,
        "order": 1,
        "identifier": "8b579082-1deb-451d-872c-f5b93a7ad4fe",
        "description": "This widget displays the highlighted fields for each entity.",
        "title": "Entities Highlights",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "8d722198-5d80-46e0-8e33-a4b44b6a6ed5",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 1,
        "order": 2,
        "identifier": "170694ec-ef03-4ebc-9db4-f3a0f7beba01",
        "description": "This widget displays all Alert events and their properties.",
        "title": "Events Table",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "8d722198-5d80-46e0-8e33-a4b44b6a6ed5",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {
        "filters": [],
        "eventSelectedFields": [
          {
            "columnName": "Name",
            "fieldRawValue": "[Event.name]"
          },
          {
            "columnName": "Source Type",
            "fieldRawValue": "[Event.sourcetype]"
          },
          {
            "columnName": "Device Product",
            "fieldRawValue": "[Event.deviceProduct]"
          },
          {
            "columnName": "Category Outcome",
            "fieldRawValue": "[Event.categoryOutcome]"
          },
          {
            "columnName": "Start Time",
            "fieldRawValue": "[Event.startTime]"
          },
          {
            "columnName": "End Time",
            "fieldRawValue": "[Event.endTime]"
          }
        ],
        "conditionsOperator": 0
      }
    },
    {
      "metadata": {
        "type": 0,
        "order": 3,
        "identifier": "4d175715-bf1a-426b-b5c0-896ec5731957",
        "description": "",
        "title": "Alert Details",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "8d722198-5d80-46e0-8e33-a4b44b6a6ed5",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {
        "keyValue": [
          {
            "key": "Alert name",
            "value": "[Alert.Name]",
            "order": 1
          },
          {
            "key": "Device Product",
            "value": "[Alert.Product]",
            "order": 2
          },
          {
            "key": "Start Time",
            "value": "[Alert.StartTime]",
            "order": 3
          },
          {
            "key": "End Time",
            "value": "[Alert.EndTime]",
            "order": 4
          }
        ]
      }
    },
    {
      "metadata": {
        "type": 11,
        "order": 4,
        "identifier": "9d91bf49-b8ab-4d9d-b682-2123dadd25ec",
        "description": "This Widget lists all playbook actions waiting for user input.",
        "title": "Pending Actions",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "8d722198-5d80-46e0-8e33-a4b44b6a6ed5",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    },
    {
      "metadata": {
        "type": 15,
        "order": 5,
        "identifier": "7ce0cb50-dd5b-4374-93c6-3f98fe01bcbb",
        "description": "This widget contains all the Insights from the Playbook Insights actions, general Insights and any other Insights you have added. They will be presented in HTML format",
        "title": "Insights",
        "width": 2,
        "presentIfEmpty": False,
        "stepIdentifier": "",
        "stepIntegration": "",
        "actionIdentifier": None,
        "predefinedWidgetTemplateIdentifier": None,
        "templateIdentifier": "8d722198-5d80-46e0-8e33-a4b44b6a6ed5",
        "conditionsGroup": {
          "conditions": [],
          "logicalOperator": 0
        }
      },
      "config": {}
    }
  ],
  "roles": [],
  "creationTimeUnixTimeInMs": 1671540654788
  }
  return template
