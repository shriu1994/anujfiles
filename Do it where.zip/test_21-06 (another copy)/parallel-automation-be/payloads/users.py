from siemplify_utils.users import CreatedUserResponse
def add_or_update_user_profile(
    user_details: CreatedUserResponse,
    permission_group: str = "Admins"
):
  return {
    "loginIdentifier": user_details.login,
    "firstName": user_details.first_name,
    "lastName": user_details.last_name,
    "permissionType": user_details.permission_type,
    "role": user_details.role,
    "socRoleId": user_details.soc_role_id,
    "email": user_details.email,
    "userName": user_details.username,
    "imageBase64": user_details.image_base64,
    "userType": user_details.user_type,
    "identityProvider": user_details.identity_provider,
    "providerName": user_details.provider_name,
    "advancedReportsAccess": user_details.advanced_reports_access,
    "accountState": user_details.account_state,
    "lastLoginTime": user_details.last_login_time,
    "previousLoginTime": user_details.previous_login_time,
    "lastPasswordChangeTime": user_details.last_password_change_time,
    "lastPasswordChangeNotificationTime":
      user_details.last_password_change_notification_time,
    "loginWrongPasswordCount": user_details.login_wrong_password_count,
    "isDeleted": user_details.is_deleted,
    "deletionTimeUnixTimeInMs": user_details.deletion_time_unix,
    "environments": user_details.environments,
    "id": user_details.id,
    "creationTimeUnixTimeInMs": user_details.creation_time_unix,
    "modificationTimeUnixTimeInMs": user_details.modification_time_unix,
    "permissionGroup": permission_group,
  }
