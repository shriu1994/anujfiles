"""Module used as a hub unifying different payload templates.
"""
from payloads import alerts
from payloads import integrations
from payloads import jobs
from payloads import playbook_actions
from payloads import reports
from payloads import views
from payloads import virustotalv3
from payloads import cases
from payloads import webhooks
from payloads import users

__all__ = (
    alerts,
    integrations,
    jobs,
    playbook_actions,
    reports,
    views,
    virustotalv3,
    cases,
    users
)
