import os


def siemplify_integration(instance_id: str) -> list[dict]:
  template = [
      {
          "integrationIdentifier": "Siemplify",
          "propertyName": "Recipients",
          "propertyDescription": None,
          "propertyDisplayName": "Monitors Mail Recipients",
          "propertyType": 2,
          "isMandatory": True,
          "value": "example@mail.com,example1@mail.com",
          "integrationInstance": instance_id,
          "environment": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0
      },
      {
          "integrationIdentifier": "Siemplify",
          "propertyName": "Elastic Server Address",
          "propertyDescription": None,
          "propertyDisplayName": "Elastic Server Address",
          "propertyType": 2,
          "isMandatory": True,
          "value": "localhost",
          "integrationInstance": instance_id,
          "environment": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0
      }
  ]
  return template


def integration_with_agent(
    int_inst_id: str,
    integration_name: str,
    agent_name: str,
    agent_id: str
) -> dict:
  """
  
  """
  template = [{

    "integrationIdentifier": integration_name,
		"propertyName": "RunRemotely",
		"propertyDescription": None,
		"propertyDisplayName": "Run Remotely",
		"propertyType": 0,
		"isMandatory": False,
		"value": "True",
		"integrationInstance": int_inst_id,
		"environment": None,
		"id": 0,
		"creationTimeUnixTimeInMs": 0,
		"modificationTimeUnixTimeInMs": 0
	}, {
		"integrationIdentifier": integration_name,
		"propertyName": "AgentIdentifier",
		"propertyDescription": None,
		"propertyDisplayName": "Agent",
		"propertyType": 9,
		"isMandatory": True,
		"value": agent_id,
		"integrationInstance": int_inst_id,
		"environment": None,
		"id": 0,
		"creationTimeUnixTimeInMs": 0,
		"modificationTimeUnixTimeInMs": 0,
		"options": [{
			"label": agent_name,
			"value": agent_id
		}]
  }]
  return template


def virustotal_integration_with_agent(
    int_inst_id: str,
    agent_name: str,
    agent_id: str
) -> dict:
  """Creates a template for VirusTotalV3 with configured agent.

  Args:
  integration_instance_id: integration instance id
  agent_name: agent name
  agent_identifier: agent id

  Returns:
    A dictionary for payload
  """

  template = [
      {
          "integrationIdentifier": "VirusTotalV3",
          "propertyName": "API Key",
          "propertyDescription": None,
          "propertyDisplayName": "API Key",
          "propertyType": 3,
          "isMandatory": True,
          "value": (
              os.environ['VT_API_KEY']
          ),
          "integrationInstance": int_inst_id,
          "environment": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0
      },
      {
          "integrationIdentifier": "VirusTotalV3",
          "propertyName": "Verify SSL",
          "propertyDescription": None,
          "propertyDisplayName": "Verify SSL",
          "propertyType": 0,
          "isMandatory": False,
          "value": "True",
          "integrationInstance": int_inst_id,
          "environment": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0
      },
      {
          "integrationIdentifier": "VirusTotalV3",
          "propertyName": "RunRemotely",
          "propertyDescription": None,
          "propertyDisplayName": "Run Remotely",
          "propertyType": 0,
          "isMandatory": False,
          "value": "True",
          "integrationInstance": int_inst_id,
          "environment": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0
      },
      {
          "integrationIdentifier": "VirusTotalV3",
          "propertyName": "AgentIdentifier",
          "propertyDescription": None,
          "propertyDisplayName": "Agent",
          "propertyType": 9,
          "isMandatory": True,
          "value": agent_id,
          "integrationInstance": int_inst_id,
          "environment": None,
          "id": 0,
          "creationTimeUnixTimeInMs": 0,
          "modificationTimeUnixTimeInMs": 0,
          "options": [
              {
                  "label": agent_name,
                  "value": agent_id
              }
          ]
      }
  ]

  return template


def emailv2_integration_with_agent(
    int_inst_id: str,
    agent_name: str,
    agent_id: str
) -> dict:
  """Creates a template for EmailV2 with configured agent.

  Args:
  integration_instance_id: integration instance id
  agent_name: agent name
  agent_identifier: agent id

  Returns:
    A dictionary for payload
  """

  template = [
            
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "Sender's address",
                "propertyDescription": None,
                "propertyDisplayName": "Sender's Address",
                "propertyType": 2,
                "isMandatory": True,
                "value": "siemplifyautomation@siemplify.co",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "Sender's Display Name",
                "propertyDescription": None,
                "propertyDisplayName": "Sender's Display Name",
                "propertyType": 2,
                "isMandatory": True,
                "value": "siemplifyautomationreports",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "SMTP Server Address",
                "propertyDescription": None,
                "propertyDisplayName": "SMTP Server Address",
                "propertyType": 5,
                "isMandatory": False,
                "value": "smtp.gmail.com",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "SMTP Port",
                "propertyDescription": None,
                "propertyDisplayName": "SMTP Port",
                "propertyType": 2,
                "isMandatory": False,
                "value": "465",
                "integrationInstance":int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "IMAP Server Address",
                "propertyDescription": None,
                "propertyDisplayName": "IMAP Server Address",
                "propertyType": 5,
                "isMandatory": False,
                "value": "imap.gmail.com",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "IMAP Port",
                "propertyDescription": None,
                "propertyDisplayName": "IMAP Port",
                "propertyType": 2,
                "isMandatory": False,
                "value": "993",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "Username",
                "propertyDescription": None,
                "propertyDisplayName": "Username",
                "propertyType": 2,
                "isMandatory": True,
                "value": "siemplifyautomation@siemplify.co",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "Password",
                "propertyDescription": None,
                "propertyDisplayName": "Password",
                "propertyType": 3,
                "isMandatory": True,
                "value": os.environ['AUTOMATION_EMAIL_PASSWORD'],
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "SMTP USE SSL",
                "propertyDescription": None,
                "propertyDisplayName": "SMTP - Use SSL",
                "propertyType": 0,
                "isMandatory": False,
                "value": "True",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "IMAP USE SSL",
                "propertyDescription": None,
                "propertyDisplayName": "IMAP - Use SSL",
                "propertyType": 0,
                "isMandatory": False,
                "value": "True",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "SMTP Use Authentication",
                "propertyDescription": None,
                "propertyDisplayName": "SMTP - Use Authentication",
                "propertyType": 0,
                "isMandatory": False,
                "value": "True",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "RunRemotely",
                "propertyDescription": None,
                "propertyDisplayName": "Run Remotely",
                "propertyType": 0,
                "isMandatory": False,
                "value": "True",
                "integrationInstance": int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0
                },
                {
                "integrationIdentifier": "EmailV2",
                "propertyName": "AgentIdentifier",
                "propertyDescription": None,
                "propertyDisplayName": "Agent",
                "propertyType": 9,
                "isMandatory": True,
                "value": agent_id,
                "integrationInstance":int_inst_id,
                "environment": None,
                "id": 0,
                "creationTimeUnixTimeInMs": 0,
                "modificationTimeUnixTimeInMs": 0,
                "options": [
                    {
                    "label": agent_name,
                    "value": agent_id
                    }
                ]
            }
  ]

  return template


def emailv2_connector_params() -> list:
  params = [
      {
          "name": "PythonProcessTimeout",
          "description": (
              "The timeout limit (in seconds) for the python process running current script"
          ),
          "type": 2,
          "value": "60",
          "isMandatory": True,
          "isAdvanced": True
      },
            {
            "name": "IMAP Server Address",
            "description": "e.g. imap.gmail.com",
            "type": 2,
            "value": "imap.gmail.com",
            "isMandatory": True,
            "isAdvanced": False
            },
            {
            "name": "IMAP Port",
            "description": "Imap port. e.g. 993",
            "type": 1,
            "value": "993",
            "isMandatory": True,
            "isAdvanced": False
            },
            {
            "name": "Username",
            "description": "IMAP Username",
            "type": 2,
            "value": "siemplifyautomation@siemplify.co",
            "isMandatory": True,
            "isAdvanced": False
            },
            {
            "name": "Password",
            "description": "IMAP Password",
            "type": 3,
            "value": os.environ['AUTOMATION_EMAIL_PASSWORD'],
            "isMandatory": True,
            "isAdvanced": False
            },
            {
            "name": "Folder to check for emails",
            "description": "Parameter can be used to specify email folder on the mailbox to search for the emails. Parameter should also accept comma separated list of folders to check the user response in multiple folders. Parameter is case sensitive.",
            "type": 2,
            "value": "Inbox",
            "isMandatory": True,
            "isAdvanced": True
            },
            {
            "name": "Server Time Zone",
            "description": "The timezone configured in the server, examples (1. UTC, 2. Asia/Jerusalem)",
            "type": 2,
            "value": "UTC",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Environment Field Name",
            "description": "If defined - connector will extract the environment from the specified event field. You can manipulate the field data using the Regex pattern field to extract specific string. In case the the extracted environment field and Siemplify environment name are not equal - you can map them in the map.json that is auto-generated on the first run, inside the <run-folder>.<run-folder> = C:\\Siemplify_Server\\Scripting\\SiemplifyConnectorExecution<Connector_Folder>",
            "type": 1,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Environment Regex Pattern",
            "description": "If defined - the connector will implement the specific RegEx pattern on the data from \"envirnment field\" to extract specific string. For example - extract domain from sender's address: \"(?<=@)(\\S+$)\"",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "IMAP USE SSL",
            "description": "Indicates whether to use ssl on connection or not.",
            "type": 0,
            "value": "true",
            "isMandatory": False,
            "isAdvanced": False
            },
            {
            "name": "Unread Emails Only",
            "description": "If checked, pull only unread mails",
            "type": 0,
            "value": "false",
            "isMandatory": False,
            "isAdvanced": False
            },
            {
            "name": "Mark Emails as Read",
            "description": "If checked, mark mails as read after pulling them",
            "type": 0,
            "value": "false",
            "isMandatory": False,
            "isAdvanced": False
            },
            {
            "name": "Attach Original EML",
            "description": "If checked, attach the original message as eml file.",
            "type": 0,
            "value": "false",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Offset Time In Days",
            "description": "Max number of days to fetch mails since. e.g. 3",
            "type": 2,
            "value": "5",
            "isMandatory": True,
            "isAdvanced": False
            },
            {
            "name": "Max Emails Per Cycle",
            "description": "Max count of mails to pull in one cycle",
            "type": 2,
            "value": "1",
            "isMandatory": True,
            "isAdvanced": False
            },
            {
            "name": "Proxy Server Address",
            "description": "The address of the proxy server to use.",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Proxy Username",
            "description": "The proxy username to authenticate with.",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Proxy Password",
            "description": "The proxy password to authenticate with.",
            "type": 3,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Additional headers to extract from emails",
            "description": "Specify additional headers to search and extract from processed emails. Found headers will be added to the email’s Siemplify event. Parameter accepts multiple values as a comma separated string, provided values can be set as an exact match or as a regex, for example, Received:, (Test).*",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Exclusion Subject Regex",
            "description": "Exclude emails for which subject matches specified. For example '([N|n]ewsletter)|([O|o]ut of office)' finds all emails containing 'Newsletter' or 'Out of office' keywords.",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Exclusion Body Regex",
            "description": "Exclude emails for which body matches specified regex. For example '([N|n]ewsletter)|([O|o]ut of office)' finds all emails containing 'Newsletter' or 'Out of office' keywords.",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Original Received Mail Prefix",
            "description": "Prefix to add to the extracted keys (to, from,subject,…) from the original email received in the monitored mailbox.",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Attached Mail File Prefix",
            "description": "Prefix to add to the extracted keys (to, from,subject,…) from the attached mail file received with the email in the monitored mailbox.",
            "type": 2,
            "value": "",
            "isMandatory": False,
            "isAdvanced": True
            },
            {
            "name": "Create a Separate Siemplify Alert per Attached Mail File?",
            "description": "if enabled, connector will create multiple alerts, 1 alert per attached mail file. This behavior can be useful when processing email with multiple mail files attached and Siemplify event mapping set to create entities from attached mail file.",
            "type": 0,
            "value": "false",
            "isMandatory": False,
            "isAdvanced": True
            }
  ]
  return params
