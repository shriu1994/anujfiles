import os


def configure_with_agent(
    int_inst_id: str,
    agent_name: str,
    agent_id: str
) -> dict:
  """Creates a template for VirusTotalV3 with configured agent.

  Args:
    integration_instance_id: integration instance id,
    agent_name: agent name
    agent_identifier: agent id

  Returns:
    A dictionary with settings to install virustotalv3 with agent
  """

  return [{
      "integrationIdentifier": "VirusTotalV3",
      "propertyName": "API Key",
      "propertyDescription": None,
      "propertyDisplayName": "API Key",
      "propertyType": 3,
      "isMandatory": True,
      "value": (
          os.environ['VT_API_KEY']
      ),
      "integrationInstance": int_inst_id,
      "environment": None,
      "id": 0,
      "creationTimeUnixTimeInMs": 0,
      "modificationTimeUnixTimeInMs": 0
      },
          {
              "integrationIdentifier": "VirusTotalV3",
              "propertyName": "Verify SSL",
              "propertyDescription": None,
              "propertyDisplayName": "Verify SSL",
              "propertyType": 0,
              "isMandatory": False,
              "value": "True",
              "integrationInstance": int_inst_id,
              "environment": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0
          },
          {
              "integrationIdentifier": "VirusTotalV3",
              "propertyName": "RunRemotely",
              "propertyDescription": None,
              "propertyDisplayName": "Run Remotely",
              "propertyType": 0,
              "isMandatory": False,
              "value": "True",
              "integrationInstance": int_inst_id,
              "environment": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0
          },
          {
              "integrationIdentifier": "VirusTotalV3",
              "propertyName": "AgentIdentifier",
              "propertyDescription": None,
              "propertyDisplayName": "Agent",
              "propertyType": 9,
              "isMandatory": True,
              "value": agent_id,
              "integrationInstance": int_inst_id,
              "environment": None,
              "id": 0,
              "creationTimeUnixTimeInMs": 0,
              "modificationTimeUnixTimeInMs": 0,
              "options": [
                  {
                      "label": agent_name,
                      "value": agent_id
                  }
                  ]
          }
          ]
