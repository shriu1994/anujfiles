def data_exfiltration_case(environment: str):
    """Returns a JSON object."""
    data = {
      "cases": [
        {
          "creatorUserId": None,
          "events": [
            {
              "_fields": {
                "baseEventIds": "[]",
                "parentEventId": -1,
                "deviceEventClassId": "Data Exfiltration",
                "deviceProduct": "DLP_Product"
              },
              "_rawDataFields": {
                "applicationProtocol": "TCP",
                "categoryOutcome": "blocked",
                "destinationAddress": "10.0.0.28",
                "destinationHostName": "lab@siemplify.local",
                "destinationPort": "770",
                "destinationProcessName": "MrlCS.sob",
                "destinationUserName": "XWzNr1l@gmail.com",
                "deviceAddress": "172.21.135.124",
                "deviceEventClassId": "Data Exfiltration",
                "deviceHostName": "ckIYC2",
                "field_24": "B0:E7:DF:6C:EF:71",
                "deviceProduct": "DLP_Product",
                "usb": "USB_DEVICE_1",
                "deviceVendor": "Vendor",
                "eventId": "0aa16009-5bb4-41a3-91ed-81347442ca29",
                "managerReceiptTime": "1522059443000",
                "message": "Data Exfiltration",
                "name": "Data Exfiltration",
                "sourceUserName": "User41@siemplify",
                "severity": "8",
                "sourceAddress": "10.0.0.51",
                "cs1": "VID_078654",
                "sourceHostName": "AppTransaction.db.siemplify",
                "startTime": "1522059443000",
                "endTime": "1522059443000",
                "sourcetype": "Data Exfiltration"
              },
              "environment": None,
              "sourceSystemName": None,
              "extensions": []
            }
          ],
          "environment": environment,
          "sourceSystemName": "Arcsight",
          "ticketId": "b32eb10c-cab9-4a71-a08b-797151e82193",
          "description": "Data Exfiltration",
          "displayId": "b32eb10c-cab9-4a71-a08b-797151e82193",
          "reason": None,
          "name": "Data Exfiltration",
          "deviceVendor": "DLP",
          "deviceProduct": "DLP_Product",
          "startTime": 1522059443000,
          "endTime": 1522059443000,
          "type": 0,
          "priority": -1,
          "ruleGenerator": "Data Exfiltration",
          "sourceGroupingIdentifier": None,
          "playbookTriggerKeywords": [],
          "extensions": [],
          "attachments": None,
          "isTrimmed": False,
          "dataType": 1,
          "sourceType": 1,
          "sourceSystemUrl": None,
          "sourceRuleIdentifier": None,
          "siemAlertId": None
        }
      ],
      "type": 0,
      "connectorIdentifier": None,
      "debugOutput": None
    }
    return data