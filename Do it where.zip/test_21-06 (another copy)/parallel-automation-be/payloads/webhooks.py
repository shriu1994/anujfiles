import random


def webhooks_payload(name: str,
                     description: str,
                     env: str,
                     identifier: str) -> dict:

  """Creates a template for Webhook mapping.

  Args:
    name:  name of the webhook
    description:  description of the test
    env:  name of the environment for the webhook
    identifier:  identifier of the webhook

  Returns:
    A dictionary with Webhook configurations
  """
  template = {'name': name,
              'description': description,
              'defaultEnvironment': env,
              'identifier': identifier,
              'webhookMappingRules':
              {'webhookInstanceIdentifier': identifier,
               'webhookMappingsFields':
               {'ticketId':
                {'mandatory': True,
                 'mapping': '[webhook_json| \"TicketId\"]',
                 'name': 'TicketId'},
                'sourceSystemName':
                {'mandatory': True,
                 'mapping': '[webhook_json| \"SourceSystemName\"]',
                 'name': 'SourceSystemName'},
                'name':
                {'mandatory': True,
                 'mapping': '[webhook_json| \"Name\"]',
                 'name': 'Name'},
                'deviceVendor':
                {'mandatory': True,
                 'mapping': '[webhook_json| \"DeviceVendor\"]',
                 'name': 'DeviceVendor'},
                'ruleGenerator':
                {'mandatory': True,
                 'mapping': '[webhook_json| \"RuleGenerator\"]',
                 'name': 'RuleGenerator'},
                'startTime':
                {'mandatory': True,
                 'mapping': '[webhook_json| \"StartTime\"]',
                 'name': 'StartTime'},
                'environment':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'Environment'},
                'description':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'Description'},
                'displayId':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'DisplayId'},
                'reason':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'Reason'},
                'deviceProduct':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'DeviceProduct'},
                'endTime':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'EndTime'},
                'priority':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'Priority'},
                'eventsList':
                {'mandatory': False,
                 'mapping': '[webhook_json| \"EventsList\"]',
                 'name': 'EventsList'},
                'eventProduct':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'EventProduct'},
                'eventName':
                {'mandatory': False,
                 'mapping': None,
                 'name': 'EventName'}}},
              'isEnabled': True,
              }

  return template


def sample_alert():
  """Creates a template for Webhook mapping.
  Returns:
    A dictionary with Webhook configurations
  """
  template = {
      'SourceSystemName': 'Phishmonger',
      'Name': 'Phishmonger Alert',
      'DeviceVendor': 'CI',
      'RuleGenerator': 'Phishmonger',
      'StartTime': '1670429181',
      'EventsList':
          [{'event_name': 'Phishmonger',
            'SourceType': 'Webhook',
            'customer_name': 'CI-Test',
            'email_link': 'fakelink.sometestsite.com',
            'email_from': 'viva-noreply@microsoft.com',
            'email_to': 'test@sometestsite.com',
            'email_cc': None,
            'email_reporter': 'test@sometestsite.com',
            'email_timestamp': '1670429181',
            'email_subject': 'Welcome to your digest',
            'email_contents_text': '',
            'email_contents_html': '',
            'email_attachment_filename': None,
            'email_headers':
            '{"From": "Microsoft Viva <viva-noreply@microsoft.com>", '
            '"To": "Justin Rauvola <test@sometestsite.com>", '
            '"Subject": "Welcome to your digest", "Thread-Topic":'
            '"Welcome to your digest", '
            '"Thread-Index": "AQHZClXYTgZR5pyQ2U+YlflJErZz5g==", '
            '"X-MS-Exchange-MessageSentRepresentingType": "1", '
            '"Date": "Wed, 7 Dec 2022 16:06:21 +0000", '
            '"Message-ID": "\\r\\n\\t<SJ0PR13MB567549FA57F8F05C78950BD4FF1"'
            '"A9@SJ0PR13MB5675.namprd13.prod.outlook.com>", '
            '"Content-Language": "en-US", '
            '"X-MS-Has-Attach": "yes", '
            '"X-MS-Exchange-Organization-SCL": "-1", '
            '"X-MS-TNEF-Correlator": "", '
            '"X-MS-Exchange-Organization-RecordReviewCfmType": "0", '
            '"Content-Type": "multipart/related;\\r\\n\\tboundary=\\"'
            '"_017_SJ0PR13MB567549FA57F8F05C78950BD4FF1A9SJ0PR13MB5675namp_\\";\\r\\n\\ttype=\\"multipart/alternative\\"", '
            '"MIME-Version": "1.0"}',
            'email_attachment_hash': None,
            'alert_id': '0d3912a5404543d3bebd34abdb5b72ef_123',
            'email_api_link': 'sometestsite.com',
            'sensorID': 'CI-Test-virtual-collector'}]
      }

  ran_ticket = random.randint(100000, 999999)
  template['TicketId'] = '0d3912a5404543d3bebd34abdb5b72' + str(ran_ticket)

  return template