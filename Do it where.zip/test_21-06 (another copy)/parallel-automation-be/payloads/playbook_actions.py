"""A hub for templates for creating playbook actions.
"""
from typing import Optional
from siemplify_utils.playbooks import add_nested_block_into_playbook
from siemplify_utils.playbooks import create_action
from siemplify_utils.playbooks import create_condition_flow
from siemplify_utils.playbooks import create_entity_selection_flow
from siemplify_utils.playbooks import create_multichoise_flow
from siemplify_utils.playbooks import create_nested_block
from siemplify_utils.playbooks import create_previous_flow


def add_entity_insight(
    text: str = "Test!",
    selected_scope: str = "All entities",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: str = None,
    assigned_users: Optional[str] = None,
) -> dict:
  """Creates a payload for playbook action "Add entity insight".

  Args:
    text: entity insight text (Defaults to "Test!")
    selected_scope: cope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Add Entity Insight",
      description="Add an insight configurable message to each targeted entity",
      script_value={"Message": text},
      selected_scope=selected_scope,
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
      assigned_users=assigned_users
  )


def add_case_comment(
    comment: str = "Test!",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
    pending_timeout: Optional[str] = None,
    assigned_users: Optional[str] = None
) -> dict:
  """Creates a payload for playbook action "Add case comment".

  Args:
    comment: case comment text (Defaults to "Test!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)
    integration_id: specify if you use non-default instance
    pending_timeout: specify pending action timeout in seconds,
    NOTE min value for it is 300

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Case Comment",
      description=(
          "Add a comment to the case the current alert has been grouped to"
      ),
      script_value={"Comment": comment},
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
      pending_timeout=pending_timeout,
      assigned_users=assigned_users
  )


def custom_test_action() -> dict:
  """Creates a payload for playbook action "Test".

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Test",
      description="Test description",
      script_value={},
  )


def add_case_tag(
    tag: str = "Test",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
    pending_timeout: Optional[str] = None,
) -> dict:
  """Creates a payload for playbook action "Add case comment".

  Args:
    tag: case tag (Defaults to "Test!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)
    integration_id: specify if you use non-default instance

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Case Tag",
      description=(
          "Add given tag to the case the current alert is grouped to"
      ),
      script_value={"tag": tag},
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
      pending_timeout=pending_timeout
  )


def add_general_insight(
    title: str = "Test Title",
    message: str = "Test Message",
    triggered_by: str = "",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
) -> dict:
  """Creates a payload for playbook action "Add case comment".

  Args:
    title: title of the insight
    message: message in the insight
    triggered_by: triggered by field in the insight
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)
    integration_id: specify if you use non-default instance

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Add General Insight",
      description=(
          "Add a general insight configurable message to the case"
      ),
      script_value={
          "Title": title,
          "Message": message,
          "Triggered By": triggered_by,
      },
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
  )


def change_alert_priority(
    priority: str = "Critical",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
) -> dict:
  """Creates a payload for playbook action "Change alert priority".

  Args:
    priority: case priority (Defaults to "Critical!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)
    integration_id: specify if you use non-default instance

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Change Alert Priority",
      description=(
          "Automatically change the alert priority to the given input. "
          "Note: This action is compatible only with Siemplify "
          "version 5.6 and higher."
      ),
      script_value={"Alert Priority": priority},
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
  )


def change_case_stage(
    stage: str = "Incident",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
) -> dict:
  """Creates a payload for playbook action "Change case stage".

  Args:
    stage: case stage (Defaults to "Incident!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)
    integration_id: specify if you use non-default instance

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Change Case Stage",
      description=f"Change case stage to {stage}",
      script_value={"Stage": stage},
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
  )


def mark_as_important(
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
) -> dict:
  """Creates a payload for playbook action "Mark as important".

  Args:
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)
    integration_id: specify if you use non-default instance

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Mark As Important",
      description="Mark case as important",
      script_value={},
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
  )


def update_case_description(
    description: str = "New description",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
    integration_id: Optional[str] = None,
) -> dict:
  """Creates a payload for playbook action "Update case description".

  Args:
    description: new case description (Defaults to "Incident!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)
    integration_id: specify if you use non-default instance

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="Siemplify",
      action_name="Update Case Description",
      description="Ability to set Case Description from playbooks.",
      script_value={"Description": description},
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
      integration_id=integration_id,
  )


def add_csv_ping_action(
    selected_scope: str = "All entities",
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
) -> dict:
  """Creates a payload for playbook action "CSV_Ping".

  Args:
    text: entity insight text (Defaults to "Test!")
    selected_scope: cope of the action (Defaults to "All entities")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_action(
      integration_name="CSV",
      action_name="Ping",
      description="",
      script_value={},
      selected_scope=selected_scope,
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
  )


def add_previous_condition_flow(
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
) -> dict:
  """Creates a payload for previous flow condition.

  Args:
    comment: case comment text (Defaults to "Test!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_previous_flow(
      integration_name="Flow",
      action_name="IfElse",
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
  )


def add_condition_flow(
) -> dict:
  """Creates a payload for flow condition.

  Args:
    comment: case comment text (Defaults to "Test!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_condition_flow(integration_name="Flow")


def add_multichoise_flow(
) -> dict:
  """Creates a payload for multichoise flow condition.

  Args:
    comment: case comment text (Defaults to "Test!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_multichoise_flow()


def create_nested_block_output_step(
) -> dict:
  """Creates a payload adding a nested block.

  Args:
    comment: case comment text (Defaults to "Test!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_nested_block(
      action_name="OutputAction",
      integration_name="Flow")


def create_nested_block_step(
    nested_name: str,
    nested_workflow_id: str
) -> dict:
  """Creates a payload for nested(block) flow.

  Args:
    comment: case comment text (Defaults to "Test!")
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return add_nested_block_into_playbook(
      nested_name=nested_name,
      nested_workflow_id=nested_workflow_id)


def add_entity_selection(
    is_automatic: bool = True,
    is_skippable: bool = True,
    skip_on_fail: bool = False,
) -> dict:
  """Creates a payload for playbook action "Add entity selection flow".

  Args:
    is_automatic: is the action automatic (Defaults to True)
    is_skippable: is the action skippable (Defaults to True)
    skip_on_fail: should the action be skipped if it failed (Defaults to False)

  Returns:
    A dict with payload to create an action for playbook
  """
  return create_entity_selection_flow(
      is_automatic=is_automatic,
      is_skippable=is_skippable,
      skip_on_fail=skip_on_fail,
  )

