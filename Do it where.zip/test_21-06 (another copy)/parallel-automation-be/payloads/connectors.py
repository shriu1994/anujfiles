import os


def generate_custom_connector_param(
    is_mandtory: bool = False,
    is_advanced: bool = False,
    param_name: str = "parameter",
    description: str = "",
    value: str = "Parameter Value",
    type: int = 2,
    mode: int = 1,
    optional_value: str = None
) -> dict:
  """Paramter template required for additional
  parameter for custom connector.
  Args:
    param_name: name of paramter
    value: value of the paramter
    description: description of the parameter
    optional_value: defaults to Null
    is_mandatory: True if the parameter is mandatory.
    is_Advanced: False as default.
    type: defaults to 2
    mode: defaults to 1

  Returns:
    An dictionary representing a paramter.
  """
  paramater = {
    "isMandatory": is_mandtory,
    "isAdvanced": is_advanced,
    "name": param_name,
    "defaultValue": value,
    "type": type,
    "description": description,
    "mode": mode,
    "optionalValues": optional_value,
  }
  return  paramater

def generate_param_for_connector_instance(
    is_mandtory: bool = False,
    is_advanced: bool = False,
    param_name: str = "parameter",
    description: str = "",
    value: str = "Parameter Value",
    type: int = 2,
) -> dict:
  """Paramter template required for additional
  parameter for connector instance.

  Args:
    param_name: name of paramter
    value: value of the paramter
    description: description of the parameter
    integration: To create in (defaults to "Siemplify")
    is_mandatory: True if the parameter is mandatory.
    is_Advanced: False as default.
    type: defaults to 2

  Returns:
    An dictionary representing a paramter.
  """
  paramater = {
    "isMandatory": is_mandtory,
    "isAdvanced": is_advanced,
    "name": param_name,
    "value": value,
    "type": type,
    "description": description,
  }
  return  paramater


def default_params_for_custom_connnector(
    product_field_name: str = "Test_field",
    event_field_name: str = "Test_field",
    polling_timeout: int = 30,
) -> list[dict]:
  """Paramter template required for default parameter.
  Args:
    product_filed_name: A string value for the field.
    event_field_name: A string value for the field.
    polling_timeout: Integer value for the field.

  Returns:
    An list of dictionary representing default paramter.
  """
  template = [
      {
          "isMandatory": True,
          "isAdvanced": False,
          "name": "Product Field Name",
          "defaultValue": product_field_name,
          "type": 2,
          "description": "The field name used to determine the device product",
          "mode": 0,
          "optionalValues": None,
      },
      {
          "isMandatory": True,
          "isAdvanced": False,
          "name": "Event Field Name",
          "defaultValue": event_field_name,
          "type": 2,
          "description": "Used to determine the event name (sub-type)",
          "mode": 0,
          "optionalValues": None,
      },
      {
          "isMandatory": True,
          "isAdvanced": False,
          "name": "Polling Timeout",
          "defaultValue": str(polling_timeout),
          "type": 17,
          "description": "Timeout (seconds) for python process running script",
          "mode": 0,
          "optionalValues": None,
      },
  ]
  return template