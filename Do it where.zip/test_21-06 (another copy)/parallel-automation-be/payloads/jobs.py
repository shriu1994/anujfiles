"""Functions that generate JSON payloads for API calls in "jobs" module.
"""
import json
from typing import Optional


def add_job(
    item_id: int,
    integration_name: str,
    job_name: str,
    interval: int = 60,
    creator: Optional[str] = None,
) -> json:
  """Template for creating an instance of a running job.

  Args:
    item_id: id of the ide item
    integration_name: name of the integration for this job
    job_name: name of the job
    interval: run interval in seconds
    creator: creator of the job

  Returns:
    A json object with data about the created job
  """
  template = {
      "uniqueIdentifier": "00000000-0000-0000-0000-000000000000",
      "id": 0,
      "jobDefinitionId": item_id,
      "name": job_name,
      "integration": integration_name,
      "script": "from SiemplifyJob import SiemplifyJob\nimport csv\nimport random\nimport string\nimport os\n\n\nINTEGRATION_NAME = \"CUSTOM_INTEGRATION\"\nSCRIPT_NAME = \"JobTemplate\"\n\n\ndef main():\n    siemplify = SiemplifyJob()\n\n# path \npath = '/tmp/automation'\n    \n# Create the directory \n# '/home / User / Documents'\ntry: \n    os.mkdir(path) \nexcept OSError as error: \n    print(error)  \nauto_path = \"/tmp/automation\"\nos.listdir(auto_path)\n\n\nfor fname in os.listdir(auto_path):\n    if fname.endswith('.csv'):\n        # do stuff on the file\n        break\nelse:\n        file_name = ''.join(random.choice(string.ascii_lowercase) for i in range(16))\n        file = open('/tmp/automation/{}.csv'.format(file_name), 'w+')\n        writer = csv.writer(file)\n        writer.writerow([\"SN\", \"Name\", \"Contribution\"])\n        writer.writerow([1, \"Guido van Rossum\", \"Python Programming\"])\n    # do stuff if a file .True doesn't exist.\n    \n\nif __name__ == \"__main__\":\n    main()",
      "creator": creator,
      "description": "Test description",
      "isEnabled": True,
      "isCustom": True,
      "version": 2,
      "parameters": [
          {
              "id": 0,
              "isMandatory": True,
              "name": "Output Name",
              "type": 2,
              "value": "Test!"
          },
          {
              "id": 0,
              "isMandatory": True,
              "name": "Polling Timeout",
              "type": 2,
              "value": "10"
          },
          {
              "id": 0,
              "isMandatory": False,
              "name": "Default Return Value",
              "type": 2,
              "value": ""
          },
          {
              "id": 0,
              "isMandatory": False,
              "name": "Include JSON Result",
              "type": 0,
              "value": "false"
          }
      ],
      "runIntervalInSeconds": interval,
      "creationTime": "2022-11-29T08:40:15.013Z",
      "lastModificationTime": "2022-11-28T20:46:12.462Z",
      "isSystemJob": False
  }

  return template
