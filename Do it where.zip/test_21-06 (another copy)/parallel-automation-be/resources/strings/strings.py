"""This file is used to import long strings from the file in the same folder.
"""
import json
import os
from dotenv import load_dotenv

PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "strings"
)

if os.path.exists(PATH):
  load_dotenv(PATH)

# Customizing functions
def customize_default_conenctor_script(
    num_of_alerts= "randrange(RANDOM_ALERT_COUNT_MAX+1)",
    alert_name= "\"Random Alert Name \" + str(uuid.uuid4())",
    alert_vendor= "VENDOR",
    alert_product= "PRODUCT",
    alert_env= "siemplify.context.connector_info.environment",
    events_per_alert= "randrange(RANDOM_EVENT_COUNT_PER_ALERT_MAX+1)",
    event_name= "\"RandomEventName \" + str(uuid.uuid4())",
    event_source_host_name= "\"DummyHostSrc\"",
    event_dest_host_name= "\"DummyHostDest\"",
    event_source_address= "\"10.0.0.\"+str(randrange(254))",
    event_dest_address= "\"55.44.33.\"+str(randrange(254))",
    event_source_username= "",
    event_dest_username= ""
) -> str:
  """
  customizes the default connector script. Every value must be given as a string.
  If it's a string itself - the inner " should be escaped. Like: "\"Dummy Name\""

  Args:
    num_of_alerts: number of alerts to be created with each run
    alert_name: name of alerts to be created
    alert_vendor: vendor name for the created alerts
    alert_product: product name fro the created alerts
    alert_env: environment for the alerts
    events_per_alert: number of events to be created for each alert
    event_name: name of each event
    event_source_host_name: event source hostname
    event_dest_host_name: event destination hostname
    event_source_address: event source address
    event_dest_address: event destination address
    event_source_username: event source username. Defaults to "" (-> no such event field)
    event_dest_username: event destination username. Defaults to "" (-> no such event field)

  Returns:
    the script with the incoroporated given changes. If none are given - 
    the default connector script
  """
  default_script = os.getenv("DEFAULT_CUSTOM_CONNECTOR_SCRIPT", "")

  customized_script = default_script.format(
    num_of_alerts = num_of_alerts,
    alert_name = alert_name,
    alert_vendor = alert_vendor,
    alert_product = alert_product,
    alert_env = alert_env,
    events_per_alert = events_per_alert,
    event_name = event_name,
    event_source_host_name = event_source_host_name,
    event_dest_host_name = event_dest_host_name,
    event_source_address = event_source_address,
    event_dest_address = event_dest_address,
    event_source_username_comment = "" if event_source_username else "# ",
    event_source_username = event_source_username,
    event_dest_username_comment = "" if event_dest_username else "# ",
    event_dest_username = event_dest_username
  )

  return customized_script


# Scripts
DEFAULT_CUSTOM_ACTION_SCRIPT = os.getenv("DEFAULT_CUSTOM_ACTION_SCRIPT", "")
DEFAULT_CUSTOM_JOB_SCRIPT = os.getenv("DEFAULT_CUSTOM_JOB_SCRIPT", "")
DEFAULT_RUNNING_JOB_SCRIPT = os.getenv("DEFAULT_RUNNING_JOB_SCRIPT", "")
TEST_ALIAS_CUSTOM_CONNECTOR_SCRIPT = os.getenv(
  "TEST_ALIAS_CUSTOM_CONNECTOR_SCRIPT",
  ""
)
# Connectors
DEFAULT_CUSTOM_CONNECTOR_PARAMS = [
    json.loads(os.getenv("DEFAULT_CUSTOM_CONNECTOR_PARAMS", ""))
]
USE_CSV_CONNECTOR_PARAMS = json.loads(os.getenv("USE_CSV_CONNECTOR_PARAMS", ""))
DEFAULT_CUSTOM_CONNECTOR_SCRIPT = customize_default_conenctor_script()

# CSV
CREATE_CSV_JOB = os.getenv("CREATE_CSV_JOB", "")

# TABLE
TABLE = os.getenv("TABLE", "")