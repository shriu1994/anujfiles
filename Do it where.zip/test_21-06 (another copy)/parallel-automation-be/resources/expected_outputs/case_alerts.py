alert_events = {
  "fields": [
    {
      "order": 0,
      "groupName": "Highlighted Fields",
      "isIntegration": False,
      "isHighlight": True,
      "items": [
        {
          "originalName": "categoryOutcome",
          "name": "CategoryOutcome",
          "value": "blocked"
        },
        {
          "originalName": "destinationAddress",
          "name": "Destination Address",
          "value": "10.0.0.28"
        },
        {
          "originalName": "destinationHostName",
          "name": "Destination Host Name",
          "value": "lab@siemplify.local"
        },
        {
          "originalName": "destinationPort",
          "name": "DestinationPort",
          "value": "770"
        },
        {
          "originalName": "destinationUserName",
          "name": "Destination User Name",
          "value": "XWzNr1l@gmail.com"
        },
        {
          "originalName": "deviceProduct",
          "name": "DeviceProduct",
          "value": "DLP_Product"
        },
        {
          "originalName": "usb",
          "name": "USB",
          "value": "USB_DEVICE_1"
        },
        {
          "originalName": "deviceVendor",
          "name": "DeviceVendor",
          "value": "Vendor"
        },
        {
          "originalName": "message",
          "name": "Message",
          "value": "Data Exfiltration"
        },
        {
          "originalName": "name",
          "name": "Name",
          "value": "Data Exfiltration"
        },
        {
          "originalName": "sourceUserName",
          "name": "Source User Name",
          "value": "User41@siemplify"
        },
        {
          "originalName": "sourceAddress",
          "name": "Source Address",
          "value": "10.0.0.51"
        },
        {
          "originalName": "sourceHostName",
          "name": "Source Host Name",
          "value": "AppTransaction.db.siemplify"
        },
        {
          "originalName": "startTime",
          "name": "Start Time",
          "value": "1669026908197"
        },
        {
          "originalName": "endTime",
          "name": "End Time",
          "value": "1669026908197"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Application",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "applicationProtocol",
          "name": "Application Protocol",
          "value": "TCP"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "System",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "categoryOutcome",
          "name": "CategoryOutcome",
          "value": "blocked"
        },
        {
          "originalName": "destinationPort",
          "name": "DestinationPort",
          "value": "770"
        },
        {
          "originalName": "deviceProduct",
          "name": "DeviceProduct",
          "value": "DLP_Product"
        },
        {
          "originalName": "deviceVendor",
          "name": "DeviceVendor",
          "value": "Vendor"
        },
        {
          "originalName": "name",
          "name": "Name",
          "value": "Data Exfiltration"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Destination",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "destinationAddress",
          "name": "Destination Address",
          "value": "10.0.0.28"
        },
        {
          "originalName": "destinationHostName",
          "name": "Destination Host Name",
          "value": "lab@siemplify.local"
        },
        {
          "originalName": "destinationProcessName",
          "name": "Destination Process Name",
          "value": "MrlCS.sob"
        },
        {
          "originalName": "destinationUserName",
          "name": "Destination User Name",
          "value": "XWzNr1l@gmail.com"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Device",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "deviceAddress",
          "name": "Device Address",
          "value": "172.21.135.124"
        },
        {
          "originalName": "deviceHostName",
          "name": "Device Host Name",
          "value": "ckIYC2"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Default",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "Field_24",
          "name": "Field_24",
          "value": "B0:E7:DF:6C:EF:71"
        },
        {
          "originalName": "cs1",
          "name": "cs1",
          "value": "VID_078654"
        },
        {
          "originalName": "sourcetype",
          "name": "sourcetype",
          "value": "Data Exfiltration"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Event",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "usb",
          "name": "USB",
          "value": "USB_DEVICE_1"
        },
        {
          "originalName": "message",
          "name": "Message",
          "value": "Data Exfiltration"
        },
        {
          "originalName": "deviceEventClassId",
          "name": "Device Event Class ID",
          "value": "Data Exfiltration"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Source",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "sourceUserName",
          "name": "Source User Name",
          "value": "User41@siemplify"
        },
        {
          "originalName": "sourceAddress",
          "name": "Source Address",
          "value": "10.0.0.51"
        },
        {
          "originalName": "sourceHostName",
          "name": "Source Host Name",
          "value": "AppTransaction.db.siemplify"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Threat",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "severity",
          "name": "Severity",
          "value": "8"
        }
      ]
    },
    {
      "order": 0,
      "groupName": "Time",
      "isIntegration": False,
      "isHighlight": False,
      "items": [
        {
          "originalName": "startTime",
          "name": "Start Time",
          "value": "1669026908197"
        },
        {
          "originalName": "endTime",
          "name": "End Time",
          "value": "1669026908197"
        }
      ]
    }
  ],
  "identifier": "c83e66cf-e74a-4275-8e8d-cb42d8283c9a",
  "caseId": 3868,
  "alertIdentifier": "DATA EXFILTRATION_8D8742D2-1BD0-4341-93B1-FC0963769F1E",
  "name": "Data Exfiltration",
  "product": "DLP_Product",
  "port": "770",
  "sourceSystemName": "Arcsight",
  "outcome": "blocked",
  "time": 1669026908197,
  "type": "Data Exfiltration",
  "artifactEntities": [
    "USB_DEVICE_1"
  ]
}
