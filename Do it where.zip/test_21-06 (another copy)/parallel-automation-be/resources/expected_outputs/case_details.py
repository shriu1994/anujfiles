address_entity = {
  "caseId": 3464,
  "identifier": "10.0.0.28",
  "entityType": "ADDRESS",
  "isInternal": False,
  "isSuspicious": False,
  "isArtifact": False,
  "isEnriched": False,
  "isVulnerable": False,
  "isPivot": False,
  "environment": "Default Environment",
  "fields": [
    {
      "isHighlight": False,
      "groupName": "Default",
      "hideOptions": False,
      "items": [
        {
          "originalName": "Network_Priority",
          "name": "Network_Priority",
          "value": "0"
        },
        {
          "originalName": "IsSuspicious",
          "name": "IsSuspicious",
          "value": "False"
        },
        {
          "originalName": "IsAttacker",
          "name": "IsAttacker",
          "value": "False"
        },
        {
          "originalName": "Environment",
          "name": "Environment",
          "value": "Default Environment"
        },
        {
          "originalName": "Alert_Id",
          "name": "Alert_Id",
          "value": "DATA EXFILTRATION_FE53591D-BFD6-4B8E-838F-F6914BAF22B6"
        },
        {
          "originalName": "Type",
          "name": "Type",
          "value": "ADDRESS"
        },
        {
          "originalName": "IsArtifact",
          "name": "IsArtifact",
          "value": "False"
        },
        {
          "originalName": "IsEnriched",
          "name": "IsEnriched",
          "value": "False"
        },
        {
          "originalName": "IsTestCase",
          "name": "IsTestCase",
          "value": "False"
        },
        {
          "originalName": "IsVulnerable",
          "name": "IsVulnerable",
          "value": "False"
        },
        {
          "originalName": "IsInternalAsset",
          "name": "IsInternalAsset",
          "value": "False"
        },
        {
          "originalName": "OriginalIdentifier",
          "name": "OriginalIdentifier",
          "value": "10.0.0.28"
        },
        {
          "originalName": "IsManuallyCreated",
          "name": "IsManuallyCreated",
          "value": "False"
        }
      ]
    },
    {
      "isHighlight": False,
      "groupName": "Entity",
      "hideOptions": False,
      "items": [
        {
          "originalName": "IsPivot",
          "name": "Is Pivot",
          "value": "False"
        }
      ]
    }
  ],
  "isManuallyCreated": False,
  "sourceUrl": None
}

username_entity = {
  "caseId": 3463,
  "identifier": "XWZNR1L@GMAIL.COM",
  "entityType": "USERUNIQNAME",
  "isInternal": False,
  "isSuspicious": False,
  "isArtifact": False,
  "isEnriched": False,
  "isVulnerable": False,
  "isPivot": False,
  "environment": "Default Environment",
  "fields": [
    {
      "isHighlight": False,
      "groupName": "Default",
      "hideOptions": False,
      "items": [
        {
          "originalName": "Network_Priority",
          "name": "Network_Priority",
          "value": "0"
        },
        {
          "originalName": "IsSuspicious",
          "name": "IsSuspicious",
          "value": "False"
        },
        {
          "originalName": "IsAttacker",
          "name": "IsAttacker",
          "value": "False"
        },
        {
          "originalName": "Environment",
          "name": "Environment",
          "value": "Default Environment"
        },
        {
          "originalName": "Alert_Id",
          "name": "Alert_Id",
          "value": "DATA EXFILTRATION_76BCD5F6-0B55-4536-AD35-4993014B6477"
        },
        {
          "originalName": "Type",
          "name": "Type",
          "value": "USERUNIQNAME"
        },
        {
          "originalName": "IsArtifact",
          "name": "IsArtifact",
          "value": "False"
        },
        {
          "originalName": "IsEnriched",
          "name": "IsEnriched",
          "value": "False"
        },
        {
          "originalName": "IsTestCase",
          "name": "IsTestCase",
          "value": "False"
        },
        {
          "originalName": "IsVulnerable",
          "name": "IsVulnerable",
          "value": "False"
        },
        {
          "originalName": "IsInternalAsset",
          "name": "IsInternalAsset",
          "value": "False"
        },
        {
          "originalName": "OriginalIdentifier",
          "name": "OriginalIdentifier",
          "value": "XWZNR1L@GMAIL.COM"
        },
        {
          "originalName": "IsManuallyCreated",
          "name": "IsManuallyCreated",
          "value": "False"
        },
        {
          "originalName": "IsFromLdapString",
          "name": "IsFromLdapString",
          "value": "False"
        }
      ]
    },
    {
      "isHighlight": False,
      "groupName": "Entity",
      "hideOptions": False,
      "items": [
        {
          "originalName": "IsPivot",
          "name": "Is Pivot",
          "value": "False"
        }
      ]
    }
  ],
  "isManuallyCreated": False,
  "sourceUrl": None
}
