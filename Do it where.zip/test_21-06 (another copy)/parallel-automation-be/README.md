# Introduction 
This is an automated testing framework for Siemplify.
# Build
- Install python3.9 (You can use 3.10+, but make sure you don't use the syntax that doesn't exist in 3.9)
- Install venv for python with ```python3 -m pip install virtualenv```
- Create a virtual environment with ```python3.9 -m venv /yourprojectfolder/venv ```
- Activate your virtual environment with ```source venv/bin/activate```
- Install dependencies (```pip install -r requirements.txt```)
- Supply the .env file with the credentials of your environment (if you are working on localhost set LOCALHOST = "True" in the .env)
# Running localhost
 
To run tests on localhost, you have 2 options:


## Devlify solution
Takes more time and requires to use the backend repoistory, you can find more info here how to do it go/devlify
## Using a container image 
 - Use docker if you can, install it from here on your cloudtop, or use podman that i think installed by default, https://docs.docker.com/engine/install/ubuntu/
 - Login to the docker hub. For auth run the command in the terminal (on your cloudtop) docker login -u dockersiemplify -p XXX or podman login -u dockersiemplify -p XXX
 - Make sure this directory exists: sudo mkdir /sys/fs/cgroup/systemd
 - Mount the directory: sudo mount -t cgroup -o none,name=systemd cgroup /sys/fs/cgroup/systemd
 - Use latest image docker, join the the space in chat called, 'siemplify_dev_dockers', you can paste this command in the terminal after you logged in.
docker run --name siemplify -d -p 80:80/tcp -p 443:443/tcp -p 5432:5432 -v /run -v /sys/fs/cgroup:/sys/fs/cgroup:ro siemplify/dev-clean:develop_6.1.5.360
 - Open browser, run enter localhost address, username: admin@domain.com, password: XXXXX


## If you decide to use container solution:  
In the project directory create .env file with this format.

    API_MAIN = "https://localhost"
    AUTH_LOGIN = "admin@domain.com"
    AUTH_PASSWORD = "XXXXXX"
    LOCALHOST = "True"
    SERVICE_ACCOUNT_JSON = ''
    PROJECT_ID = ""
    CUSTOMER = ""
    APPKEY = ""
    SDK_APPKEY = ""

## If you decide to use devlify solution: 
In the project directory create .env file with this format.

    API_MAIN = "https://localhost:8443"
    AUTH_LOGIN = "admin@siemplify.co"
    AUTH_PASSWORD = "XXXXXXX"
    LOCALHOST = "True"
    SERVICE_ACCOUNT_JSON = ''
    PROJECT_ID = ""
    CUSTOMER = ""
    APPKEY = ""
    SDK_APPKEY = ""

## IF YOU HAVE ISSUES INSTALLING INTEGRATIONS WHEN USING DEVLIFY SOLUTION, RUN THIS STEPS: 
 - Delete it first
 sudo /usr/local/bin/python3.7 -m pip uninstall importlib-metadata
 - Then install it
/usr/local/bin/python3.7 -m pip install importlib-metadata==4.13.0

# Running the tests
- You can run tests with a specific tag by specifying it with ```pytest --tags TAG```. 
- If you want to use multiple tags write them one after another, separated by commas without spaces like ```pytest --tags TAGONE,TAGTWO,TAGTHREE```.
- Currently available tags: CASES, PLAYBOOKS, CONNECTORS, REPORTS, SEARCH, USERS, VIEWS, DASHBOARDS, INTEGRATIONS, JOBS, SLA, TASKS

# Running tests in parallel
- You can run tests in parallel by specifying the tags and adding ```-n``` after the tags with either a number of CPU cores you would like to use to run
separate threads or "auto" to automaticallly use all available cores. 
For example: ```pytest --tags TAG -n 5``` will run tests in 5 parallel threads and ```pytest --tags TAG -n auto``` will use all of the available cores on your machine.

## Not all tests can be run in parallel!
Because all the tests are ran on the same instance some tests that require changing instance-wide settings can not be run in parallel because they can interfere with other tests. If your tests uses a function that has a suffix of _sequence_only (mostly those are functions that change the settings) please mark your test with "SEQUENCE" tag and do not run it in parallel mode.

# Writing tests
- A test is a function with name starting with "test_". For tests using only the built-in siemplify functionality please use /tests/platform_tests folder and find 
a file corresponding to a part of siemplify client you want to test (i.e. Cases, Playbooks, etc.). If it doesn't exist you can create a new file named
"test_yourmodulename".
- Each test requires a decorator specifying its tags like ```@tags(["TAGONE", "TAGTWO"])```
- If your test requires an integration to be installed in your environment use the ```@integrations_required(integrations=["Integration1", "Integration2"])``` decorator on your test. The parameters for configuring the integrations must be provided in the integration_data.json file in the /AutomationBE directory.
- Every test must have a docstring with a test name and a list of every step of the test (see example below).
- To create/fetch/delete something in your siemplify environment use siemplify.modulename.functionname methods. Like ```siemplify.cases.create_manual_case()```.
- All functions sending requests to the server return Response object by default (unless specified otherwise).
- All functions have most of the parameters set by default. If you want to customize your function call (i.e. change name of the user you want to create) please set the parameters manually!
- You can use provided utility functions to find the things you need to verify in the responses. Like ```siemplify.utils.find_key_value_in_json()```.
- All the functions making a request are automatically asserted! If a function receives any status code other than 200 in the response the test will fail!
- If you want to assert some data manually, please use the custom functions: ```strong_assert()``` if you want a test to fail immediately after this assert fails or 
```soft_assert()``` if you want the test to continue running even if the assertion failed (tests will fail at the end).
- Please see the example of a test function below.

# Example test
    @tags(["CASES", "ALL"])
    def test_ingest_case():
    """Performs an "Ingest simulated case" test.

    Steps:
    1) Simulate a case
    2) Verify that case appeared in the queue
    """
    # Simulate a case
    siemplify.cases.simulate_cases_for_test(
        cases=[enums.DefaultCases.MALWARE_DETECTED]
    )
    last_case = siemplify.cases.get_last_case_details_for_test()
    required_title = "Virus Found Or security risk found"
    strong_assert(
        compare=last_case.title,
        to=required_title,
        success_message=f"Correct case title received: {required_title}",
        failure_message=(
            f"Wrong title received. Expected: {required_title}, ",
            f"received: {last_case.title}"
        ),
    )

# Contributing to the repository
## Ground rules
- __Consistency__ over __Convenience__! Please look at the patterns used by other contributors and consider following them. Being consistent with the rest
of the repository is more important than making a shortcut! Some procedures might be tedious but keeping the flows understandable and manageable is worth it.
- __Readability__ over __Efficiency__! Your code should be easy to read and understand for the person not familiar with the whole repository! Insert comments where needed. Please don't use one-letter variables, complicated one-line comprehensions and non-intuitive variable names.
- __User-friendliness__ over __Complexity__! Having intricate functions is great, but don't forget a person using your function may not be familiar with all of its parameters so make sure to provide as many default values as possible and make parameters easy to understand and set manually.
- If you have any feedback on how to improve a certain flow or a feature request, please send it to Kirill Tomashchuk.
## Using gpylint
Please install the official [google linter](https://g3doc.corp.google.com/devtools/gpylint/g3doc/editor_integration.md?cl=head) into the IDE of your choice to make correcting syntax easier! (requires google account)
## Coding style
We do all the coding according to the [google python style guide](https://engdoc.corp.google.com/eng/doc/devguide/py/style/index.md?cl=head). (requires google account)
### Main points:
- We use 2-space indentation and a hanging 4-space indent. (See example below)
- We have an 80 character limit per line. If you have a very long string, store it in the resources/strings and import it. (see how existing strings are imported for reference)
- We use python 3.9 style type annotations. For that we import needed classes from typing. When we specify type as dictionary we have to create a TypedDict with parameters that are supposed to be in the dictionary. (see example below)
- All imports have to be single-line (except for typing) and in alphabetical order. First import lines are “import Module”, then “from Package import Module”
- All functions not intended to be used by a person writing a test should start with an underscore
- Two empty lines between functions or classes, one empty line between class methods
- Every class and function should have a docstring, see docstring format in the example below
- If your function has keyword arguments please specify them when calling the function
- We generally use [Black-style coding](https://black.readthedocs.io/en/stable/the_black_code_style/current_style.html) when it comes to wrapping lines, if your function call doesn't fit into 80 characters please wrap it in parentheses like in the example below (the exception being the decorators - there we can close the parentheses on the same line)
- If you use a function as a parameter and it doesn't fit the 80 character limit please assign it to a variable beforehand and use that instead

# Example code
You can copy this into a python file for better formatting.

    """This docstring is required at the start of every file.

    This is a followup string. First line in docstring must end with a dot and
    then a blank line before this part. All the imports below it have to
    be in alphabetical order.
    """
    # We don't use "from datetime import datetime" because google doesn't like it
    import datetime
    import json
    # Here we can use multi-line import
    from typing import Optional, TypedDict, Union
    # And here we can not
    from requests import Response
    from requests import Session
    # Our custom function - no relative imports
    from whatever_module.api_endpoints import SOME_API_ENDPOINT


    # Typed dicts for type hints
    class InputData(TypedDict):
      # <--- 2 space indentation here
      id: str
      first_name: str
      second_name: str
      age: int

    SESSION = Session()


    def inject_user_data(
        # <--- 4 space indentation
        name: str,
        json_data: InputData,
        timestamp: str,
        additional_params: Optional[Union[list[str], tuple[str]]] = None,
    ) -> Response:
      """Injects new data into the database.

      This is a full explanation of the functionality if it is not self-explanatory

      Args:
        name: name of something we need to save
        json_data: data to send to server
        timestamp: date and time in "d/m/y h:m:s" format
        additional_params: additional parameters for whatever this is in a form of
          a list of strings or tuple of strings

      Returns:
        A Response object from the server
      """
      # <--- 2 space indentation here
      converted_time = datetime.datetime.strptime(timestamp, "%d/%m/%y %H:%M:%S")
      constructed_dict = {
          # <--- but extra 4 space indentation here
          "name": name,
          "data": json_data,
          "timestamp": converted_time,
          "some_list": additional_params,  # Trailing comma in multi-line sequences
      }
      payload = json.dumps(constructed_dict)
      response = SESSION.post(
          # <--- and again 4 spaces here
          url=SOME_API_ENDPOINT,
          data=payload,  # Again, trailing comma here
      )

      return response
    # <--- add a blank line here after the function
